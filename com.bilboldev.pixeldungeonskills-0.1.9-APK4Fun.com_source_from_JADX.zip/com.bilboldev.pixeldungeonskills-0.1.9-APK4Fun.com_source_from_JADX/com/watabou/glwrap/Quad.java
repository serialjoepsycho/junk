package com.watabou.glwrap;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class Quad {
    public static final int SIZE;
    public static final short[] VALUES;
    private static int indexSize;
    private static ShortBuffer indices;

    static {
        VALUES = new short[]{(short) 0, (short) 1, (short) 2, (short) 0, (short) 2, (short) 3};
        SIZE = VALUES.length;
        indexSize = 0;
    }

    public static FloatBuffer create() {
        return ByteBuffer.allocateDirect(64).order(ByteOrder.nativeOrder()).asFloatBuffer();
    }

    public static FloatBuffer createSet(int size) {
        return ByteBuffer.allocateDirect(((size * 16) * 32) / 8).order(ByteOrder.nativeOrder()).asFloatBuffer();
    }

    public static ShortBuffer getIndices(int size) {
        if (size > indexSize) {
            indexSize = size;
            indices = ByteBuffer.allocateDirect(((SIZE * size) * 16) / 8).order(ByteOrder.nativeOrder()).asShortBuffer();
            short[] values = new short[(size * 6)];
            int limit = size * 4;
            int pos = 0;
            for (int ofs = 0; ofs < limit; ofs += 4) {
                int i = pos + 1;
                values[pos] = (short) (ofs + 0);
                pos = i + 1;
                values[i] = (short) (ofs + 1);
                i = pos + 1;
                values[pos] = (short) (ofs + 2);
                pos = i + 1;
                values[i] = (short) (ofs + 0);
                i = pos + 1;
                values[pos] = (short) (ofs + 2);
                pos = i + 1;
                values[i] = (short) (ofs + 3);
            }
            indices.put(values);
            indices.position(0);
        }
        return indices;
    }

    public static void fill(float[] v, float x1, float x2, float y1, float y2, float u1, float u2, float v1, float v2) {
        v[0] = x1;
        v[1] = y1;
        v[2] = u1;
        v[3] = v1;
        v[4] = x2;
        v[5] = y1;
        v[6] = u2;
        v[7] = v1;
        v[8] = x2;
        v[9] = y2;
        v[10] = u2;
        v[11] = v2;
        v[12] = x1;
        v[13] = y2;
        v[14] = u1;
        v[15] = v2;
    }

    public static void fillXY(float[] v, float x1, float x2, float y1, float y2) {
        v[0] = x1;
        v[1] = y1;
        v[4] = x2;
        v[5] = y1;
        v[8] = x2;
        v[9] = y2;
        v[12] = x1;
        v[13] = y2;
    }

    public static void fillUV(float[] v, float u1, float u2, float v1, float v2) {
        v[2] = u1;
        v[3] = v1;
        v[6] = u2;
        v[7] = v1;
        v[10] = u2;
        v[11] = v2;
        v[14] = u1;
        v[15] = v2;
    }
}
