package com.watabou.glwrap;

import android.opengl.GLES20;
import java.nio.FloatBuffer;

public class Attribute {
    private int location;

    public Attribute(int location) {
        this.location = location;
    }

    public int location() {
        return this.location;
    }

    public void enable() {
        GLES20.glEnableVertexAttribArray(this.location);
    }

    public void disable() {
        GLES20.glDisableVertexAttribArray(this.location);
    }

    public void vertexPointer(int size, int stride, FloatBuffer ptr) {
        GLES20.glVertexAttribPointer(this.location, size, 5126, false, (stride * 32) / 8, ptr);
    }
}
