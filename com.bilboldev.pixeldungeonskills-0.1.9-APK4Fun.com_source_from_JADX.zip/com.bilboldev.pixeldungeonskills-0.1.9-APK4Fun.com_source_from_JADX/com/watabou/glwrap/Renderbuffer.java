package com.watabou.glwrap;

import android.opengl.GLES20;

public class Renderbuffer {
    public static final int DEPTH16 = 33189;
    public static final int RGBA8 = 6408;
    public static final int STENCIL8 = 36168;
    private int id;

    public Renderbuffer() {
        int[] buffers = new int[1];
        GLES20.glGenRenderbuffers(1, buffers, 0);
        this.id = buffers[0];
    }

    public int id() {
        return this.id;
    }

    public void bind() {
        GLES20.glBindRenderbuffer(36161, this.id);
    }

    public void delete() {
        GLES20.glDeleteRenderbuffers(1, new int[]{this.id}, 0);
    }

    public void storage(int format, int width, int height) {
        GLES20.glRenderbufferStorage(36161, format, width, height);
    }
}
