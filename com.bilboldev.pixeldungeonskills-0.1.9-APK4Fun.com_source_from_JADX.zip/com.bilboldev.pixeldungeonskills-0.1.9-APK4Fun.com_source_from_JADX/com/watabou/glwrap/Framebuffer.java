package com.watabou.glwrap;

import android.opengl.GLES20;

public class Framebuffer {
    public static final int COLOR = 36064;
    public static final int DEPTH = 36096;
    public static final int STENCIL = 36128;
    public static final Framebuffer system;
    private int id;

    static {
        system = new Framebuffer(0);
    }

    public Framebuffer() {
        int[] buffers = new int[1];
        GLES20.glGenBuffers(1, buffers, 0);
        this.id = buffers[0];
    }

    private Framebuffer(int n) {
    }

    public void bind() {
        GLES20.glBindFramebuffer(36160, this.id);
    }

    public void delete() {
        GLES20.glDeleteFramebuffers(1, new int[]{this.id}, 0);
    }

    public void attach(int point, Texture tex) {
        bind();
        GLES20.glFramebufferTexture2D(36160, point, 3553, tex.id, 0);
    }

    public void attach(int point, Renderbuffer buffer) {
        bind();
        GLES20.glFramebufferRenderbuffer(36161, point, 3553, buffer.id());
    }

    public boolean status() {
        bind();
        return GLES20.glCheckFramebufferStatus(36160) == 36053;
    }
}
