package com.watabou.glwrap;

import android.opengl.GLES20;

public class Shader {
    public static final int FRAGMENT = 35632;
    public static final int VERTEX = 35633;
    private int handle;

    public Shader(int type) {
        this.handle = GLES20.glCreateShader(type);
    }

    public int handle() {
        return this.handle;
    }

    public void source(String src) {
        GLES20.glShaderSource(this.handle, src);
    }

    public void compile() {
        GLES20.glCompileShader(this.handle);
        int[] status = new int[1];
        GLES20.glGetShaderiv(this.handle, 35713, status, 0);
        if (status[0] == 0) {
            throw new Error(GLES20.glGetShaderInfoLog(this.handle));
        }
    }

    public void delete() {
        GLES20.glDeleteShader(this.handle);
    }

    public static Shader createCompiled(int type, String src) {
        Shader shader = new Shader(type);
        shader.source(src);
        shader.compile();
        return shader;
    }
}
