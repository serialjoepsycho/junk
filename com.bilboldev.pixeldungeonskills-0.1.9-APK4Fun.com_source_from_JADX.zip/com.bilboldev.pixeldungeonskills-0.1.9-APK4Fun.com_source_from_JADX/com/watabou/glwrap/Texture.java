package com.watabou.glwrap;

import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;

public class Texture {
    public static final int CLAMP = 33071;
    public static final int LINEAR = 9729;
    public static final int MIRROR = 33648;
    public static final int NEAREST = 9728;
    public static final int REPEAT = 10497;
    public int id;
    public boolean premultiplied;

    public Texture() {
        this.premultiplied = false;
        int[] ids = new int[1];
        GLES20.glGenTextures(1, ids, 0);
        this.id = ids[0];
        bind();
    }

    public static void activate(int index) {
        GLES20.glActiveTexture(33984 + index);
    }

    public void bind() {
        GLES20.glBindTexture(3553, this.id);
    }

    public void filter(int minMode, int maxMode) {
        bind();
        GLES20.glTexParameterf(3553, 10241, (float) minMode);
        GLES20.glTexParameterf(3553, 10240, (float) maxMode);
    }

    public void wrap(int s, int t) {
        bind();
        GLES20.glTexParameterf(3553, 10242, (float) s);
        GLES20.glTexParameterf(3553, 10243, (float) t);
    }

    public void delete() {
        GLES20.glDeleteTextures(1, new int[]{this.id}, 0);
    }

    public void bitmap(Bitmap bitmap) {
        bind();
        GLUtils.texImage2D(3553, 0, bitmap, 0);
        this.premultiplied = true;
    }

    public void pixels(int w, int h, int[] pixels) {
        bind();
        IntBuffer imageBuffer = ByteBuffer.allocateDirect((w * h) * 4).order(ByteOrder.nativeOrder()).asIntBuffer();
        imageBuffer.put(pixels);
        imageBuffer.position(0);
        GLES20.glTexImage2D(3553, 0, Renderbuffer.RGBA8, w, h, 0, Renderbuffer.RGBA8, 5121, imageBuffer);
    }

    public void pixels(int w, int h, byte[] pixels) {
        bind();
        ByteBuffer imageBuffer = ByteBuffer.allocateDirect(w * h).order(ByteOrder.nativeOrder());
        imageBuffer.put(pixels);
        imageBuffer.position(0);
        GLES20.glPixelStorei(3317, 1);
        GLES20.glTexImage2D(3553, 0, 6406, w, h, 0, 6406, 5121, imageBuffer);
    }

    public void handMade(Bitmap bitmap, boolean recode) {
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        int[] pixels = new int[(w * h)];
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h);
        if (recode) {
            for (int i = 0; i < pixels.length; i++) {
                int color = pixels[i];
                pixels[i] = (((color & 255) << 16) | (color & -16711936)) | ((color >> 16) & 255);
            }
        }
        pixels(w, h, pixels);
        this.premultiplied = false;
    }

    public static Texture create(Bitmap bmp) {
        Texture tex = new Texture();
        tex.bitmap(bmp);
        return tex;
    }

    public static Texture create(int width, int height, int[] pixels) {
        Texture tex = new Texture();
        tex.pixels(width, height, pixels);
        return tex;
    }

    public static Texture create(int width, int height, byte[] pixels) {
        Texture tex = new Texture();
        tex.pixels(width, height, pixels);
        return tex;
    }
}
