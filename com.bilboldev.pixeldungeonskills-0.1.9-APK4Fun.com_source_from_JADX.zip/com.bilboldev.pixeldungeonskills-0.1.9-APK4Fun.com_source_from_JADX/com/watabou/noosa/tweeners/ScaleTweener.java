package com.watabou.noosa.tweeners;

import com.watabou.noosa.Visual;
import com.watabou.utils.PointF;

public class ScaleTweener extends Tweener {
    public PointF end;
    public PointF start;
    public Visual visual;

    public ScaleTweener(Visual visual, PointF scale, float time) {
        super(visual, time);
        this.visual = visual;
        this.start = visual.scale;
        this.end = scale;
    }

    protected void updateValues(float progress) {
        this.visual.scale = PointF.inter(this.start, this.end, progress);
    }
}
