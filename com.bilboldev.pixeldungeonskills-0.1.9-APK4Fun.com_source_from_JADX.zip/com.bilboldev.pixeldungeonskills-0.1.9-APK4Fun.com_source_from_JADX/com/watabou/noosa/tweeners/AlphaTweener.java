package com.watabou.noosa.tweeners;

import com.watabou.noosa.Visual;

public class AlphaTweener extends Tweener {
    public float delta;
    public Visual image;
    public float start;

    public AlphaTweener(Visual image, float alpha, float time) {
        super(image, time);
        this.image = image;
        this.start = image.alpha();
        this.delta = alpha - this.start;
    }

    protected void updateValues(float progress) {
        this.image.alpha(this.start + (this.delta * progress));
    }
}
