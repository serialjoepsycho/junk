package com.watabou.noosa.tweeners;

public class Delayer extends Tweener {
    public Delayer() {
        super(null, 0.0f);
    }

    public Delayer(float time) {
        super(null, time);
    }

    protected void updateValues(float progress) {
    }
}
