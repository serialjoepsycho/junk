package com.watabou.noosa.tweeners;

import com.watabou.noosa.Game;
import com.watabou.noosa.Gizmo;
import com.watabou.pixeldungeon.items.keys.Key;

public abstract class Tweener extends Gizmo {
    public float elapsed;
    public float interval;
    public Listener listener;
    public Gizmo target;

    public interface Listener {
        void onComplete(Tweener tweener);
    }

    protected abstract void updateValues(float f);

    public Tweener(Gizmo target, float interval) {
        this.target = target;
        this.interval = interval;
        this.elapsed = 0.0f;
    }

    public void update() {
        this.elapsed += Game.elapsed;
        if (this.elapsed >= this.interval) {
            updateValues(Key.TIME_TO_UNLOCK);
            onComplete();
            kill();
            return;
        }
        updateValues(this.elapsed / this.interval);
    }

    protected void onComplete() {
        if (this.listener != null) {
            this.listener.onComplete(this);
        }
    }
}
