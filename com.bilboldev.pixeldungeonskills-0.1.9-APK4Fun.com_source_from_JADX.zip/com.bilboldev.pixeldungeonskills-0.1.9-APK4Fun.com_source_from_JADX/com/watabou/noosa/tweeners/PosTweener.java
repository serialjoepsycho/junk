package com.watabou.noosa.tweeners;

import com.watabou.noosa.Visual;
import com.watabou.utils.PointF;

public class PosTweener extends Tweener {
    public PointF end;
    public PointF start;
    public Visual visual;

    public PosTweener(Visual visual, PointF pos, float time) {
        super(visual, time);
        this.visual = visual;
        this.start = visual.point();
        this.end = pos;
    }

    protected void updateValues(float progress) {
        this.visual.point(PointF.inter(this.start, this.end, progress));
    }
}
