package com.watabou.noosa.particles;

import android.opengl.GLES20;
import com.watabou.noosa.Game;
import com.watabou.noosa.Group;
import com.watabou.noosa.Visual;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;

public class Emitter extends Group {
    public boolean autoKill;
    protected int count;
    protected Factory factory;
    public float height;
    protected float interval;
    protected boolean lightMode;
    public boolean on;
    protected int quantity;
    protected Visual target;
    protected float time;
    public float width;
    public float f8x;
    public float f9y;

    public static abstract class Factory {
        public abstract void emit(Emitter emitter, int i, float f, float f2);

        public boolean lightMode() {
            return false;
        }
    }

    public Emitter() {
        this.lightMode = false;
        this.on = false;
        this.autoKill = true;
    }

    public void pos(float x, float y) {
        pos(x, y, 0.0f, 0.0f);
    }

    public void pos(PointF p) {
        pos(p.f24x, p.f25y, 0.0f, 0.0f);
    }

    public void pos(float x, float y, float width, float height) {
        this.f8x = x;
        this.f9y = y;
        this.width = width;
        this.height = height;
        this.target = null;
    }

    public void pos(Visual target) {
        this.target = target;
    }

    public void burst(Factory factory, int quantity) {
        start(factory, 0.0f, quantity);
    }

    public void pour(Factory factory, float interval) {
        start(factory, interval, 0);
    }

    public void start(Factory factory, float interval, int quantity) {
        this.factory = factory;
        this.lightMode = factory.lightMode();
        this.interval = interval;
        this.quantity = quantity;
        this.count = 0;
        this.time = Random.Float(interval);
        this.on = true;
    }

    public void update() {
        if (this.on) {
            this.time += Game.elapsed;
            while (this.time > this.interval) {
                this.time -= this.interval;
                emit(this.count);
                if (this.quantity > 0) {
                    int i = this.count + 1;
                    this.count = i;
                    if (i >= this.quantity) {
                        this.on = false;
                        break;
                    }
                }
            }
        } else if (this.autoKill && countLiving() == 0) {
            kill();
        }
        super.update();
    }

    protected void emit(int index) {
        if (this.target == null) {
            this.factory.emit(this, index, this.f8x + Random.Float(this.width), this.f9y + Random.Float(this.height));
        } else {
            this.factory.emit(this, index, this.target.f2x + Random.Float(this.target.width), this.target.f3y + Random.Float(this.target.height));
        }
    }

    public void draw() {
        if (this.lightMode) {
            GLES20.glBlendFunc(770, 1);
            super.draw();
            GLES20.glBlendFunc(770, 771);
            return;
        }
        super.draw();
    }
}
