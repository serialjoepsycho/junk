package com.watabou.noosa.particles;

import com.watabou.noosa.Game;
import com.watabou.noosa.PseudoPixel;

public class PixelParticle extends PseudoPixel {
    protected float left;
    protected float lifespan;
    protected float size;

    public static class Shrinking extends PixelParticle {
        public void update() {
            super.update();
            size((this.size * this.left) / this.lifespan);
        }
    }

    public PixelParticle() {
        this.origin.set(0.5f);
    }

    public void reset(float x, float y, int color, float size, float lifespan) {
        revive();
        this.x = x;
        this.y = y;
        color(color);
        this.size = size;
        size(size);
        this.lifespan = lifespan;
        this.left = lifespan;
    }

    public void update() {
        super.update();
        float f = this.left - Game.elapsed;
        this.left = f;
        if (f <= 0.0f) {
            kill();
        }
    }
}
