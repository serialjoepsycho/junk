package com.watabou.noosa;

import java.util.ArrayList;

public class Group extends Gizmo {
    public int length;
    protected ArrayList<Gizmo> members;

    public Group() {
        this.members = new ArrayList();
        this.length = 0;
    }

    public void destroy() {
        for (int i = 0; i < this.length; i++) {
            Gizmo g = (Gizmo) this.members.get(i);
            if (g != null) {
                g.destroy();
            }
        }
        this.members.clear();
        this.members = null;
        this.length = 0;
    }

    public void update() {
        for (int i = 0; i < this.length; i++) {
            Gizmo g = (Gizmo) this.members.get(i);
            if (g != null && g.exists && g.active) {
                g.update();
            }
        }
    }

    public void draw() {
        for (int i = 0; i < this.length; i++) {
            Gizmo g = (Gizmo) this.members.get(i);
            if (g != null && g.exists && g.visible) {
                g.draw();
            }
        }
    }

    public void kill() {
        for (int i = 0; i < this.length; i++) {
            Gizmo g = (Gizmo) this.members.get(i);
            if (g != null && g.exists) {
                g.kill();
            }
        }
        super.kill();
    }

    public int indexOf(Gizmo g) {
        return this.members.indexOf(g);
    }

    public Gizmo add(Gizmo g) {
        if (g.parent != this) {
            if (g.parent != null) {
                g.parent.remove(g);
            }
            for (int i = 0; i < this.length; i++) {
                if (this.members.get(i) == null) {
                    this.members.set(i, g);
                    g.parent = this;
                    break;
                }
            }
            this.members.add(g);
            g.parent = this;
            this.length++;
        }
        return g;
    }

    public Gizmo addToBack(Gizmo g) {
        if (g.parent == this) {
            sendToBack(g);
        } else {
            if (g.parent != null) {
                g.parent.remove(g);
            }
            if (this.members.get(0) == null) {
                this.members.set(0, g);
                g.parent = this;
            } else {
                this.members.add(0, g);
                g.parent = this;
                this.length++;
            }
        }
        return g;
    }

    public Gizmo recycle(Class<? extends Gizmo> c) {
        Gizmo g = getFirstAvailable(c);
        if (g != null) {
            return g;
        }
        if (c == null) {
            return null;
        }
        try {
            return add((Gizmo) c.newInstance());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public Gizmo erase(Gizmo g) {
        int index = this.members.indexOf(g);
        if (index == -1) {
            return null;
        }
        this.members.set(index, null);
        g.parent = null;
        return g;
    }

    public Gizmo remove(Gizmo g) {
        if (!this.members.remove(g)) {
            return null;
        }
        this.length--;
        g.parent = null;
        return g;
    }

    public Gizmo replace(Gizmo oldOne, Gizmo newOne) {
        int index = this.members.indexOf(oldOne);
        if (index == -1) {
            return null;
        }
        this.members.set(index, newOne);
        newOne.parent = this;
        oldOne.parent = null;
        return newOne;
    }

    public Gizmo getFirstAvailable(Class<? extends Gizmo> c) {
        for (int i = 0; i < this.length; i++) {
            Gizmo g = (Gizmo) this.members.get(i);
            if (g != null && !g.exists && (c == null || g.getClass() == c)) {
                return g;
            }
        }
        return null;
    }

    public int countLiving() {
        int count = 0;
        for (int i = 0; i < this.length; i++) {
            Gizmo g = (Gizmo) this.members.get(i);
            if (g != null && g.exists && g.alive) {
                count++;
            }
        }
        return count;
    }

    public int countDead() {
        int count = 0;
        for (int i = 0; i < this.length; i++) {
            Gizmo g = (Gizmo) this.members.get(i);
            if (!(g == null || g.alive)) {
                count++;
            }
        }
        return count;
    }

    public Gizmo random() {
        if (this.length > 0) {
            return (Gizmo) this.members.get((int) (Math.random() * ((double) this.length)));
        }
        return null;
    }

    public void clear() {
        for (int i = 0; i < this.length; i++) {
            Gizmo g = (Gizmo) this.members.get(i);
            if (g != null) {
                g.parent = null;
            }
        }
        this.members.clear();
        this.length = 0;
    }

    public Gizmo bringToFront(Gizmo g) {
        if (!this.members.contains(g)) {
            return null;
        }
        this.members.remove(g);
        this.members.add(g);
        return g;
    }

    public Gizmo sendToBack(Gizmo g) {
        if (!this.members.contains(g)) {
            return null;
        }
        this.members.remove(g);
        this.members.add(0, g);
        return g;
    }
}
