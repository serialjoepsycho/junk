package com.watabou.noosa;

import com.watabou.glwrap.Matrix;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.utils.GameMath;
import com.watabou.utils.Point;
import com.watabou.utils.PointF;

public class Visual extends Gizmo {
    public float aa;
    public PointF acc;
    public float am;
    public float angle;
    public float angularSpeed;
    public float ba;
    public float bm;
    public float ga;
    public float gm;
    public float height;
    protected float[] matrix;
    public PointF origin;
    public float ra;
    public float rm;
    public PointF scale;
    public PointF speed;
    public float width;
    public float f2x;
    public float f3y;

    public Visual(float x, float y, float width, float height) {
        this.f2x = x;
        this.f3y = y;
        this.width = width;
        this.height = height;
        this.scale = new PointF(Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK);
        this.origin = new PointF();
        this.matrix = new float[16];
        resetColor();
        this.speed = new PointF();
        this.acc = new PointF();
    }

    public void update() {
        updateMotion();
    }

    public void draw() {
        updateMatrix();
    }

    protected void updateMatrix() {
        Matrix.setIdentity(this.matrix);
        Matrix.translate(this.matrix, this.f2x, this.f3y);
        Matrix.translate(this.matrix, this.origin.f24x, this.origin.f25y);
        if (this.angle != 0.0f) {
            Matrix.rotate(this.matrix, this.angle);
        }
        if (!(this.scale.f24x == Key.TIME_TO_UNLOCK && this.scale.f25y == Key.TIME_TO_UNLOCK)) {
            Matrix.scale(this.matrix, this.scale.f24x, this.scale.f25y);
        }
        Matrix.translate(this.matrix, -this.origin.f24x, -this.origin.f25y);
    }

    public PointF point() {
        return new PointF(this.f2x, this.f3y);
    }

    public PointF point(PointF p) {
        this.f2x = p.f24x;
        this.f3y = p.f25y;
        return p;
    }

    public Point point(Point p) {
        this.f2x = (float) p.f18x;
        this.f3y = (float) p.f19y;
        return p;
    }

    public PointF center() {
        return new PointF(this.f2x + (this.width / Pickaxe.TIME_TO_MINE), this.f3y + (this.height / Pickaxe.TIME_TO_MINE));
    }

    public PointF center(PointF p) {
        this.f2x = p.f24x - (this.width / Pickaxe.TIME_TO_MINE);
        this.f3y = p.f25y - (this.height / Pickaxe.TIME_TO_MINE);
        return p;
    }

    public float width() {
        return this.width * this.scale.f24x;
    }

    public float height() {
        return this.height * this.scale.f25y;
    }

    protected void updateMotion() {
        float elapsed = Game.elapsed;
        float d = (GameMath.speed(this.speed.f24x, this.acc.f24x) - this.speed.f24x) / Pickaxe.TIME_TO_MINE;
        PointF pointF = this.speed;
        pointF.f24x += d;
        this.f2x += this.speed.f24x * elapsed;
        pointF = this.speed;
        pointF.f24x += d;
        d = (GameMath.speed(this.speed.f25y, this.acc.f25y) - this.speed.f25y) / Pickaxe.TIME_TO_MINE;
        pointF = this.speed;
        pointF.f25y += d;
        this.f3y += this.speed.f25y * elapsed;
        pointF = this.speed;
        pointF.f25y += d;
        this.angle += this.angularSpeed * elapsed;
    }

    public void alpha(float value) {
        this.am = value;
        this.aa = 0.0f;
    }

    public float alpha() {
        return this.am + this.aa;
    }

    public void invert() {
        this.bm = -1.0f;
        this.gm = -1.0f;
        this.rm = -1.0f;
        this.ba = Key.TIME_TO_UNLOCK;
        this.ga = Key.TIME_TO_UNLOCK;
        this.ra = Key.TIME_TO_UNLOCK;
    }

    public void lightness(float value) {
        if (value < 0.5f) {
            float f = value * Pickaxe.TIME_TO_MINE;
            this.bm = f;
            this.gm = f;
            this.rm = f;
            this.ba = 0.0f;
            this.ga = 0.0f;
            this.ra = 0.0f;
            return;
        }
        f = Pickaxe.TIME_TO_MINE - (value * Pickaxe.TIME_TO_MINE);
        this.bm = f;
        this.gm = f;
        this.rm = f;
        f = (value * Pickaxe.TIME_TO_MINE) - Key.TIME_TO_UNLOCK;
        this.ba = f;
        this.ga = f;
        this.ra = f;
    }

    public void brightness(float value) {
        this.bm = value;
        this.gm = value;
        this.rm = value;
    }

    public void tint(float r, float g, float b, float strength) {
        float f = Key.TIME_TO_UNLOCK - strength;
        this.bm = f;
        this.gm = f;
        this.rm = f;
        this.ra = r * strength;
        this.ga = g * strength;
        this.ba = b * strength;
    }

    public void tint(int color, float strength) {
        float f = Key.TIME_TO_UNLOCK - strength;
        this.bm = f;
        this.gm = f;
        this.rm = f;
        this.ra = (((float) ((color >> 16) & 255)) / 255.0f) * strength;
        this.ga = (((float) ((color >> 8) & 255)) / 255.0f) * strength;
        this.ba = (((float) (color & 255)) / 255.0f) * strength;
    }

    public void color(float r, float g, float b) {
        this.bm = 0.0f;
        this.gm = 0.0f;
        this.rm = 0.0f;
        this.ra = r;
        this.ga = g;
        this.ba = b;
    }

    public void color(int color) {
        color(((float) ((color >> 16) & 255)) / 255.0f, ((float) ((color >> 8) & 255)) / 255.0f, ((float) (color & 255)) / 255.0f);
    }

    public void hardlight(float r, float g, float b) {
        this.ba = 0.0f;
        this.ga = 0.0f;
        this.ra = 0.0f;
        this.rm = r;
        this.gm = g;
        this.bm = b;
    }

    public void hardlight(int color) {
        hardlight(((float) (color >> 16)) / 255.0f, ((float) ((color >> 8) & 255)) / 255.0f, ((float) (color & 255)) / 255.0f);
    }

    public void resetColor() {
        this.am = Key.TIME_TO_UNLOCK;
        this.bm = Key.TIME_TO_UNLOCK;
        this.gm = Key.TIME_TO_UNLOCK;
        this.rm = Key.TIME_TO_UNLOCK;
        this.aa = 0.0f;
        this.ba = 0.0f;
        this.ga = 0.0f;
        this.ra = 0.0f;
    }

    public boolean overlapsPoint(float x, float y) {
        return x >= this.f2x && x < this.f2x + (this.width * this.scale.f24x) && y >= this.f3y && y < this.f3y + (this.height * this.scale.f25y);
    }

    public boolean overlapsScreenPoint(int x, int y) {
        Camera c = camera();
        if (c == null) {
            return false;
        }
        PointF p = c.screenToCamera(x, y);
        return overlapsPoint(p.f24x, p.f25y);
    }

    public boolean isVisible() {
        Camera c = camera();
        float cx = c.scroll.f24x;
        float cy = c.scroll.f25y;
        return this.f2x + width() >= cx && this.f3y + height() >= cy && this.f2x < ((float) c.width) + cx && this.f3y < ((float) c.height) + cy;
    }
}
