package com.watabou.noosa;

import android.graphics.Bitmap;
import android.graphics.RectF;
import com.watabou.gltextures.SmartTexture;
import com.watabou.gltextures.TextureCache;
import com.watabou.glwrap.Matrix;
import com.watabou.glwrap.Quad;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.items.keys.Key;
import java.nio.FloatBuffer;

public class BitmapText extends Visual {
    protected boolean dirty;
    protected Font font;
    protected FloatBuffer quads;
    public int realLength;
    protected String text;
    protected float[] vertices;

    public static class Font extends TextureFilm {
        public static final String LATIN_FULL = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u007f";
        public static final String LATIN_UPPER = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        public boolean autoUppercase;
        public float baseLine;
        public float lineHeight;
        public SmartTexture texture;
        public float tracking;

        protected Font(SmartTexture tx) {
            super(tx);
            this.tracking = 0.0f;
            this.autoUppercase = false;
            this.texture = tx;
        }

        public Font(SmartTexture tx, int width, String chars) {
            this(tx, width, tx.height, chars);
        }

        public Font(SmartTexture tx, int width, int height, String chars) {
            super(tx);
            this.tracking = 0.0f;
            this.autoUppercase = false;
            this.texture = tx;
            this.autoUppercase = chars.equals(LATIN_UPPER);
            int length = chars.length();
            float uw = ((float) width) / ((float) tx.width);
            float vh = ((float) height) / ((float) tx.height);
            float top = 0.0f;
            float bottom = vh;
            int i = 0;
            float left = 0.0f;
            while (i < length) {
                float left2 = left + uw;
                add(Character.valueOf(chars.charAt(i)), new RectF(left, top, left2, bottom));
                if (left2 >= Key.TIME_TO_UNLOCK) {
                    left2 = 0.0f;
                    top = bottom;
                    bottom += vh;
                }
                i++;
                left = left2;
            }
            float f = (float) height;
            this.baseLine = f;
            this.lineHeight = f;
        }

        protected void splitBy(Bitmap bitmap, int height, int color, String chars) {
            int j;
            this.autoUppercase = chars.equals(LATIN_UPPER);
            int length = chars.length();
            int width = bitmap.getWidth();
            float vHeight = ((float) height) / ((float) bitmap.getHeight());
            int pos = 0;
            loop0:
            while (pos < width) {
                for (j = 0; j < height; j++) {
                    if (bitmap.getPixel(pos, j) != color) {
                        break loop0;
                    }
                }
                pos++;
            }
            add(Character.valueOf(' '), new RectF(0.0f, 0.0f, ((float) pos) / ((float) width), vHeight));
            for (int i = 0; i < length; i++) {
                char ch = chars.charAt(i);
                if (ch != ' ') {
                    int separator = pos;
                    boolean found;
                    do {
                        separator++;
                        if (separator >= width) {
                            break;
                        }
                        found = true;
                        j = 0;
                        while (j < height) {
                            if (bitmap.getPixel(separator, j) != color) {
                                found = false;
                                break;
                                continue;
                            } else {
                                j++;
                            }
                        }
                    } while (!found);
                    add(Character.valueOf(ch), new RectF(((float) pos) / ((float) width), 0.0f, ((float) separator) / ((float) width), vHeight));
                    pos = separator + 1;
                }
            }
            float height2 = height((RectF) this.frames.get(Character.valueOf(chars.charAt(0))));
            this.baseLine = height2;
            this.lineHeight = height2;
        }

        public static Font colorMarked(Bitmap bmp, int color, String chars) {
            Font font = new Font(TextureCache.get(bmp));
            font.splitBy(bmp, bmp.getHeight(), color, chars);
            return font;
        }

        public static Font colorMarked(Bitmap bmp, int height, int color, String chars) {
            Font font = new Font(TextureCache.get(bmp));
            font.splitBy(bmp, height, color, chars);
            return font;
        }

        public RectF get(char ch) {
            if (this.autoUppercase) {
                ch = Character.toUpperCase(ch);
            }
            return super.get(Character.valueOf(ch));
        }
    }

    public BitmapText() {
        this(BuildConfig.VERSION_NAME, null);
    }

    public BitmapText(Font font) {
        this(BuildConfig.VERSION_NAME, font);
    }

    public BitmapText(String text, Font font) {
        super(0.0f, 0.0f, 0.0f, 0.0f);
        this.vertices = new float[16];
        this.dirty = true;
        this.text = text;
        this.font = font;
    }

    public void destroy() {
        this.text = null;
        this.font = null;
        this.vertices = null;
        this.quads = null;
        super.destroy();
    }

    protected void updateMatrix() {
        Matrix.setIdentity(this.matrix);
        Matrix.translate(this.matrix, this.x, this.y);
        Matrix.scale(this.matrix, this.scale.f24x, this.scale.f25y);
        Matrix.rotate(this.matrix, this.angle);
    }

    public void draw() {
        super.draw();
        NoosaScript script = NoosaScript.get();
        this.font.texture.bind();
        if (this.dirty) {
            updateVertices();
        }
        script.camera(camera());
        script.uModel.valueM4(this.matrix);
        script.lighting(this.rm, this.gm, this.bm, this.am, this.ra, this.ga, this.ba, this.aa);
        script.drawQuadSet(this.quads, this.realLength);
    }

    protected void updateVertices() {
        this.width = 0.0f;
        this.height = 0.0f;
        if (this.text == null) {
            this.text = BuildConfig.VERSION_NAME;
        }
        this.quads = Quad.createSet(this.text.length());
        this.realLength = 0;
        int length = this.text.length();
        for (int i = 0; i < length; i++) {
            RectF rect = this.font.get(this.text.charAt(i));
            if (rect == null) {
                rect = null;
            }
            float w = this.font.width(rect);
            float h = this.font.height(rect);
            this.vertices[0] = this.width;
            this.vertices[1] = 0.0f;
            this.vertices[2] = rect.left;
            this.vertices[3] = rect.top;
            this.vertices[4] = this.width + w;
            this.vertices[5] = 0.0f;
            this.vertices[6] = rect.right;
            this.vertices[7] = rect.top;
            this.vertices[8] = this.width + w;
            this.vertices[9] = h;
            this.vertices[10] = rect.right;
            this.vertices[11] = rect.bottom;
            this.vertices[12] = this.width;
            this.vertices[13] = h;
            this.vertices[14] = rect.left;
            this.vertices[15] = rect.bottom;
            this.quads.put(this.vertices);
            this.realLength++;
            this.width += this.font.tracking + w;
            if (h > this.height) {
                this.height = h;
            }
        }
        if (length > 0) {
            this.width -= this.font.tracking;
        }
        this.dirty = false;
    }

    public void measure() {
        this.width = 0.0f;
        this.height = 0.0f;
        if (this.text == null) {
            this.text = BuildConfig.VERSION_NAME;
        }
        int length = this.text.length();
        for (int i = 0; i < length; i++) {
            RectF rect = this.font.get(this.text.charAt(i));
            float w = this.font.width(rect);
            float h = this.font.height(rect);
            this.width += this.font.tracking + w;
            if (h > this.height) {
                this.height = h;
            }
        }
        if (length > 0) {
            this.width -= this.font.tracking;
        }
    }

    public float baseLine() {
        return this.font.baseLine * this.scale.f25y;
    }

    public Font font() {
        return this.font;
    }

    public void font(Font value) {
        this.font = value;
    }

    public String text() {
        return this.text;
    }

    public void text(String str) {
        this.text = str;
        this.dirty = true;
    }
}
