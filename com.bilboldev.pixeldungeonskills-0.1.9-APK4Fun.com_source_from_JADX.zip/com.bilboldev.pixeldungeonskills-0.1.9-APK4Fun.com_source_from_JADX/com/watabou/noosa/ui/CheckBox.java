package com.watabou.noosa.ui;

public class CheckBox extends Button {
    protected boolean checked;

    public boolean checked() {
        return this.checked;
    }

    public void checked(boolean value) {
        if (this.checked != value) {
            this.checked = value;
            updateState();
        }
    }

    protected void updateState() {
    }

    protected void onClick() {
        checked(!this.checked);
        onChange();
    }

    protected void onChange() {
    }
}
