package com.watabou.noosa.ui;

import com.watabou.input.Touchscreen.Touch;
import com.watabou.noosa.Game;
import com.watabou.noosa.TouchArea;
import com.watabou.pixeldungeon.items.keys.Key;

public class Button extends Component {
    public static float longClick;
    protected TouchArea hotArea;
    protected float pressTime;
    protected boolean pressed;
    protected boolean processed;

    /* renamed from: com.watabou.noosa.ui.Button.1 */
    class C00101 extends TouchArea {
        C00101(float x, float y, float width, float height) {
            super(x, y, width, height);
        }

        protected void onTouchDown(Touch touch) {
            Button.this.pressed = true;
            Button.this.pressTime = 0.0f;
            Button.this.processed = false;
            Button.this.onTouchDown();
        }

        protected void onTouchUp(Touch touch) {
            Button.this.pressed = false;
            Button.this.onTouchUp();
        }

        protected void onClick(Touch touch) {
            if (!Button.this.processed) {
                Button.this.onClick();
            }
        }
    }

    static {
        longClick = Key.TIME_TO_UNLOCK;
    }

    protected void createChildren() {
        this.hotArea = new C00101(0.0f, 0.0f, 0.0f, 0.0f);
        add(this.hotArea);
    }

    public void update() {
        super.update();
        this.hotArea.active = this.visible;
        if (this.pressed) {
            float f = this.pressTime + Game.elapsed;
            this.pressTime = f;
            if (f >= longClick) {
                this.pressed = false;
                if (onLongClick()) {
                    this.hotArea.reset();
                    this.processed = true;
                    onTouchUp();
                    Game.vibrate(50);
                }
            }
        }
    }

    protected void onTouchDown() {
    }

    protected void onTouchUp() {
    }

    protected void onClick() {
    }

    protected boolean onLongClick() {
        return false;
    }

    protected void layout() {
        this.hotArea.x = this.x;
        this.hotArea.y = this.y;
        this.hotArea.width = this.width;
        this.hotArea.height = this.height;
    }
}
