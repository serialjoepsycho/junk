package com.watabou.noosa.ui;

import com.watabou.noosa.Group;
import com.watabou.pixeldungeon.items.quest.Pickaxe;

public class Component extends Group {
    protected float height;
    protected float width;
    protected float f10x;
    protected float f11y;

    public Component() {
        createChildren();
    }

    public Component setPos(float x, float y) {
        this.f10x = x;
        this.f11y = y;
        layout();
        return this;
    }

    public Component setSize(float width, float height) {
        this.width = width;
        this.height = height;
        layout();
        return this;
    }

    public Component setRect(float x, float y, float width, float height) {
        this.f10x = x;
        this.f11y = y;
        this.width = width;
        this.height = height;
        layout();
        return this;
    }

    public boolean inside(float x, float y) {
        return x >= this.f10x && y >= this.f11y && x < this.f10x + this.width && y < this.f11y + this.height;
    }

    public void fill(Component c) {
        setRect(c.f10x, c.f11y, c.width, c.height);
    }

    public float left() {
        return this.f10x;
    }

    public float right() {
        return this.f10x + this.width;
    }

    public float centerX() {
        return this.f10x + (this.width / Pickaxe.TIME_TO_MINE);
    }

    public float top() {
        return this.f11y;
    }

    public float bottom() {
        return this.f11y + this.height;
    }

    public float centerY() {
        return this.f11y + (this.height / Pickaxe.TIME_TO_MINE);
    }

    public float width() {
        return this.width;
    }

    public float height() {
        return this.height;
    }

    protected void createChildren() {
    }

    protected void layout() {
    }
}
