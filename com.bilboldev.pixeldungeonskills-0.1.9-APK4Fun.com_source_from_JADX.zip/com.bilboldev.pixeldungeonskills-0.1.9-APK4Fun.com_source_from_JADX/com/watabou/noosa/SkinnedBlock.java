package com.watabou.noosa;

import android.graphics.RectF;
import com.watabou.glwrap.Texture;
import com.watabou.pixeldungeon.items.keys.Key;

public class SkinnedBlock extends Image {
    protected float offsetX;
    protected float offsetY;
    protected float scaleX;
    protected float scaleY;

    public SkinnedBlock(float width, float height, Object tx) {
        super(tx);
        this.texture.wrap(Texture.REPEAT, Texture.REPEAT);
        size(width, height);
    }

    public void frame(RectF frame) {
        this.scaleX = Key.TIME_TO_UNLOCK;
        this.scaleY = Key.TIME_TO_UNLOCK;
        this.offsetX = 0.0f;
        this.offsetY = 0.0f;
        super.frame(new RectF(0.0f, 0.0f, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK));
    }

    protected void updateFrame() {
        float tw = Key.TIME_TO_UNLOCK / ((float) this.texture.width);
        float th = Key.TIME_TO_UNLOCK / ((float) this.texture.height);
        float u0 = this.offsetX * tw;
        float v0 = this.offsetY * th;
        float u1 = u0 + ((this.width * tw) / this.scaleX);
        float v1 = v0 + ((this.height * th) / this.scaleY);
        this.vertices[2] = u0;
        this.vertices[3] = v0;
        this.vertices[6] = u1;
        this.vertices[7] = v0;
        this.vertices[10] = u1;
        this.vertices[11] = v1;
        this.vertices[14] = u0;
        this.vertices[15] = v1;
        this.dirty = true;
    }

    public void offsetTo(float x, float y) {
        this.offsetX = x;
        this.offsetY = y;
        updateFrame();
    }

    public void offset(float x, float y) {
        this.offsetX += x;
        this.offsetY += y;
        updateFrame();
    }

    public float offsetX() {
        return this.offsetX;
    }

    public float offsetY() {
        return this.offsetY;
    }

    public void scale(float x, float y) {
        this.scaleX = x;
        this.scaleY = y;
        updateFrame();
    }

    public void size(float w, float h) {
        this.width = w;
        this.height = h;
        updateFrame();
        updateVertices();
    }
}
