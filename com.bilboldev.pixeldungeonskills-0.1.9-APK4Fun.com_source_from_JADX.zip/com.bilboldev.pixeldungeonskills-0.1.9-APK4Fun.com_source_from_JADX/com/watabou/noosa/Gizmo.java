package com.watabou.noosa;

public class Gizmo {
    public boolean active;
    public boolean alive;
    public Camera camera;
    public boolean exists;
    public Group parent;
    public boolean visible;

    public Gizmo() {
        this.exists = true;
        this.alive = true;
        this.active = true;
        this.visible = true;
    }

    public void destroy() {
        this.parent = null;
    }

    public void update() {
    }

    public void draw() {
    }

    public void kill() {
        this.alive = false;
        this.exists = false;
    }

    public void revive() {
        this.alive = true;
        this.exists = true;
    }

    public Camera camera() {
        if (this.camera != null) {
            return this.camera;
        }
        if (this.parent != null) {
            return this.parent.camera();
        }
        return null;
    }

    public boolean isVisible() {
        if (this.parent == null) {
            return this.visible;
        }
        return this.visible && this.parent.isVisible();
    }

    public boolean isActive() {
        if (this.parent == null) {
            return this.active;
        }
        return this.active && this.parent.isActive();
    }

    public void killAndErase() {
        kill();
        if (this.parent != null) {
            this.parent.erase(this);
        }
    }

    public void remove() {
        if (this.parent != null) {
            this.parent.remove(this);
        }
    }
}
