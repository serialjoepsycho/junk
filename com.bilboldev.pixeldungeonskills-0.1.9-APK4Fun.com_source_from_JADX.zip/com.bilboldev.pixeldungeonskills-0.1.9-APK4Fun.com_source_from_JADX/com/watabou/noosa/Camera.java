package com.watabou.noosa;

import com.watabou.glwrap.Matrix;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.utils.Point;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class Camera extends Gizmo {
    protected static ArrayList<Camera> all;
    protected static float invH2;
    protected static float invW2;
    public static Camera main;
    public int height;
    public float[] matrix;
    int screenHeight;
    int screenWidth;
    public PointF scroll;
    private float shakeDuration;
    private float shakeMagX;
    private float shakeMagY;
    private float shakeTime;
    protected float shakeX;
    protected float shakeY;
    public Visual target;
    public int width;
    public int f6x;
    public int f7y;
    public float zoom;

    static {
        all = new ArrayList();
    }

    public static Camera reset() {
        return reset(createFullscreen(Key.TIME_TO_UNLOCK));
    }

    public static Camera reset(Camera newCamera) {
        invW2 = Pickaxe.TIME_TO_MINE / ((float) Game.width);
        invH2 = Pickaxe.TIME_TO_MINE / ((float) Game.height);
        int length = all.size();
        for (int i = 0; i < length; i++) {
            ((Camera) all.get(i)).destroy();
        }
        all.clear();
        Camera add = add(newCamera);
        main = add;
        return add;
    }

    public static Camera add(Camera camera) {
        all.add(camera);
        return camera;
    }

    public static Camera remove(Camera camera) {
        all.remove(camera);
        return camera;
    }

    public static void updateAll() {
        int length = all.size();
        for (int i = 0; i < length; i++) {
            Camera c = (Camera) all.get(i);
            if (c.exists && c.active) {
                c.update();
            }
        }
    }

    public static Camera createFullscreen(float zoom) {
        int w = (int) Math.ceil((double) (((float) Game.width) / zoom));
        int h = (int) Math.ceil((double) (((float) Game.height) / zoom));
        return new Camera(((int) (((float) Game.width) - (((float) w) * zoom))) / 2, ((int) (((float) Game.height) - (((float) h) * zoom))) / 2, w, h, zoom);
    }

    public Camera(int x, int y, int width, int height, float zoom) {
        this.shakeMagX = TomeOfMastery.TIME_TO_READ;
        this.shakeMagY = TomeOfMastery.TIME_TO_READ;
        this.shakeTime = 0.0f;
        this.shakeDuration = Key.TIME_TO_UNLOCK;
        this.f6x = x;
        this.f7y = y;
        this.width = width;
        this.height = height;
        this.zoom = zoom;
        this.screenWidth = (int) (((float) width) * zoom);
        this.screenHeight = (int) (((float) height) * zoom);
        this.scroll = new PointF();
        this.matrix = new float[16];
        Matrix.setIdentity(this.matrix);
    }

    public void destroy() {
        this.target = null;
        this.matrix = null;
    }

    public void zoom(float value) {
        zoom(value, this.scroll.f24x + ((float) (this.width / 2)), this.scroll.f25y + ((float) (this.height / 2)));
    }

    public void zoom(float value, float fx, float fy) {
        this.zoom = value;
        this.width = (int) (((float) this.screenWidth) / this.zoom);
        this.height = (int) (((float) this.screenHeight) / this.zoom);
        focusOn(fx, fy);
    }

    public void resize(int width, int height) {
        this.width = width;
        this.height = height;
        this.screenWidth = (int) (((float) width) * this.zoom);
        this.screenHeight = (int) (((float) height) * this.zoom);
    }

    public void update() {
        super.update();
        if (this.target != null) {
            focusOn(this.target);
        }
        float f = this.shakeTime - Game.elapsed;
        this.shakeTime = f;
        if (f > 0.0f) {
            float damping = this.shakeTime / this.shakeDuration;
            this.shakeX = Random.Float(-this.shakeMagX, this.shakeMagX) * damping;
            this.shakeY = Random.Float(-this.shakeMagY, this.shakeMagY) * damping;
        } else {
            this.shakeX = 0.0f;
            this.shakeY = 0.0f;
        }
        updateMatrix();
    }

    public PointF center() {
        return new PointF((float) (this.width / 2), (float) (this.height / 2));
    }

    public boolean hitTest(float x, float y) {
        return x >= ((float) this.f6x) && y >= ((float) this.f7y) && x < ((float) (this.f6x + this.screenWidth)) && y < ((float) (this.f7y + this.screenHeight));
    }

    public void focusOn(float x, float y) {
        this.scroll.set(x - ((float) (this.width / 2)), y - ((float) (this.height / 2)));
    }

    public void focusOn(PointF point) {
        focusOn(point.f24x, point.f25y);
    }

    public void focusOn(Visual visual) {
        focusOn(visual.center());
    }

    public PointF screenToCamera(int x, int y) {
        return new PointF((((float) (x - this.f6x)) / this.zoom) + this.scroll.f24x, (((float) (y - this.f7y)) / this.zoom) + this.scroll.f25y);
    }

    public Point cameraToScreen(float x, float y) {
        return new Point((int) (((x - this.scroll.f24x) * this.zoom) + ((float) this.f6x)), (int) (((y - this.scroll.f25y) * this.zoom) + ((float) this.f7y)));
    }

    public float screenWidth() {
        return ((float) this.width) * this.zoom;
    }

    public float screenHeight() {
        return ((float) this.height) * this.zoom;
    }

    protected void updateMatrix() {
        this.matrix[0] = this.zoom * invW2;
        this.matrix[5] = (-this.zoom) * invH2;
        this.matrix[12] = (-1.0f + (((float) this.f6x) * invW2)) - ((this.scroll.f24x + this.shakeX) * this.matrix[0]);
        this.matrix[13] = (Key.TIME_TO_UNLOCK - (((float) this.f7y) * invH2)) - ((this.scroll.f25y + this.shakeY) * this.matrix[5]);
    }

    public void shake(float magnitude, float duration) {
        this.shakeMagY = magnitude;
        this.shakeMagX = magnitude;
        this.shakeDuration = duration;
        this.shakeTime = duration;
    }
}
