package com.watabou.noosa;

import android.graphics.RectF;
import com.watabou.glwrap.Quad;
import com.watabou.noosa.BitmapText.Font;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.utils.PointF;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class BitmapTextMultiline extends BitmapText {
    protected static final Pattern PARAGRAPH;
    protected static final Pattern WORD;
    public boolean[] mask;
    public int maxWidth;
    protected float spaceSize;

    public class LineSplitter {
        private StringBuilder curLine;
        private float curLineWidth;
        private ArrayList<BitmapText> lines;
        private PointF metrics;

        public LineSplitter() {
            this.metrics = new PointF();
        }

        private void newLine(String str, float width) {
            BitmapText txt = new BitmapText(this.curLine.toString(), BitmapTextMultiline.this.font);
            txt.scale.set(BitmapTextMultiline.this.scale.f24x);
            this.lines.add(txt);
            this.curLine = new StringBuilder(str);
            this.curLineWidth = width;
        }

        private void append(String str, float width) {
            float f = 0.0f;
            float f2 = this.curLineWidth;
            if (this.curLineWidth > 0.0f) {
                f = BitmapTextMultiline.this.font.tracking;
            }
            this.curLineWidth = (f + width) + f2;
            this.curLine.append(str);
        }

        public ArrayList<BitmapText> split() {
            this.lines = new ArrayList();
            this.curLine = new StringBuilder();
            this.curLineWidth = 0.0f;
            String[] paragraphs = BitmapTextMultiline.PARAGRAPH.split(BitmapTextMultiline.this.text);
            for (CharSequence split : paragraphs) {
                String[] words = BitmapTextMultiline.WORD.split(split);
                for (String word : words) {
                    if (word.length() != 0) {
                        BitmapTextMultiline.this.getWordMetrics(word, this.metrics);
                        if (this.curLineWidth <= 0.0f || (this.curLineWidth + BitmapTextMultiline.this.font.tracking) + this.metrics.f24x <= ((float) BitmapTextMultiline.this.maxWidth) / BitmapTextMultiline.this.scale.f24x) {
                            append(word, this.metrics.f24x);
                        } else {
                            newLine(word, this.metrics.f24x);
                        }
                        if (this.curLineWidth <= 0.0f || (this.curLineWidth + BitmapTextMultiline.this.font.tracking) + BitmapTextMultiline.this.spaceSize <= ((float) BitmapTextMultiline.this.maxWidth) / BitmapTextMultiline.this.scale.f24x) {
                            append(" ", BitmapTextMultiline.this.spaceSize);
                        } else {
                            newLine(BuildConfig.VERSION_NAME, 0.0f);
                        }
                    }
                }
                newLine(BuildConfig.VERSION_NAME, 0.0f);
            }
            return this.lines;
        }
    }

    private class SymbolWriter {
        public float height;
        public float lineHeight;
        public float lineWidth;
        public float width;
        public float f4x;
        public float f5y;

        private SymbolWriter() {
            this.width = 0.0f;
            this.height = 0.0f;
            this.lineWidth = 0.0f;
            this.lineHeight = 0.0f;
            this.f4x = 0.0f;
            this.f5y = 0.0f;
        }

        public void addSymbol(float w, float h) {
            float f = 0.0f;
            if (this.lineWidth <= 0.0f || (this.lineWidth + BitmapTextMultiline.this.font.tracking) + w <= ((float) BitmapTextMultiline.this.maxWidth) / BitmapTextMultiline.this.scale.f24x) {
                this.f4x = this.lineWidth;
                float f2 = this.lineWidth;
                if (this.lineWidth > 0.0f) {
                    f = BitmapTextMultiline.this.font.tracking;
                }
                this.lineWidth = (f + w) + f2;
                if (h > this.lineHeight) {
                    this.lineHeight = h;
                    return;
                }
                return;
            }
            newLine(w, h);
        }

        public void addSpace(float w) {
            float f = 0.0f;
            if (this.lineWidth <= 0.0f || (this.lineWidth + BitmapTextMultiline.this.font.tracking) + w <= ((float) BitmapTextMultiline.this.maxWidth) / BitmapTextMultiline.this.scale.f24x) {
                this.f4x = this.lineWidth;
                float f2 = this.lineWidth;
                if (this.lineWidth > 0.0f) {
                    f = BitmapTextMultiline.this.font.tracking;
                }
                this.lineWidth = (f + w) + f2;
                return;
            }
            newLine(0.0f, 0.0f);
        }

        public void newLine(float w, float h) {
            this.height += this.lineHeight;
            if (this.width < this.lineWidth) {
                this.width = this.lineWidth;
            }
            this.lineWidth = w;
            this.lineHeight = h;
            this.f4x = 0.0f;
            this.f5y = this.height;
        }
    }

    static {
        PARAGRAPH = Pattern.compile("\n");
        WORD = Pattern.compile("\\s+");
    }

    public BitmapTextMultiline(Font font) {
        this(BuildConfig.VERSION_NAME, font);
    }

    public BitmapTextMultiline(String text, Font font) {
        super(text, font);
        this.maxWidth = Integer.MAX_VALUE;
        this.spaceSize = font.width(font.get(' '));
    }

    protected void updateVertices() {
        if (this.text == null) {
            this.text = BuildConfig.VERSION_NAME;
        }
        this.quads = Quad.createSet(this.text.length());
        this.realLength = 0;
        BitmapTextMultiline bitmapTextMultiline = this;
        SymbolWriter writer = new SymbolWriter();
        PointF metrics = new PointF();
        String[] paragraphs = PARAGRAPH.split(this.text);
        int pos = 0;
        for (CharSequence split : paragraphs) {
            String[] words = WORD.split(split);
            for (String word : words) {
                if (word.length() != 0) {
                    getWordMetrics(word, metrics);
                    writer.addSymbol(metrics.f24x, metrics.f25y);
                    int length = word.length();
                    float shift = 0.0f;
                    for (int k = 0; k < length; k++) {
                        RectF rect = this.font.get(word.charAt(k));
                        float w = this.font.width(rect);
                        float h = this.font.height(rect);
                        if (this.mask == null || this.mask[pos]) {
                            this.vertices[0] = writer.f4x + shift;
                            this.vertices[1] = writer.f5y;
                            this.vertices[2] = rect.left;
                            this.vertices[3] = rect.top;
                            this.vertices[4] = (writer.f4x + shift) + w;
                            this.vertices[5] = writer.f5y;
                            this.vertices[6] = rect.right;
                            this.vertices[7] = rect.top;
                            this.vertices[8] = (writer.f4x + shift) + w;
                            this.vertices[9] = writer.f5y + h;
                            this.vertices[10] = rect.right;
                            this.vertices[11] = rect.bottom;
                            this.vertices[12] = writer.f4x + shift;
                            this.vertices[13] = writer.f5y + h;
                            this.vertices[14] = rect.left;
                            this.vertices[15] = rect.bottom;
                            this.quads.put(this.vertices);
                            this.realLength++;
                        }
                        shift += this.font.tracking + w;
                        pos++;
                    }
                    writer.addSpace(this.spaceSize);
                }
            }
            writer.newLine(0.0f, this.font.lineHeight);
        }
        this.dirty = false;
    }

    private void getWordMetrics(String word, PointF metrics) {
        float w = 0.0f;
        float h = 0.0f;
        int length = word.length();
        for (int i = 0; i < length; i++) {
            float f;
            RectF rect = this.font.get(word.charAt(i));
            float width = this.font.width(rect);
            if (w > 0.0f) {
                f = this.font.tracking;
            } else {
                f = 0.0f;
            }
            w += f + width;
            h = Math.max(h, this.font.height(rect));
        }
        metrics.set(w, h);
    }

    public void measure() {
        SymbolWriter writer = new SymbolWriter();
        PointF metrics = new PointF();
        String[] paragraphs = PARAGRAPH.split(this.text);
        for (CharSequence split : paragraphs) {
            String[] words = WORD.split(split);
            for (String word : words) {
                if (word.length() != 0) {
                    getWordMetrics(word, metrics);
                    writer.addSymbol(metrics.f24x, metrics.f25y);
                    writer.addSpace(this.spaceSize);
                }
            }
            writer.newLine(0.0f, this.font.lineHeight);
        }
        this.width = writer.width;
        this.height = writer.height;
    }
}
