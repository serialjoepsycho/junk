package com.watabou.noosa;

import android.graphics.RectF;
import com.watabou.pixeldungeon.items.keys.Key;

public class MovieClip extends Image {
    protected Animation curAnim;
    protected int curFrame;
    protected boolean finished;
    protected float frameTimer;
    public Listener listener;
    public boolean paused;

    public static class Animation {
        public float delay;
        public RectF[] frames;
        public boolean looped;

        public Animation(int fps, boolean looped) {
            this.delay = Key.TIME_TO_UNLOCK / ((float) fps);
            this.looped = looped;
        }

        public Animation frames(RectF... frames) {
            this.frames = frames;
            return this;
        }

        public Animation frames(TextureFilm film, Object... frames) {
            this.frames = new RectF[frames.length];
            for (int i = 0; i < frames.length; i++) {
                this.frames[i] = film.get(frames[i]);
            }
            return this;
        }

        public Animation clone() {
            return new Animation(Math.round(Key.TIME_TO_UNLOCK / this.delay), this.looped).frames(this.frames);
        }
    }

    public interface Listener {
        void onComplete(Animation animation);
    }

    public MovieClip() {
        this.paused = false;
    }

    public MovieClip(Object tx) {
        super(tx);
        this.paused = false;
    }

    public void update() {
        super.update();
        if (!this.paused) {
            updateAnimation();
        }
    }

    protected void updateAnimation() {
        if (this.curAnim != null && this.curAnim.delay > 0.0f) {
            if (this.curAnim.looped || !this.finished) {
                int lastFrame = this.curFrame;
                this.frameTimer += Game.elapsed;
                while (this.frameTimer > this.curAnim.delay) {
                    this.frameTimer -= this.curAnim.delay;
                    if (this.curFrame == this.curAnim.frames.length - 1) {
                        if (this.curAnim.looped) {
                            this.curFrame = 0;
                        }
                        this.finished = true;
                        if (this.listener != null) {
                            this.listener.onComplete(this.curAnim);
                            if (this.curAnim == null) {
                                return;
                            }
                        } else {
                            continue;
                        }
                    } else {
                        this.curFrame++;
                    }
                }
                if (this.curFrame != lastFrame) {
                    frame(this.curAnim.frames[this.curFrame]);
                }
            }
        }
    }

    public void play(Animation anim) {
        play(anim, false);
    }

    public void play(Animation anim, boolean force) {
        if (force || this.curAnim == null || this.curAnim != anim || (!this.curAnim.looped && this.finished)) {
            this.curAnim = anim;
            this.curFrame = 0;
            this.finished = false;
            this.frameTimer = 0.0f;
            if (anim != null) {
                frame(anim.frames[this.curFrame]);
            }
        }
    }
}
