package com.watabou.noosa;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLSurfaceView.Renderer;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.View.OnTouchListener;
import com.watabou.billing.IabHelper;
import com.watabou.billing.IabHelper.OnIabSetupFinishedListener;
import com.watabou.billing.IabResult;
import com.watabou.glscripts.Script;
import com.watabou.gltextures.TextureCache;
import com.watabou.input.Keys;
import com.watabou.input.Touchscreen;
import com.watabou.noosa.audio.Music;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.utils.BitmapCache;
import com.watabou.utils.SystemTime;
import java.util.ArrayList;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class Game extends Activity implements Renderer, OnTouchListener {
    public static float density;
    public static float elapsed;
    public static int height;
    public static Game instance;
    public static IabHelper mHelper;
    public static float timeScale;
    public static String version;
    public static int width;
    protected SurfaceHolder holder;
    protected ArrayList<KeyEvent> keysEvents;
    protected ArrayList<MotionEvent> motionEvents;
    protected long now;
    protected boolean requestedReset;
    protected Scene requestedScene;
    protected Scene scene;
    protected Class<? extends Scene> sceneClass;
    protected long step;
    protected GLSurfaceView view;

    /* renamed from: com.watabou.noosa.Game.1 */
    class C00071 implements OnIabSetupFinishedListener {
        C00071() {
        }

        public void onIabSetupFinished(IabResult result) {
            if (!result.isSuccess()) {
            }
        }
    }

    static {
        density = Key.TIME_TO_UNLOCK;
        timeScale = Key.TIME_TO_UNLOCK;
        elapsed = 0.0f;
    }

    public Game(Class<? extends Scene> c) {
        this.requestedReset = true;
        this.motionEvents = new ArrayList();
        this.keysEvents = new ArrayList();
        this.sceneClass = c;
    }

    protected void onCreate(Bundle savedInstanceState) {
        try {
            mHelper = new IabHelper(this, "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyAqfFKdmIbnqorhGMoUVToAHK7vGfqsdJFNX8PSDzhXc9IAiiNpI/mD38/67nQmra1vtmhF17p7UNQaiH/LKHdZ+eT6vf2UeWBf1v3rgEAMi8UoQgDuQhJsI7DUTGSwyWygVAcVqY4s/Wz7tLxto5zVfRCPb2EMXpVau0HrC4hroae1kAKfjCqXBI5Nkhp9WoWFoK/+lQo6UfD8uya5WzYIk2X8Xwn24Rylhcf2jIdKSuFqhGjJdfI9jxvnuYGem1SC+9ox7GzXXwCdKfgFtaCDvRHlgtjnFi83OUP8N+BOlmvCOdRjjncNm4AZTdGDTeTDzLfBZpkxL7u0PPCIUVwIDAQAB");
            mHelper.startSetup(new C00071());
        } catch (Exception e) {
        }
        super.onCreate(savedInstanceState);
        instance = this;
        TextureCache.context = this;
        BitmapCache.context = this;
        DisplayMetrics m = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(m);
        density = m.density;
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (NameNotFoundException e2) {
            version = "???";
        }
        setVolumeControlStream(3);
        this.view = new GLSurfaceView(this);
        this.view.setEGLContextClientVersion(2);
        this.view.setEGLConfigChooser(false);
        this.view.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        this.view.setRenderer(this);
        this.view.setOnTouchListener(this);
        setContentView(this.view);
    }

    public void onResume() {
        super.onResume();
        this.now = 0;
        this.view.onResume();
        Music.INSTANCE.resume();
        Sample.INSTANCE.resume();
    }

    public void onPause() {
        super.onPause();
        if (this.scene != null) {
            this.scene.pause();
        }
        this.view.onPause();
        Script.reset();
        Music.INSTANCE.pause();
        Sample.INSTANCE.pause();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (!mHelper.handleActivityResult(requestCode, resultCode, data)) {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void onDestroy() {
        super.onDestroy();
        destroyGame();
        try {
            if (mHelper != null) {
                mHelper.dispose();
            }
            mHelper = null;
        } catch (Exception e) {
        }
        Music.INSTANCE.mute();
        Sample.INSTANCE.reset();
    }

    @SuppressLint({"Recycle", "ClickableViewAccessibility"})
    public boolean onTouch(View view, MotionEvent event) {
        synchronized (this.motionEvents) {
            this.motionEvents.add(MotionEvent.obtain(event));
        }
        return true;
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 25 || keyCode == 24) {
            return false;
        }
        synchronized (this.motionEvents) {
            this.keysEvents.add(event);
        }
        return true;
    }

    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == 25 || keyCode == 24) {
            return false;
        }
        synchronized (this.motionEvents) {
            this.keysEvents.add(event);
        }
        return true;
    }

    public void onDrawFrame(GL10 gl) {
        long j = 0;
        if (width != 0 && height != 0) {
            SystemTime.tick();
            long rightNow = SystemTime.now;
            if (this.now != 0) {
                j = rightNow - this.now;
            }
            this.step = j;
            this.now = rightNow;
            step();
            NoosaScript.get().resetCamera();
            GLES20.glScissor(0, 0, width, height);
            GLES20.glClear(16384);
            draw();
        }
    }

    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        width = width;
        height = height;
    }

    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glEnable(3042);
        GLES20.glBlendFunc(770, 771);
        GLES20.glEnable(3089);
        TextureCache.reload();
    }

    protected void destroyGame() {
        if (this.scene != null) {
            this.scene.destroy();
            this.scene = null;
        }
        instance = null;
    }

    public static void resetScene() {
        switchScene(instance.sceneClass);
    }

    public static void switchScene(Class<? extends Scene> c) {
        instance.sceneClass = c;
        instance.requestedReset = true;
    }

    public static Scene scene() {
        return instance.scene;
    }

    protected void step() {
        if (this.requestedReset) {
            this.requestedReset = false;
            try {
                this.requestedScene = (Scene) this.sceneClass.newInstance();
                switchScene();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        update();
    }

    protected void draw() {
        this.scene.draw();
    }

    protected void switchScene() {
        Camera.reset();
        if (this.scene != null) {
            this.scene.destroy();
        }
        this.scene = this.requestedScene;
        this.scene.create();
        elapsed = 0.0f;
        timeScale = Key.TIME_TO_UNLOCK;
    }

    protected void update() {
        elapsed = (timeScale * ((float) this.step)) * 0.001f;
        synchronized (this.motionEvents) {
            Touchscreen.processTouchEvents(this.motionEvents);
            this.motionEvents.clear();
        }
        synchronized (this.keysEvents) {
            Keys.processTouchEvents(this.keysEvents);
            this.keysEvents.clear();
        }
        this.scene.update();
        Camera.updateAll();
    }

    public static void vibrate(int milliseconds) {
        ((Vibrator) instance.getSystemService("vibrator")).vibrate((long) milliseconds);
    }
}
