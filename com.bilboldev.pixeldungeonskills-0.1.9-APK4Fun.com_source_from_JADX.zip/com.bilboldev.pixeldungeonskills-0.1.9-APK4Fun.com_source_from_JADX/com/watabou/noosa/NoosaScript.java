package com.watabou.noosa;

import android.opengl.GLES20;
import com.watabou.glscripts.Script;
import com.watabou.glwrap.Attribute;
import com.watabou.glwrap.Quad;
import com.watabou.glwrap.Uniform;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class NoosaScript extends Script {
    private static final String SHADER = "uniform mat4 uCamera;uniform mat4 uModel;attribute vec4 aXYZW;attribute vec2 aUV;varying vec2 vUV;void main() {  gl_Position = uCamera * uModel * aXYZW;  vUV = aUV;}//\nprecision mediump float;varying vec2 vUV;uniform sampler2D uTex;uniform vec4 uColorM;uniform vec4 uColorA;void main() {  gl_FragColor = texture2D( uTex, vUV ) * uColorM + uColorA;}";
    public Attribute aUV;
    public Attribute aXY;
    private Camera lastCamera;
    public Uniform uCamera;
    public Uniform uColorA;
    public Uniform uColorM;
    public Uniform uModel;
    public Uniform uTex;

    public NoosaScript() {
        compile(shader());
        this.uCamera = uniform("uCamera");
        this.uModel = uniform("uModel");
        this.uTex = uniform("uTex");
        this.uColorM = uniform("uColorM");
        this.uColorA = uniform("uColorA");
        this.aXY = attribute("aXYZW");
        this.aUV = attribute("aUV");
    }

    public void use() {
        super.use();
        this.aXY.enable();
        this.aUV.enable();
    }

    public void drawElements(FloatBuffer vertices, ShortBuffer indices, int size) {
        vertices.position(0);
        this.aXY.vertexPointer(2, 4, vertices);
        vertices.position(2);
        this.aUV.vertexPointer(2, 4, vertices);
        GLES20.glDrawElements(4, size, 5123, indices);
    }

    public void drawQuad(FloatBuffer vertices) {
        vertices.position(0);
        this.aXY.vertexPointer(2, 4, vertices);
        vertices.position(2);
        this.aUV.vertexPointer(2, 4, vertices);
        GLES20.glDrawElements(4, Quad.SIZE, 5123, Quad.getIndices(1));
    }

    public void drawQuadSet(FloatBuffer vertices, int size) {
        if (size != 0) {
            vertices.position(0);
            this.aXY.vertexPointer(2, 4, vertices);
            vertices.position(2);
            this.aUV.vertexPointer(2, 4, vertices);
            GLES20.glDrawElements(4, Quad.SIZE * size, 5123, Quad.getIndices(size));
        }
    }

    public void lighting(float rm, float gm, float bm, float am, float ra, float ga, float ba, float aa) {
        this.uColorM.value4f(rm, gm, bm, am);
        this.uColorA.value4f(ra, ga, ba, aa);
    }

    public void resetCamera() {
        this.lastCamera = null;
    }

    public void camera(Camera camera) {
        if (camera == null) {
            camera = Camera.main;
        }
        if (camera != this.lastCamera) {
            this.lastCamera = camera;
            this.uCamera.valueM4(camera.matrix);
            GLES20.glScissor(camera.f6x, (Game.height - camera.screenHeight) - camera.f7y, camera.screenWidth, camera.screenHeight);
        }
    }

    public static NoosaScript get() {
        return (NoosaScript) Script.use(NoosaScript.class);
    }

    protected String shader() {
        return SHADER;
    }
}
