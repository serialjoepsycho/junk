package com.watabou.noosa;

import com.watabou.gltextures.TextureCache;

public class ColorBlock extends Image implements Resizable {
    public ColorBlock(float width, float height, int color) {
        super(TextureCache.createSolid(color));
        this.scale.set(width, height);
        this.origin.set(0.0f, 0.0f);
    }

    public void size(float width, float height) {
        this.scale.set(width, height);
    }

    public float width() {
        return this.scale.f24x;
    }

    public float height() {
        return this.scale.f25y;
    }
}
