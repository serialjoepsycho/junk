package com.watabou.noosa;

import android.graphics.RectF;
import com.watabou.gltextures.SmartTexture;
import com.watabou.gltextures.TextureCache;
import com.watabou.pixeldungeon.items.keys.Key;
import java.util.HashMap;

public class TextureFilm {
    private static final RectF FULL;
    protected HashMap<Object, RectF> frames;
    private int texHeight;
    private int texWidth;

    static {
        FULL = new RectF(0.0f, 0.0f, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK);
    }

    public TextureFilm(Object tx) {
        this.frames = new HashMap();
        SmartTexture texture = TextureCache.get(tx);
        this.texWidth = texture.width;
        this.texHeight = texture.height;
        add(null, FULL);
    }

    public TextureFilm(SmartTexture texture, int width) {
        this(texture, width, texture.height);
    }

    public TextureFilm(Object tx, int width, int height) {
        this.frames = new HashMap();
        SmartTexture texture = TextureCache.get(tx);
        this.texWidth = texture.width;
        this.texHeight = texture.height;
        float uw = ((float) width) / ((float) this.texWidth);
        float vh = ((float) height) / ((float) this.texHeight);
        int cols = this.texWidth / width;
        int rows = this.texHeight / height;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                add(Integer.valueOf((i * cols) + j), new RectF(((float) j) * uw, ((float) i) * vh, ((float) (j + 1)) * uw, ((float) (i + 1)) * vh));
            }
        }
    }

    public TextureFilm(TextureFilm atlas, Object key, int width, int height) {
        this.frames = new HashMap();
        this.texWidth = atlas.texWidth;
        this.texHeight = atlas.texHeight;
        RectF patch = atlas.get(key);
        float uw = ((float) width) / ((float) this.texWidth);
        float vh = ((float) height) / ((float) this.texHeight);
        int cols = (int) (width(patch) / ((float) width));
        int rows = (int) (height(patch) / ((float) height));
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                RectF rect = new RectF(((float) j) * uw, ((float) i) * vh, ((float) (j + 1)) * uw, ((float) (i + 1)) * vh);
                rect.offset(patch.left, patch.top);
                add(Integer.valueOf((i * cols) + j), rect);
            }
        }
    }

    public void add(Object id, RectF rect) {
        this.frames.put(id, rect);
    }

    public RectF get(Object id) {
        return (RectF) this.frames.get(id);
    }

    public float width(RectF frame) {
        return frame.width() * ((float) this.texWidth);
    }

    public float height(RectF frame) {
        return frame.height() * ((float) this.texHeight);
    }
}
