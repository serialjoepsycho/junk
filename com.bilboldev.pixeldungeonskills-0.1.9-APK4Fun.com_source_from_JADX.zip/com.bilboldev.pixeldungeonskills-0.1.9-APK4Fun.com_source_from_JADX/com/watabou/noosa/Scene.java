package com.watabou.noosa;

import com.watabou.input.Keys;
import com.watabou.input.Keys.Key;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Signal;
import com.watabou.utils.Signal.Listener;

public class Scene extends Group {
    private Listener<Key> keyListener;

    /* renamed from: com.watabou.noosa.Scene.1 */
    class C00081 implements Listener<Key> {
        C00081() {
        }

        public void onSignal(Key key) {
            if (Game.instance != null && key.pressed) {
                switch (key.code) {
                    case WndUpdates.ID_HALLS /*4*/:
                        Scene.this.onBackPressed();
                    case ItemSpriteSheet.MASTERY /*82*/:
                        Scene.this.onMenuPressed();
                    default:
                }
            }
        }
    }

    public void create() {
        Signal signal = Keys.event;
        Listener c00081 = new C00081();
        this.keyListener = c00081;
        signal.add(c00081);
    }

    public void destroy() {
        Keys.event.remove(this.keyListener);
        super.destroy();
    }

    public void pause() {
    }

    public void resume() {
    }

    public void update() {
        super.update();
    }

    public Camera camera() {
        return Camera.main;
    }

    protected void onBackPressed() {
        Game.instance.finish();
    }

    protected void onMenuPressed() {
    }
}
