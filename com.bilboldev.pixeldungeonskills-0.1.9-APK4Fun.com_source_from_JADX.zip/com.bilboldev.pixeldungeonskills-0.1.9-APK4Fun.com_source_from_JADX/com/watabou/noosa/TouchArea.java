package com.watabou.noosa;

import com.watabou.input.Touchscreen;
import com.watabou.input.Touchscreen.Touch;
import com.watabou.utils.Signal.Listener;

public class TouchArea extends Visual implements Listener<Touch> {
    public Visual target;
    protected Touch touch;

    public TouchArea(Visual target) {
        super(0.0f, 0.0f, 0.0f, 0.0f);
        this.touch = null;
        this.target = target;
        Touchscreen.event.add(this);
    }

    public TouchArea(float x, float y, float width, float height) {
        super(x, y, width, height);
        this.touch = null;
        this.target = this;
        this.visible = false;
        Touchscreen.event.add(this);
    }

    public void onSignal(Touch touch) {
        if (isActive()) {
            boolean hit = touch != null && this.target.overlapsScreenPoint((int) touch.start.f24x, (int) touch.start.f25y);
            if (hit) {
                Touchscreen.event.cancel();
                if (touch.down) {
                    if (this.touch == null) {
                        this.touch = touch;
                    }
                    onTouchDown(touch);
                    return;
                }
                onTouchUp(touch);
                if (this.touch == touch) {
                    this.touch = null;
                    onClick(touch);
                }
            } else if (touch == null && this.touch != null) {
                onDrag(this.touch);
            } else if (this.touch != null && touch != null && !touch.down) {
                onTouchUp(touch);
                this.touch = null;
            }
        }
    }

    protected void onTouchDown(Touch touch) {
    }

    protected void onTouchUp(Touch touch) {
    }

    protected void onClick(Touch touch) {
    }

    protected void onDrag(Touch touch) {
    }

    public void reset() {
        this.touch = null;
    }

    public void destroy() {
        Touchscreen.event.remove(this);
        super.destroy();
    }
}
