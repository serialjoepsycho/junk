package com.watabou.noosa;

public interface Resizable {
    float height();

    void size(float f, float f2);

    float width();
}
