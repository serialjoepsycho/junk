package com.watabou.noosa.audio;

import android.content.res.AssetFileDescriptor;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import com.watabou.noosa.Game;
import com.watabou.pixeldungeon.items.keys.Key;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;

public enum Sample implements OnLoadCompleteListener {
    INSTANCE;
    
    public static final int MAX_STREAMS = 8;
    private boolean enabled;
    protected HashMap<Object, Integer> ids;
    private LinkedList<String> loadingQueue;
    protected SoundPool pool;

    /* renamed from: com.watabou.noosa.audio.Sample.1 */
    class C00091 implements OnLoadCompleteListener {
        C00091() {
        }

        public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
            Sample.this.loadNext();
        }
    }

    public void reset() {
        this.pool.release();
        this.pool = new SoundPool(MAX_STREAMS, 3, 0);
        this.pool.setOnLoadCompleteListener(this);
        this.ids.clear();
    }

    public void pause() {
        if (this.pool != null) {
            this.pool.autoPause();
        }
    }

    public void resume() {
        if (this.pool != null) {
            this.pool.autoResume();
        }
    }

    public void load(String... assets) {
        for (String asset : assets) {
            this.loadingQueue.add(asset);
        }
        loadNext();
    }

    private void loadNext() {
        String asset = (String) this.loadingQueue.poll();
        if (asset == null) {
            return;
        }
        if (this.ids.containsKey(asset)) {
            loadNext();
            return;
        }
        try {
            this.pool.setOnLoadCompleteListener(new C00091());
            AssetFileDescriptor fd = Game.instance.getAssets().openFd(asset);
            this.ids.put(asset, Integer.valueOf(this.pool.load(fd, 1)));
            fd.close();
        } catch (IOException e) {
            loadNext();
        }
    }

    public void unload(Object src) {
        if (this.ids.containsKey(src)) {
            this.pool.unload(((Integer) this.ids.get(src)).intValue());
            this.ids.remove(src);
        }
    }

    public int play(Object id) {
        return play(id, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK);
    }

    public int play(Object id, float volume) {
        return play(id, volume, volume, Key.TIME_TO_UNLOCK);
    }

    public int play(Object id, float leftVolume, float rightVolume, float rate) {
        if (this.enabled && this.ids.containsKey(id)) {
            return this.pool.play(((Integer) this.ids.get(id)).intValue(), leftVolume, rightVolume, 0, 0, rate);
        }
        return -1;
    }

    public void enable(boolean value) {
        this.enabled = value;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
    }
}
