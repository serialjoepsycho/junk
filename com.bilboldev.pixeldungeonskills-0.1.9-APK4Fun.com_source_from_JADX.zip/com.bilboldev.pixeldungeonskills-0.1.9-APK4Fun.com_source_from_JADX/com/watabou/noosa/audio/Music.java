package com.watabou.noosa.audio;

import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import com.watabou.noosa.Game;
import java.io.IOException;

public enum Music implements OnPreparedListener, OnErrorListener {
    INSTANCE;
    
    private boolean enabled;
    private boolean lastLooping;
    private String lastPlayed;
    private MediaPlayer player;

    public void play(String assetName, boolean looping) {
        if (!isPlaying() || !this.lastPlayed.equals(assetName)) {
            stop();
            this.lastPlayed = assetName;
            this.lastLooping = looping;
            if (this.enabled && assetName != null) {
                try {
                    AssetFileDescriptor afd = Game.instance.getAssets().openFd(assetName);
                    this.player = new MediaPlayer();
                    this.player.setAudioStreamType(3);
                    this.player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                    this.player.setOnPreparedListener(this);
                    this.player.setOnErrorListener(this);
                    this.player.setLooping(looping);
                    this.player.prepareAsync();
                } catch (IOException e) {
                    this.player.release();
                    this.player = null;
                }
            }
        }
    }

    public void mute() {
        this.lastPlayed = null;
        stop();
    }

    public void onPrepared(MediaPlayer player) {
        player.start();
    }

    public boolean onError(MediaPlayer mp, int what, int extra) {
        if (this.player != null) {
            this.player.release();
            this.player = null;
        }
        return true;
    }

    public void pause() {
        if (this.player != null) {
            this.player.pause();
        }
    }

    public void resume() {
        if (this.player != null) {
            this.player.start();
        }
    }

    public void stop() {
        if (this.player != null) {
            this.player.stop();
            this.player.release();
            this.player = null;
        }
    }

    public void volume(float value) {
        if (this.player != null) {
            this.player.setVolume(value, value);
        }
    }

    public boolean isPlaying() {
        return this.player != null && this.player.isPlaying();
    }

    public void enable(boolean value) {
        this.enabled = value;
        if (isPlaying() && !value) {
            stop();
        } else if (!isPlaying() && value) {
            play(this.lastPlayed, this.lastLooping);
        }
    }

    public boolean isEnabled() {
        return this.enabled;
    }
}
