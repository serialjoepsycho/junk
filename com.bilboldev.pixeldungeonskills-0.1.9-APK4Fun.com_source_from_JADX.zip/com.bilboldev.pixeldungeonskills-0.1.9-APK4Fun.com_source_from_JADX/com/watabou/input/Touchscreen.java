package com.watabou.input;

import android.view.MotionEvent;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.PointF;
import com.watabou.utils.Signal;
import java.util.ArrayList;
import java.util.HashMap;

public class Touchscreen {
    public static Signal<Touch> event;
    public static HashMap<Integer, Touch> pointers;
    public static boolean touched;
    public static float f0x;
    public static float f1y;

    public static class Touch {
        public PointF current;
        public boolean down;
        public PointF start;

        public Touch(MotionEvent e, int index) {
            float x = e.getX(index);
            float y = e.getY(index);
            this.start = new PointF(x, y);
            this.current = new PointF(x, y);
            this.down = true;
        }

        public void update(MotionEvent e, int index) {
            this.current.set(e.getX(index), e.getY(index));
        }

        public Touch up() {
            this.down = false;
            return this;
        }
    }

    static {
        event = new Signal(true);
        pointers = new HashMap();
    }

    public static void processTouchEvents(ArrayList<MotionEvent> events) {
        int size = events.size();
        for (int i = 0; i < size; i++) {
            MotionEvent e = (MotionEvent) events.get(i);
            Touch touch;
            switch (e.getAction() & 255) {
                case WndUpdates.ID_SEWERS /*0*/:
                    touched = true;
                    touch = new Touch(e, 0);
                    pointers.put(Integer.valueOf(e.getPointerId(0)), touch);
                    event.dispatch(touch);
                    break;
                case WndUpdates.ID_PRISON /*1*/:
                    touched = false;
                    event.dispatch(((Touch) pointers.remove(Integer.valueOf(e.getPointerId(0)))).up());
                    break;
                case WndUpdates.ID_CAVES /*2*/:
                    int count = e.getPointerCount();
                    for (int j = 0; j < count; j++) {
                        ((Touch) pointers.get(Integer.valueOf(e.getPointerId(j)))).update(e, j);
                    }
                    event.dispatch(null);
                    break;
                case BuffIndicator.HUNGER /*5*/:
                    int index = e.getActionIndex();
                    touch = new Touch(e, index);
                    pointers.put(Integer.valueOf(e.getPointerId(index)), touch);
                    event.dispatch(touch);
                    break;
                case BuffIndicator.STARVATION /*6*/:
                    event.dispatch(((Touch) pointers.remove(Integer.valueOf(e.getPointerId(e.getActionIndex())))).up());
                    break;
                default:
                    break;
            }
            e.recycle();
        }
    }
}
