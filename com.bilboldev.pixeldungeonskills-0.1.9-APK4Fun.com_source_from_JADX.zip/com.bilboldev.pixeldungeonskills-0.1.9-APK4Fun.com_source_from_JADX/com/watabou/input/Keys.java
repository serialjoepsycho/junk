package com.watabou.input;

import android.view.KeyEvent;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Signal;
import java.util.ArrayList;

public class Keys {
    public static final int BACK = 4;
    public static final int MENU = 82;
    public static final int VOLUME_DOWN = 25;
    public static final int VOLUME_UP = 24;
    public static Signal<Key> event;

    public static class Key {
        public int code;
        public boolean pressed;

        public Key(int code, boolean pressed) {
            this.code = code;
            this.pressed = pressed;
        }
    }

    static {
        event = new Signal(true);
    }

    public static void processTouchEvents(ArrayList<KeyEvent> events) {
        int size = events.size();
        for (int i = 0; i < size; i++) {
            KeyEvent e = (KeyEvent) events.get(i);
            switch (e.getAction()) {
                case WndUpdates.ID_SEWERS /*0*/:
                    event.dispatch(new Key(e.getKeyCode(), true));
                    break;
                case WndUpdates.ID_PRISON /*1*/:
                    event.dispatch(new Key(e.getKeyCode(), false));
                    break;
                default:
                    break;
            }
        }
    }
}
