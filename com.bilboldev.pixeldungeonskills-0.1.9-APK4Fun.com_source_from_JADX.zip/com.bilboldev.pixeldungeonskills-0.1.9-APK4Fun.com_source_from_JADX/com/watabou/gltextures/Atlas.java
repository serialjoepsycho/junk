package com.watabou.gltextures;

import android.graphics.RectF;
import java.util.HashMap;

public class Atlas {
    protected int cols;
    protected HashMap<Object, RectF> namedFrames;
    public SmartTexture tx;
    protected float uvHeight;
    protected float uvLeft;
    protected float uvTop;
    protected float uvWidth;

    public Atlas(SmartTexture tx) {
        this.tx = tx;
        tx.atlas = this;
        this.namedFrames = new HashMap();
    }

    public void add(Object key, int left, int top, int right, int bottom) {
        add(key, uvRect(this.tx, left, top, right, bottom));
    }

    public void add(Object key, RectF rect) {
        this.namedFrames.put(key, rect);
    }

    public void grid(int width) {
        grid(width, this.tx.height);
    }

    public void grid(int width, int height) {
        grid(0, 0, width, height, this.tx.width / width);
    }

    public void grid(int left, int top, int width, int height, int cols) {
        this.uvLeft = ((float) left) / ((float) this.tx.width);
        this.uvTop = ((float) top) / ((float) this.tx.height);
        this.uvWidth = ((float) width) / ((float) this.tx.width);
        this.uvHeight = ((float) height) / ((float) this.tx.height);
        this.cols = cols;
    }

    public RectF get(int index) {
        float l = this.uvLeft + (this.uvWidth * ((float) (index % this.cols)));
        float t = this.uvTop + (this.uvHeight * ((float) (index / this.cols)));
        return new RectF(l, t, this.uvWidth + l, this.uvHeight + t);
    }

    public RectF get(Object key) {
        return (RectF) this.namedFrames.get(key);
    }

    public float width(RectF rect) {
        return rect.width() * ((float) this.tx.width);
    }

    public float height(RectF rect) {
        return rect.height() * ((float) this.tx.height);
    }

    public static RectF uvRect(SmartTexture tx, int left, int top, int right, int bottom) {
        return new RectF(((float) left) / ((float) tx.width), ((float) top) / ((float) tx.height), ((float) right) / ((float) tx.width), ((float) bottom) / ((float) tx.height));
    }
}
