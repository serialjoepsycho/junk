package com.watabou.gltextures;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader.TileMode;
import com.watabou.glwrap.Texture;
import com.watabou.pixeldungeon.BuildConfig;
import java.util.HashMap;

public class TextureCache {
    private static HashMap<Object, SmartTexture> all;
    private static Options bitmapOptions;
    public static Context context;

    static {
        all = new HashMap();
        bitmapOptions = new Options();
        bitmapOptions.inScaled = false;
        bitmapOptions.inDither = false;
        bitmapOptions.inPreferredConfig = Config.ARGB_8888;
    }

    public static SmartTexture createSolid(int color) {
        String key = "1x1:" + color;
        if (all.containsKey(key)) {
            return (SmartTexture) all.get(key);
        }
        Bitmap bmp = Bitmap.createBitmap(1, 1, Config.ARGB_8888);
        bmp.eraseColor(color);
        SmartTexture tx = new SmartTexture(bmp);
        all.put(key, tx);
        return tx;
    }

    public static SmartTexture createGradient(int width, int height, int... colors) {
        String key = BuildConfig.VERSION_NAME + width + "x" + height + ":" + colors;
        if (all.containsKey(key)) {
            return (SmartTexture) all.get(key);
        }
        Bitmap bmp = Bitmap.createBitmap(width, height, Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        Paint paint = new Paint();
        paint.setShader(new LinearGradient(0.0f, 0.0f, 0.0f, (float) height, colors, null, TileMode.CLAMP));
        canvas.drawPaint(paint);
        SmartTexture tx = new SmartTexture(bmp);
        all.put(key, tx);
        return tx;
    }

    public static void add(Object key, SmartTexture tx) {
        all.put(key, tx);
    }

    public static SmartTexture get(Object src) {
        if (all.containsKey(src)) {
            return (SmartTexture) all.get(src);
        }
        if (src instanceof SmartTexture) {
            return (SmartTexture) src;
        }
        SmartTexture tx = new SmartTexture(getBitmap(src));
        all.put(src, tx);
        return tx;
    }

    public static void clear() {
        for (Texture txt : all.values()) {
            txt.delete();
        }
        all.clear();
    }

    public static void reload() {
        for (SmartTexture tx : all.values()) {
            tx.reload();
        }
    }

    public static Bitmap getBitmap(Object src) {
        try {
            if (src instanceof Integer) {
                return BitmapFactory.decodeResource(context.getResources(), ((Integer) src).intValue(), bitmapOptions);
            }
            if (src instanceof String) {
                return BitmapFactory.decodeStream(context.getAssets().open((String) src), null, bitmapOptions);
            }
            return src instanceof Bitmap ? (Bitmap) src : null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean contains(Object key) {
        return all.containsKey(key);
    }
}
