package com.watabou.gltextures;

import android.graphics.Bitmap;
import android.graphics.RectF;
import com.watabou.glwrap.Texture;

public class SmartTexture extends Texture {
    public Atlas atlas;
    public Bitmap bitmap;
    public int fModeMax;
    public int fModeMin;
    public int height;
    public int wModeH;
    public int wModeV;
    public int width;

    public SmartTexture(Bitmap bitmap) {
        this(bitmap, Texture.NEAREST, Texture.CLAMP);
    }

    public SmartTexture(Bitmap bitmap, int filtering, int wrapping) {
        bitmap(bitmap);
        filter(filtering, filtering);
        wrap(wrapping, wrapping);
    }

    public void filter(int minMode, int maxMode) {
        this.fModeMin = minMode;
        this.fModeMax = maxMode;
        super.filter(minMode, maxMode);
    }

    public void wrap(int s, int t) {
        this.wModeH = s;
        this.wModeV = t;
        super.wrap(s, t);
    }

    public void bitmap(Bitmap bitmap) {
        bitmap(bitmap, false);
    }

    public void bitmap(Bitmap bitmap, boolean premultiplied) {
        if (premultiplied) {
            super.bitmap(bitmap);
        } else {
            handMade(bitmap, true);
        }
        this.bitmap = bitmap;
        this.width = bitmap.getWidth();
        this.height = bitmap.getHeight();
    }

    public void reload() {
        this.id = new SmartTexture(this.bitmap).id;
        filter(this.fModeMin, this.fModeMax);
        wrap(this.wModeH, this.wModeV);
    }

    public void delete() {
        super.delete();
        this.bitmap.recycle();
        this.bitmap = null;
    }

    public RectF uvRect(int left, int top, int right, int bottom) {
        return new RectF(((float) left) / ((float) this.width), ((float) top) / ((float) this.height), ((float) right) / ((float) this.width), ((float) bottom) / ((float) this.height));
    }
}
