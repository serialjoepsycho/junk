package com.watabou.gltextures;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import com.watabou.glwrap.Texture;

public class Gradient extends SmartTexture {
    public Gradient(int[] colors) {
        super(Bitmap.createBitmap(colors.length, 1, Config.ARGB_8888));
        for (int i = 0; i < colors.length; i++) {
            this.bitmap.setPixel(i, 0, colors[i]);
        }
        bitmap(this.bitmap);
        filter(Texture.LINEAR, Texture.LINEAR);
        wrap(Texture.CLAMP, Texture.CLAMP);
        TextureCache.add(Gradient.class, this);
    }
}
