package com.watabou.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Graph {

    public interface Node {
        int distance();

        void distance(int i);

        Collection<? extends Node> edges();

        int price();

        void price(int i);
    }

    public static <T extends Node> void setPrice(List<T> nodes, int value) {
        for (T node : nodes) {
            node.price(value);
        }
    }

    public static <T extends Node> void buildDistanceMap(Collection<T> nodes, Node focus) {
        for (T node : nodes) {
            node.distance(Integer.MAX_VALUE);
        }
        LinkedList<Node> queue = new LinkedList();
        focus.distance(0);
        queue.add(focus);
        while (!queue.isEmpty()) {
            Node node2 = (Node) queue.poll();
            int distance = node2.distance();
            int price = node2.price();
            for (Node edge : node2.edges()) {
                if (edge.distance() > distance + price) {
                    queue.add(edge);
                    edge.distance(distance + price);
                }
            }
        }
    }

    public static <T extends Node> List<T> buildPath(Collection<T> collection, T from, T to) {
        List<T> path = new ArrayList();
        T next;
        for (T room = from; room != to; room = next) {
            int min = room.distance();
            next = null;
            Iterator it = room.edges().iterator();
            while (it.hasNext()) {
                T edge = (Node) it.next();
                int distance = edge.distance();
                if (distance < min) {
                    min = distance;
                    next = edge;
                }
            }
            if (next == null) {
                return null;
            }
            path.add(next);
        }
        return path;
    }
}
