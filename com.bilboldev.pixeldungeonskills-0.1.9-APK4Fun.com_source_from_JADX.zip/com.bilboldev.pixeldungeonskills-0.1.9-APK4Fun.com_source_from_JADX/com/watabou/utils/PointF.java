package com.watabou.utils;

import android.annotation.SuppressLint;
import android.util.FloatMath;
import com.watabou.pixeldungeon.BuildConfig;

@SuppressLint({"FloatMath"})
public class PointF {
    public static final float G2R = 0.017453292f;
    public static final float PI = 3.1415925f;
    public static final float PI2 = 6.283185f;
    public float f24x;
    public float f25y;

    public PointF(float x, float y) {
        this.f24x = x;
        this.f25y = y;
    }

    public PointF(PointF p) {
        this.f24x = p.f24x;
        this.f25y = p.f25y;
    }

    public PointF(Point p) {
        this.f24x = (float) p.f18x;
        this.f25y = (float) p.f19y;
    }

    public PointF clone() {
        return new PointF(this);
    }

    public PointF scale(float f) {
        this.f24x *= f;
        this.f25y *= f;
        return this;
    }

    public PointF invScale(float f) {
        this.f24x /= f;
        this.f25y /= f;
        return this;
    }

    public PointF set(float x, float y) {
        this.f24x = x;
        this.f25y = y;
        return this;
    }

    public PointF set(PointF p) {
        this.f24x = p.f24x;
        this.f25y = p.f25y;
        return this;
    }

    public PointF set(float v) {
        this.f24x = v;
        this.f25y = v;
        return this;
    }

    public PointF polar(float a, float l) {
        this.f24x = FloatMath.cos(a) * l;
        this.f25y = FloatMath.sin(a) * l;
        return this;
    }

    public PointF offset(float dx, float dy) {
        this.f24x += dx;
        this.f25y += dy;
        return this;
    }

    public PointF offset(PointF p) {
        this.f24x += p.f24x;
        this.f25y += p.f25y;
        return this;
    }

    public PointF negate() {
        this.f24x = -this.f24x;
        this.f25y = -this.f25y;
        return this;
    }

    public PointF normalize() {
        float l = length();
        this.f24x /= l;
        this.f25y /= l;
        return this;
    }

    public Point floor() {
        return new Point((int) this.f24x, (int) this.f25y);
    }

    public float length() {
        return FloatMath.sqrt((this.f24x * this.f24x) + (this.f25y * this.f25y));
    }

    public static PointF sum(PointF a, PointF b) {
        return new PointF(a.f24x + b.f24x, a.f25y + b.f25y);
    }

    public static PointF diff(PointF a, PointF b) {
        return new PointF(a.f24x - b.f24x, a.f25y - b.f25y);
    }

    public static PointF inter(PointF a, PointF b, float d) {
        return new PointF(a.f24x + ((b.f24x - a.f24x) * d), a.f25y + ((b.f25y - a.f25y) * d));
    }

    public static float distance(PointF a, PointF b) {
        float dx = a.f24x - b.f24x;
        float dy = a.f25y - b.f25y;
        return FloatMath.sqrt((dx * dx) + (dy * dy));
    }

    public static float angle(PointF start, PointF end) {
        return (float) Math.atan2((double) (end.f25y - start.f25y), (double) (end.f24x - start.f24x));
    }

    public String toString() {
        return BuildConfig.VERSION_NAME + this.f24x + ", " + this.f25y;
    }
}
