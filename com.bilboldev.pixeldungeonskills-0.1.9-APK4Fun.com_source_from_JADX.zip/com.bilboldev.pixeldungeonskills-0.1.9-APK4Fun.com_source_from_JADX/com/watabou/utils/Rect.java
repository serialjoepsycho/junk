package com.watabou.utils;

public class Rect {
    public int bottom;
    public int left;
    public int right;
    public int top;

    public Rect() {
        this(0, 0, 0, 0);
    }

    public Rect(Rect rect) {
        this(rect.left, rect.top, rect.right, rect.bottom);
    }

    public Rect(int left, int top, int right, int bottom) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }

    public int width() {
        return this.right - this.left;
    }

    public int height() {
        return this.bottom - this.top;
    }

    public int square() {
        return (this.right - this.left) * (this.bottom - this.top);
    }

    public Rect set(int left, int top, int right, int bottom) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
        return this;
    }

    public Rect set(Rect rect) {
        return set(rect.left, rect.top, rect.right, rect.bottom);
    }

    public boolean isEmpty() {
        return this.right <= this.left || this.bottom <= this.top;
    }

    public Rect setEmpty() {
        this.bottom = 0;
        this.top = 0;
        this.right = 0;
        this.left = 0;
        return this;
    }

    public Rect intersect(Rect other) {
        Rect result = new Rect();
        result.left = Math.max(this.left, other.left);
        result.right = Math.min(this.right, other.right);
        result.top = Math.max(this.top, other.top);
        result.bottom = Math.min(this.bottom, other.bottom);
        return result;
    }

    public Rect union(int x, int y) {
        if (isEmpty()) {
            return set(x, y, x + 1, y + 1);
        }
        if (x < this.left) {
            this.left = x;
        } else if (x >= this.right) {
            this.right = x + 1;
        }
        if (y < this.top) {
            this.top = y;
            return this;
        } else if (y < this.bottom) {
            return this;
        } else {
            this.bottom = y + 1;
            return this;
        }
    }

    public Rect union(Point p) {
        return union(p.f18x, p.f19y);
    }

    public boolean inside(Point p) {
        return p.f18x >= this.left && p.f18x < this.right && p.f19y >= this.top && p.f19y < this.bottom;
    }

    public Rect shrink(int d) {
        return new Rect(this.left + d, this.top + d, this.right - d, this.bottom - d);
    }

    public Rect shrink() {
        return shrink(1);
    }
}
