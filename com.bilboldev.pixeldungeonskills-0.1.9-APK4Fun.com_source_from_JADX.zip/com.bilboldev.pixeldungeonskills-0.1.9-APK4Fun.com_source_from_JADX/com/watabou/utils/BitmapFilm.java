package com.watabou.utils;

import android.graphics.Bitmap;
import android.graphics.Rect;
import java.util.HashMap;

public class BitmapFilm {
    public Bitmap bitmap;
    protected HashMap<Object, Rect> frames;

    public BitmapFilm(Bitmap bitmap) {
        this.frames = new HashMap();
        this.bitmap = bitmap;
        add(null, new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight()));
    }

    public BitmapFilm(Bitmap bitmap, int width) {
        this(bitmap, width, bitmap.getHeight());
    }

    public BitmapFilm(Bitmap bitmap, int width, int height) {
        this.frames = new HashMap();
        this.bitmap = bitmap;
        int cols = bitmap.getWidth() / width;
        int rows = bitmap.getHeight() / height;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                add(Integer.valueOf((i * cols) + j), new Rect(j * width, i * height, (j + 1) * width, (i + 1) * height));
            }
        }
    }

    public void add(Object id, Rect rect) {
        this.frames.put(id, rect);
    }

    public Rect get(Object id) {
        return (Rect) this.frames.get(id);
    }
}
