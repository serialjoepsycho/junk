package com.watabou.utils;

import java.util.LinkedList;

public class Signal<T> {
    private boolean canceled;
    private LinkedList<Listener<T>> listeners;
    private boolean stackMode;

    public interface Listener<T> {
        void onSignal(T t);
    }

    public Signal() {
        this(false);
    }

    public Signal(boolean stackMode) {
        this.listeners = new LinkedList();
        this.stackMode = stackMode;
    }

    public void add(Listener<T> listener) {
        if (!this.listeners.contains(listener)) {
            if (this.stackMode) {
                this.listeners.addFirst(listener);
            } else {
                this.listeners.addLast(listener);
            }
        }
    }

    public void remove(Listener<T> listener) {
        this.listeners.remove(listener);
    }

    public void removeAll() {
        this.listeners.clear();
    }

    public void replace(Listener<T> listener) {
        removeAll();
        add(listener);
    }

    public int numListeners() {
        return this.listeners.size();
    }

    public void dispatch(T t) {
        Listener[] list = (Listener[]) this.listeners.toArray(new Listener[0]);
        this.canceled = false;
        for (Listener<T> listener : list) {
            if (this.listeners.contains(listener)) {
                listener.onSignal(t);
                if (this.canceled) {
                    return;
                }
            }
        }
    }

    public void cancel() {
        this.canceled = true;
    }
}
