package com.watabou.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import java.io.IOException;
import java.util.HashMap;

public class BitmapCache {
    private static final String DEFAULT = "__default";
    public static Context context;
    private static HashMap<String, Layer> layers;
    private static Options opts;

    private static class Layer extends HashMap<Object, Bitmap> {
        private Layer() {
        }

        public void clear() {
            for (Bitmap bmp : values()) {
                bmp.recycle();
            }
            super.clear();
        }
    }

    static {
        layers = new HashMap();
        opts = new Options();
        opts.inDither = false;
    }

    public static Bitmap get(String assetName) {
        return get(DEFAULT, assetName);
    }

    public static Bitmap get(String layerName, String assetName) {
        Layer layer;
        if (layers.containsKey(layerName)) {
            layer = (Layer) layers.get(layerName);
        } else {
            layer = new Layer();
            layers.put(layerName, layer);
        }
        if (layer.containsKey(assetName)) {
            return (Bitmap) layer.get(assetName);
        }
        try {
            Bitmap bmp = BitmapFactory.decodeStream(context.getResources().getAssets().open(assetName), null, opts);
            layer.put(assetName, bmp);
            return bmp;
        } catch (IOException e) {
            return null;
        }
    }

    public static Bitmap get(int resID) {
        return get(DEFAULT, resID);
    }

    public static Bitmap get(String layerName, int resID) {
        Layer layer;
        if (layers.containsKey(layerName)) {
            layer = (Layer) layers.get(layerName);
        } else {
            layer = new Layer();
            layers.put(layerName, layer);
        }
        if (layer.containsKey(Integer.valueOf(resID))) {
            return (Bitmap) layer.get(Integer.valueOf(resID));
        }
        Bitmap bmp = BitmapFactory.decodeResource(context.getResources(), resID);
        layer.put(Integer.valueOf(resID), bmp);
        return bmp;
    }

    public static void clear(String layerName) {
        if (layers.containsKey(layerName)) {
            ((Layer) layers.get(layerName)).clear();
            layers.remove(layerName);
        }
    }

    public static void clear() {
        for (Layer layer : layers.values()) {
            layer.clear();
        }
        layers.clear();
    }
}
