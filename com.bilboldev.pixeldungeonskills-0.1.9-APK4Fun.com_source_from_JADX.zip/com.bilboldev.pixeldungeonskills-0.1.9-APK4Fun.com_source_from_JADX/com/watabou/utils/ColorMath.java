package com.watabou.utils;

import com.watabou.pixeldungeon.items.keys.Key;

public class ColorMath {
    public static int interpolate(int A, int B, float p) {
        if (p <= 0.0f) {
            return A;
        }
        if (p >= Key.TIME_TO_UNLOCK) {
            return B;
        }
        float p1 = Key.TIME_TO_UNLOCK - p;
        return ((((int) ((((float) (A >> 16)) * p1) + (((float) (B >> 16)) * p))) << 16) + (((int) ((((float) ((A >> 8) & 255)) * p1) + (((float) ((B >> 8) & 255)) * p))) << 8)) + ((int) ((((float) (A & 255)) * p1) + (((float) (B & 255)) * p)));
    }

    public static int interpolate(float p, int... colors) {
        if (p <= 0.0f) {
            return colors[0];
        }
        if (p >= Key.TIME_TO_UNLOCK) {
            return colors[colors.length - 1];
        }
        int segment = (int) (((float) colors.length) * p);
        return interpolate(colors[segment], colors[segment + 1], (((float) (colors.length - 1)) * p) % Key.TIME_TO_UNLOCK);
    }

    public static int random(int a, int b) {
        return interpolate(a, b, Random.Float());
    }
}
