package com.watabou.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Bundle {
    private static final String CLASS_NAME = "__className";
    private static HashMap<String, String> aliases;
    private JSONObject data;

    static {
        aliases = new HashMap();
    }

    public Bundle() {
        this(new JSONObject());
    }

    public String toString() {
        return this.data.toString();
    }

    private Bundle(JSONObject data) {
        this.data = data;
    }

    public boolean isNull() {
        return this.data == null;
    }

    public ArrayList<String> fields() {
        ArrayList<String> result = new ArrayList();
        Iterator<String> iterator = this.data.keys();
        while (iterator.hasNext()) {
            result.add(iterator.next());
        }
        return result;
    }

    public boolean contains(String key) {
        return !this.data.isNull(key);
    }

    public boolean getBoolean(String key) {
        return this.data.optBoolean(key);
    }

    public int getInt(String key) {
        return this.data.optInt(key);
    }

    public float getFloat(String key) {
        return (float) this.data.optDouble(key);
    }

    public String getString(String key) {
        return this.data.optString(key);
    }

    public Bundle getBundle(String key) {
        return new Bundle(this.data.optJSONObject(key));
    }

    private Bundlable get() {
        try {
            String clName = getString(CLASS_NAME);
            if (aliases.containsKey(clName)) {
                clName = (String) aliases.get(clName);
            }
            Class<?> cl = Class.forName(clName);
            if (cl == null) {
                return null;
            }
            Bundlable object = (Bundlable) cl.newInstance();
            object.restoreFromBundle(this);
            return object;
        } catch (Exception e) {
            return null;
        }
    }

    public Bundlable get(String key) {
        return getBundle(key).get();
    }

    public <E extends Enum<E>> E getEnum(String key, Class<E> enumClass) {
        try {
            return Enum.valueOf(enumClass, this.data.getString(key));
        } catch (JSONException e) {
            return ((Enum[]) enumClass.getEnumConstants())[0];
        }
    }

    public int[] getIntArray(String key) {
        try {
            JSONArray array = this.data.getJSONArray(key);
            int length = array.length();
            int[] iArr = new int[length];
            for (int i = 0; i < length; i++) {
                iArr[i] = array.getInt(i);
            }
            return iArr;
        } catch (JSONException e) {
            return null;
        }
    }

    public boolean[] getBooleanArray(String key) {
        try {
            JSONArray array = this.data.getJSONArray(key);
            int length = array.length();
            boolean[] zArr = new boolean[length];
            for (int i = 0; i < length; i++) {
                zArr[i] = array.getBoolean(i);
            }
            return zArr;
        } catch (JSONException e) {
            return null;
        }
    }

    public String[] getStringArray(String key) {
        try {
            JSONArray array = this.data.getJSONArray(key);
            int length = array.length();
            String[] strArr = new String[length];
            for (int i = 0; i < length; i++) {
                strArr[i] = array.getString(i);
            }
            return strArr;
        } catch (JSONException e) {
            return null;
        }
    }

    public Collection<Bundlable> getCollection(String key) {
        ArrayList<Bundlable> list = new ArrayList();
        try {
            JSONArray array = this.data.getJSONArray(key);
            for (int i = 0; i < array.length(); i++) {
                list.add(new Bundle(array.getJSONObject(i)).get());
            }
        } catch (JSONException e) {
        }
        return list;
    }

    public void put(String key, boolean value) {
        try {
            this.data.put(key, value);
        } catch (JSONException e) {
        }
    }

    public void put(String key, int value) {
        try {
            this.data.put(key, value);
        } catch (JSONException e) {
        }
    }

    public void put(String key, float value) {
        try {
            this.data.put(key, (double) value);
        } catch (JSONException e) {
        }
    }

    public void put(String key, String value) {
        try {
            this.data.put(key, value);
        } catch (JSONException e) {
        }
    }

    public void put(String key, Bundle bundle) {
        try {
            this.data.put(key, bundle.data);
        } catch (JSONException e) {
        }
    }

    public void put(String key, Bundlable object) {
        if (object != null) {
            try {
                Bundle bundle = new Bundle();
                bundle.put(CLASS_NAME, object.getClass().getName());
                object.storeInBundle(bundle);
                this.data.put(key, bundle.data);
            } catch (JSONException e) {
            }
        }
    }

    public void put(String key, Enum<?> value) {
        if (value != null) {
            try {
                this.data.put(key, value.name());
            } catch (JSONException e) {
            }
        }
    }

    public void put(String key, int[] array) {
        try {
            JSONArray jsonArray = new JSONArray();
            for (int i = 0; i < array.length; i++) {
                jsonArray.put(i, array[i]);
            }
            this.data.put(key, jsonArray);
        } catch (JSONException e) {
        }
    }

    public void put(String key, boolean[] array) {
        try {
            JSONArray jsonArray = new JSONArray();
            for (int i = 0; i < array.length; i++) {
                jsonArray.put(i, array[i]);
            }
            this.data.put(key, jsonArray);
        } catch (JSONException e) {
        }
    }

    public void put(String key, String[] array) {
        try {
            JSONArray jsonArray = new JSONArray();
            for (int i = 0; i < array.length; i++) {
                jsonArray.put(i, array[i]);
            }
            this.data.put(key, jsonArray);
        } catch (JSONException e) {
        }
    }

    public void put(String key, Collection<? extends Bundlable> collection) {
        JSONArray array = new JSONArray();
        for (Bundlable object : collection) {
            Bundle bundle = new Bundle();
            bundle.put(CLASS_NAME, object.getClass().getName());
            object.storeInBundle(bundle);
            array.put(bundle.data);
        }
        try {
            this.data.put(key, array);
        } catch (JSONException e) {
        }
    }

    public static Bundle read(InputStream stream) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
            StringBuilder all = new StringBuilder();
            for (String line = reader.readLine(); line != null; line = reader.readLine()) {
                all.append(line);
            }
            JSONObject json = (JSONObject) new JSONTokener(all.toString()).nextValue();
            reader.close();
            return new Bundle(json);
        } catch (Exception e) {
            return null;
        }
    }

    public static Bundle read(byte[] bytes) {
        try {
            return new Bundle((JSONObject) new JSONTokener(new String(bytes)).nextValue());
        } catch (JSONException e) {
            return null;
        }
    }

    public static boolean write(Bundle bundle, OutputStream stream) {
        try {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stream));
            writer.write(bundle.data.toString());
            writer.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static void addAlias(Class<?> cl, String alias) {
        aliases.put(alias, cl.getName());
    }
}
