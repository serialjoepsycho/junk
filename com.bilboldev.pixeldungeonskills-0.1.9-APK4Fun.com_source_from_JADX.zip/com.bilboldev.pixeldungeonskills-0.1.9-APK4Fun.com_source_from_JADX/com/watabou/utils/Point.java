package com.watabou.utils;

public class Point {
    public int f18x;
    public int f19y;

    public Point(int x, int y) {
        this.f18x = x;
        this.f19y = y;
    }

    public Point(Point p) {
        this.f18x = p.f18x;
        this.f19y = p.f19y;
    }

    public Point set(int x, int y) {
        this.f18x = x;
        this.f19y = y;
        return this;
    }

    public Point set(Point p) {
        this.f18x = p.f18x;
        this.f19y = p.f19y;
        return this;
    }

    public Point clone() {
        return new Point(this);
    }

    public Point scale(float f) {
        this.f18x = (int) (((float) this.f18x) * f);
        this.f19y = (int) (((float) this.f19y) * f);
        return this;
    }

    public Point offset(int dx, int dy) {
        this.f18x += dx;
        this.f19y += dy;
        return this;
    }

    public Point offset(Point d) {
        this.f18x += d.f18x;
        this.f19y += d.f19y;
        return this;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Point)) {
            return false;
        }
        Point p = (Point) obj;
        if (p.f18x == this.f18x && p.f19y == this.f19y) {
            return true;
        }
        return false;
    }
}
