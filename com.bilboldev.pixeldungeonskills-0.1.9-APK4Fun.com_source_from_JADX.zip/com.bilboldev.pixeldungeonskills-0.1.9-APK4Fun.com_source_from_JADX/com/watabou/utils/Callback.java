package com.watabou.utils;

public interface Callback {
    void call();
}
