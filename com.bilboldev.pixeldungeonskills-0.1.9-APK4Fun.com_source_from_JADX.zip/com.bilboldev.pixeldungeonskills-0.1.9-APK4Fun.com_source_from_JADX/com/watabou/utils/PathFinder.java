package com.watabou.utils;

import com.watabou.pixeldungeon.items.quest.Pickaxe;
import java.util.Arrays;
import java.util.LinkedList;

public class PathFinder {
    private static int[] dir;
    public static int[] distance;
    private static boolean[] goals;
    private static int[] queue;
    private static int size;

    public static class Path extends LinkedList<Integer> {
    }

    static {
        size = 0;
    }

    public static void setMapSize(int width, int height) {
        int size = width * height;
        if (size != size) {
            size = size;
            distance = new int[size];
            goals = new boolean[size];
            queue = new int[size];
            dir = new int[]{-1, 1, -width, width, (-width) - 1, (-width) + 1, width - 1, width + 1};
        }
    }

    public static Path find(int from, int to, boolean[] passable) {
        if (!buildDistanceMap(from, to, passable)) {
            return null;
        }
        Path result = new Path();
        int s = from;
        do {
            int minD = distance[s];
            int mins = s;
            for (int i : dir) {
                int n = s + i;
                int thisD = distance[n];
                if (thisD < minD) {
                    minD = thisD;
                    mins = n;
                }
            }
            s = mins;
            result.add(Integer.valueOf(s));
        } while (s != to);
        return result;
    }

    public static int getStep(int from, int to, boolean[] passable) {
        if (!buildDistanceMap(from, to, passable)) {
            return -1;
        }
        int minD = distance[from];
        int best = from;
        for (int i : dir) {
            int step = from + i;
            int stepD = distance[step];
            if (stepD < minD) {
                minD = stepD;
                best = step;
            }
        }
        return best;
    }

    public static int getStepBack(int cur, int from, boolean[] passable) {
        int d = buildEscapeDistanceMap(cur, from, Pickaxe.TIME_TO_MINE, passable);
        for (int i = 0; i < size; i++) {
            goals[i] = distance[i] == d;
        }
        if (!buildDistanceMap(cur, goals, passable)) {
            return -1;
        }
        int s = cur;
        int minD = distance[s];
        int mins = s;
        for (int i2 : dir) {
            int n = s + i2;
            int thisD = distance[n];
            if (thisD < minD) {
                minD = thisD;
                mins = n;
            }
        }
        return mins;
    }

    private static boolean buildDistanceMap(int from, int to, boolean[] passable) {
        if (from == to) {
            return false;
        }
        int head;
        Arrays.fill(distance, Integer.MAX_VALUE);
        int tail = 0 + 1;
        queue[0] = to;
        distance[to] = 0;
        int tail2 = tail;
        int head2 = 0;
        while (head2 < tail2) {
            head = head2 + 1;
            int step = queue[head2];
            if (step == from) {
                return true;
            }
            int nextDistance = distance[step] + 1;
            for (int i : dir) {
                int n = step + i;
                if (n == from || (n >= 0 && n < size && passable[n] && distance[n] > nextDistance)) {
                    tail = tail2 + 1;
                    queue[tail2] = n;
                    distance[n] = nextDistance;
                    tail2 = tail;
                }
            }
            head2 = head;
        }
        head = head2;
        return false;
    }

    public static void buildDistanceMap(int to, boolean[] passable, int limit) {
        int head;
        Arrays.fill(distance, Integer.MAX_VALUE);
        int tail = 0 + 1;
        queue[0] = to;
        distance[to] = 0;
        int tail2 = tail;
        int head2 = 0;
        while (head2 < tail2) {
            head = head2 + 1;
            int step = queue[head2];
            int nextDistance = distance[step] + 1;
            if (nextDistance <= limit) {
                for (int i : dir) {
                    int n = step + i;
                    if (n >= 0 && n < size && passable[n] && distance[n] > nextDistance) {
                        tail = tail2 + 1;
                        queue[tail2] = n;
                        distance[n] = nextDistance;
                        tail2 = tail;
                    }
                }
                head2 = head;
            } else {
                return;
            }
        }
        head = head2;
    }

    private static boolean buildDistanceMap(int from, boolean[] to, boolean[] passable) {
        if (to[from]) {
            return false;
        }
        Arrays.fill(distance, Integer.MAX_VALUE);
        int tail = 0;
        for (int i = 0; i < size; i++) {
            if (to[i]) {
                int tail2 = tail + 1;
                queue[tail] = i;
                distance[i] = 0;
                tail = tail2;
            }
        }
        int head = 0;
        while (head < tail) {
            int i2 = head + 1;
            int step = queue[head];
            if (step == from) {
                return true;
            }
            int nextDistance = distance[step] + 1;
            for (int i3 : dir) {
                int n = step + i3;
                if (n == from || (n >= 0 && n < size && passable[n] && distance[n] > nextDistance)) {
                    tail2 = tail + 1;
                    queue[tail] = n;
                    distance[n] = nextDistance;
                    tail = tail2;
                }
            }
            head = i2;
        }
        return false;
    }

    private static int buildEscapeDistanceMap(int cur, int from, float factor, boolean[] passable) {
        int head;
        Arrays.fill(distance, Integer.MAX_VALUE);
        int destDist = Integer.MAX_VALUE;
        int tail = 0 + 1;
        queue[0] = from;
        distance[from] = 0;
        int dist = 0;
        int tail2 = tail;
        int head2 = 0;
        while (head2 < tail2) {
            head = head2 + 1;
            int step = queue[head2];
            dist = distance[step];
            if (dist > destDist) {
                return destDist;
            }
            if (step == cur) {
                destDist = ((int) (((float) dist) * factor)) + 1;
            }
            int nextDistance = dist + 1;
            for (int i : dir) {
                int n = step + i;
                if (n >= 0 && n < size && passable[n] && distance[n] > nextDistance) {
                    tail = tail2 + 1;
                    queue[tail2] = n;
                    distance[n] = nextDistance;
                    tail2 = tail;
                }
            }
            head2 = head;
        }
        head = head2;
        return dist;
    }

    private static void buildDistanceMap(int to, boolean[] passable) {
        Arrays.fill(distance, Integer.MAX_VALUE);
        int tail = 0 + 1;
        queue[0] = to;
        distance[to] = 0;
        int tail2 = tail;
        int head = 0;
        while (head < tail2) {
            int head2 = head + 1;
            int step = queue[head];
            int nextDistance = distance[step] + 1;
            for (int i : dir) {
                int n = step + i;
                if (n >= 0 && n < size && passable[n] && distance[n] > nextDistance) {
                    tail = tail2 + 1;
                    queue[tail2] = n;
                    distance[n] = nextDistance;
                    tail2 = tail;
                }
            }
            head = head2;
        }
    }
}
