package com.watabou.billing;

public class Base64DecoderException extends Exception {
    private static final long serialVersionUID = 1;

    public Base64DecoderException(String s) {
        super(s);
    }
}
