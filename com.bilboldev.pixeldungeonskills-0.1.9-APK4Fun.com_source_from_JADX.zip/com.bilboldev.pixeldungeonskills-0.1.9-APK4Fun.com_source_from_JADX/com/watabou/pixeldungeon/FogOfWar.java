package com.watabou.pixeldungeon;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import com.watabou.gltextures.SmartTexture;
import com.watabou.gltextures.TextureCache;
import com.watabou.glwrap.Texture;
import com.watabou.noosa.Image;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.GameScene;
import java.util.Arrays;

public class FogOfWar extends Image {
    private static final int INVISIBLE = -16777216;
    private static final int MAPPED = -867950063;
    private static final int VISIBLE = 0;
    private static final int VISITED = -871296751;
    private int height2;
    private int pHeight;
    private int pWidth;
    private int[] pixels;
    private int width2;

    private class FogTexture extends SmartTexture {
        public FogTexture() {
            super(Bitmap.createBitmap(FogOfWar.this.width2, FogOfWar.this.height2, Config.ARGB_8888));
            filter(Texture.LINEAR, Texture.LINEAR);
            TextureCache.add(FogOfWar.class, this);
        }

        public void reload() {
            super.reload();
            GameScene.afterObserve();
        }
    }

    public FogOfWar(int mapWidth, int mapHeight) {
        this.pWidth = mapWidth + 1;
        this.pHeight = mapHeight + 1;
        this.width2 = 1;
        while (this.width2 < this.pWidth) {
            this.width2 <<= 1;
        }
        this.height2 = 1;
        while (this.height2 < this.pHeight) {
            this.height2 <<= 1;
        }
        this.width = ((float) this.width2) * ShadowBox.SIZE;
        this.height = ((float) this.height2) * ShadowBox.SIZE;
        texture(new FogTexture());
        this.scale.set(ShadowBox.SIZE, ShadowBox.SIZE);
        float f = (-1098907648) / Pickaxe.TIME_TO_MINE;
        this.y = f;
        this.x = f;
    }

    public void updateVisibility(boolean[] visible, boolean[] visited, boolean[] mapped) {
        if (this.pixels == null) {
            this.pixels = new int[(this.width2 * this.height2)];
            Arrays.fill(this.pixels, INVISIBLE);
        }
        for (int i = 1; i < this.pHeight - 1; i++) {
            int pos = (this.pWidth - 1) * i;
            for (int j = 1; j < this.pWidth - 1; j++) {
                pos++;
                int c = INVISIBLE;
                if (visible[pos] && visible[pos - (this.pWidth - 1)] && visible[pos - 1] && visible[(pos - (this.pWidth - 1)) - 1]) {
                    c = VISIBLE;
                } else if (visited[pos] && visited[pos - (this.pWidth - 1)] && visited[pos - 1] && visited[(pos - (this.pWidth - 1)) - 1]) {
                    c = VISITED;
                } else if (mapped[pos] && mapped[pos - (this.pWidth - 1)] && mapped[pos - 1] && mapped[(pos - (this.pWidth - 1)) - 1]) {
                    c = MAPPED;
                }
                this.pixels[(this.width2 * i) + j] = c;
            }
        }
        this.texture.pixels(this.width2, this.height2, this.pixels);
    }
}
