package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Scene;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.items.Amulet;
import com.watabou.pixeldungeon.levels.Level.Feeling;
import com.watabou.pixeldungeon.levels.painters.Painter;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Random;
import java.util.Arrays;

public class LastLevel extends Level {
    private static final int SIZE = 7;
    private int pedestal;

    public LastLevel() {
        this.color1 = 8393984;
        this.color2 = 10913057;
    }

    public String tilesTex() {
        return Assets.TILES_HALLS;
    }

    public String waterTex() {
        return Assets.WATER_HALLS;
    }

    protected boolean build() {
        Arrays.fill(this.map, 4);
        Painter.fill(this, 1, 1, SIZE, SIZE, 63);
        Painter.fill(this, 2, 2, 5, 5, 1);
        Painter.fill(this, 3, 3, 3, 3, 14);
        this.entrance = 228;
        this.map[this.entrance] = SIZE;
        this.exit = this.entrance - 224;
        this.map[this.exit] = 25;
        this.pedestal = ItemSpriteSheet.SCROLL_BLOODY;
        this.map[this.pedestal] = 11;
        int[] iArr = this.map;
        int i = this.pedestal - 1;
        this.map[this.pedestal + 1] = 36;
        iArr[i] = 36;
        this.feeling = Feeling.NONE;
        return true;
    }

    protected void decorate() {
        for (int i = 0; i < Level.LENGTH; i++) {
            if (this.map[i] == 1 && Random.Int(10) == 0) {
                this.map[i] = 24;
            }
        }
    }

    protected void createMobs() {
    }

    protected void createItems() {
        drop(new Amulet(), this.pedestal);
    }

    public int randomRespawnCell() {
        return -1;
    }

    public String tileName(int tile) {
        switch (tile) {
            case WndUpdates.ID_CAVES /*2*/:
                return "Embermoss";
            case BuffIndicator.FROST /*15*/:
                return "Emberfungi";
            case ItemSpriteSheet.RING_RUBY /*35*/:
            case ItemSpriteSheet.RING_AMETHYST /*36*/:
                return "Pillar";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Cold lava";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case ItemSpriteSheet.RING_RUBY /*35*/:
            case ItemSpriteSheet.RING_AMETHYST /*36*/:
                return "The pillar is made of real humanoid skulls. Awesome.";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "It looks like lava, but it's cold and probably safe to touch.";
            default:
                return super.tileDesc(tile);
        }
    }

    public void addVisuals(Scene scene) {
        HallsLevel.addVisuals(this, scene);
    }
}
