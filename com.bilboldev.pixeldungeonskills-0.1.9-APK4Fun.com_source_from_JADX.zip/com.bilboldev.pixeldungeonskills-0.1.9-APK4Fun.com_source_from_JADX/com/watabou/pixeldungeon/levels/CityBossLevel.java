package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Scene;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Bones;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Heap.Type;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.SkeletonKey;
import com.watabou.pixeldungeon.levels.painters.Painter;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;

public class CityBossLevel extends Level {
    private static final int CENTER = 15;
    private static final int CHAMBER_HEIGHT = 3;
    private static final String DOOR = "door";
    private static final String DROPPED = "droppped";
    private static final String ENTERED = "entered";
    private static final int HALL_HEIGHT = 15;
    private static final int HALL_WIDTH = 7;
    private static final int LEFT = 12;
    private static final int TOP = 2;
    private int arenaDoor;
    private boolean enteredArena;
    private boolean keyDropped;

    public CityBossLevel() {
        this.color1 = 4941366;
        this.color2 = 15921906;
        this.enteredArena = false;
        this.keyDropped = false;
    }

    public String tilesTex() {
        return Assets.TILES_CITY;
    }

    public String waterTex() {
        return Assets.WATER_CITY;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(DOOR, this.arenaDoor);
        bundle.put(ENTERED, this.enteredArena);
        bundle.put(DROPPED, this.keyDropped);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.arenaDoor = bundle.getInt(DOOR);
        this.enteredArena = bundle.getBoolean(ENTERED);
        this.keyDropped = bundle.getBoolean(DROPPED);
    }

    protected boolean build() {
        Painter.fill(this, LEFT, TOP, HALL_WIDTH, HALL_HEIGHT, 1);
        Painter.fill(this, HALL_HEIGHT, TOP, 1, HALL_HEIGHT, 14);
        for (int y = CHAMBER_HEIGHT; y < 17; y += TOP) {
            this.map[((y * 32) + HALL_HEIGHT) - 2] = 36;
            this.map[((y * 32) + HALL_HEIGHT) + TOP] = 36;
        }
        int left = pedestal(true);
        int right = pedestal(false);
        int[] iArr = this.map;
        this.map[right] = 11;
        iArr[left] = 11;
        for (int i = left + 1; i < right; i++) {
            this.map[i] = 14;
        }
        this.exit = 47;
        this.map[this.exit] = 25;
        this.arenaDoor = 559;
        this.map[this.arenaDoor] = 5;
        Painter.fill(this, LEFT, 18, HALL_WIDTH, CHAMBER_HEIGHT, 1);
        Painter.fill(this, LEFT, 18, 1, CHAMBER_HEIGHT, 41);
        Painter.fill(this, 18, 18, 1, CHAMBER_HEIGHT, 41);
        this.entrance = (((Random.Int(TOP) + 19) * 32) + LEFT) + Random.Int(5);
        this.map[this.entrance] = HALL_WIDTH;
        return true;
    }

    protected void decorate() {
        for (int i = 0; i < Level.LENGTH; i++) {
            if (this.map[i] == 1 && Random.Int(10) == 0) {
                this.map[i] = 24;
            } else if (this.map[i] == 4 && Random.Int(8) == 0) {
                this.map[i] = LEFT;
            }
        }
        this.map[(this.arenaDoor + 32) + 1] = 29;
    }

    public static int pedestal(boolean left) {
        if (left) {
            return 301;
        }
        return 305;
    }

    protected void createMobs() {
    }

    public Actor respawner() {
        return null;
    }

    protected void createItems() {
        Item item = Bones.get();
        if (item != null) {
            while (true) {
                int pos = Random.IntRange(13, 17) + (Random.IntRange(18, 20) * 32);
                if (pos != this.entrance && this.map[pos] != 29) {
                    drop(item, pos).type = Type.SKELETON;
                    return;
                }
            }
        }
    }

    public int randomRespawnCell() {
        return -1;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void press(int r9, com.watabou.pixeldungeon.actors.Char r10) {
        /*
        r8 = this;
        super.press(r9, r10);
        r3 = r8.enteredArena;
        if (r3 != 0) goto L_0x007c;
    L_0x0007:
        r3 = r8.outsideEntraceRoom(r9);
        if (r3 == 0) goto L_0x007c;
    L_0x000d:
        r3 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r10 != r3) goto L_0x007c;
    L_0x0011:
        r3 = 1;
        r8.enteredArena = r3;
        r3 = com.watabou.pixeldungeon.Dungeon.depth;
        r0 = com.watabou.pixeldungeon.actors.mobs.Bestiary.mob(r3);
        r3 = r0.HUNTING;
        r0.state = r3;
        r1 = 0;
    L_0x001f:
        r3 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;
        r3 = com.watabou.utils.Random.Int(r3);
        r0.pos = r3;
        r3 = passable;
        r4 = r0.pos;
        r3 = r3[r4];
        if (r3 == 0) goto L_0x001f;
    L_0x002f:
        r3 = r0.pos;
        r3 = r8.outsideEntraceRoom(r3);
        if (r3 == 0) goto L_0x001f;
    L_0x0037:
        r3 = com.watabou.pixeldungeon.Dungeon.visible;
        r4 = r0.pos;
        r3 = r3[r4];
        if (r3 == 0) goto L_0x0046;
    L_0x003f:
        r2 = r1 + 1;
        r3 = 20;
        if (r1 < r3) goto L_0x007d;
    L_0x0045:
        r1 = r2;
    L_0x0046:
        com.watabou.pixeldungeon.scenes.GameScene.add(r0);
        r3 = com.watabou.pixeldungeon.Dungeon.visible;
        r4 = r0.pos;
        r3 = r3[r4];
        if (r3 == 0) goto L_0x006d;
    L_0x0051:
        r0.notice();
        r3 = r0.sprite;
        r4 = 0;
        r3.alpha(r4);
        r3 = r0.sprite;
        r3 = r3.parent;
        r4 = new com.watabou.noosa.tweeners.AlphaTweener;
        r5 = r0.sprite;
        r6 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        r7 = 1036831949; // 0x3dcccccd float:0.1 double:5.122630465E-315;
        r4.<init>(r5, r6, r7);
        r3.add(r4);
    L_0x006d:
        r3 = r8.arenaDoor;
        r4 = 10;
        com.watabou.pixeldungeon.levels.Level.set(r3, r4);
        r3 = r8.arenaDoor;
        com.watabou.pixeldungeon.scenes.GameScene.updateMap(r3);
        com.watabou.pixeldungeon.Dungeon.observe();
    L_0x007c:
        return;
    L_0x007d:
        r1 = r2;
        goto L_0x001f;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.watabou.pixeldungeon.levels.CityBossLevel.press(int, com.watabou.pixeldungeon.actors.Char):void");
    }

    public Heap drop(Item item, int cell) {
        if (!this.keyDropped && (item instanceof SkeletonKey)) {
            this.keyDropped = true;
            Level.set(this.arenaDoor, 5);
            GameScene.updateMap(this.arenaDoor);
            Dungeon.observe();
        }
        return super.drop(item, cell);
    }

    private boolean outsideEntraceRoom(int cell) {
        return cell / 32 < this.arenaDoor / 32;
    }

    public String tileName(int tile) {
        switch (tile) {
            case HALL_HEIGHT /*15*/:
                return "High blooming flowers";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Suspiciously colored water";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case HALL_WIDTH /*7*/:
                return "A ramp leads up to the upper depth.";
            case BuffIndicator.OOZE /*8*/:
                return "A ramp leads down to the lower depth.";
            case LEFT /*12*/:
            case BuffIndicator.BARKSKIN /*24*/:
                return "Several tiles are missing here.";
            case BuffIndicator.WEAKNESS /*14*/:
                return "Thick carpet covers the floor.";
            case ItemSpriteSheet.RING_RUBY /*35*/:
            case ItemSpriteSheet.RING_AMETHYST /*36*/:
                return "The statue depicts some dwarf standing in a heroic stance.";
            case ItemSpriteSheet.SCROLL_SOWILO /*41*/:
                return "The rows of books on different disciplines fill the bookshelf.";
            default:
                return super.tileDesc(tile);
        }
    }

    public void addVisuals(Scene scene) {
        CityLevel.addVisuals(this, scene);
    }
}
