package com.watabou.pixeldungeon.levels.traps;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Poison;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.PoisonParticle;

public class PoisonTrap {
    public static void trigger(int pos, Char ch) {
        if (ch != null) {
            ((Poison) Buff.affect(ch, Poison.class)).set(Poison.durationFactor(ch) * ((float) ((Dungeon.depth / 2) + 4)));
        }
        CellEmitter.center(pos).burst(PoisonParticle.SPLASH, 3);
    }
}
