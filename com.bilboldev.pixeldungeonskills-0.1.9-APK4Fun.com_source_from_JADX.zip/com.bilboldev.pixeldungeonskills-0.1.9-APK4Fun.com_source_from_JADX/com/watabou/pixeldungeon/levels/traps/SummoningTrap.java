package com.watabou.pixeldungeon.levels.traps;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class SummoningTrap {
    private static final float DELAY = 2.0f;
    private static final Mob DUMMY;

    /* renamed from: com.watabou.pixeldungeon.levels.traps.SummoningTrap.1 */
    static class C01081 extends Mob {
        C01081() {
        }
    }

    static {
        DUMMY = new C01081();
    }

    public static void trigger(int pos, Char c) {
        if (!Dungeon.bossLevel()) {
            if (c != null) {
                Actor.occupyCell(c);
            }
            int nMobs = 1;
            if (Random.Int(2) == 0) {
                nMobs = 1 + 1;
                if (Random.Int(2) == 0) {
                    nMobs++;
                }
            }
            ArrayList<Integer> candidates = new ArrayList();
            for (int i : Level.NEIGHBOURS8) {
                int p = pos + i;
                if (Actor.findChar(p) == null && (Level.passable[p] || Level.avoid[p])) {
                    candidates.add(Integer.valueOf(p));
                }
            }
            ArrayList<Integer> respawnPoints = new ArrayList();
            for (nMobs = 
            /* Method generation error in method: com.watabou.pixeldungeon.levels.traps.SummoningTrap.trigger(int, com.watabou.pixeldungeon.actors.Char):void
jadx.core.utils.exceptions.CodegenException: Error generate insn: PHI: (r4_3 'nMobs' int) = (r4_0 'nMobs' int), (r4_1 'nMobs' int), (r4_2 'nMobs' int) binds: {(r4_2 'nMobs' int)=B:8:0x001c, (r4_0 'nMobs' int)=B:5:0x0012, (r4_1 'nMobs' int)=B:7:0x001a} in method: com.watabou.pixeldungeon.levels.traps.SummoningTrap.trigger(int, com.watabou.pixeldungeon.actors.Char):void
	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:225)
	at jadx.core.codegen.RegionGen.makeLoop(RegionGen.java:184)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:61)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:87)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:53)
	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:93)
	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:118)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:57)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:87)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:53)
	at jadx.core.codegen.RegionGen.makeSimpleRegion(RegionGen.java:87)
	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:53)
	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:177)
	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:324)
	at jadx.core.codegen.ClassGen.addMethods(ClassGen.java:263)
	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:226)
	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:116)
	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:81)
	at jadx.core.codegen.CodeGen.visit(CodeGen.java:19)
	at jadx.core.ProcessClass.process(ProcessClass.java:43)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:281)
	at jadx.api.JavaClass.decompile(JavaClass.java:59)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:161)
Caused by: jadx.core.utils.exceptions.CodegenException: Unknown instruction: PHI in method: com.watabou.pixeldungeon.levels.traps.SummoningTrap.trigger(int, com.watabou.pixeldungeon.actors.Char):void
	at jadx.core.codegen.InsnGen.makeInsnBody(InsnGen.java:512)
	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:219)
	... 22 more
 */
        }
