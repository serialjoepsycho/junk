package com.watabou.pixeldungeon.levels.traps;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.utils.GLog;
import java.util.Iterator;

public class AlarmTrap {
    public static void trigger(int pos, Char ch) {
        Iterator it = Dungeon.level.mobs.iterator();
        while (it.hasNext()) {
            Char mob = (Mob) it.next();
            if (mob != ch) {
                mob.beckon(pos);
            }
        }
        if (Dungeon.visible[pos]) {
            GLog.m4w("The trap emits a piercing sound that echoes throughout the dungeon!", new Object[0]);
            CellEmitter.center(pos).start(Speck.factory(5), 0.3f, 3);
        }
        Sample.INSTANCE.play(Assets.SND_ALERT);
    }
}
