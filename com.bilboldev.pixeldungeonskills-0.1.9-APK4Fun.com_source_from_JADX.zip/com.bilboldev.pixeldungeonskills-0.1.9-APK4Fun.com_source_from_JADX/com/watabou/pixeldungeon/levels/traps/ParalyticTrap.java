package com.watabou.pixeldungeon.levels.traps;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.blobs.ParalyticGas;
import com.watabou.pixeldungeon.scenes.GameScene;

public class ParalyticTrap {
    public static void trigger(int pos, Char ch) {
        GameScene.add(Blob.seed(pos, (Dungeon.depth * 5) + 80, ParalyticGas.class));
    }
}
