package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Camera;
import com.watabou.noosa.Scene;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Bones;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.Bestiary;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Heap.Type;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.SkeletonKey;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.levels.painters.Painter;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;

public class CavesBossLevel extends Level {
    private static final String DOOR = "door";
    private static final String DROPPED = "droppped";
    private static final String ENTERED = "entered";
    private static final int ROOM_BOTTOM = 18;
    private static final int ROOM_LEFT = 14;
    private static final int ROOM_RIGHT = 18;
    private static final int ROOM_TOP = 14;
    private int arenaDoor;
    private boolean enteredArena;
    private boolean keyDropped;

    public CavesBossLevel() {
        this.color1 = 5459774;
        this.color2 = 12179041;
        this.viewDistance = 6;
        this.enteredArena = false;
        this.keyDropped = false;
    }

    public String tilesTex() {
        return Assets.TILES_CAVES;
    }

    public String waterTex() {
        return Assets.WATER_CAVES;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(DOOR, this.arenaDoor);
        bundle.put(ENTERED, this.enteredArena);
        bundle.put(DROPPED, this.keyDropped);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.arenaDoor = bundle.getInt(DOOR);
        this.enteredArena = bundle.getBoolean(ENTERED);
        this.keyDropped = bundle.getBoolean(DROPPED);
    }

    protected boolean build() {
        int i;
        int topMost = Integer.MAX_VALUE;
        for (i = 0; i < 8; i++) {
            int left;
            int right;
            int top;
            int bottom;
            if (Random.Int(2) == 0) {
                left = Random.Int(1, 11);
                right = 21;
            } else {
                left = 11;
                right = Random.Int(21, 31);
            }
            if (Random.Int(2) == 0) {
                top = Random.Int(2, 11);
                bottom = 21;
            } else {
                top = 11;
                bottom = Random.Int(17, 31);
            }
            Painter.fill(this, left, top, (right - left) + 1, (bottom - top) + 1, 1);
            if (top < topMost) {
                topMost = top;
                this.exit = Random.Int(left, right) + ((top - 1) * 32);
            }
        }
        this.map[this.exit] = 25;
        for (i = 0; i < Level.LENGTH; i++) {
            if (this.map[i] == 1 && Random.Int(6) == 0) {
                this.map[i] = 23;
            }
        }
        Painter.fill(this, 13, 13, 7, 7, 4);
        Painter.fill(this, ROOM_TOP, 15, 5, 4, 1);
        Painter.fill(this, ROOM_TOP, ROOM_TOP, 5, 1, 17);
        this.arenaDoor = Random.Int(ROOM_TOP, ROOM_RIGHT) + 608;
        this.map[this.arenaDoor] = 5;
        this.entrance = Random.Int(15, 17) + (Random.Int(15, 17) * 32);
        this.map[this.entrance] = 7;
        boolean[] patch = Patch.generate(0.45f, 6);
        i = 0;
        while (i < Level.LENGTH) {
            if (this.map[i] == 1 && patch[i]) {
                this.map[i] = 63;
            }
            i++;
        }
        return true;
    }

    protected void decorate() {
        int i;
        int sign;
        for (i = 33; i < 992; i++) {
            if (this.map[i] == 1) {
                int n = 0;
                if (this.map[i + 1] == 4) {
                    n = 0 + 1;
                }
                if (this.map[i - 1] == 4) {
                    n++;
                }
                if (this.map[i + 32] == 4) {
                    n++;
                }
                if (this.map[i - 32] == 4) {
                    n++;
                }
                if (Random.Int(8) <= n) {
                    this.map[i] = 24;
                }
            }
        }
        for (i = 0; i < Level.LENGTH; i++) {
            if (this.map[i] == 4 && Random.Int(8) == 0) {
                this.map[i] = 12;
            }
        }
        do {
            sign = Random.Int(ROOM_TOP, ROOM_RIGHT) + (Random.Int(ROOM_TOP, ROOM_RIGHT) * 32);
        } while (sign == this.entrance);
        this.map[sign] = 29;
    }

    protected void createMobs() {
    }

    public Actor respawner() {
        return null;
    }

    protected void createItems() {
        Item item = Bones.get();
        if (item != null) {
            while (true) {
                int pos = Random.IntRange(ROOM_TOP, ROOM_RIGHT) + (Random.IntRange(15, ROOM_RIGHT) * 32);
                if (pos != this.entrance && this.map[pos] != 29) {
                    drop(item, pos).type = Type.SKELETON;
                    return;
                }
            }
        }
    }

    public int randomRespawnCell() {
        return -1;
    }

    public void press(int cell, Char hero) {
        super.press(cell, hero);
        if (!this.enteredArena && outsideEntraceRoom(cell) && hero == Dungeon.hero) {
            this.enteredArena = true;
            Mob boss = Bestiary.mob(Dungeon.depth);
            boss.state = boss.HUNTING;
            while (true) {
                boss.pos = Random.Int(Level.LENGTH);
                if (passable[boss.pos] && outsideEntraceRoom(boss.pos) && !Dungeon.visible[boss.pos]) {
                    GameScene.add(boss);
                    Level.set(this.arenaDoor, 4);
                    GameScene.updateMap(this.arenaDoor);
                    Dungeon.observe();
                    CellEmitter.get(this.arenaDoor).start(Speck.factory(8), 0.07f, 10);
                    Camera.main.shake(CurareDart.DURATION, 0.7f);
                    Sample.INSTANCE.play(Assets.SND_ROCKS);
                    return;
                }
            }
        }
    }

    public Heap drop(Item item, int cell) {
        if (!this.keyDropped && (item instanceof SkeletonKey)) {
            this.keyDropped = true;
            CellEmitter.get(this.arenaDoor).start(Speck.factory(8), 0.07f, 10);
            Level.set(this.arenaDoor, 24);
            GameScene.updateMap(this.arenaDoor);
            Dungeon.observe();
        }
        return super.drop(item, cell);
    }

    private boolean outsideEntraceRoom(int cell) {
        int cx = cell % 32;
        int cy = cell / 32;
        return cx < 13 || cx > 19 || cy < 13 || cy > 19;
    }

    public String tileName(int tile) {
        switch (tile) {
            case WndUpdates.ID_CAVES /*2*/:
                return "Fluorescent moss";
            case BuffIndicator.FROST /*15*/:
                return "Fluorescent mushrooms";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Freezing cold water.";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case BuffIndicator.SLOW /*7*/:
                return "The ladder leads up to the upper depth.";
            case BuffIndicator.OOZE /*8*/:
                return "The ladder leads down to the lower depth.";
            case BuffIndicator.INVISIBLE /*12*/:
                return "A vein of some ore is visible on the wall. Gold?";
            case BuffIndicator.FROST /*15*/:
                return "Huge mushrooms block the view.";
            default:
                return super.tileDesc(tile);
        }
    }

    public void addVisuals(Scene scene) {
        CavesLevel.addVisuals(this, scene);
    }
}
