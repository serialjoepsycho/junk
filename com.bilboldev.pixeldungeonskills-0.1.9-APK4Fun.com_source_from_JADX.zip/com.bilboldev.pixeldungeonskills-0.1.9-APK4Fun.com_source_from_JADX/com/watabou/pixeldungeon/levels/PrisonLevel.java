package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Scene;
import com.watabou.noosa.particles.Emitter;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.actors.mobs.npcs.Wandmaker.Quest;
import com.watabou.pixeldungeon.effects.Halo;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.effects.particles.FlameParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.levels.Level.Feeling;
import com.watabou.pixeldungeon.levels.Room.Type;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;
import java.util.Iterator;

public class PrisonLevel extends RegularLevel {

    private static class Torch extends Emitter {
        private int pos;

        public Torch(int pos) {
            this.pos = pos;
            PointF p = DungeonTilemap.tileCenterToWorld(pos);
            pos(p.f24x - Key.TIME_TO_UNLOCK, p.f25y + CurareDart.DURATION, Pickaxe.TIME_TO_MINE, 0.0f);
            pour(FlameParticle.FACTORY, 0.15f);
            add(new Halo(ShadowBox.SIZE, 16777164, 0.2f).point(p.f24x, p.f25y));
        }

        public void update() {
            boolean z = Dungeon.visible[this.pos];
            this.visible = z;
            if (z) {
                super.update();
            }
        }
    }

    public PrisonLevel() {
        this.color1 = 6976061;
        this.color2 = 8950348;
    }

    public String tilesTex() {
        return Assets.TILES_PRISON;
    }

    public String waterTex() {
        return Assets.WATER_PRISON;
    }

    protected boolean[] water() {
        return Patch.generate(this.feeling == Feeling.WATER ? 0.65f : 0.45f, 4);
    }

    protected boolean[] grass() {
        return Patch.generate(this.feeling == Feeling.GRASS ? 0.6f : 0.4f, 3);
    }

    protected void assignRoomType() {
        super.assignRoomType();
        Iterator it = this.rooms.iterator();
        while (it.hasNext()) {
            Room r = (Room) it.next();
            if (r.type == Type.TUNNEL) {
                r.type = Type.PASSAGE;
            }
        }
    }

    protected void createMobs() {
        super.createMobs();
        Quest.spawn(this, this.roomEntrance);
    }

    protected void decorate() {
        int pos;
        int i = 33;
        while (i < 991) {
            if (this.map[i] == 1) {
                float c = 0.05f;
                if (this.map[i + 1] == 4 && this.map[i + 32] == 4) {
                    c = 0.05f + 0.2f;
                }
                if (this.map[i - 1] == 4 && this.map[i + 32] == 4) {
                    c += 0.2f;
                }
                if (this.map[i + 1] == 4 && this.map[i - 32] == 4) {
                    c += 0.2f;
                }
                if (this.map[i - 1] == 4 && this.map[i - 32] == 4) {
                    c += 0.2f;
                }
                if (Random.Float() < c) {
                    this.map[i] = 24;
                }
            }
            i++;
        }
        i = 0;
        while (i < 32) {
            if (this.map[i] == 4 && ((this.map[i + 32] == 1 || this.map[i + 32] == 14) && Random.Int(6) == 0)) {
                this.map[i] = 12;
            }
            i++;
        }
        i = 32;
        while (i < 992) {
            if (this.map[i] == 4 && this.map[i - 32] == 4 && ((this.map[i + 32] == 1 || this.map[i + 32] == 14) && Random.Int(3) == 0)) {
                this.map[i] = 12;
            }
            i++;
        }
        do {
            pos = this.roomEntrance.random();
        } while (pos == this.entrance);
        this.map[pos] = 29;
    }

    public String tileName(int tile) {
        switch (tile) {
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Dark cold water.";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case BuffIndicator.BARKSKIN /*24*/:
                return "There are old blood stains on the floor.";
            case ItemSpriteSheet.SCROLL_SOWILO /*41*/:
                return "This is probably a vestige of a prison library. Might it burn?";
            default:
                return super.tileDesc(tile);
        }
    }

    public void addVisuals(Scene scene) {
        super.addVisuals(scene);
        addVisuals(this, scene);
    }

    public static void addVisuals(Level level, Scene scene) {
        for (int i = 0; i < Level.LENGTH; i++) {
            if (level.map[i] == 12) {
                scene.add(new Torch(i));
            }
        }
    }
}
