package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Gold;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Level.Feeling;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Point;
import com.watabou.utils.Random;

public class StandardPainter extends Painter {
    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        for (Door door : room.connected.values()) {
            door.set(Type.REGULAR);
        }
        if (!Dungeon.bossLevel() && Random.Int(5) == 0) {
            switch (Random.Int(6)) {
                case WndUpdates.ID_SEWERS /*0*/:
                    if (level.feeling != Feeling.GRASS) {
                        if (Math.min(room.width(), room.height()) >= 4 && Math.max(room.width(), room.height()) >= 6) {
                            paintGraveyard(level, room);
                            return;
                        }
                    }
                case WndUpdates.ID_PRISON /*1*/:
                    if (Dungeon.depth > 1) {
                        paintBurned(level, room);
                        return;
                    }
                    break;
                case WndUpdates.ID_CAVES /*2*/:
                    if (Math.max(room.width(), room.height()) >= 4) {
                        paintStriped(level, room);
                        return;
                    }
                    break;
                case WndUpdates.ID_METROPOLIS /*3*/:
                    if (room.width() >= 6 && room.height() >= 6) {
                        paintStudy(level, room);
                        return;
                    }
                case WndUpdates.ID_HALLS /*4*/:
                    if (level.feeling != Feeling.WATER) {
                        if (room.connected.size() == 2 && room.width() >= 4 && room.height() >= 4) {
                            paintBridge(level, room);
                            return;
                        }
                    }
                case BuffIndicator.HUNGER /*5*/:
                    if (!(Dungeon.bossLevel() || Dungeon.bossLevel(Dungeon.depth + 1) || Math.min(room.width(), room.height()) < 5)) {
                        paintFissure(level, room);
                        return;
                    }
            }
        }
        Painter.fill(level, room, 1, 1);
    }

    private static void paintBurned(Level level, Room room) {
        for (int i = room.top + 1; i < room.bottom; i++) {
            for (int j = room.left + 1; j < room.right; j++) {
                int t = 9;
                switch (Random.Int(5)) {
                    case WndUpdates.ID_SEWERS /*0*/:
                        t = 1;
                        break;
                    case WndUpdates.ID_PRISON /*1*/:
                        t = 19;
                        break;
                    case WndUpdates.ID_CAVES /*2*/:
                        t = 20;
                        break;
                    case WndUpdates.ID_METROPOLIS /*3*/:
                        t = 23;
                        break;
                    default:
                        break;
                }
                level.map[(i * 32) + j] = t;
            }
        }
    }

    private static void paintGraveyard(Level level, Room room) {
        Painter.fill(level, room.left + 1, room.top + 1, room.width() - 1, room.height() - 1, 2);
        int w = room.width() - 1;
        int h = room.height() - 1;
        int nGraves = Math.max(w, h) / 2;
        int index = Random.Int(nGraves);
        int shift = Random.Int(2);
        int i = 0;
        while (i < nGraves) {
            int pos;
            if (w > h) {
                pos = (((room.left + 1) + shift) + (i * 2)) + (((room.top + 2) + Random.Int(h - 2)) * 32);
            } else {
                pos = ((room.left + 2) + Random.Int(w - 2)) + ((((room.top + 1) + shift) + (i * 2)) * 32);
            }
            level.drop(i == index ? Generator.random() : new Gold(), pos).type = Heap.Type.TOMB;
            i++;
        }
    }

    private static void paintStriped(Level level, Room room) {
        Painter.fill(level, room.left + 1, room.top + 1, room.width() - 1, room.height() - 1, 14);
        int i;
        if (room.width() > room.height()) {
            for (i = room.left + 2; i < room.right; i += 2) {
                Painter.fill(level, i, room.top + 1, 1, room.height() - 1, 15);
            }
            return;
        }
        for (i = room.top + 2; i < room.bottom; i += 2) {
            Painter.fill(level, room.left + 1, i, room.width() - 1, 1, 15);
        }
    }

    private static void paintStudy(Level level, Room room) {
        Painter.fill(level, room.left + 1, room.top + 1, room.width() - 1, room.height() - 1, 41);
        Painter.fill(level, room.left + 2, room.top + 2, room.width() - 3, room.height() - 3, 14);
        for (Point door : room.connected.values()) {
            if (door.f18x == room.left) {
                Painter.set(level, door.f18x + 1, door.f19y, 1);
            } else if (door.f18x == room.right) {
                Painter.set(level, door.f18x - 1, door.f19y, 1);
            } else if (door.f19y == room.top) {
                Painter.set(level, door.f18x, door.f19y + 1, 1);
            } else if (door.f19y == room.bottom) {
                Painter.set(level, door.f18x, door.f19y - 1, 1);
            }
        }
        Painter.set(level, room.center(), 11);
    }

    private static void paintBridge(Level level, Room room) {
        int i = room.left + 1;
        int i2 = room.top + 1;
        int width = room.width() - 1;
        int height = room.height() - 1;
        int i3 = (Dungeon.bossLevel() || Dungeon.bossLevel(Dungeon.depth + 1) || Random.Int(3) != 0) ? 63 : 0;
        Painter.fill(level, i, i2, width, height, i3);
        Point door1 = null;
        Point door2 = null;
        for (Point p : room.connected.values()) {
            if (door1 == null) {
                door1 = p;
            } else {
                door2 = p;
            }
        }
        int s;
        if ((door1.f18x == room.left && door2.f18x == room.right) || (door1.f18x == room.right && door2.f18x == room.left)) {
            s = room.width() / 2;
            Painter.drawInside(level, room, door1, s, 14);
            Painter.drawInside(level, room, door2, s, 14);
            Painter.fill(level, room.center().f18x, Math.min(door1.f19y, door2.f19y), 1, Math.abs(door1.f19y - door2.f19y) + 1, 14);
        } else if ((door1.f19y == room.top && door2.f19y == room.bottom) || (door1.f19y == room.bottom && door2.f19y == room.top)) {
            s = room.height() / 2;
            Painter.drawInside(level, room, door1, s, 14);
            Painter.drawInside(level, room, door2, s, 14);
            Painter.fill(level, Math.min(door1.f18x, door2.f18x), room.center().f19y, Math.abs(door1.f18x - door2.f18x) + 1, 1, 14);
        } else if (door1.f18x == door2.f18x) {
            Painter.fill(level, door1.f18x == room.left ? room.left + 1 : room.right - 1, Math.min(door1.f19y, door2.f19y), 1, Math.abs(door1.f19y - door2.f19y) + 1, 14);
        } else if (door1.f19y == door2.f19y) {
            Painter.fill(level, Math.min(door1.f18x, door2.f18x), door1.f19y == room.top ? room.top + 1 : room.bottom - 1, Math.abs(door1.f18x - door2.f18x) + 1, 1, 14);
        } else if (door1.f19y == room.top || door1.f19y == room.bottom) {
            Painter.drawInside(level, room, door1, Math.abs(door1.f19y - door2.f19y), 14);
            Painter.drawInside(level, room, door2, Math.abs(door1.f18x - door2.f18x), 14);
        } else if (door1.f18x == room.left || door1.f18x == room.right) {
            Painter.drawInside(level, room, door1, Math.abs(door1.f18x - door2.f18x), 14);
            Painter.drawInside(level, room, door2, Math.abs(door1.f19y - door2.f19y), 14);
        }
    }

    private static void paintFissure(Level level, Room room) {
        Painter.fill(level, room.left + 1, room.top + 1, room.width() - 1, room.height() - 1, 1);
        for (int i = room.top + 2; i < room.bottom - 1; i++) {
            for (int j = room.left + 2; j < room.right - 1; j++) {
                if (Math.min(Math.min(i - room.top, room.bottom - i), Math.min(j - room.left, room.right - j)) > 2 || Random.Int(2) == 0) {
                    Painter.set(level, j, i, 0);
                }
            }
        }
    }
}
