package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Point;
import com.watabou.utils.Random;

public class TunnelPainter extends Painter {
    public static void paint(Level level, Room room) {
        int floor = level.tunnelTile();
        Point c = room.center();
        int from;
        int to;
        int step;
        int i;
        if (room.width() > room.height() || (room.width() == room.height() && Random.Int(2) == 0)) {
            from = room.right - 1;
            to = room.left + 1;
            for (Door door : room.connected.values()) {
                if (door.y < c.f19y) {
                    step = 1;
                } else {
                    step = -1;
                }
                if (door.x == room.left) {
                    from = room.left + 1;
                    for (i = door.y; i != c.f19y; i += step) {
                        Painter.set(level, from, i, floor);
                    }
                } else if (door.x == room.right) {
                    to = room.right - 1;
                    for (i = door.y; i != c.f19y; i += step) {
                        Painter.set(level, to, i, floor);
                    }
                } else {
                    if (door.x < from) {
                        from = door.x;
                    }
                    if (door.x > to) {
                        to = door.x;
                    }
                    for (i = door.y + step; i != c.f19y; i += step) {
                        Painter.set(level, door.x, i, floor);
                    }
                }
            }
            for (i = from; i <= to; i++) {
                Painter.set(level, i, c.f19y, floor);
            }
        } else {
            from = room.bottom - 1;
            to = room.top + 1;
            for (Door door2 : room.connected.values()) {
                if (door2.x < c.f18x) {
                    step = 1;
                } else {
                    step = -1;
                }
                if (door2.y == room.top) {
                    from = room.top + 1;
                    for (i = door2.x; i != c.f18x; i += step) {
                        Painter.set(level, i, from, floor);
                    }
                } else if (door2.y == room.bottom) {
                    to = room.bottom - 1;
                    for (i = door2.x; i != c.f18x; i += step) {
                        Painter.set(level, i, to, floor);
                    }
                } else {
                    if (door2.y < from) {
                        from = door2.y;
                    }
                    if (door2.y > to) {
                        to = door2.y;
                    }
                    for (i = door2.x + step; i != c.f18x; i += step) {
                        Painter.set(level, i, door2.y, floor);
                    }
                }
            }
            for (i = from; i <= to; i++) {
                Painter.set(level, c.f18x, i, floor);
            }
        }
        for (Door door22 : room.connected.values()) {
            door22.set(Type.TUNNEL);
        }
    }
}
