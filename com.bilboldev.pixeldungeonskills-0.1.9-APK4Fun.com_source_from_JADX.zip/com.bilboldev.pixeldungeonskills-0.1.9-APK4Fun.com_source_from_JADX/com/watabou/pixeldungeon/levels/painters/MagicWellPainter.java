package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.blobs.WaterOfAwareness;
import com.watabou.pixeldungeon.actors.blobs.WaterOfHealth;
import com.watabou.pixeldungeon.actors.blobs.WaterOfTransmutation;
import com.watabou.pixeldungeon.actors.blobs.WellWater;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Point;
import com.watabou.utils.Random;

public class MagicWellPainter extends Painter {
    private static final Class<?>[] WATERS;

    static {
        WATERS = new Class[]{WaterOfAwareness.class, WaterOfHealth.class, WaterOfTransmutation.class};
    }

    public static void paint(Level level, Room room) {
        Class<? extends WellWater> waterClass;
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 1);
        Point c = room.center();
        Painter.set(level, c.f18x, c.f19y, 34);
        if (Dungeon.depth >= Dungeon.transmutation) {
            waterClass = WaterOfTransmutation.class;
        } else {
            waterClass = (Class) Random.element(WATERS);
        }
        if (waterClass == WaterOfTransmutation.class) {
            Dungeon.transmutation = Integer.MAX_VALUE;
        }
        WellWater water = (WellWater) level.blobs.get(waterClass);
        if (water == null) {
            try {
                water = (WellWater) waterClass.newInstance();
            } catch (Exception e) {
                water = null;
            }
        }
        water.seed(c.f18x + (c.f19y * 32), 1);
        level.blobs.put(waterClass, water);
        room.entrance().set(Type.REGULAR);
    }
}
