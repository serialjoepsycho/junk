package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.items.Gold;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Heap.Type;
import com.watabou.pixeldungeon.items.keys.IronKey;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.utils.Random;

public class TreasuryPainter extends Painter {
    public static void paint(Level level, Room room) {
        int i;
        int pos;
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 1);
        Painter.set(level, room.center(), 35);
        Type heapType = Random.Int(2) == 0 ? Type.CHEST : Type.HEAP;
        int n = Random.IntRange(2, 3);
        for (i = 0; i < n; i++) {
            Type type;
            while (true) {
                pos = room.random();
                if (level.map[pos] == 1 && level.heaps.get(pos) == null) {
                    break;
                }
            }
            Heap drop = level.drop(new Gold().random(), pos);
            if (i == 0 && heapType == Type.CHEST) {
                type = Type.MIMIC;
            } else {
                type = heapType;
            }
            drop.type = type;
        }
        if (heapType == Type.HEAP) {
            for (i = 0; i < 6; i++) {
                do {
                    pos = room.random();
                } while (level.map[pos] != 1);
                level.drop(new Gold(Random.IntRange(1, 3)), pos);
            }
        }
        room.entrance().set(Door.Type.LOCKED);
        level.addItemToSpawn(new IronKey());
    }
}
