package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Point;
import com.watabou.utils.Random;

public class WeakFloorPainter extends Painter {
    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 0);
        Door door = room.entrance();
        door.set(Type.REGULAR);
        int i;
        if (door.x == room.left) {
            for (i = room.top + 1; i < room.bottom; i++) {
                Painter.drawInside(level, room, new Point(room.left, i), Random.IntRange(1, room.width() - 2), 14);
            }
        } else if (door.x == room.right) {
            for (i = room.top + 1; i < room.bottom; i++) {
                Painter.drawInside(level, room, new Point(room.right, i), Random.IntRange(1, room.width() - 2), 14);
            }
        } else if (door.y == room.top) {
            for (i = room.left + 1; i < room.right; i++) {
                Painter.drawInside(level, room, new Point(i, room.top), Random.IntRange(1, room.height() - 2), 14);
            }
        } else if (door.y == room.bottom) {
            for (i = room.left + 1; i < room.right; i++) {
                Painter.drawInside(level, room, new Point(i, room.bottom), Random.IntRange(1, room.height() - 2), 14);
            }
        }
    }
}
