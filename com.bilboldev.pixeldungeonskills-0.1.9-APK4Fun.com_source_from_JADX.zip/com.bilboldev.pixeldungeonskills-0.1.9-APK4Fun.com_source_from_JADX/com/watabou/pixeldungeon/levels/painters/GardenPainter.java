package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.actors.blobs.Foliage;
import com.watabou.pixeldungeon.items.Honeypot;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.pixeldungeon.plants.Sungrass.Seed;
import com.watabou.utils.Random;

public class GardenPainter extends Painter {
    public static void paint(Level level, Room room) {
        int i;
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 15);
        Painter.fill(level, room, 2, 2);
        room.entrance().set(Type.REGULAR);
        if (Random.Int(2) == 0) {
            level.drop(new Honeypot(), room.random());
        } else {
            int bushes;
            if (Random.Int(5) == 0) {
                bushes = 2;
            } else {
                bushes = 1;
            }
            for (i = 0; i < bushes; i++) {
                int pos = room.random();
                Painter.set(level, pos, 2);
                level.plant(new Seed(), pos);
            }
        }
        Foliage light = (Foliage) level.blobs.get(Foliage.class);
        if (light == null) {
            light = new Foliage();
        }
        for (i = room.top + 1; i < room.bottom; i++) {
            for (int j = room.left + 1; j < room.right; j++) {
                light.seed((i * 32) + j, 1);
            }
        }
        level.blobs.put(Foliage.class, light);
    }
}
