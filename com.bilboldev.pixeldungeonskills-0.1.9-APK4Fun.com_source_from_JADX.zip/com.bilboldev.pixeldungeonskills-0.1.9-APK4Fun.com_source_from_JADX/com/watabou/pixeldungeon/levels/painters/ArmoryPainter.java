package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.items.Bomb;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.IronKey;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Point;
import com.watabou.utils.Random;

public class ArmoryPainter extends Painter {
    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 1);
        Door entrance = room.entrance();
        Point statue = null;
        if (entrance.x == room.left) {
            statue = new Point(room.right - 1, Random.Int(2) == 0 ? room.top + 1 : room.bottom - 1);
        } else if (entrance.x == room.right) {
            statue = new Point(room.left + 1, Random.Int(2) == 0 ? room.top + 1 : room.bottom - 1);
        } else if (entrance.y == room.top) {
            statue = new Point(Random.Int(2) == 0 ? room.left + 1 : room.right - 1, room.bottom - 1);
        } else if (entrance.y == room.bottom) {
            statue = new Point(Random.Int(2) == 0 ? room.left + 1 : room.right - 1, room.top + 1);
        }
        if (statue != null) {
            Painter.set(level, statue, 35);
        }
        int n = (Random.Int(4) == 0 ? 1 : 0) + 3;
        for (int i = 0; i < n; i++) {
            int pos;
            while (true) {
                pos = room.random();
                if (level.map[pos] == 1 && level.heaps.get(pos) == null) {
                    break;
                }
            }
            level.drop(prize(level), pos);
        }
        entrance.set(Type.LOCKED);
        level.addItemToSpawn(new IronKey());
    }

    private static Item prize(Level level) {
        if (Random.Int(6) == 0) {
            return new Bomb().random();
        }
        return Generator.random((Category) Random.oneOf(Category.ARMOR, Category.WEAPON));
    }
}
