package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.potions.PotionOfLiquidFlame;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Random;

public class StoragePainter extends Painter {
    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 14);
        int n = Random.IntRange(3, 4);
        for (int i = 0; i < n; i++) {
            int pos;
            do {
                pos = room.random();
            } while (level.map[pos] != 14);
            level.drop(prize(level), pos);
        }
        room.entrance().set(Type.BARRICADE);
        level.addItemToSpawn(new PotionOfLiquidFlame());
    }

    private static Item prize(Level level) {
        Item prize = level.itemToSpanAsPrize();
        if (prize != null) {
            return prize;
        }
        return Generator.random((Category) Random.oneOf(Category.POTION, Category.SCROLL, Category.FOOD, Category.GOLD, Category.MISC));
    }
}
