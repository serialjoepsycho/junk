package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.actors.blobs.Alchemy;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.IronKey;
import com.watabou.pixeldungeon.items.potions.Potion;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Point;
import com.watabou.utils.Random;

public class LaboratoryPainter extends Painter {
    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 14);
        Door entrance = room.entrance();
        Point pot = null;
        if (entrance.x == room.left) {
            pot = new Point(room.right - 1, Random.Int(2) == 0 ? room.top + 1 : room.bottom - 1);
        } else if (entrance.x == room.right) {
            pot = new Point(room.left + 1, Random.Int(2) == 0 ? room.top + 1 : room.bottom - 1);
        } else if (entrance.y == room.top) {
            pot = new Point(Random.Int(2) == 0 ? room.left + 1 : room.right - 1, room.bottom - 1);
        } else if (entrance.y == room.bottom) {
            int i;
            if (Random.Int(2) == 0) {
                i = room.left + 1;
            } else {
                i = room.right - 1;
            }
            pot = new Point(i, room.top + 1);
        }
        Painter.set(level, pot, 42);
        Alchemy alchemy = new Alchemy();
        alchemy.seed(pot.f18x + (pot.f19y * 32), 1);
        level.blobs.put(Alchemy.class, alchemy);
        int n = Random.IntRange(2, 3);
        for (int i2 = 0; i2 < n; i2++) {
            int pos;
            while (true) {
                pos = room.random();
                if (level.map[pos] == 14 && level.heaps.get(pos) == null) {
                    break;
                }
            }
            level.drop(prize(level), pos);
        }
        entrance.set(Type.LOCKED);
        level.addItemToSpawn(new IronKey());
    }

    private static Item prize(Level level) {
        Item prize = level.itemToSpanAsPrize();
        if (prize instanceof Potion) {
            return prize;
        }
        if (prize != null) {
            level.addItemToSpawn(prize);
        }
        return Generator.random(Category.POTION);
    }
}
