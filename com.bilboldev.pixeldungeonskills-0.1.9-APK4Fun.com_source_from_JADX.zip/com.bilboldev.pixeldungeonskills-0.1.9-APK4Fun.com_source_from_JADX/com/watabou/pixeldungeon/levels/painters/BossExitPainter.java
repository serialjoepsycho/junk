package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;

public class BossExitPainter extends Painter {
    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 1);
        for (Door door : room.connected.values()) {
            door.set(Type.REGULAR);
        }
        level.exit = (room.top * 32) + ((room.left + room.right) / 2);
        Painter.set(level, level.exit, 25);
    }
}
