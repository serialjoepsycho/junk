package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.actors.mobs.npcs.ImpShopkeeper;
import com.watabou.pixeldungeon.actors.mobs.npcs.Shopkeeper;
import com.watabou.pixeldungeon.items.Ankh;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Heap.Type;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.Torch;
import com.watabou.pixeldungeon.items.Weightstone;
import com.watabou.pixeldungeon.items.armor.LeatherArmor;
import com.watabou.pixeldungeon.items.armor.MailArmor;
import com.watabou.pixeldungeon.items.armor.PlateArmor;
import com.watabou.pixeldungeon.items.armor.ScaleArmor;
import com.watabou.pixeldungeon.items.bags.ScrollHolder;
import com.watabou.pixeldungeon.items.bags.SeedPouch;
import com.watabou.pixeldungeon.items.bags.WandHolster;
import com.watabou.pixeldungeon.items.food.OverpricedRation;
import com.watabou.pixeldungeon.items.potions.PotionOfHealing;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfIdentify;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfMagicMapping;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfRemoveCurse;
import com.watabou.pixeldungeon.items.weapon.melee.BattleAxe;
import com.watabou.pixeldungeon.items.weapon.melee.Glaive;
import com.watabou.pixeldungeon.items.weapon.melee.Longsword;
import com.watabou.pixeldungeon.items.weapon.melee.Mace;
import com.watabou.pixeldungeon.items.weapon.melee.Quarterstaff;
import com.watabou.pixeldungeon.items.weapon.melee.Spear;
import com.watabou.pixeldungeon.items.weapon.melee.Sword;
import com.watabou.pixeldungeon.items.weapon.melee.WarHammer;
import com.watabou.pixeldungeon.levels.LastShopLevel;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Point;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class ShopPainter extends Painter {
    private static int pasHeight;
    private static int pasWidth;

    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 14);
        pasWidth = room.width() - 2;
        pasHeight = room.height() - 2;
        int per = (pasWidth * 2) + (pasHeight * 2);
        Item[] range = range();
        int pos = xy2p(room, room.entrance()) + ((per - range.length) / 2);
        for (Item drop : range) {
            Point xy = p2xy(room, (pos + per) % per);
            int cell = xy.f18x + (xy.f19y * 32);
            if (level.heaps.get(cell) != null) {
                do {
                    cell = room.random();
                } while (level.heaps.get(cell) != null);
            }
            level.drop(drop, cell).type = Type.FOR_SALE;
            pos++;
        }
        placeShopkeeper(level, room);
        for (Door door : room.connected.values()) {
            door.set(Door.Type.REGULAR);
        }
    }

    private static Item[] range() {
        ArrayList<Item> items = new ArrayList();
        switch (Dungeon.depth) {
            case BuffIndicator.STARVATION /*6*/:
                items.add((Random.Int(2) == 0 ? new Quarterstaff() : new Spear()).identify());
                items.add(new LeatherArmor().identify());
                items.add(new SeedPouch());
                items.add(new Weightstone());
                break;
            case BuffIndicator.ROOTS /*11*/:
                items.add((Random.Int(2) == 0 ? new Sword() : new Mace()).identify());
                items.add(new MailArmor().identify());
                items.add(new ScrollHolder());
                items.add(new Weightstone());
                break;
            case BuffIndicator.BLINDNESS /*16*/:
                items.add((Random.Int(2) == 0 ? new Longsword() : new BattleAxe()).identify());
                items.add(new ScaleArmor().identify());
                items.add(new WandHolster());
                items.add(new Weightstone());
                break;
            case BuffIndicator.HEART /*21*/:
                switch (Random.Int(3)) {
                    case WndUpdates.ID_SEWERS /*0*/:
                        items.add(new Glaive().identify());
                        break;
                    case WndUpdates.ID_PRISON /*1*/:
                        items.add(new WarHammer().identify());
                        break;
                    case WndUpdates.ID_CAVES /*2*/:
                        items.add(new PlateArmor().identify());
                        break;
                }
                items.add(new Torch());
                items.add(new Torch());
                break;
        }
        items.add(new PotionOfHealing());
        for (int i = 0; i < 3; i++) {
            items.add(Generator.random(Category.POTION));
        }
        items.add(new ScrollOfIdentify());
        items.add(new ScrollOfRemoveCurse());
        items.add(new ScrollOfMagicMapping());
        items.add(Generator.random(Category.SCROLL));
        items.add(new OverpricedRation());
        items.add(new OverpricedRation());
        items.add(new Ankh());
        Item[] range = (Item[]) items.toArray(new Item[0]);
        Random.shuffle(range);
        return range;
    }

    private static void placeShopkeeper(Level level, Room room) {
        int pos;
        Mob shopkeeper;
        do {
            pos = room.random();
        } while (level.heaps.get(pos) != null);
        if (level instanceof LastShopLevel) {
            shopkeeper = new ImpShopkeeper();
        } else {
            shopkeeper = new Shopkeeper();
        }
        shopkeeper.pos = pos;
        level.mobs.add(shopkeeper);
        if (level instanceof LastShopLevel) {
            for (int i : Level.NEIGHBOURS9) {
                int p = shopkeeper.pos + i;
                if (level.map[p] == 14) {
                    level.map[p] = 63;
                }
            }
        }
    }

    private static int xy2p(Room room, Point xy) {
        if (xy.f19y == room.top) {
            return (xy.f18x - room.left) - 1;
        }
        if (xy.f18x == room.right) {
            return ((xy.f19y - room.top) - 1) + pasWidth;
        }
        if (xy.f19y == room.bottom) {
            return (((room.right - xy.f18x) - 1) + pasWidth) + pasHeight;
        }
        if (xy.f19y == room.top + 1) {
            return 0;
        }
        return (((room.bottom - xy.f19y) - 1) + (pasWidth * 2)) + pasHeight;
    }

    private static Point p2xy(Room room, int p) {
        if (p < pasWidth) {
            return new Point((room.left + 1) + p, room.top + 1);
        }
        if (p < pasWidth + pasHeight) {
            return new Point(room.right - 1, (room.top + 1) + (p - pasWidth));
        }
        if (p < (pasWidth * 2) + pasHeight) {
            return new Point((room.right - 1) - (p - (pasWidth + pasHeight)), room.bottom - 1);
        }
        return new Point(room.left + 1, (room.bottom - 1) - (p - ((pasWidth * 2) + pasHeight)));
    }
}
