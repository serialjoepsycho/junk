package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.actors.mobs.npcs.RatKing;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Gold;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.weapon.missiles.MissileWeapon;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Random;

public class RatKingPainter extends Painter {
    public static void paint(Level level, Room room) {
        int i;
        Heap chest;
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 14);
        Door entrance = room.entrance();
        entrance.set(Type.HIDDEN);
        int door = entrance.x + (entrance.y * 32);
        for (i = room.left + 1; i < room.right; i++) {
            addChest(level, ((room.top + 1) * 32) + i, door);
            addChest(level, ((room.bottom - 1) * 32) + i, door);
        }
        for (i = room.top + 2; i < room.bottom - 1; i++) {
            addChest(level, ((i * 32) + room.left) + 1, door);
            addChest(level, ((i * 32) + room.right) - 1, door);
        }
        do {
            chest = (Heap) level.heaps.get(room.random());
        } while (chest == null);
        chest.type = Heap.Type.MIMIC;
        RatKing king = new RatKing();
        king.pos = room.random(1);
        level.mobs.add(king);
    }

    private static void addChest(Level level, int pos, int door) {
        if (pos != door - 1 && pos != door + 1 && pos != door - 32 && pos != door + 32) {
            Item prize;
            switch (Random.Int(10)) {
                case WndUpdates.ID_SEWERS /*0*/:
                    prize = Generator.random(Category.WEAPON);
                    if (!(prize instanceof MissileWeapon)) {
                        prize.degrade(Random.Int(3));
                        break;
                    } else {
                        prize.quantity(1);
                        break;
                    }
                case WndUpdates.ID_PRISON /*1*/:
                    prize = Generator.random(Category.ARMOR).degrade(Random.Int(3));
                    break;
                default:
                    prize = new Gold(Random.IntRange(1, 5));
                    break;
            }
            level.drop(prize, pos).type = Heap.Type.CHEST;
        }
    }
}
