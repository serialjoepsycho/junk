package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;

public class EntrancePainter extends Painter {
    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 1);
        for (Door door : room.connected.values()) {
            door.set(Type.REGULAR);
        }
        level.entrance = room.random(1);
        level.storage = room.random(2);
        Painter.set(level, level.entrance, 7);
        Painter.set(level, level.storage, 64);
    }
}
