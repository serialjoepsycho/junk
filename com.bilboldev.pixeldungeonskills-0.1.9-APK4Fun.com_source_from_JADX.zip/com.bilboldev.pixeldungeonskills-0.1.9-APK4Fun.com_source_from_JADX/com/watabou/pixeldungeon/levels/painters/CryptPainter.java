package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.IronKey;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Point;

public class CryptPainter extends Painter {
    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 1);
        Point c = room.center();
        int cx = c.f18x;
        int cy = c.f19y;
        Door entrance = room.entrance();
        entrance.set(Type.LOCKED);
        level.addItemToSpawn(new IronKey());
        if (entrance.x == room.left) {
            Painter.set(level, new Point(room.right - 1, room.top + 1), 35);
            Painter.set(level, new Point(room.right - 1, room.bottom - 1), 35);
            cx = room.right - 2;
        } else if (entrance.x == room.right) {
            Painter.set(level, new Point(room.left + 1, room.top + 1), 35);
            Painter.set(level, new Point(room.left + 1, room.bottom - 1), 35);
            cx = room.left + 2;
        } else if (entrance.y == room.top) {
            Painter.set(level, new Point(room.left + 1, room.bottom - 1), 35);
            Painter.set(level, new Point(room.right - 1, room.bottom - 1), 35);
            cy = room.bottom - 2;
        } else if (entrance.y == room.bottom) {
            Painter.set(level, new Point(room.left + 1, room.top + 1), 35);
            Painter.set(level, new Point(room.right - 1, room.top + 1), 35);
            cy = room.top + 2;
        }
        level.drop(prize(level), (cy * 32) + cx).type = Heap.Type.TOMB;
    }

    private static Item prize(Level level) {
        Item prize = Generator.random(Category.ARMOR);
        for (int i = 0; i < 3; i++) {
            Item another = Generator.random(Category.ARMOR);
            if (another.level > prize.level) {
                prize = another;
            }
        }
        return prize;
    }
}
