package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.utils.Random;

public class VaultPainter extends Painter {
    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void paint(com.watabou.pixeldungeon.levels.Level r7, com.watabou.pixeldungeon.levels.Room r8) {
        /*
        r6 = 1;
        r5 = 4;
        com.watabou.pixeldungeon.levels.painters.Painter.fill(r7, r8, r5);
        com.watabou.pixeldungeon.levels.painters.Painter.fill(r7, r8, r6, r6);
        r5 = r8.left;
        r6 = r8.right;
        r5 = r5 + r6;
        r1 = r5 / 2;
        r5 = r8.top;
        r6 = r8.bottom;
        r5 = r5 + r6;
        r2 = r5 / 2;
        r5 = r2 * 32;
        r0 = r1 + r5;
        r5 = 3;
        r5 = com.watabou.utils.Random.Int(r5);
        switch(r5) {
            case 0: goto L_0x0034;
            case 1: goto L_0x0049;
            case 2: goto L_0x007f;
            default: goto L_0x0022;
        };
    L_0x0022:
        r5 = r8.entrance();
        r6 = com.watabou.pixeldungeon.levels.Room.Door.Type.LOCKED;
        r5.set(r6);
        r5 = new com.watabou.pixeldungeon.items.keys.IronKey;
        r5.<init>();
        r7.addItemToSpawn(r5);
        return;
    L_0x0034:
        r5 = prize(r7);
        r5 = r7.drop(r5, r0);
        r6 = com.watabou.pixeldungeon.items.Heap.Type.LOCKED_CHEST;
        r5.type = r6;
        r5 = new com.watabou.pixeldungeon.items.keys.GoldenKey;
        r5.<init>();
        r7.addItemToSpawn(r5);
        goto L_0x0022;
    L_0x0049:
        r3 = prize(r7);
        r4 = prize(r7);
        r5 = r3.getClass();
        r6 = r4.getClass();
        if (r5 == r6) goto L_0x0049;
    L_0x005b:
        r5 = r7.drop(r3, r0);
        r6 = com.watabou.pixeldungeon.items.Heap.Type.CRYSTAL_CHEST;
        r5.type = r6;
        r5 = com.watabou.pixeldungeon.levels.Level.NEIGHBOURS8;
        r6 = 8;
        r6 = com.watabou.utils.Random.Int(r6);
        r5 = r5[r6];
        r5 = r5 + r0;
        r5 = r7.drop(r4, r5);
        r6 = com.watabou.pixeldungeon.items.Heap.Type.CRYSTAL_CHEST;
        r5.type = r6;
        r5 = new com.watabou.pixeldungeon.items.keys.GoldenKey;
        r5.<init>();
        r7.addItemToSpawn(r5);
        goto L_0x0022;
    L_0x007f:
        r5 = prize(r7);
        r7.drop(r5, r0);
        r5 = 11;
        com.watabou.pixeldungeon.levels.painters.Painter.set(r7, r0, r5);
        goto L_0x0022;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.watabou.pixeldungeon.levels.painters.VaultPainter.paint(com.watabou.pixeldungeon.levels.Level, com.watabou.pixeldungeon.levels.Room):void");
    }

    private static Item prize(Level level) {
        return Generator.random((Category) Random.oneOf(Category.WAND, Category.RING));
    }
}
