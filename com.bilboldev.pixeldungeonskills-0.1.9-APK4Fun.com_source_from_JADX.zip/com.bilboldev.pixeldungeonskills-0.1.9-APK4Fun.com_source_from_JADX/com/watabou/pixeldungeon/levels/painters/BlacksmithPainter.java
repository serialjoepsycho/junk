package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.mobs.npcs.Blacksmith;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Random;

public class BlacksmithPainter extends Painter {
    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 19);
        Painter.fill(level, room, 2, 14);
        for (int i = 0; i < 2; i++) {
            int pos;
            do {
                pos = room.random();
            } while (level.map[pos] != 14);
            level.drop(Generator.random((Category) Random.oneOf(Category.ARMOR, Category.WEAPON)), pos);
        }
        for (Door door : room.connected.values()) {
            door.set(Type.UNLOCKED);
            Painter.drawInside(level, room, door, 1, 1);
        }
        Blacksmith npc = new Blacksmith();
        do {
            npc.pos = room.random(1);
        } while (level.heaps.get(npc.pos) != null);
        level.mobs.add(npc);
        Actor.occupyCell(npc);
    }
}
