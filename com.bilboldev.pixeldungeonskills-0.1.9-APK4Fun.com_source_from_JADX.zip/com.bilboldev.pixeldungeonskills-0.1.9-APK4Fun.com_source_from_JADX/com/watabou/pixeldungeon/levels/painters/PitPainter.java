package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.IronKey;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Point;
import com.watabou.utils.Random;

public class PitPainter extends Painter {
    public static void paint(Level level, Room room) {
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, 1);
        Door entrance = room.entrance();
        entrance.set(Type.LOCKED);
        Point well = null;
        if (entrance.x == room.left) {
            well = new Point(room.right - 1, Random.Int(2) == 0 ? room.top + 1 : room.bottom - 1);
        } else if (entrance.x == room.right) {
            well = new Point(room.left + 1, Random.Int(2) == 0 ? room.top + 1 : room.bottom - 1);
        } else if (entrance.y == room.top) {
            well = new Point(Random.Int(2) == 0 ? room.left + 1 : room.right - 1, room.bottom - 1);
        } else if (entrance.y == room.bottom) {
            well = new Point(Random.Int(2) == 0 ? room.left + 1 : room.right - 1, room.top + 1);
        }
        Painter.set(level, well, 3);
        int remains = room.random();
        while (level.map[remains] == 3) {
            remains = room.random();
        }
        level.drop(new IronKey(), remains).type = Heap.Type.SKELETON;
        if (Random.Int(5) == 0) {
            level.drop(Generator.random(Category.RING), remains);
        } else {
            level.drop(Generator.random((Category) Random.oneOf(Category.WEAPON, Category.ARMOR)), remains);
        }
        int n = Random.IntRange(1, 2);
        for (int i = 0; i < n; i++) {
            level.drop(prize(level), remains);
        }
    }

    private static Item prize(Level level) {
        Item prize = level.itemToSpanAsPrize();
        if (prize != null) {
            return prize;
        }
        return Generator.random((Category) Random.oneOf(Category.POTION, Category.SCROLL, Category.FOOD, Category.GOLD));
    }
}
