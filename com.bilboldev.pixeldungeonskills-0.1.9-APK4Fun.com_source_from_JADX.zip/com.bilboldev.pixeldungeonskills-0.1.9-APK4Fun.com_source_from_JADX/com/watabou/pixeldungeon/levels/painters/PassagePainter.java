package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Point;
import java.util.ArrayList;
import java.util.Collections;

public class PassagePainter extends Painter {
    private static int pasHeight;
    private static int pasWidth;

    public static void paint(Level level, Room room) {
        pasWidth = room.width() - 2;
        pasHeight = room.height() - 2;
        int floor = level.tunnelTile();
        ArrayList<Integer> joints = new ArrayList();
        for (Point door : room.connected.values()) {
            joints.add(Integer.valueOf(xy2p(room, door)));
        }
        Collections.sort(joints);
        int nJoints = joints.size();
        int perimeter = (pasWidth * 2) + (pasHeight * 2);
        int start = 0;
        int maxD = (((Integer) joints.get(0)).intValue() + perimeter) - ((Integer) joints.get(nJoints - 1)).intValue();
        for (int i = 1; i < nJoints; i++) {
            int d = ((Integer) joints.get(i)).intValue() - ((Integer) joints.get(i - 1)).intValue();
            if (d > maxD) {
                maxD = d;
                start = i;
            }
        }
        int end = ((start + nJoints) - 1) % nJoints;
        int p = ((Integer) joints.get(start)).intValue();
        do {
            Painter.set(level, p2xy(room, p), floor);
            p = (p + 1) % perimeter;
        } while (p != ((Integer) joints.get(end)).intValue());
        Painter.set(level, p2xy(room, p), floor);
        for (Door door2 : room.connected.values()) {
            door2.set(Type.TUNNEL);
        }
    }

    private static int xy2p(Room room, Point xy) {
        if (xy.f19y == room.top) {
            return (xy.f18x - room.left) - 1;
        }
        if (xy.f18x == room.right) {
            return ((xy.f19y - room.top) - 1) + pasWidth;
        }
        if (xy.f19y == room.bottom) {
            return (((room.right - xy.f18x) - 1) + pasWidth) + pasHeight;
        }
        if (xy.f19y == room.top + 1) {
            return 0;
        }
        return (((room.bottom - xy.f19y) - 1) + (pasWidth * 2)) + pasHeight;
    }

    private static Point p2xy(Room room, int p) {
        if (p < pasWidth) {
            return new Point((room.left + 1) + p, room.top + 1);
        }
        if (p < pasWidth + pasHeight) {
            return new Point(room.right - 1, (room.top + 1) + (p - pasWidth));
        }
        if (p < (pasWidth * 2) + pasHeight) {
            return new Point((room.right - 1) - (p - (pasWidth + pasHeight)), room.bottom - 1);
        }
        return new Point(room.left + 1, (room.bottom - 1) - (p - ((pasWidth * 2) + pasHeight)));
    }
}
