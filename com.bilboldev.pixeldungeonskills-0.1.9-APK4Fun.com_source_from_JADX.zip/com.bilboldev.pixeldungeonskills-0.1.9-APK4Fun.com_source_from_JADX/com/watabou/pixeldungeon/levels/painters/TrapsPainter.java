package com.watabou.pixeldungeon.levels.painters;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.potions.PotionOfLevitation;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Door.Type;
import com.watabou.utils.Random;

public class TrapsPainter extends Painter {
    public static void paint(Level level, Room room) {
        Object[] traps = new Integer[6];
        traps[0] = Integer.valueOf(17);
        traps[1] = Integer.valueOf(17);
        traps[2] = Integer.valueOf(17);
        traps[3] = Integer.valueOf(21);
        traps[4] = Integer.valueOf(21);
        traps[5] = Integer.valueOf(!Dungeon.bossLevel(Dungeon.depth + 1) ? 0 : 39);
        Painter.fill(level, room, 4);
        Painter.fill(level, room, 1, ((Integer) Random.element(traps)).intValue());
        Door door = room.entrance();
        door.set(Type.REGULAR);
        int lastRow = level.map[(room.left + 1) + ((room.top + 1) * 32)] == 0 ? 0 : 1;
        int x = -1;
        int y = -1;
        if (door.x == room.left) {
            x = room.right - 1;
            y = room.top + (room.height() / 2);
            Painter.fill(level, x, room.top + 1, 1, room.height() - 1, lastRow);
        } else if (door.x == room.right) {
            x = room.left + 1;
            y = room.top + (room.height() / 2);
            Painter.fill(level, x, room.top + 1, 1, room.height() - 1, lastRow);
        } else if (door.y == room.top) {
            x = room.left + (room.width() / 2);
            y = room.bottom - 1;
            Painter.fill(level, room.left + 1, y, room.width() - 1, 1, lastRow);
        } else if (door.y == room.bottom) {
            x = room.left + (room.width() / 2);
            y = room.top + 1;
            Painter.fill(level, room.left + 1, y, room.width() - 1, 1, lastRow);
        }
        int pos = x + (y * 32);
        if (Random.Int(3) == 0) {
            if (lastRow == 0) {
                Painter.set(level, pos, 1);
            }
            level.drop(prize(level), pos).type = Heap.Type.CHEST;
        } else {
            Painter.set(level, pos, 11);
            level.drop(prize(level), pos);
        }
        level.addItemToSpawn(new PotionOfLevitation());
    }

    private static Item prize(Level level) {
        Item prize = level.itemToSpanAsPrize();
        if (prize != null) {
            return prize;
        }
        prize = Generator.random((Category) Random.oneOf(Category.WEAPON, Category.ARMOR));
        for (int i = 0; i < 3; i++) {
            Item another = Generator.random((Category) Random.oneOf(Category.WEAPON, Category.ARMOR));
            if (another.level > prize.level) {
                prize = another;
            }
        }
        return prize;
    }
}
