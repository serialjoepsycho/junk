package com.watabou.pixeldungeon.levels;

import com.watabou.utils.Random;

public class Patch {
    private static boolean[] cur;
    private static boolean[] off;

    static {
        cur = new boolean[Level.LENGTH];
        off = new boolean[Level.LENGTH];
    }

    public static boolean[] generate(float seed, int nGen) {
        int i;
        for (i = 0; i < Level.LENGTH; i++) {
            boolean z;
            boolean[] zArr = off;
            if (Random.Float() < seed) {
                z = true;
            } else {
                z = false;
            }
            zArr[i] = z;
        }
        for (i = 0; i < nGen; i++) {
            for (int y = 1; y < 31; y++) {
                for (int x = 1; x < 31; x++) {
                    int pos = x + (y * 32);
                    int count = 0;
                    if (off[(pos - 32) - 1]) {
                        count = 0 + 1;
                    }
                    if (off[pos - 32]) {
                        count++;
                    }
                    if (off[(pos - 32) + 1]) {
                        count++;
                    }
                    if (off[pos - 1]) {
                        count++;
                    }
                    if (off[pos + 1]) {
                        count++;
                    }
                    if (off[(pos + 32) - 1]) {
                        count++;
                    }
                    if (off[pos + 32]) {
                        count++;
                    }
                    if (off[(pos + 32) + 1]) {
                        count++;
                    }
                    if (!off[pos] && count >= 5) {
                        cur[pos] = true;
                    } else if (!off[pos] || count < 4) {
                        cur[pos] = false;
                    } else {
                        cur[pos] = true;
                    }
                }
            }
            boolean[] tmp = cur;
            cur = off;
            off = tmp;
        }
        return off;
    }
}
