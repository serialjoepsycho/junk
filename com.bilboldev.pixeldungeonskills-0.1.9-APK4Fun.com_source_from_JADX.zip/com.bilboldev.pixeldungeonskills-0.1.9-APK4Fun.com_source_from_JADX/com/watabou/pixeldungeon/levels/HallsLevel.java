package com.watabou.pixeldungeon.levels;

import android.opengl.GLES20;
import com.watabou.noosa.Game;
import com.watabou.noosa.Group;
import com.watabou.noosa.Scene;
import com.watabou.noosa.particles.PixelParticle.Shrinking;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.items.Torch;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level.Feeling;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;

public class HallsLevel extends RegularLevel {

    public static class FireParticle extends Shrinking {
        public FireParticle() {
            color(15628066);
            this.lifespan = Key.TIME_TO_UNLOCK;
            this.acc.set(0.0f, 80.0f);
        }

        public void reset(float x, float y) {
            revive();
            this.x = x;
            this.y = y;
            this.left = this.lifespan;
            this.speed.set(0.0f, -40.0f);
            this.size = 4.0f;
        }

        public void update() {
            float f = Key.TIME_TO_UNLOCK;
            super.update();
            float p = this.left / this.lifespan;
            if (p > 0.8f) {
                f = (Key.TIME_TO_UNLOCK - p) * GasesImmunity.DURATION;
            }
            this.am = f;
        }
    }

    private static class Stream extends Group {
        private float delay;
        private int pos;

        public Stream(int pos) {
            this.pos = pos;
            this.delay = Random.Float(Pickaxe.TIME_TO_MINE);
        }

        public void update() {
            boolean z = Dungeon.visible[this.pos];
            this.visible = z;
            if (z) {
                super.update();
                float f = this.delay - Game.elapsed;
                this.delay = f;
                if (f <= 0.0f) {
                    this.delay = Random.Float(Pickaxe.TIME_TO_MINE);
                    PointF p = DungeonTilemap.tileToWorld(this.pos);
                    ((FireParticle) recycle(FireParticle.class)).reset(p.f24x + Random.Float(ShadowBox.SIZE), p.f25y + Random.Float(ShadowBox.SIZE));
                }
            }
        }

        public void draw() {
            GLES20.glBlendFunc(770, 1);
            super.draw();
            GLES20.glBlendFunc(770, 771);
        }
    }

    public HallsLevel() {
        this.minRoomSize = 6;
        this.viewDistance = Math.max(25 - Dungeon.depth, 1);
        this.color1 = 8393984;
        this.color2 = 10913057;
    }

    public void create() {
        addItemToSpawn(new Torch());
        super.create();
    }

    public String tilesTex() {
        return Assets.TILES_HALLS;
    }

    public String waterTex() {
        return Assets.WATER_HALLS;
    }

    protected boolean[] water() {
        return Patch.generate(this.feeling == Feeling.WATER ? 0.55f : 0.4f, 6);
    }

    protected boolean[] grass() {
        return Patch.generate(this.feeling == Feeling.GRASS ? 0.55f : 0.3f, 3);
    }

    protected void decorate() {
        int pos;
        int i = 33;
        while (i < 991) {
            if (this.map[i] == 1) {
                int count = 0;
                for (int i2 : NEIGHBOURS8) {
                    if ((Terrain.flags[this.map[i2 + i]] & 1) > 0) {
                        count++;
                    }
                }
                if (Random.Int(80) < count) {
                    this.map[i] = 24;
                }
            } else if (this.map[i] == 4 && this.map[i - 1] != 12 && this.map[i - 32] != 12 && Random.Int(20) == 0) {
                this.map[i] = 12;
            }
            i++;
        }
        do {
            pos = this.roomEntrance.random();
        } while (pos == this.entrance);
        this.map[pos] = 29;
    }

    public String tileName(int tile) {
        switch (tile) {
            case WndUpdates.ID_CAVES /*2*/:
                return "Embermoss";
            case BuffIndicator.FROST /*15*/:
                return "Emberfungi";
            case ItemSpriteSheet.RING_RUBY /*35*/:
            case ItemSpriteSheet.RING_AMETHYST /*36*/:
                return "Pillar";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Cold lava";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case ItemSpriteSheet.RING_RUBY /*35*/:
            case ItemSpriteSheet.RING_AMETHYST /*36*/:
                return "The pillar is made of real humanoid skulls. Awesome.";
            case ItemSpriteSheet.SCROLL_SOWILO /*41*/:
                return "Books in ancient languages smoulder in the bookshelf.";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "It looks like lava, but it's cold and probably safe to touch.";
            default:
                return super.tileDesc(tile);
        }
    }

    public void addVisuals(Scene scene) {
        super.addVisuals(scene);
        addVisuals(this, scene);
    }

    public static void addVisuals(Level level, Scene scene) {
        for (int i = 0; i < Level.LENGTH; i++) {
            if (level.map[i] == 63) {
                scene.add(new Stream(i));
            }
        }
    }
}
