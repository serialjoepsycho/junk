package com.watabou.pixeldungeon.levels;

public class Terrain {
    public static final int ALARM_TRAP = 30;
    public static final int ALCHEMY = 42;
    public static final int AVOID = 32;
    public static final int BARRICADE = 13;
    public static final int BOOKSHELF = 41;
    public static final int CHASM = 0;
    public static final int CHASM_FLOOR = 43;
    public static final int CHASM_FLOOR_SP = 44;
    public static final int CHASM_WALL = 45;
    public static final int CHASM_WATER = 46;
    public static final int DOOR = 5;
    public static final int EMBERS = 9;
    public static final int EMPTY = 1;
    public static final int EMPTY_DECO = 24;
    public static final int EMPTY_SP = 14;
    public static final int EMPTY_WELL = 3;
    public static final int ENTRANCE = 7;
    public static final int EXIT = 8;
    public static final int FIRE_TRAP = 19;
    public static final int FLAMABLE = 4;
    public static final int GRASS = 2;
    public static final int GRIPPING_TRAP = 37;
    public static final int HIGH_GRASS = 15;
    public static final int INACTIVE_TRAP = 23;
    public static final int LIGHTNING_TRAP = 32;
    public static final int LIQUID = 64;
    public static final int LOCKED_DOOR = 10;
    public static final int LOCKED_EXIT = 25;
    public static final int LOS_BLOCKING = 2;
    public static final int OPEN_DOOR = 6;
    public static final int PARALYTIC_TRAP = 21;
    public static final int PASSABLE = 1;
    public static final int PEDESTAL = 11;
    public static final int PIT = 128;
    public static final int POISON_TRAP = 27;
    public static final int SECRET = 8;
    public static final int SECRET_ALARM_TRAP = 31;
    public static final int SECRET_DOOR = 16;
    public static final int SECRET_FIRE_TRAP = 20;
    public static final int SECRET_GRIPPING_TRAP = 38;
    public static final int SECRET_LIGHTNING_TRAP = 33;
    public static final int SECRET_PARALYTIC_TRAP = 22;
    public static final int SECRET_POISON_TRAP = 28;
    public static final int SECRET_SUMMONING_TRAP = 40;
    public static final int SECRET_TOXIC_TRAP = 18;
    public static final int SIGN = 29;
    public static final int SOLID = 16;
    public static final int STATUE = 35;
    public static final int STATUE_SP = 36;
    public static final int STORAGE = 64;
    public static final int SUMMONING_TRAP = 39;
    public static final int TOXIC_TRAP = 17;
    public static final int UNLOCKED_EXIT = 26;
    public static final int UNSTITCHABLE = 256;
    public static final int WALL = 4;
    public static final int WALL_DECO = 12;
    public static final int WATER = 63;
    public static final int WATER_TILES = 48;
    public static final int WELL = 34;
    public static final int[] flags;

    static {
        flags = new int[UNSTITCHABLE];
        flags[CHASM] = 416;
        flags[PASSABLE] = PASSABLE;
        flags[LOS_BLOCKING] = DOOR;
        flags[EMPTY_WELL] = PASSABLE;
        flags[WATER] = 321;
        flags[WALL] = 274;
        flags[DOOR] = 279;
        flags[OPEN_DOOR] = 261;
        flags[ENTRANCE] = PASSABLE;
        flags[STORAGE] = PASSABLE;
        flags[SECRET] = PASSABLE;
        flags[EMBERS] = PASSABLE;
        flags[LOCKED_DOOR] = 274;
        flags[PEDESTAL] = 257;
        flags[WALL_DECO] = flags[WALL];
        flags[BARRICADE] = SECRET_PARALYTIC_TRAP;
        flags[EMPTY_SP] = flags[PASSABLE] | UNSTITCHABLE;
        flags[HIGH_GRASS] = ENTRANCE;
        flags[EMPTY_DECO] = flags[PASSABLE];
        flags[LOCKED_EXIT] = SOLID;
        flags[UNLOCKED_EXIT] = PASSABLE;
        flags[SIGN] = DOOR;
        flags[WELL] = LIGHTNING_TRAP;
        flags[STATUE] = SOLID;
        flags[STATUE_SP] = flags[STATUE] | UNSTITCHABLE;
        flags[BOOKSHELF] = flags[BARRICADE] | UNSTITCHABLE;
        flags[ALCHEMY] = PASSABLE;
        flags[CHASM_WALL] = flags[CHASM];
        flags[CHASM_FLOOR] = flags[CHASM];
        flags[CHASM_FLOOR_SP] = flags[CHASM];
        flags[CHASM_WATER] = flags[CHASM];
        flags[SOLID] = (flags[WALL] | SECRET) | UNSTITCHABLE;
        flags[TOXIC_TRAP] = LIGHTNING_TRAP;
        flags[SECRET_TOXIC_TRAP] = flags[PASSABLE] | SECRET;
        flags[FIRE_TRAP] = LIGHTNING_TRAP;
        flags[SECRET_FIRE_TRAP] = flags[PASSABLE] | SECRET;
        flags[PARALYTIC_TRAP] = LIGHTNING_TRAP;
        flags[SECRET_PARALYTIC_TRAP] = flags[PASSABLE] | SECRET;
        flags[POISON_TRAP] = LIGHTNING_TRAP;
        flags[SECRET_POISON_TRAP] = flags[PASSABLE] | SECRET;
        flags[ALARM_TRAP] = LIGHTNING_TRAP;
        flags[SECRET_ALARM_TRAP] = flags[PASSABLE] | SECRET;
        flags[LIGHTNING_TRAP] = LIGHTNING_TRAP;
        flags[SECRET_LIGHTNING_TRAP] = flags[PASSABLE] | SECRET;
        flags[GRIPPING_TRAP] = LIGHTNING_TRAP;
        flags[SECRET_GRIPPING_TRAP] = flags[PASSABLE] | SECRET;
        flags[SUMMONING_TRAP] = LIGHTNING_TRAP;
        flags[SECRET_SUMMONING_TRAP] = flags[PASSABLE] | SECRET;
        flags[INACTIVE_TRAP] = flags[PASSABLE];
        for (int i = WATER_TILES; i < STORAGE; i += PASSABLE) {
            flags[i] = flags[WATER];
        }
    }

    public static int discover(int terr) {
        switch (terr) {
            case SOLID /*16*/:
                return DOOR;
            case SECRET_TOXIC_TRAP /*18*/:
                return TOXIC_TRAP;
            case SECRET_FIRE_TRAP /*20*/:
                return FIRE_TRAP;
            case SECRET_PARALYTIC_TRAP /*22*/:
                return PARALYTIC_TRAP;
            case SECRET_POISON_TRAP /*28*/:
                return POISON_TRAP;
            case SECRET_ALARM_TRAP /*31*/:
                return ALARM_TRAP;
            case SECRET_LIGHTNING_TRAP /*33*/:
                return LIGHTNING_TRAP;
            case SECRET_GRIPPING_TRAP /*38*/:
                return GRIPPING_TRAP;
            case SECRET_SUMMONING_TRAP /*40*/:
                return SUMMONING_TRAP;
            default:
                return terr;
        }
    }
}
