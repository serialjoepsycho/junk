package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Scene;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Bones;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.actors.mobs.Yog;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.FlameParticle;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Heap.Type;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.SkeletonKey;
import com.watabou.pixeldungeon.levels.painters.Painter;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;

public class HallsBossLevel extends Level {
    private static final String DROPPED = "droppped";
    private static final String ENTERED = "entered";
    private static final int ROOM_BOTTOM = 17;
    private static final int ROOM_LEFT = 15;
    private static final int ROOM_RIGHT = 17;
    private static final int ROOM_TOP = 15;
    private static final String STAIRS = "stairs";
    private boolean enteredArena;
    private boolean keyDropped;
    private int stairs;

    public HallsBossLevel() {
        this.color1 = 8393984;
        this.color2 = 10913057;
        this.viewDistance = 3;
        this.stairs = -1;
        this.enteredArena = false;
        this.keyDropped = false;
    }

    public String tilesTex() {
        return Assets.TILES_HALLS;
    }

    public String waterTex() {
        return Assets.WATER_HALLS;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(STAIRS, this.stairs);
        bundle.put(ENTERED, this.enteredArena);
        bundle.put(DROPPED, this.keyDropped);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.stairs = bundle.getInt(STAIRS);
        this.enteredArena = bundle.getBoolean(ENTERED);
        this.keyDropped = bundle.getBoolean(DROPPED);
    }

    protected boolean build() {
        int i;
        for (i = 0; i < 5; i++) {
            int top = Random.IntRange(2, 14);
            int bottom = Random.IntRange(18, 22);
            Painter.fill(this, (i * 4) + 2, top, 4, (bottom - top) + 1, 1);
            if (i == 2) {
                this.exit = ((i * 4) + 3) + ((top - 1) * 32);
            }
            for (int j = 0; j < 4; j++) {
                if (Random.Int(2) == 0) {
                    this.map[((i * 4) + j) + (Random.IntRange(top + 1, bottom - 1) * 32)] = 12;
                }
            }
        }
        this.map[this.exit] = 25;
        Painter.fill(this, 14, 14, 5, 5, 4);
        Painter.fill(this, ROOM_TOP, ROOM_TOP, 3, 3, 1);
        this.entrance = Random.Int(16, 16) + (Random.Int(16, 16) * 32);
        this.map[this.entrance] = 7;
        boolean[] patch = Patch.generate(0.45f, 6);
        i = 0;
        while (i < Level.LENGTH) {
            if (this.map[i] == 1 && patch[i]) {
                this.map[i] = 63;
            }
            i++;
        }
        return true;
    }

    protected void decorate() {
        for (int i = 0; i < Level.LENGTH; i++) {
            if (this.map[i] == 1 && Random.Int(10) == 0) {
                this.map[i] = 24;
            }
        }
    }

    protected void createMobs() {
    }

    public Actor respawner() {
        return null;
    }

    protected void createItems() {
        Item item = Bones.get();
        if (item != null) {
            while (true) {
                int pos = Random.IntRange(ROOM_TOP, ROOM_RIGHT) + (Random.IntRange(16, ROOM_RIGHT) * 32);
                if (pos != this.entrance && this.map[pos] != 29) {
                    drop(item, pos).type = Type.SKELETON;
                    return;
                }
            }
        }
    }

    public int randomRespawnCell() {
        return -1;
    }

    public void press(int cell, Char hero) {
        super.press(cell, hero);
        if (!this.enteredArena && hero == Dungeon.hero && cell != this.entrance) {
            int i;
            this.enteredArena = true;
            for (i = 14; i <= 18; i++) {
                doMagic(i + 448);
                doMagic(i + 576);
            }
            for (i = ROOM_TOP; i < 18; i++) {
                doMagic(((i * 32) + ROOM_TOP) - 1);
                doMagic(((i * 32) + ROOM_RIGHT) + 1);
            }
            doMagic(this.entrance);
            GameScene.updateMap();
            Dungeon.observe();
            Mob boss = new Yog();
            while (true) {
                boss.pos = Random.Int(Level.LENGTH);
                if (passable[boss.pos] && !Dungeon.visible[boss.pos]) {
                    GameScene.add(boss);
                    boss.spawnFists();
                    this.stairs = this.entrance;
                    this.entrance = -1;
                    return;
                }
            }
        }
    }

    private void doMagic(int cell) {
        Level.set(cell, 14);
        CellEmitter.get(cell).start(FlameParticle.FACTORY, 0.1f, 3);
    }

    public Heap drop(Item item, int cell) {
        if (!this.keyDropped && (item instanceof SkeletonKey)) {
            this.keyDropped = true;
            this.entrance = this.stairs;
            Level.set(this.entrance, 7);
            GameScene.updateMap(this.entrance);
        }
        return super.drop(item, cell);
    }

    public String tileName(int tile) {
        switch (tile) {
            case WndUpdates.ID_CAVES /*2*/:
                return "Embermoss";
            case ROOM_TOP /*15*/:
                return "Emberfungi";
            case ItemSpriteSheet.RING_RUBY /*35*/:
            case ItemSpriteSheet.RING_AMETHYST /*36*/:
                return "Pillar";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Cold lava";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case ItemSpriteSheet.RING_RUBY /*35*/:
            case ItemSpriteSheet.RING_AMETHYST /*36*/:
                return "The pillar is made of real humanoid skulls. Awesome.";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "It looks like lava, but it's cold and probably safe to touch.";
            default:
                return super.tileDesc(tile);
        }
    }

    public void addVisuals(Scene scene) {
        HallsLevel.addVisuals(this, scene);
    }
}
