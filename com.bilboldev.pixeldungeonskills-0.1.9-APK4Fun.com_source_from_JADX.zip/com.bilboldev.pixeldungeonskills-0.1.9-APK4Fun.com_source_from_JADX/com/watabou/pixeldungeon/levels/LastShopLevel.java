package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Scene;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Bones;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.mobs.npcs.Imp.Quest;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.levels.Room.Type;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.utils.Graph;
import com.watabou.utils.Random;
import java.util.Iterator;
import java.util.List;

public class LastShopLevel extends RegularLevel {
    public LastShopLevel() {
        this.color1 = 4941366;
        this.color2 = 15921906;
    }

    public String tilesTex() {
        return Assets.TILES_CITY;
    }

    public String waterTex() {
        return Assets.WATER_CITY;
    }

    protected boolean build() {
        initRooms();
        int retry = 0;
        int minDistance = (int) Math.sqrt((double) this.rooms.size());
        while (true) {
            int i = 0;
            while (true) {
                int innerRetry = i + 1;
                if (i <= 10) {
                    this.roomEntrance = (Room) Random.element(this.rooms);
                    if (this.roomEntrance.width() >= 4 && this.roomEntrance.height() >= 4) {
                        break;
                    }
                    i = innerRetry;
                } else {
                    return false;
                }
            }
            i = 0;
            while (true) {
                innerRetry = i + 1;
                if (i <= 10) {
                    this.roomExit = (Room) Random.element(this.rooms);
                    if (this.roomExit != this.roomEntrance && this.roomExit.width() >= 6 && this.roomExit.height() >= 6 && this.roomExit.top != 0) {
                        break;
                    }
                    i = innerRetry;
                } else {
                    return false;
                }
            }
            Graph.buildDistanceMap(this.rooms, this.roomExit);
            int distance = Graph.buildPath(this.rooms, this.roomEntrance, this.roomExit).size();
            int retry2 = retry + 1;
            if (retry > 10) {
                retry = retry2;
                return false;
            } else if (distance >= minDistance) {
                break;
            } else {
                retry = retry2;
            }
        }
        this.roomEntrance.type = Type.ENTRANCE;
        this.roomExit.type = Type.EXIT;
        Graph.buildDistanceMap(this.rooms, this.roomExit);
        Graph.setPrice(Graph.buildPath(this.rooms, this.roomEntrance, this.roomExit), this.roomEntrance.distance);
        Graph.buildDistanceMap(this.rooms, this.roomExit);
        List<Room> path = Graph.buildPath(this.rooms, this.roomEntrance, this.roomExit);
        Room room = this.roomEntrance;
        for (Room next : path) {
            room.connect(next);
            room = next;
        }
        Room roomShop = null;
        int shopSquare = 0;
        Iterator it = this.rooms.iterator();
        while (it.hasNext()) {
            Room r = (Room) it.next();
            if (r.type == Type.NULL && r.connected.size() > 0) {
                r.type = Type.PASSAGE;
                if (r.square() > shopSquare) {
                    roomShop = r;
                    shopSquare = r.square();
                }
            }
        }
        if (roomShop == null || shopSquare < 30) {
            retry = retry2;
            return false;
        }
        roomShop.type = Quest.isCompleted() ? Type.SHOP : Type.STANDARD;
        paint();
        paintWater();
        paintGrass();
        retry = retry2;
        return true;
    }

    protected void decorate() {
        for (int i = 0; i < Level.LENGTH; i++) {
            if (this.map[i] == 1 && Random.Int(10) == 0) {
                this.map[i] = 24;
            } else if (this.map[i] == 4 && Random.Int(8) == 0) {
                this.map[i] = 12;
            } else if (this.map[i] == 16) {
                this.map[i] = 5;
            }
        }
        if (Quest.isCompleted()) {
            int pos;
            do {
                pos = this.roomEntrance.random();
            } while (pos == this.entrance);
            this.map[pos] = 29;
        }
    }

    protected void createMobs() {
    }

    public Actor respawner() {
        return null;
    }

    protected void createItems() {
        Item item = Bones.get();
        if (item != null) {
            while (true) {
                int pos = this.roomEntrance.random();
                if (pos != this.entrance && this.map[pos] != 29) {
                    drop(item, pos).type = Heap.Type.SKELETON;
                    return;
                }
            }
        }
    }

    public int randomRespawnCell() {
        return -1;
    }

    public String tileName(int tile) {
        switch (tile) {
            case BuffIndicator.FROST /*15*/:
                return "High blooming flowers";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Suspiciously colored water";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case BuffIndicator.SLOW /*7*/:
                return "A ramp leads up to the upper depth.";
            case BuffIndicator.OOZE /*8*/:
                return "A ramp leads down to the Inferno.";
            case BuffIndicator.INVISIBLE /*12*/:
            case BuffIndicator.BARKSKIN /*24*/:
                return "Several tiles are missing here.";
            case BuffIndicator.WEAKNESS /*14*/:
                return "Thick carpet covers the floor.";
            default:
                return super.tileDesc(tile);
        }
    }

    protected boolean[] water() {
        return Patch.generate(0.35f, 4);
    }

    protected boolean[] grass() {
        return Patch.generate(0.3f, 3);
    }

    public void addVisuals(Scene scene) {
        CityLevel.addVisuals(this, scene);
    }
}
