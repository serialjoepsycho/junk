package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Scene;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Bones;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.Bestiary;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.IronKey;
import com.watabou.pixeldungeon.items.keys.SkeletonKey;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Type;
import com.watabou.pixeldungeon.levels.painters.Painter;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.utils.Bundle;
import com.watabou.utils.Graph;
import com.watabou.utils.Point;
import com.watabou.utils.Random;
import java.util.Iterator;
import java.util.List;

public class PrisonBossLevel extends RegularLevel {
    private static final String ARENA = "arena";
    private static final String DOOR = "door";
    private static final String DROPPED = "droppped";
    private static final String ENTERED = "entered";
    private Room anteroom;
    private int arenaDoor;
    private boolean enteredArena;
    private boolean keyDropped;

    public PrisonBossLevel() {
        this.color1 = 6976061;
        this.color2 = 8950348;
        this.enteredArena = false;
        this.keyDropped = false;
    }

    public String tilesTex() {
        return Assets.TILES_PRISON;
    }

    public String waterTex() {
        return Assets.WATER_PRISON;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(ARENA, this.roomExit);
        bundle.put(DOOR, this.arenaDoor);
        bundle.put(ENTERED, this.enteredArena);
        bundle.put(DROPPED, this.keyDropped);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.roomExit = (Room) bundle.get(ARENA);
        this.arenaDoor = bundle.getInt(DOOR);
        this.enteredArena = bundle.getBoolean(ENTERED);
        this.keyDropped = bundle.getBoolean(DROPPED);
    }

    protected boolean build() {
        initRooms();
        int i = 0;
        while (true) {
            int retry = i + 1;
            if (i > 10) {
                return false;
            }
            int i2 = 0;
            while (true) {
                int innerRetry = i2 + 1;
                if (i2 <= 10) {
                    this.roomEntrance = (Room) Random.element(this.rooms);
                    if (this.roomEntrance.width() >= 4 && this.roomEntrance.height() >= 4) {
                        break;
                    }
                    i2 = innerRetry;
                } else {
                    return false;
                }
            }
            i2 = 0;
            while (true) {
                innerRetry = i2 + 1;
                if (i2 <= 10) {
                    this.roomExit = (Room) Random.element(this.rooms);
                    if (this.roomExit != this.roomEntrance && this.roomExit.width() >= 7 && this.roomExit.height() >= 7 && this.roomExit.top != 0) {
                        break;
                    }
                    i2 = innerRetry;
                } else {
                    return false;
                }
            }
            Graph.buildDistanceMap(this.rooms, this.roomExit);
            if (Graph.buildPath(this.rooms, this.roomEntrance, this.roomExit).size() >= 3) {
                break;
            }
            i = retry;
        }
        this.roomEntrance.type = Type.ENTRANCE;
        this.roomExit.type = Type.BOSS_EXIT;
        Graph.setPrice(Graph.buildPath(this.rooms, this.roomEntrance, this.roomExit), this.roomEntrance.distance);
        Graph.buildDistanceMap(this.rooms, this.roomExit);
        List<Room> path = Graph.buildPath(this.rooms, this.roomEntrance, this.roomExit);
        this.anteroom = (Room) path.get(path.size() - 2);
        this.anteroom.type = Type.STANDARD;
        Room room = this.roomEntrance;
        for (Room next : path) {
            room.connect(next);
            room = next;
        }
        Iterator it = this.rooms.iterator();
        while (it.hasNext()) {
            Room r = (Room) it.next();
            if (r.type == Type.NULL && r.connected.size() > 0) {
                r.type = Type.PASSAGE;
            }
        }
        paint();
        if (((Door) this.roomExit.connected.get((Room) this.roomExit.connected.keySet().toArray()[0])).y == this.roomExit.top) {
            return false;
        }
        paintWater();
        paintGrass();
        placeTraps();
        return true;
    }

    protected boolean[] water() {
        return Patch.generate(0.45f, 5);
    }

    protected boolean[] grass() {
        return Patch.generate(0.3f, 4);
    }

    protected void paintDoors(Room r) {
        for (Room n : r.connected.keySet()) {
            if (r.type != Type.NULL) {
                Point door = (Point) r.connected.get(n);
                if (r.type == Type.PASSAGE && n.type == Type.PASSAGE) {
                    Painter.set((Level) this, door, 1);
                } else {
                    Painter.set((Level) this, door, 5);
                }
            }
        }
    }

    protected void placeTraps() {
        int nTraps = nTraps();
        for (int i = 0; i < nTraps; i++) {
            int trapPos = Random.Int(Level.LENGTH);
            if (this.map[trapPos] == 1) {
                this.map[trapPos] = 27;
            }
        }
    }

    protected void decorate() {
        int pos;
        int i = 33;
        while (i < 991) {
            if (this.map[i] == 1) {
                float c = 0.15f;
                if (this.map[i + 1] == 4 && this.map[i + 32] == 4) {
                    c = 0.15f + 0.2f;
                }
                if (this.map[i - 1] == 4 && this.map[i + 32] == 4) {
                    c += 0.2f;
                }
                if (this.map[i + 1] == 4 && this.map[i - 32] == 4) {
                    c += 0.2f;
                }
                if (this.map[i - 1] == 4 && this.map[i - 32] == 4) {
                    c += 0.2f;
                }
                if (Random.Float() < c) {
                    this.map[i] = 24;
                }
            }
            i++;
        }
        i = 0;
        while (i < 32) {
            if (this.map[i] == 4 && ((this.map[i + 32] == 1 || this.map[i + 32] == 14) && Random.Int(4) == 0)) {
                this.map[i] = 12;
            }
            i++;
        }
        i = 32;
        while (i < 992) {
            if (this.map[i] == 4 && this.map[i - 32] == 4 && ((this.map[i + 32] == 1 || this.map[i + 32] == 14) && Random.Int(2) == 0)) {
                this.map[i] = 12;
            }
            i++;
        }
        do {
            pos = this.roomEntrance.random();
        } while (pos == this.entrance);
        this.map[pos] = 29;
        Point door = this.roomExit.entrance();
        this.arenaDoor = door.f18x + (door.f19y * 32);
        Painter.set((Level) this, this.arenaDoor, 10);
        Painter.fill(this, this.roomExit.left + 2, this.roomExit.top + 2, this.roomExit.width() - 3, this.roomExit.height() - 3, 23);
    }

    protected void createMobs() {
    }

    public Actor respawner() {
        return null;
    }

    protected void createItems() {
        int keyPos = this.anteroom.random();
        while (!passable[keyPos]) {
            keyPos = this.anteroom.random();
        }
        drop(new IronKey(), keyPos).type = Heap.Type.CHEST;
        Item item = Bones.get();
        if (item != null) {
            while (true) {
                int pos = this.roomEntrance.random();
                if (pos != this.entrance && this.map[pos] != 29) {
                    drop(item, pos).type = Heap.Type.SKELETON;
                    return;
                }
            }
        }
    }

    public void press(int cell, Char ch) {
        super.press(cell, ch);
        if (ch == Dungeon.hero && !this.enteredArena && this.roomExit.inside(cell)) {
            this.enteredArena = true;
            while (true) {
                int pos = this.roomExit.random();
                if (pos != cell && Actor.findChar(pos) == null) {
                    Mob boss = Bestiary.mob(Dungeon.depth);
                    boss.state = boss.HUNTING;
                    boss.pos = pos;
                    GameScene.add(boss);
                    boss.notice();
                    mobPress(boss);
                    Level.set(this.arenaDoor, 10);
                    GameScene.updateMap(this.arenaDoor);
                    Dungeon.observe();
                    return;
                }
            }
        }
    }

    public Heap drop(Item item, int cell) {
        if (!this.keyDropped && (item instanceof SkeletonKey)) {
            this.keyDropped = true;
            Level.set(this.arenaDoor, 5);
            GameScene.updateMap(this.arenaDoor);
            Dungeon.observe();
        }
        return super.drop(item, cell);
    }

    public int randomRespawnCell() {
        return -1;
    }

    public String tileName(int tile) {
        switch (tile) {
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Dark cold water.";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case BuffIndicator.BARKSKIN /*24*/:
                return "There are old blood stains on the floor.";
            default:
                return super.tileDesc(tile);
        }
    }

    public void addVisuals(Scene scene) {
        PrisonLevel.addVisuals(this, scene);
    }
}
