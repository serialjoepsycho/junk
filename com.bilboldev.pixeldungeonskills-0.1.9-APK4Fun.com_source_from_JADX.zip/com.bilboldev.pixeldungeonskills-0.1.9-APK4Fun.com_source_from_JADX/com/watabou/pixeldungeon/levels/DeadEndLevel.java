package com.watabou.pixeldungeon.levels;

import com.watabou.pixeldungeon.Assets;
import com.watabou.utils.Random;
import java.util.Arrays;

public class DeadEndLevel extends Level {
    private static final int SIZE = 5;

    public DeadEndLevel() {
        this.color1 = 5459774;
        this.color2 = 12179041;
    }

    public String tilesTex() {
        return Assets.TILES_CAVES;
    }

    public String waterTex() {
        return Assets.WATER_HALLS;
    }

    protected boolean build() {
        int i;
        Arrays.fill(this.map, 4);
        for (i = 2; i < SIZE; i++) {
            for (int j = 2; j < SIZE; j++) {
                this.map[(i * 32) + j] = 1;
            }
        }
        for (i = 1; i <= SIZE; i++) {
            int[] iArr = this.map;
            int i2 = i + 32;
            int[] iArr2 = this.map;
            int i3 = i + 160;
            int[] iArr3 = this.map;
            int i4 = (i * 32) + 1;
            this.map[(i * 32) + SIZE] = 63;
            iArr3[i4] = 63;
            iArr2[i3] = 63;
            iArr[i2] = 63;
        }
        this.entrance = 163;
        this.map[this.entrance] = 7;
        this.exit = -1;
        this.map[99] = 29;
        return true;
    }

    protected void decorate() {
        for (int i = 0; i < Level.LENGTH; i++) {
            if (this.map[i] == 1 && Random.Int(10) == 0) {
                this.map[i] = 24;
            } else if (this.map[i] == 4 && Random.Int(8) == 0) {
                this.map[i] = 12;
            }
        }
    }

    protected void createMobs() {
    }

    protected void createItems() {
    }

    public int randomRespawnCell() {
        return -1;
    }
}
