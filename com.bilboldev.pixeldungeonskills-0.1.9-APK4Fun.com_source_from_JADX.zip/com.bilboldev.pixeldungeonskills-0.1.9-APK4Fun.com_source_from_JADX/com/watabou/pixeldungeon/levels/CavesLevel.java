package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Game;
import com.watabou.noosa.Group;
import com.watabou.noosa.Scene;
import com.watabou.noosa.particles.PixelParticle;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.actors.mobs.npcs.Blacksmith.Quest;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level.Feeling;
import com.watabou.pixeldungeon.levels.Room.Type;
import com.watabou.pixeldungeon.levels.painters.Painter;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Point;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;
import com.watabou.utils.Rect;
import java.util.Iterator;

public class CavesLevel extends RegularLevel {

    public static final class Sparkle extends PixelParticle {
        public void reset(float x, float y) {
            revive();
            this.x = x;
            this.y = y;
            this.lifespan = 0.5f;
            this.left = 0.5f;
        }

        public void update() {
            super.update();
            float p = this.left / this.lifespan;
            float f = p < 0.5f ? p * Pickaxe.TIME_TO_MINE : (Key.TIME_TO_UNLOCK - p) * Pickaxe.TIME_TO_MINE;
            this.am = f;
            size(f * Pickaxe.TIME_TO_MINE);
        }
    }

    private static class Vein extends Group {
        private float delay;
        private int pos;

        public Vein(int pos) {
            this.pos = pos;
            this.delay = Random.Float(Pickaxe.TIME_TO_MINE);
        }

        public void update() {
            boolean z = Dungeon.visible[this.pos];
            this.visible = z;
            if (z) {
                super.update();
                float f = this.delay - Game.elapsed;
                this.delay = f;
                if (f <= 0.0f) {
                    this.delay = Random.Float();
                    PointF p = DungeonTilemap.tileToWorld(this.pos);
                    ((Sparkle) recycle(Sparkle.class)).reset(p.f24x + Random.Float(ShadowBox.SIZE), p.f25y + Random.Float(ShadowBox.SIZE));
                }
            }
        }
    }

    public CavesLevel() {
        this.color1 = 5459774;
        this.color2 = 12179041;
        this.viewDistance = 6;
    }

    public String tilesTex() {
        return Assets.TILES_CAVES;
    }

    public String waterTex() {
        return Assets.WATER_CAVES;
    }

    protected boolean[] water() {
        return Patch.generate(this.feeling == Feeling.WATER ? 0.6f : 0.45f, 6);
    }

    protected boolean[] grass() {
        return Patch.generate(this.feeling == Feeling.GRASS ? 0.55f : 0.35f, 3);
    }

    protected void assignRoomType() {
        super.assignRoomType();
        Quest.spawn(this.rooms);
    }

    protected void decorate() {
        int i;
        int pos;
        Iterator it = this.rooms.iterator();
        while (it.hasNext()) {
            Room room = (Room) it.next();
            if (room.type == Type.STANDARD && room.width() > 3 && room.height() > 3) {
                int corner;
                int s = room.square();
                if (Random.Int(s) > 8) {
                    corner = (room.left + 1) + ((room.top + 1) * 32);
                    if (this.map[corner - 1] == 4 && this.map[corner - 32] == 4) {
                        this.map[corner] = 4;
                    }
                }
                if (Random.Int(s) > 8) {
                    corner = (room.right - 1) + ((room.top + 1) * 32);
                    if (this.map[corner + 1] == 4 && this.map[corner - 32] == 4) {
                        this.map[corner] = 4;
                    }
                }
                if (Random.Int(s) > 8) {
                    corner = (room.left + 1) + ((room.bottom - 1) * 32);
                    if (this.map[corner - 1] == 4 && this.map[corner + 32] == 4) {
                        this.map[corner] = 4;
                    }
                }
                if (Random.Int(s) > 8) {
                    corner = (room.right - 1) + ((room.bottom - 1) * 32);
                    if (this.map[corner + 1] == 4 && this.map[corner + 32] == 4) {
                        this.map[corner] = 4;
                    }
                }
                for (Room n : room.connected.keySet()) {
                    Room n2;
                    if ((n2.type == Type.STANDARD || n2.type == Type.TUNNEL) && Random.Int(3) == 0) {
                        Painter.set((Level) this, (Point) room.connected.get(n2), 24);
                    }
                }
            }
        }
        for (i = 33; i < 992; i++) {
            if (this.map[i] == 1) {
                int n3 = 0;
                if (this.map[i + 1] == 4) {
                    n3 = 0 + 1;
                }
                if (this.map[i - 1] == 4) {
                    n3++;
                }
                if (this.map[i + 32] == 4) {
                    n3++;
                }
                if (this.map[i - 32] == 4) {
                    n3++;
                }
                if (Random.Int(6) <= n3) {
                    this.map[i] = 24;
                }
            }
        }
        for (i = 0; i < Level.LENGTH; i++) {
            if (this.map[i] == 4 && Random.Int(12) == 0) {
                this.map[i] = 12;
            }
        }
        do {
            pos = this.roomEntrance.random();
        } while (pos == this.entrance);
        this.map[pos] = 29;
        if (!Dungeon.bossLevel(Dungeon.depth + 1)) {
            Iterator it2 = this.rooms.iterator();
            while (it2.hasNext()) {
                Room r = (Room) it2.next();
                if (r.type == Type.STANDARD) {
                    Iterator it3 = r.neigbours.iterator();
                    while (it3.hasNext()) {
                        n2 = (Room) it3.next();
                        if (n2.type == Type.STANDARD && !r.connected.containsKey(n2)) {
                            Rect w = r.intersect(n2);
                            if (w.left == w.right && w.bottom - w.top >= 5) {
                                w.top += 2;
                                w.bottom--;
                                w.right++;
                                Painter.fill(this, w.left, w.top, 1, w.height(), 0);
                            } else if (w.top == w.bottom && w.right - w.left >= 5) {
                                w.left += 2;
                                w.right--;
                                w.bottom++;
                                Painter.fill(this, w.left, w.top, w.width(), 1, 0);
                            }
                        }
                    }
                }
            }
        }
    }

    public String tileName(int tile) {
        switch (tile) {
            case WndUpdates.ID_CAVES /*2*/:
                return "Fluorescent moss";
            case BuffIndicator.FROST /*15*/:
                return "Fluorescent mushrooms";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Freezing cold water.";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case BuffIndicator.SLOW /*7*/:
                return "The ladder leads up to the upper depth.";
            case BuffIndicator.OOZE /*8*/:
                return "The ladder leads down to the lower depth.";
            case BuffIndicator.INVISIBLE /*12*/:
                return "A vein of some ore is visible on the wall. Gold?";
            case BuffIndicator.FROST /*15*/:
                return "Huge mushrooms block the view.";
            case ItemSpriteSheet.SCROLL_SOWILO /*41*/:
                return "Who would need a bookshelf in a cave?";
            default:
                return super.tileDesc(tile);
        }
    }

    public void addVisuals(Scene scene) {
        super.addVisuals(scene);
        addVisuals(this, scene);
    }

    public static void addVisuals(Level level, Scene scene) {
        for (int i = 0; i < Level.LENGTH; i++) {
            if (level.map[i] == 12) {
                scene.add(new Vein(i));
            }
        }
    }
}
