package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Game;
import com.watabou.noosa.Scene;
import com.watabou.noosa.particles.Emitter;
import com.watabou.noosa.particles.Emitter.Factory;
import com.watabou.noosa.particles.PixelParticle;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.actors.mobs.npcs.Ghost.Quest;
import com.watabou.pixeldungeon.effects.Ripple;
import com.watabou.pixeldungeon.items.DewVial;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level.Feeling;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.utils.ColorMath;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;

public class SewerLevel extends RegularLevel {

    private static class Sink extends Emitter {
        private static final Factory factory;
        private int pos;
        private float rippleDelay;

        /* renamed from: com.watabou.pixeldungeon.levels.SewerLevel.Sink.1 */
        static class C01041 extends Factory {
            C01041() {
            }

            public void emit(Emitter emitter, int index, float x, float y) {
                ((WaterParticle) emitter.recycle(WaterParticle.class)).reset(x, y);
            }
        }

        static {
            factory = new C01041();
        }

        public Sink(int pos) {
            this.rippleDelay = 0.0f;
            this.pos = pos;
            PointF p = DungeonTilemap.tileCenterToWorld(pos);
            pos(p.f24x - Pickaxe.TIME_TO_MINE, p.f25y + Key.TIME_TO_UNLOCK, 4.0f, 0.0f);
            pour(factory, 0.05f);
        }

        public void update() {
            boolean z = Dungeon.visible[this.pos];
            this.visible = z;
            if (z) {
                super.update();
                float f = this.rippleDelay - Game.elapsed;
                this.rippleDelay = f;
                if (f <= 0.0f) {
                    Ripple ripple = GameScene.ripple(this.pos + 32);
                    ripple.y -= 8.0f;
                    this.rippleDelay = Random.Float(0.2f, 0.3f);
                }
            }
        }
    }

    public static final class WaterParticle extends PixelParticle {
        public WaterParticle() {
            this.acc.f25y = 50.0f;
            this.am = 0.5f;
            color(ColorMath.random(11979970, 3892819));
            size(Pickaxe.TIME_TO_MINE);
        }

        public void reset(float x, float y) {
            revive();
            this.x = x;
            this.y = y;
            this.speed.set(Random.Float(-2.0f, Pickaxe.TIME_TO_MINE), 0.0f);
            this.lifespan = 0.5f;
            this.left = 0.5f;
        }
    }

    public SewerLevel() {
        this.color1 = 4748860;
        this.color2 = 5871946;
    }

    public String tilesTex() {
        return Assets.TILES_SEWERS;
    }

    public String waterTex() {
        return Assets.WATER_SEWERS;
    }

    protected boolean[] water() {
        return Patch.generate(this.feeling == Feeling.WATER ? 0.6f : 0.45f, 5);
    }

    protected boolean[] grass() {
        return Patch.generate(this.feeling == Feeling.GRASS ? 0.6f : 0.4f, 4);
    }

    protected void decorate() {
        int pos;
        int i = 0;
        while (i < 32) {
            if (this.map[i] == 4 && this.map[i + 32] == 63 && Random.Int(4) == 0) {
                this.map[i] = 12;
            }
            i++;
        }
        i = 32;
        while (i < 992) {
            if (this.map[i] == 4 && this.map[i - 32] == 4 && this.map[i + 32] == 63 && Random.Int(2) == 0) {
                this.map[i] = 12;
            }
            i++;
        }
        for (i = 33; i < 991; i++) {
            if (this.map[i] == 1) {
                int i2;
                int i3;
                if (this.map[i + 1] == 4) {
                    i2 = 1;
                } else {
                    i2 = 0;
                }
                if (this.map[i - 1] == 4) {
                    i3 = 1;
                } else {
                    i3 = 0;
                }
                i3 += i2;
                if (this.map[i + 32] == 4) {
                    i2 = 1;
                } else {
                    i2 = 0;
                }
                i3 += i2;
                if (this.map[i - 32] == 4) {
                    i2 = 1;
                } else {
                    i2 = 0;
                }
                int count = i3 + i2;
                if (Random.Int(16) < count * count) {
                    this.map[i] = 24;
                }
            }
        }
        do {
            pos = this.roomEntrance.random();
        } while (pos == this.entrance);
        this.map[pos] = 29;
    }

    protected void createMobs() {
        super.createMobs();
        Quest.spawn(this);
    }

    protected void createItems() {
        if (Dungeon.dewVial && Random.Int(4 - Dungeon.depth) == 0) {
            addItemToSpawn(new DewVial());
            Dungeon.dewVial = false;
        }
        super.createItems();
    }

    public void addVisuals(Scene scene) {
        super.addVisuals(scene);
        addVisuals(this, scene);
    }

    public static void addVisuals(Level level, Scene scene) {
        for (int i = 0; i < Level.LENGTH; i++) {
            if (level.map[i] == 12) {
                scene.add(new Sink(i));
            }
        }
    }

    public String tileName(int tile) {
        switch (tile) {
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Murky water";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case BuffIndicator.BARKSKIN /*24*/:
                return "Wet yellowish moss covers the floor.";
            case ItemSpriteSheet.SCROLL_SOWILO /*41*/:
                return "The bookshelf is packed with cheap useless books. Might it burn?";
            default:
                return super.tileDesc(tile);
        }
    }
}
