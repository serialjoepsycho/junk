package com.watabou.pixeldungeon.levels.features;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;

public class Door {
    public static void enter(int pos) {
        Level.set(pos, 6);
        GameScene.updateMap(pos);
        Dungeon.observe();
        if (Dungeon.visible[pos]) {
            Sample.INSTANCE.play(Assets.SND_OPEN);
        }
    }

    public static void leave(int pos) {
        if (Dungeon.level.heaps.get(pos) == null) {
            Level.set(pos, 5);
            GameScene.updateMap(pos);
            Dungeon.observe();
        }
    }
}
