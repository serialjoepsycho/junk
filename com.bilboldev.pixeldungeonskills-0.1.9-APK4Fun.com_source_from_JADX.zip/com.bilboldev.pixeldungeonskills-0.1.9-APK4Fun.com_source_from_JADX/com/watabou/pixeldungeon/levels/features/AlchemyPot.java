package com.watabou.pixeldungeon.levels.features;

import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.windows.WndBag.Listener;
import com.watabou.pixeldungeon.windows.WndBag.Mode;

public class AlchemyPot {
    private static final String TXT_SELECT_SEED = "Select a seed to throw";
    private static Hero hero;
    private static final Listener itemSelector;
    private static int pos;

    /* renamed from: com.watabou.pixeldungeon.levels.features.AlchemyPot.1 */
    static class C01051 implements Listener {
        C01051() {
        }

        public void onSelect(Item item) {
            if (item != null) {
                item.cast(AlchemyPot.hero, AlchemyPot.pos);
            }
        }
    }

    public static void operate(Hero hero, int pos) {
        hero = hero;
        pos = pos;
        GameScene.selectItem(itemSelector, Mode.SEED, TXT_SELECT_SEED);
    }

    static {
        itemSelector = new C01051();
    }
}
