package com.watabou.pixeldungeon.levels.features;

import com.watabou.noosa.Camera;
import com.watabou.noosa.Game;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Cripple;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.Hero.Doom;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.levels.RegularLevel;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.Room.Type;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.InterlevelScene;
import com.watabou.pixeldungeon.scenes.InterlevelScene.Mode;
import com.watabou.pixeldungeon.sprites.MobSprite;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndOptions;
import com.watabou.utils.Random;

public class Chasm {
    private static final String TXT_CHASM = "Chasm";
    private static final String TXT_JUMP = "Do you really want to jump into the chasm? You can probably die.";
    private static final String TXT_NO = "No, I changed my mind";
    private static final String TXT_YES = "Yes, I know what I'm doing";
    public static boolean jumpConfirmed;

    /* renamed from: com.watabou.pixeldungeon.levels.features.Chasm.1 */
    static class C01061 extends WndOptions {
        final /* synthetic */ Hero val$hero;

        C01061(String title, String message, String[] options, Hero hero) {
            this.val$hero = hero;
            super(title, message, options);
        }

        protected void onSelect(int index) {
            if (index == 0) {
                Chasm.jumpConfirmed = true;
                this.val$hero.resume();
            }
        }
    }

    /* renamed from: com.watabou.pixeldungeon.levels.features.Chasm.2 */
    static class C01072 implements Doom {
        C01072() {
        }

        public void onDeath() {
            Badges.validateDeathFromFalling();
            Dungeon.fail(Utils.format(ResultDescriptions.FALL, Integer.valueOf(Dungeon.depth)));
            GLog.m2n("You fell to death...", new Object[0]);
        }
    }

    static {
        jumpConfirmed = false;
    }

    public static void heroJump(Hero hero) {
        GameScene.show(new C01061(TXT_CHASM, TXT_JUMP, new String[]{TXT_YES, TXT_NO}, hero));
    }

    public static void heroFall(int pos) {
        jumpConfirmed = false;
        Sample.INSTANCE.play(Assets.SND_FALLING);
        if (Dungeon.hero.isAlive()) {
            Dungeon.hero.interrupt();
            InterlevelScene.mode = Mode.FALL;
            if (Dungeon.level instanceof RegularLevel) {
                boolean z;
                Room room = ((RegularLevel) Dungeon.level).room(pos);
                if (room == null || room.type != Type.WEAK_FLOOR) {
                    z = false;
                } else {
                    z = true;
                }
                InterlevelScene.fallIntoPit = z;
            } else {
                InterlevelScene.fallIntoPit = false;
            }
            Game.switchScene(InterlevelScene.class);
            return;
        }
        Dungeon.hero.sprite.visible = false;
    }

    public static void heroLand() {
        Hero hero = Dungeon.hero;
        hero.sprite.burst(hero.sprite.blood(), 10);
        Camera.main.shake(4.0f, 0.2f);
        Buff.prolong(hero, Cripple.class, TomeOfMastery.TIME_TO_READ);
        hero.damage(Random.IntRange(hero.HT / 3, hero.HT / 2), new C01072());
    }

    public static void mobFall(Mob mob) {
        mob.destroy();
        ((MobSprite) mob.sprite).fall();
    }
}
