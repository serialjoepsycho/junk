package com.watabou.pixeldungeon.levels.features;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Barkskin;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroSubClass;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.LeafParticle;
import com.watabou.pixeldungeon.items.Dewdrop;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.rings.RingOfHerbalism.Herbalism;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.utils.Random;

public class HighGrass {
    public static void trample(Level level, int pos, Char ch) {
        Level.set(pos, 2);
        GameScene.updateMap(pos);
        if (!Dungeon.isChallenged(8)) {
            int herbalismLevel = 0;
            if (ch != null) {
                Herbalism herbalism = (Herbalism) ch.buff(Herbalism.class);
                if (herbalism != null) {
                    herbalismLevel = herbalism.level;
                }
            }
            if (herbalismLevel >= 0 && Random.Int(18) <= Random.Int(herbalismLevel + 1)) {
                level.drop(Generator.random(Category.SEED), pos).sprite.drop();
            }
            if (herbalismLevel >= 0 && Random.Int(6) <= Random.Int(herbalismLevel + 1)) {
                level.drop(new Dewdrop(), pos).sprite.drop();
            }
        }
        int leaves = 4;
        if ((ch instanceof Hero) && ((Hero) ch).subClass == HeroSubClass.WARDEN) {
            ((Barkskin) Buff.affect(ch, Barkskin.class)).level(ch.HT / 3);
            leaves = 8;
        }
        CellEmitter.get(pos).burst(LeafParticle.LEVEL_SPECIFIC, leaves);
        Dungeon.observe();
    }
}
