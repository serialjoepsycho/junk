package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Scene;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Statistics;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.buffs.Awareness;
import com.watabou.pixeldungeon.actors.buffs.Blindness;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Champ;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.buffs.Shadows;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.mobs.Bestiary;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.effects.particles.FlowParticle.Flow;
import com.watabou.pixeldungeon.effects.particles.WindParticle.Wind;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Gold;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Heap.Type;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.bags.ScrollHolder;
import com.watabou.pixeldungeon.items.bags.SeedPouch;
import com.watabou.pixeldungeon.items.food.Food;
import com.watabou.pixeldungeon.items.potions.PotionOfHealing;
import com.watabou.pixeldungeon.items.potions.PotionOfStrength;
import com.watabou.pixeldungeon.items.scrolls.Scroll;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfEnchantment;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfUpgrade;
import com.watabou.pixeldungeon.levels.features.Chasm;
import com.watabou.pixeldungeon.levels.features.Door;
import com.watabou.pixeldungeon.levels.painters.Painter;
import com.watabou.pixeldungeon.levels.traps.AlarmTrap;
import com.watabou.pixeldungeon.levels.traps.FireTrap;
import com.watabou.pixeldungeon.levels.traps.GrippingTrap;
import com.watabou.pixeldungeon.levels.traps.LightningTrap;
import com.watabou.pixeldungeon.levels.traps.ParalyticTrap;
import com.watabou.pixeldungeon.levels.traps.PoisonTrap;
import com.watabou.pixeldungeon.levels.traps.SummoningTrap;
import com.watabou.pixeldungeon.levels.traps.ToxicTrap;
import com.watabou.pixeldungeon.mechanics.ShadowCaster;
import com.watabou.pixeldungeon.plants.Plant;
import com.watabou.pixeldungeon.plants.Plant.Seed;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;
import com.watabou.utils.SparseArray;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public abstract class Level implements Bundlable {
    private static final String BLOBS = "blobs";
    private static final String ENTRANCE = "entrance";
    private static final String EXIT = "exit";
    private static final String HEAPS = "heaps";
    public static final int HEIGHT = 32;
    public static final int LENGTH = 1024;
    private static final String MAP = "map";
    private static final String MAPPED = "mapped";
    private static final String MOBS = "mobs";
    public static final int[] NEIGHBOURS4;
    public static final int[] NEIGHBOURS8;
    public static final int[] NEIGHBOURS9;
    private static final String PLANTS = "plants";
    private static final String STORAGE = "storage";
    protected static final float TIME_TO_RESPAWN = 50.0f;
    private static final String TXT_HIDDEN_PLATE_CLICKS = "A hidden pressure plate clicks!";
    private static final String VISITED = "visited";
    public static final int WIDTH = 32;
    public static boolean[] avoid;
    public static boolean[] discoverable;
    public static boolean[] fieldOfView;
    public static boolean[] flamable;
    public static int loadedMapSize;
    public static boolean[] losBlocking;
    public static boolean[] passable;
    public static boolean[] pit;
    protected static boolean pitRoomNeeded;
    public static boolean resizingNeeded;
    public static boolean[] secret;
    public static boolean[] solid;
    public static boolean[] water;
    protected static boolean weakFloorCreated;
    public HashMap<Class<? extends Blob>, Blob> blobs;
    public int color1;
    public int color2;
    public int entrance;
    public int exit;
    public Feeling feeling;
    public SparseArray<Heap> heaps;
    protected ArrayList<Item> itemsToSpawn;
    public int[] map;
    public boolean[] mapped;
    public HashSet<Mob> mobs;
    public SparseArray<Plant> plants;
    public int storage;
    public int viewDistance;
    public boolean[] visited;

    /* renamed from: com.watabou.pixeldungeon.levels.Level.1 */
    class C01021 extends Actor {
        C01021() {
        }

        protected boolean act() {
            if (Level.this.mobs.size() < Level.this.nMobs()) {
                Mob mob = Bestiary.mutable(Dungeon.depth);
                mob.state = mob.WANDERING;
                mob.pos = Level.this.randomRespawnCell();
                if (Dungeon.hero.isAlive() && mob.pos != -1) {
                    GameScene.add(mob);
                    if (Random.Int(10) < Level.this.difficultyChamp()) {
                        Buff.affect(mob, Champ.class);
                    }
                    if (Statistics.amuletObtained) {
                        mob.beckon(Dungeon.hero.pos);
                    }
                }
            }
            float f = (Dungeon.nightMode || Statistics.amuletObtained) ? 25.0f : Level.TIME_TO_RESPAWN;
            spend(f);
            return true;
        }
    }

    public enum Feeling {
        NONE,
        CHASM,
        WATER,
        GRASS
    }

    protected abstract boolean build();

    protected abstract void createItems();

    protected abstract void createMobs();

    protected abstract void decorate();

    public Level() {
        int i;
        if (Dungeon.isChallenged(WIDTH)) {
            i = 3;
        } else {
            i = 8;
        }
        this.viewDistance = i;
        this.feeling = Feeling.NONE;
        this.itemsToSpawn = new ArrayList();
        this.color1 = 17408;
        this.color2 = 8965188;
    }

    static {
        NEIGHBOURS4 = new int[]{-32, 1, WIDTH, -1};
        NEIGHBOURS8 = new int[]{1, -1, WIDTH, -32, 33, -31, 31, -33};
        NEIGHBOURS9 = new int[]{0, 1, -1, WIDTH, -32, 33, -31, 31, -33};
        fieldOfView = new boolean[LENGTH];
        passable = new boolean[LENGTH];
        losBlocking = new boolean[LENGTH];
        flamable = new boolean[LENGTH];
        secret = new boolean[LENGTH];
        solid = new boolean[LENGTH];
        avoid = new boolean[LENGTH];
        water = new boolean[LENGTH];
        pit = new boolean[LENGTH];
        discoverable = new boolean[LENGTH];
        pitRoomNeeded = false;
        weakFloorCreated = false;
    }

    public void create() {
        boolean pitNeeded = true;
        resizingNeeded = false;
        this.map = new int[LENGTH];
        this.visited = new boolean[LENGTH];
        Arrays.fill(this.visited, false);
        this.mapped = new boolean[LENGTH];
        Arrays.fill(this.mapped, false);
        this.mobs = new HashSet();
        this.heaps = new SparseArray();
        this.blobs = new HashMap();
        this.plants = new SparseArray();
        if (!Dungeon.bossLevel()) {
            addItemToSpawn(Generator.random(Category.FOOD));
            if (Dungeon.posNeeded()) {
                addItemToSpawn(new PotionOfStrength());
                Dungeon.potionOfStrength++;
            }
            if (Dungeon.souNeeded()) {
                addItemToSpawn(new ScrollOfUpgrade());
                Dungeon.scrollsOfUpgrade++;
            }
            if (Dungeon.soeNeeded()) {
                addItemToSpawn(new ScrollOfEnchantment());
                Dungeon.scrollsOfEnchantment++;
            }
            if (Dungeon.depth > 1) {
                switch (Random.Int(10)) {
                    case WndUpdates.ID_SEWERS /*0*/:
                        if (!Dungeon.bossLevel(Dungeon.depth + 1)) {
                            this.feeling = Feeling.CHASM;
                            break;
                        }
                        break;
                    case WndUpdates.ID_PRISON /*1*/:
                        this.feeling = Feeling.WATER;
                        break;
                    case WndUpdates.ID_CAVES /*2*/:
                        this.feeling = Feeling.GRASS;
                        break;
                }
            }
        }
        if (Dungeon.depth <= 1 || !weakFloorCreated) {
            pitNeeded = false;
        }
        do {
            Arrays.fill(this.map, this.feeling == Feeling.CHASM ? 0 : 4);
            pitRoomNeeded = pitNeeded;
            weakFloorCreated = false;
        } while (!build());
        decorate();
        buildFlagMaps();
        cleanWalls();
        createMobs();
        createItems();
    }

    public void reset() {
        int i = 0;
        Mob[] mobArr = (Mob[]) this.mobs.toArray(new Mob[0]);
        int length = mobArr.length;
        while (i < length) {
            Mob mob = mobArr[i];
            if (!mob.reset()) {
                this.mobs.remove(mob);
            }
            i++;
        }
        createMobs();
    }

    public void restoreFromBundle(Bundle bundle) {
        this.mobs = new HashSet();
        this.heaps = new SparseArray();
        this.blobs = new HashMap();
        this.plants = new SparseArray();
        this.map = bundle.getIntArray(MAP);
        this.visited = bundle.getBooleanArray(VISITED);
        this.mapped = bundle.getBooleanArray(MAPPED);
        this.entrance = bundle.getInt(ENTRANCE);
        this.storage = bundle.getInt(STORAGE);
        this.exit = bundle.getInt(EXIT);
        weakFloorCreated = false;
        adjustMapSize();
        for (Bundlable heap : bundle.getCollection(HEAPS)) {
            Heap heap2 = (Heap) heap;
            if (resizingNeeded) {
                heap2.pos = adjustPos(heap2.pos);
            }
            this.heaps.put(heap2.pos, heap2);
        }
        for (Bundlable plant : bundle.getCollection(PLANTS)) {
            Plant plant2 = (Plant) plant;
            if (resizingNeeded) {
                plant2.pos = adjustPos(plant2.pos);
            }
            this.plants.put(plant2.pos, plant2);
        }
        for (Bundlable mob : bundle.getCollection(MOBS)) {
            Mob mob2 = (Mob) mob;
            if (mob2 != null) {
                if (resizingNeeded) {
                    mob2.pos = adjustPos(mob2.pos);
                }
                this.mobs.add(mob2);
            }
        }
        for (Bundlable blob : bundle.getCollection(BLOBS)) {
            Blob blob2 = (Blob) blob;
            this.blobs.put(blob2.getClass(), blob2);
        }
        buildFlagMaps();
        cleanWalls();
    }

    public void storeInBundle(Bundle bundle) {
        bundle.put(MAP, this.map);
        bundle.put(VISITED, this.visited);
        bundle.put(MAPPED, this.mapped);
        bundle.put(ENTRANCE, this.entrance);
        bundle.put(STORAGE, this.storage);
        bundle.put(EXIT, this.exit);
        bundle.put(HEAPS, this.heaps.values());
        bundle.put(PLANTS, this.plants.values());
        bundle.put(MOBS, this.mobs);
        bundle.put(BLOBS, this.blobs.values());
    }

    public int tunnelTile() {
        return this.feeling == Feeling.CHASM ? 14 : 1;
    }

    private void adjustMapSize() {
        if (this.map.length < LENGTH) {
            resizingNeeded = true;
            loadedMapSize = (int) Math.sqrt((double) this.map.length);
            int[] map = new int[LENGTH];
            Arrays.fill(map, 4);
            boolean[] visited = new boolean[LENGTH];
            Arrays.fill(visited, false);
            boolean[] mapped = new boolean[LENGTH];
            Arrays.fill(mapped, false);
            for (int i = 0; i < loadedMapSize; i++) {
                System.arraycopy(this.map, loadedMapSize * i, map, i * WIDTH, loadedMapSize);
                System.arraycopy(this.visited, loadedMapSize * i, visited, i * WIDTH, loadedMapSize);
                System.arraycopy(this.mapped, loadedMapSize * i, mapped, i * WIDTH, loadedMapSize);
            }
            this.map = map;
            this.visited = visited;
            this.mapped = mapped;
            this.entrance = adjustPos(this.entrance);
            this.exit = adjustPos(this.exit);
            this.storage = adjustPos(this.storage);
            return;
        }
        resizingNeeded = false;
    }

    public int adjustPos(int pos) {
        return ((pos / loadedMapSize) * WIDTH) + (pos % loadedMapSize);
    }

    public String tilesTex() {
        return null;
    }

    public String waterTex() {
        return null;
    }

    public void addVisuals(Scene scene) {
        int i = 0;
        while (i < LENGTH) {
            if (pit[i]) {
                scene.add(new Wind(i));
                if (i >= WIDTH && water[i - 32]) {
                    scene.add(new Flow(i - 32));
                }
            }
            i++;
        }
    }

    public int nMobs() {
        return 0;
    }

    public int difficultyChamp() {
        if (Dungeon.difficulty == 1) {
            return 1;
        }
        if (Dungeon.difficulty == 0) {
            return 2;
        }
        return Dungeon.difficulty + 1;
    }

    public Actor respawner() {
        return new C01021();
    }

    public int randomRespawnCell() {
        while (true) {
            int cell = Random.Int(LENGTH);
            if (passable[cell] && !Dungeon.visible[cell] && Actor.findChar(cell) == null) {
                return cell;
            }
        }
    }

    public int randomDestination() {
        int cell;
        do {
            cell = Random.Int(LENGTH);
        } while (!passable[cell]);
        return cell;
    }

    public void addItemToSpawn(Item item) {
        if (item != null) {
            this.itemsToSpawn.add(item);
        }
    }

    public Item itemToSpanAsPrize() {
        if (Random.Int(this.itemsToSpawn.size() + 1) <= 0) {
            return null;
        }
        Item item = (Item) Random.element(this.itemsToSpawn);
        this.itemsToSpawn.remove(item);
        return item;
    }

    private void buildFlagMaps() {
        int i;
        for (i = 0; i < LENGTH; i++) {
            boolean z;
            int flags = Terrain.flags[this.map[i]];
            boolean[] zArr = passable;
            if ((flags & 1) != 0) {
                z = true;
            } else {
                z = false;
            }
            zArr[i] = z;
            zArr = losBlocking;
            if ((flags & 2) != 0) {
                z = true;
            } else {
                z = false;
            }
            zArr[i] = z;
            zArr = flamable;
            if ((flags & 4) != 0) {
                z = true;
            } else {
                z = false;
            }
            zArr[i] = z;
            zArr = secret;
            if ((flags & 8) != 0) {
                z = true;
            } else {
                z = false;
            }
            zArr[i] = z;
            zArr = solid;
            if ((flags & 16) != 0) {
                z = true;
            } else {
                z = false;
            }
            zArr[i] = z;
            zArr = avoid;
            if ((flags & WIDTH) != 0) {
                z = true;
            } else {
                z = false;
            }
            zArr[i] = z;
            zArr = water;
            if ((flags & 64) != 0) {
                z = true;
            } else {
                z = false;
            }
            zArr[i] = z;
            zArr = pit;
            if ((flags & ItemSpriteSheet.SCROLL_SKILLPOINT) != 0) {
                z = true;
            } else {
                z = false;
            }
            zArr[i] = z;
        }
        for (i = 0; i < WIDTH; i++) {
            boolean[] zArr2 = passable;
            avoid[i] = false;
            zArr2[i] = false;
            zArr2 = passable;
            int i2 = 992 + i;
            avoid[992 + i] = false;
            zArr2[i2] = false;
        }
        for (i = WIDTH; i < 992; i += WIDTH) {
            zArr2 = passable;
            avoid[i] = false;
            zArr2[i] = false;
            zArr2 = passable;
            i2 = (i + WIDTH) - 1;
            avoid[(i + WIDTH) - 1] = false;
            zArr2[i2] = false;
        }
        i = WIDTH;
        while (i < 992) {
            if (water[i]) {
                int t = 48;
                for (int j = 0; j < NEIGHBOURS4.length; j++) {
                    if ((Terrain.flags[this.map[NEIGHBOURS4[j] + i]] & Terrain.UNSTITCHABLE) != 0) {
                        t += 1 << j;
                    }
                }
                this.map[i] = t;
            }
            if (pit[i] && !pit[i - 32]) {
                int c = this.map[i - 32];
                if (c == 14 || c == 36) {
                    this.map[i] = 44;
                } else if (water[i - 32]) {
                    this.map[i] = 46;
                } else if ((Terrain.flags[c] & Terrain.UNSTITCHABLE) != 0) {
                    this.map[i] = 45;
                } else {
                    this.map[i] = 43;
                }
            }
            i++;
        }
    }

    private void cleanWalls() {
        for (int i = 0; i < LENGTH; i++) {
            boolean d = false;
            for (int i2 : NEIGHBOURS9) {
                int n = i + i2;
                if (n >= 0 && n < LENGTH && this.map[n] != 4 && this.map[n] != 12) {
                    d = true;
                    break;
                }
            }
            if (d) {
                d = false;
                for (int i22 : NEIGHBOURS9) {
                    n = i + i22;
                    if (n >= 0 && n < LENGTH && !pit[n]) {
                        d = true;
                        break;
                    }
                }
            }
            discoverable[i] = d;
        }
    }

    public static void set(int cell, int terrain) {
        boolean z;
        boolean z2 = false;
        Painter.set(Dungeon.level, cell, terrain);
        int flags = Terrain.flags[terrain];
        passable[cell] = (flags & 1) != 0;
        boolean[] zArr = losBlocking;
        if ((flags & 2) != 0) {
            z = true;
        } else {
            z = false;
        }
        zArr[cell] = z;
        zArr = flamable;
        if ((flags & 4) != 0) {
            z = true;
        } else {
            z = false;
        }
        zArr[cell] = z;
        zArr = secret;
        if ((flags & 8) != 0) {
            z = true;
        } else {
            z = false;
        }
        zArr[cell] = z;
        zArr = solid;
        if ((flags & 16) != 0) {
            z = true;
        } else {
            z = false;
        }
        zArr[cell] = z;
        zArr = avoid;
        if ((flags & WIDTH) != 0) {
            z = true;
        } else {
            z = false;
        }
        zArr[cell] = z;
        zArr = pit;
        if ((flags & ItemSpriteSheet.SCROLL_SKILLPOINT) != 0) {
            z = true;
        } else {
            z = false;
        }
        zArr[cell] = z;
        boolean[] zArr2 = water;
        if (terrain == 63 || terrain >= 48) {
            z2 = true;
        }
        zArr2[cell] = z2;
    }

    public Heap drop(Item item, int cell) {
        int n;
        if (Dungeon.isChallenged(1) && (item instanceof Food)) {
            item = new Gold(item.price());
        } else if (Dungeon.isChallenged(2) && (item instanceof Armor)) {
            item = new Gold(item.price());
        } else if (Dungeon.isChallenged(4) && (item instanceof PotionOfHealing)) {
            item = new Gold(item.price());
        } else if (Dungeon.isChallenged(8) && (item instanceof SeedPouch)) {
            item = new Gold(item.price());
        } else if (Dungeon.isChallenged(64) && (((item instanceof Scroll) || (item instanceof ScrollHolder)) && !(item instanceof ScrollOfUpgrade))) {
            item = new Gold(item.price());
        }
        if (this.map[cell] == 42 && !(item instanceof Seed)) {
            do {
                n = cell + NEIGHBOURS8[Random.Int(8)];
            } while (this.map[n] != 14);
            cell = n;
        }
        Heap heap = (Heap) this.heaps.get(cell);
        if (heap == null) {
            heap = new Heap();
            heap.pos = cell;
            if (this.map[cell] == 0 || (Dungeon.level != null && pit[cell])) {
                Dungeon.dropToChasm(item);
                GameScene.discard(heap);
            } else {
                this.heaps.put(cell, heap);
                GameScene.add(heap);
            }
        } else if (heap.type == Type.LOCKED_CHEST || heap.type == Type.CRYSTAL_CHEST) {
            do {
                n = cell + NEIGHBOURS8[Random.Int(8)];
                if (passable[n]) {
                    break;
                }
            } while (!avoid[n]);
            return drop(item, n);
        }
        heap.drop(item);
        if (Dungeon.level != null) {
            press(cell, null);
        }
        return heap;
    }

    public Plant plant(Seed seed, int pos) {
        Plant plant = (Plant) this.plants.get(pos);
        if (plant != null) {
            plant.wither();
        }
        plant = seed.couch(pos);
        this.plants.put(pos, plant);
        GameScene.add(plant);
        return plant;
    }

    public void uproot(int pos) {
        this.plants.delete(pos);
    }

    public int pitCell() {
        return randomRespawnCell();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void press(int r7, com.watabou.pixeldungeon.actors.Char r8) {
        /*
        r6 = this;
        r5 = 1;
        r4 = 0;
        r2 = pit;
        r2 = r2[r7];
        if (r2 == 0) goto L_0x0010;
    L_0x0008:
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r8 != r2) goto L_0x0010;
    L_0x000c:
        com.watabou.pixeldungeon.levels.features.Chasm.heroFall(r7);
    L_0x000f:
        return;
    L_0x0010:
        r1 = 0;
        r2 = r6.map;
        r2 = r2[r7];
        switch(r2) {
            case 5: goto L_0x01ee;
            case 6: goto L_0x0018;
            case 7: goto L_0x0018;
            case 8: goto L_0x0018;
            case 9: goto L_0x0018;
            case 10: goto L_0x0018;
            case 11: goto L_0x0018;
            case 12: goto L_0x0018;
            case 13: goto L_0x0018;
            case 14: goto L_0x0018;
            case 15: goto L_0x01dd;
            case 16: goto L_0x0018;
            case 17: goto L_0x0047;
            case 18: goto L_0x0040;
            case 19: goto L_0x0078;
            case 20: goto L_0x0071;
            case 21: goto L_0x00ac;
            case 22: goto L_0x00a5;
            case 23: goto L_0x0018;
            case 24: goto L_0x0018;
            case 25: goto L_0x0018;
            case 26: goto L_0x0018;
            case 27: goto L_0x00e0;
            case 28: goto L_0x00d9;
            case 29: goto L_0x0018;
            case 30: goto L_0x0114;
            case 31: goto L_0x010d;
            case 32: goto L_0x0148;
            case 33: goto L_0x0141;
            case 34: goto L_0x01e2;
            case 35: goto L_0x0018;
            case 36: goto L_0x0018;
            case 37: goto L_0x017c;
            case 38: goto L_0x0175;
            case 39: goto L_0x01b0;
            case 40: goto L_0x01a9;
            case 41: goto L_0x0018;
            case 42: goto L_0x01e7;
            default: goto L_0x0018;
        };
    L_0x0018:
        if (r1 == 0) goto L_0x0032;
    L_0x001a:
        r2 = com.watabou.noosa.audio.Sample.INSTANCE;
        r3 = "snd_trap.mp3";
        r2.play(r3);
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r8 != r2) goto L_0x002a;
    L_0x0025:
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        r2.interrupt();
    L_0x002a:
        r2 = 23;
        set(r7, r2);
        com.watabou.pixeldungeon.scenes.GameScene.updateMap(r7);
    L_0x0032:
        r2 = r6.plants;
        r0 = r2.get(r7);
        r0 = (com.watabou.pixeldungeon.plants.Plant) r0;
        if (r0 == 0) goto L_0x000f;
    L_0x003c:
        r0.activate(r8);
        goto L_0x000f;
    L_0x0040:
        r2 = "A hidden pressure plate clicks!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m1i(r2, r3);
    L_0x0047:
        r1 = 1;
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r8 != r2) goto L_0x006d;
    L_0x004c:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.heroClass;
        r3 = com.watabou.pixeldungeon.actors.hero.HeroClass.ROGUE;
        if (r2 != r3) goto L_0x0069;
    L_0x0055:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.skillSecondActive;
        if (r2 != r5) goto L_0x0069;
    L_0x005c:
        r2 = "You disabled a trap!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m2n(r2, r3);
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2.skillSecondActive = r4;
        goto L_0x0018;
    L_0x0069:
        com.watabou.pixeldungeon.levels.traps.ToxicTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x006d:
        com.watabou.pixeldungeon.levels.traps.ToxicTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x0071:
        r2 = "A hidden pressure plate clicks!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m1i(r2, r3);
    L_0x0078:
        r1 = 1;
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r8 != r2) goto L_0x00a0;
    L_0x007d:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.heroClass;
        r3 = com.watabou.pixeldungeon.actors.hero.HeroClass.ROGUE;
        if (r2 != r3) goto L_0x009b;
    L_0x0086:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.skillSecondActive;
        if (r2 != r5) goto L_0x009b;
    L_0x008d:
        r2 = "You disabled a trap!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m2n(r2, r3);
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2.skillSecondActive = r4;
        goto L_0x0018;
    L_0x009b:
        com.watabou.pixeldungeon.levels.traps.FireTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x00a0:
        com.watabou.pixeldungeon.levels.traps.FireTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x00a5:
        r2 = "A hidden pressure plate clicks!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m1i(r2, r3);
    L_0x00ac:
        r1 = 1;
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r8 != r2) goto L_0x00d4;
    L_0x00b1:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.heroClass;
        r3 = com.watabou.pixeldungeon.actors.hero.HeroClass.ROGUE;
        if (r2 != r3) goto L_0x00cf;
    L_0x00ba:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.skillSecondActive;
        if (r2 != r5) goto L_0x00cf;
    L_0x00c1:
        r2 = "You disabled a trap!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m2n(r2, r3);
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2.skillSecondActive = r4;
        goto L_0x0018;
    L_0x00cf:
        com.watabou.pixeldungeon.levels.traps.ParalyticTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x00d4:
        com.watabou.pixeldungeon.levels.traps.ParalyticTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x00d9:
        r2 = "A hidden pressure plate clicks!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m1i(r2, r3);
    L_0x00e0:
        r1 = 1;
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r8 != r2) goto L_0x0108;
    L_0x00e5:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.heroClass;
        r3 = com.watabou.pixeldungeon.actors.hero.HeroClass.ROGUE;
        if (r2 != r3) goto L_0x0103;
    L_0x00ee:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.skillSecondActive;
        if (r2 != r5) goto L_0x0103;
    L_0x00f5:
        r2 = "You disabled a trap!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m2n(r2, r3);
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2.skillSecondActive = r4;
        goto L_0x0018;
    L_0x0103:
        com.watabou.pixeldungeon.levels.traps.PoisonTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x0108:
        com.watabou.pixeldungeon.levels.traps.PoisonTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x010d:
        r2 = "A hidden pressure plate clicks!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m1i(r2, r3);
    L_0x0114:
        r1 = 1;
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r8 != r2) goto L_0x013c;
    L_0x0119:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.heroClass;
        r3 = com.watabou.pixeldungeon.actors.hero.HeroClass.ROGUE;
        if (r2 != r3) goto L_0x0137;
    L_0x0122:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.skillSecondActive;
        if (r2 != r5) goto L_0x0137;
    L_0x0129:
        r2 = "You disabled a trap!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m2n(r2, r3);
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2.skillSecondActive = r4;
        goto L_0x0018;
    L_0x0137:
        com.watabou.pixeldungeon.levels.traps.AlarmTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x013c:
        com.watabou.pixeldungeon.levels.traps.AlarmTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x0141:
        r2 = "A hidden pressure plate clicks!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m1i(r2, r3);
    L_0x0148:
        r1 = 1;
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r8 != r2) goto L_0x0170;
    L_0x014d:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.heroClass;
        r3 = com.watabou.pixeldungeon.actors.hero.HeroClass.ROGUE;
        if (r2 != r3) goto L_0x016b;
    L_0x0156:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.skillSecondActive;
        if (r2 != r5) goto L_0x016b;
    L_0x015d:
        r2 = "You disabled a trap!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m2n(r2, r3);
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2.skillSecondActive = r4;
        goto L_0x0018;
    L_0x016b:
        com.watabou.pixeldungeon.levels.traps.LightningTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x0170:
        com.watabou.pixeldungeon.levels.traps.LightningTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x0175:
        r2 = "A hidden pressure plate clicks!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m1i(r2, r3);
    L_0x017c:
        r1 = 1;
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r8 != r2) goto L_0x01a4;
    L_0x0181:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.heroClass;
        r3 = com.watabou.pixeldungeon.actors.hero.HeroClass.ROGUE;
        if (r2 != r3) goto L_0x019f;
    L_0x018a:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.skillSecondActive;
        if (r2 != r5) goto L_0x019f;
    L_0x0191:
        r2 = "You disabled a trap!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m2n(r2, r3);
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2.skillSecondActive = r4;
        goto L_0x0018;
    L_0x019f:
        com.watabou.pixeldungeon.levels.traps.GrippingTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x01a4:
        com.watabou.pixeldungeon.levels.traps.GrippingTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x01a9:
        r2 = "A hidden pressure plate clicks!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m1i(r2, r3);
    L_0x01b0:
        r1 = 1;
        r2 = com.watabou.pixeldungeon.Dungeon.hero;
        if (r8 != r2) goto L_0x01d8;
    L_0x01b5:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.heroClass;
        r3 = com.watabou.pixeldungeon.actors.hero.HeroClass.ROGUE;
        if (r2 != r3) goto L_0x01d3;
    L_0x01be:
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2 = r2.skillSecondActive;
        if (r2 != r5) goto L_0x01d3;
    L_0x01c5:
        r2 = "You disabled a trap!";
        r3 = new java.lang.Object[r4];
        com.watabou.pixeldungeon.utils.GLog.m2n(r2, r3);
        r2 = r8;
        r2 = (com.watabou.pixeldungeon.actors.hero.Hero) r2;
        r2.skillSecondActive = r4;
        goto L_0x0018;
    L_0x01d3:
        com.watabou.pixeldungeon.levels.traps.SummoningTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x01d8:
        com.watabou.pixeldungeon.levels.traps.SummoningTrap.trigger(r7, r8);
        goto L_0x0018;
    L_0x01dd:
        com.watabou.pixeldungeon.levels.features.HighGrass.trample(r6, r7, r8);
        goto L_0x0018;
    L_0x01e2:
        com.watabou.pixeldungeon.actors.blobs.WellWater.affectCell(r7);
        goto L_0x0018;
    L_0x01e7:
        if (r8 != 0) goto L_0x0018;
    L_0x01e9:
        com.watabou.pixeldungeon.actors.blobs.Alchemy.transmute(r7);
        goto L_0x0018;
    L_0x01ee:
        com.watabou.pixeldungeon.levels.features.Door.enter(r7);
        goto L_0x0018;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.watabou.pixeldungeon.levels.Level.press(int, com.watabou.pixeldungeon.actors.Char):void");
    }

    public void mobPress(Mob mob) {
        int cell = mob.pos;
        if (!pit[cell] || mob.flying) {
            boolean trap = true;
            switch (this.map[cell]) {
                case BuffIndicator.HUNGER /*5*/:
                    Door.enter(cell);
                    break;
                case BuffIndicator.COMBO /*17*/:
                    ToxicTrap.trigger(cell, mob);
                    break;
                case BuffIndicator.HEALING /*19*/:
                    FireTrap.trigger(cell, mob);
                    break;
                case BuffIndicator.HEART /*21*/:
                    ParalyticTrap.trigger(cell, mob);
                    break;
                case BuffIndicator.MARK /*27*/:
                    PoisonTrap.trigger(cell, mob);
                    break;
                case ItemSpriteSheet.GLAIVE /*30*/:
                    AlarmTrap.trigger(cell, mob);
                    break;
                case WIDTH /*32*/:
                    LightningTrap.trigger(cell, mob);
                    break;
                case ItemSpriteSheet.RING_TOPAZ /*37*/:
                    GrippingTrap.trigger(cell, mob);
                    break;
                case ItemSpriteSheet.RING_TOURMALINE /*39*/:
                    SummoningTrap.trigger(cell, mob);
                    break;
            }
            trap = false;
            if (trap) {
                if (Dungeon.visible[cell]) {
                    Sample.INSTANCE.play(Assets.SND_TRAP);
                }
                set(cell, 23);
                GameScene.updateMap(cell);
            }
            Plant plant = (Plant) this.plants.get(cell);
            if (plant != null) {
                plant.activate(mob);
                return;
            }
            return;
        }
        Chasm.mobFall(mob);
    }

    public boolean[] updateFieldOfView(Char c) {
        boolean sighted;
        int sense;
        Iterator it;
        int ax;
        int bx;
        int ay;
        int by;
        int len;
        int pos;
        int y;
        int i;
        int p;
        int cx = c.pos % WIDTH;
        int cy = c.pos / WIDTH;
        if (c.buff(Blindness.class) == null) {
            if (c.buff(Shadows.class) == null && c.isAlive()) {
                sighted = true;
                if (sighted) {
                    Arrays.fill(fieldOfView, false);
                } else {
                    ShadowCaster.castShadow(cx, cy, fieldOfView, c.viewDistance);
                }
                sense = 1;
                if (c.isAlive()) {
                    it = c.buffs(MindVision.class).iterator();
                    while (it.hasNext()) {
                        sense = Math.max(((MindVision) ((Buff) it.next())).distance, sense);
                    }
                }
                if ((sighted && sense > 1) || !sighted) {
                    ax = Math.max(0, cx - sense);
                    bx = Math.min(cx + sense, 31);
                    ay = Math.max(0, cy - sense);
                    by = Math.min(cy + sense, 31);
                    len = (bx - ax) + 1;
                    pos = ax + (ay * WIDTH);
                    y = ay;
                    while (y <= by) {
                        Arrays.fill(fieldOfView, pos, pos + len, true);
                        y++;
                        pos += WIDTH;
                    }
                    for (i = 0; i < LENGTH; i++) {
                        boolean[] zArr = fieldOfView;
                        zArr[i] = zArr[i] & discoverable[i];
                    }
                }
                if (c.isAlive()) {
                    if (c.buff(MindVision.class) == null) {
                        it = this.mobs.iterator();
                        while (it.hasNext()) {
                            p = ((Mob) it.next()).pos;
                            fieldOfView[p] = true;
                            fieldOfView[p + 1] = true;
                            fieldOfView[p - 1] = true;
                            fieldOfView[(p + WIDTH) + 1] = true;
                            fieldOfView[(p + WIDTH) - 1] = true;
                            fieldOfView[(p - 32) + 1] = true;
                            fieldOfView[(p - 32) - 1] = true;
                            fieldOfView[p + WIDTH] = true;
                            fieldOfView[p - 32] = true;
                        }
                    } else if (c == Dungeon.hero && ((Hero) c).heroClass == HeroClass.HUNTRESS) {
                        it = this.mobs.iterator();
                        while (it.hasNext()) {
                            p = ((Mob) it.next()).pos;
                            if (distance(c.pos, p) == 2) {
                                fieldOfView[p] = true;
                                fieldOfView[p + 1] = true;
                                fieldOfView[p - 1] = true;
                                fieldOfView[(p + WIDTH) + 1] = true;
                                fieldOfView[(p + WIDTH) - 1] = true;
                                fieldOfView[(p - 32) + 1] = true;
                                fieldOfView[(p - 32) - 1] = true;
                                fieldOfView[p + WIDTH] = true;
                                fieldOfView[p - 32] = true;
                            }
                        }
                    }
                    if (c.buff(Awareness.class) != null) {
                        for (Heap heap : this.heaps.values()) {
                            p = heap.pos;
                            fieldOfView[p] = true;
                            fieldOfView[p + 1] = true;
                            fieldOfView[p - 1] = true;
                            fieldOfView[(p + WIDTH) + 1] = true;
                            fieldOfView[(p + WIDTH) - 1] = true;
                            fieldOfView[(p - 32) + 1] = true;
                            fieldOfView[(p - 32) - 1] = true;
                            fieldOfView[p + WIDTH] = true;
                            fieldOfView[p - 32] = true;
                        }
                    }
                }
                return fieldOfView;
            }
        }
        sighted = false;
        if (sighted) {
            Arrays.fill(fieldOfView, false);
        } else {
            ShadowCaster.castShadow(cx, cy, fieldOfView, c.viewDistance);
        }
        sense = 1;
        if (c.isAlive()) {
            it = c.buffs(MindVision.class).iterator();
            while (it.hasNext()) {
                sense = Math.max(((MindVision) ((Buff) it.next())).distance, sense);
            }
        }
        ax = Math.max(0, cx - sense);
        bx = Math.min(cx + sense, 31);
        ay = Math.max(0, cy - sense);
        by = Math.min(cy + sense, 31);
        len = (bx - ax) + 1;
        pos = ax + (ay * WIDTH);
        y = ay;
        while (y <= by) {
            Arrays.fill(fieldOfView, pos, pos + len, true);
            y++;
            pos += WIDTH;
        }
        for (i = 0; i < LENGTH; i++) {
            boolean[] zArr2 = fieldOfView;
            zArr2[i] = zArr2[i] & discoverable[i];
        }
        if (c.isAlive()) {
            if (c.buff(MindVision.class) == null) {
                it = this.mobs.iterator();
                while (it.hasNext()) {
                    p = ((Mob) it.next()).pos;
                    if (distance(c.pos, p) == 2) {
                        fieldOfView[p] = true;
                        fieldOfView[p + 1] = true;
                        fieldOfView[p - 1] = true;
                        fieldOfView[(p + WIDTH) + 1] = true;
                        fieldOfView[(p + WIDTH) - 1] = true;
                        fieldOfView[(p - 32) + 1] = true;
                        fieldOfView[(p - 32) - 1] = true;
                        fieldOfView[p + WIDTH] = true;
                        fieldOfView[p - 32] = true;
                    }
                }
            } else {
                it = this.mobs.iterator();
                while (it.hasNext()) {
                    p = ((Mob) it.next()).pos;
                    fieldOfView[p] = true;
                    fieldOfView[p + 1] = true;
                    fieldOfView[p - 1] = true;
                    fieldOfView[(p + WIDTH) + 1] = true;
                    fieldOfView[(p + WIDTH) - 1] = true;
                    fieldOfView[(p - 32) + 1] = true;
                    fieldOfView[(p - 32) - 1] = true;
                    fieldOfView[p + WIDTH] = true;
                    fieldOfView[p - 32] = true;
                }
            }
            if (c.buff(Awareness.class) != null) {
                while (it.hasNext()) {
                    p = heap.pos;
                    fieldOfView[p] = true;
                    fieldOfView[p + 1] = true;
                    fieldOfView[p - 1] = true;
                    fieldOfView[(p + WIDTH) + 1] = true;
                    fieldOfView[(p + WIDTH) - 1] = true;
                    fieldOfView[(p - 32) + 1] = true;
                    fieldOfView[(p - 32) - 1] = true;
                    fieldOfView[p + WIDTH] = true;
                    fieldOfView[p - 32] = true;
                }
            }
        }
        return fieldOfView;
    }

    public static int distance(int a, int b) {
        return Math.max(Math.abs((a % WIDTH) - (b % WIDTH)), Math.abs((a / WIDTH) - (b / WIDTH)));
    }

    public static boolean adjacent(int a, int b) {
        int diff = Math.abs(a - b);
        if (diff == 1 || diff == WIDTH || diff == 33 || diff == 31) {
            return true;
        }
        return false;
    }

    public String tileName(int tile) {
        if (tile >= 48) {
            return tileName(63);
        }
        if (tile != 0 && (Terrain.flags[tile] & ItemSpriteSheet.SCROLL_SKILLPOINT) != 0) {
            return tileName(0);
        }
        switch (tile) {
            case WndUpdates.ID_SEWERS /*0*/:
                return "Chasm";
            case WndUpdates.ID_PRISON /*1*/:
            case BuffIndicator.WEAKNESS /*14*/:
            case BuffIndicator.FURY /*18*/:
            case BuffIndicator.ARMOR /*20*/:
            case BuffIndicator.LIGHT /*22*/:
            case BuffIndicator.BARKSKIN /*24*/:
            case BuffIndicator.DEFERRED /*28*/:
            case ItemSpriteSheet.DART /*31*/:
            case ItemSpriteSheet.RING_OPAL /*33*/:
                return "Floor";
            case WndUpdates.ID_CAVES /*2*/:
                return "Grass";
            case WndUpdates.ID_METROPOLIS /*3*/:
                return "Empty well";
            case WndUpdates.ID_HALLS /*4*/:
            case BuffIndicator.INVISIBLE /*12*/:
            case BuffIndicator.BLINDNESS /*16*/:
                return "Wall";
            case BuffIndicator.HUNGER /*5*/:
                return "Closed door";
            case BuffIndicator.STARVATION /*6*/:
                return "Open door";
            case BuffIndicator.SLOW /*7*/:
                return "Depth entrance";
            case BuffIndicator.OOZE /*8*/:
                return "Depth exit";
            case BuffIndicator.AMOK /*9*/:
                return "Embers";
            case BuffIndicator.TERROR /*10*/:
                return "Locked door";
            case BuffIndicator.ROOTS /*11*/:
                return "Pedestal";
            case BuffIndicator.SHADOWS /*13*/:
                return "Barricade";
            case BuffIndicator.FROST /*15*/:
                return "High grass";
            case BuffIndicator.COMBO /*17*/:
                return "Toxic gas trap";
            case BuffIndicator.HEALING /*19*/:
                return "Fire trap";
            case BuffIndicator.HEART /*21*/:
                return "Paralytic gas trap";
            case BuffIndicator.CRIPPLE /*23*/:
                return "Triggered trap";
            case BuffIndicator.IMMUNITY /*25*/:
                return "Locked depth exit";
            case ItemButton.SIZE /*26*/:
                return "Unlocked depth exit";
            case BuffIndicator.MARK /*27*/:
                return "Poison dart trap";
            case BuffIndicator.VERTIGO /*29*/:
                return "Sign";
            case ItemSpriteSheet.GLAIVE /*30*/:
                return "Alarm trap";
            case WIDTH /*32*/:
                return "Lightning trap";
            case ItemSpriteSheet.RING_GARNET /*34*/:
                return "Well";
            case ItemSpriteSheet.RING_RUBY /*35*/:
            case ItemSpriteSheet.RING_AMETHYST /*36*/:
                return "Statue";
            case ItemSpriteSheet.RING_TOPAZ /*37*/:
                return "Gripping trap";
            case ItemSpriteSheet.RING_TOURMALINE /*39*/:
                return "Summoning trap";
            case ItemSpriteSheet.SCROLL_SOWILO /*41*/:
                return "Bookshelf";
            case ItemSpriteSheet.SCROLL_LAGUZ /*42*/:
                return "Alchemy pot";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Water";
            default:
                return "???";
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case WndUpdates.ID_SEWERS /*0*/:
                return "You can't see the bottom.";
            case WndUpdates.ID_METROPOLIS /*3*/:
                return "The well has run dry.";
            case BuffIndicator.SLOW /*7*/:
                return "Stairs lead up to the upper depth.";
            case BuffIndicator.OOZE /*8*/:
            case ItemButton.SIZE /*26*/:
                return "Stairs lead down to the lower depth.";
            case BuffIndicator.AMOK /*9*/:
                return "Embers cover the floor.";
            case BuffIndicator.TERROR /*10*/:
                return "This door is locked, you need a matching key to unlock it.";
            case BuffIndicator.SHADOWS /*13*/:
                return "The wooden barricade is firmly set but has dried over the years. Might it burn?";
            case BuffIndicator.FROST /*15*/:
                return "Dense vegetation blocks the view.";
            case BuffIndicator.COMBO /*17*/:
            case BuffIndicator.HEALING /*19*/:
            case BuffIndicator.HEART /*21*/:
            case BuffIndicator.MARK /*27*/:
            case ItemSpriteSheet.GLAIVE /*30*/:
            case WIDTH /*32*/:
            case ItemSpriteSheet.RING_TOPAZ /*37*/:
            case ItemSpriteSheet.RING_TOURMALINE /*39*/:
                return "Stepping onto a hidden pressure plate will activate the trap.";
            case BuffIndicator.CRIPPLE /*23*/:
                return "The trap has been triggered before and it's not dangerous anymore.";
            case BuffIndicator.IMMUNITY /*25*/:
                return "Heavy bars block the stairs leading down.";
            case BuffIndicator.VERTIGO /*29*/:
                return "You can't read the text from here.";
            case ItemSpriteSheet.RING_RUBY /*35*/:
            case ItemSpriteSheet.RING_AMETHYST /*36*/:
                return "Someone wanted to adorn this place, but failed, obviously.";
            case ItemSpriteSheet.SCROLL_LAGUZ /*42*/:
                return "Drop some seeds here to cook a potion.";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "In case of burning step into the water to extinguish the fire.";
            default:
                if (tile >= 48) {
                    return tileDesc(63);
                }
                if ((Terrain.flags[tile] & ItemSpriteSheet.SCROLL_SKILLPOINT) != 0) {
                    return tileDesc(0);
                }
                return BuildConfig.VERSION_NAME;
        }
    }
}
