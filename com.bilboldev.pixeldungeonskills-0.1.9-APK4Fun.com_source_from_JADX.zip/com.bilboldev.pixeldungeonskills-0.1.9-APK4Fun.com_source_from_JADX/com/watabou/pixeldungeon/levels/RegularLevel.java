package com.watabou.pixeldungeon.levels;

import com.watabou.pixeldungeon.Bones;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Champ;
import com.watabou.pixeldungeon.actors.mobs.Bestiary;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfUpgrade;
import com.watabou.pixeldungeon.levels.Level.Feeling;
import com.watabou.pixeldungeon.levels.Room.Door;
import com.watabou.pixeldungeon.levels.Room.Type;
import com.watabou.pixeldungeon.levels.painters.Painter;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.Graph;
import com.watabou.utils.Random;
import com.watabou.utils.Rect;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public abstract class RegularLevel extends Level {
    protected int maxRoomSize;
    protected int minRoomSize;
    protected Room roomEntrance;
    protected Room roomExit;
    protected HashSet<Room> rooms;
    public int secretDoors;
    protected ArrayList<Type> specials;

    /* renamed from: com.watabou.pixeldungeon.levels.RegularLevel.1 */
    static /* synthetic */ class C01031 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$levels$Room$Door$Type;

        static {
            $SwitchMap$com$watabou$pixeldungeon$levels$Room$Door$Type = new int[Door.Type.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$levels$Room$Door$Type[Door.Type.EMPTY.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$levels$Room$Door$Type[Door.Type.TUNNEL.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$levels$Room$Door$Type[Door.Type.REGULAR.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$levels$Room$Door$Type[Door.Type.UNLOCKED.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$levels$Room$Door$Type[Door.Type.HIDDEN.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$levels$Room$Door$Type[Door.Type.BARRICADE.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$levels$Room$Door$Type[Door.Type.LOCKED.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
        }
    }

    protected abstract boolean[] grass();

    protected abstract boolean[] water();

    public RegularLevel() {
        this.minRoomSize = 7;
        this.maxRoomSize = 9;
    }

    protected boolean build() {
        if (!initRooms()) {
            return false;
        }
        Room room;
        int retry = 0;
        int minDistance = (int) Math.sqrt((double) this.rooms.size());
        while (true) {
            this.roomEntrance = (Room) Random.element(this.rooms);
            if (this.roomEntrance.width() >= 4 && this.roomEntrance.height() >= 4) {
                while (true) {
                    this.roomExit = (Room) Random.element(this.rooms);
                    room = this.roomExit;
                    Room room2 = this.roomEntrance;
                    if (room != r0 && this.roomExit.width() >= 4 && this.roomExit.height() >= 4) {
                        break;
                    }
                }
                Graph.buildDistanceMap(this.rooms, this.roomExit);
                int distance = this.roomEntrance.distance();
                int retry2 = retry + 1;
                if (retry > 10) {
                    return false;
                }
                if (distance >= minDistance) {
                    break;
                }
                retry = retry2;
            }
        }
        room = this.roomEntrance;
        room.type = Type.ENTRANCE;
        room = this.roomExit;
        room.type = Type.EXIT;
        Collection connected = new HashSet();
        connected.add(this.roomEntrance);
        Graph.buildDistanceMap(this.rooms, this.roomExit);
        List<Room> path = Graph.buildPath(this.rooms, this.roomEntrance, this.roomExit);
        Room room3 = this.roomEntrance;
        for (Room next : path) {
            room3.connect(next);
            room3 = next;
            connected.add(room3);
        }
        Graph.setPrice(path, this.roomEntrance.distance);
        Graph.buildDistanceMap(this.rooms, this.roomExit);
        path = Graph.buildPath(this.rooms, this.roomEntrance, this.roomExit);
        room3 = this.roomEntrance;
        for (Room next2 : path) {
            room3.connect(next2);
            room3 = next2;
            connected.add(room3);
        }
        int nConnected = (int) (((float) this.rooms.size()) * Random.Float(0.5f, 0.7f));
        while (connected.size() < nConnected) {
            Room cr = (Room) Random.element(connected);
            Room or = (Room) Random.element(cr.neigbours);
            if (!connected.contains(or)) {
                cr.connect(or);
                connected.add(or);
            }
        }
        if (Dungeon.shopOnLevel()) {
            Room shop = null;
            for (Room r : this.roomEntrance.connected.keySet()) {
                if (r.connected.size() == 1 && r.width() >= 5 && r.height() >= 5) {
                    shop = r;
                    break;
                }
            }
            if (shop == null) {
                return false;
            }
            shop.type = Type.SHOP;
        }
        this.specials = new ArrayList(Room.SPECIALS);
        if (Dungeon.bossLevel(Dungeon.depth + 1)) {
            this.specials.remove(Type.WEAK_FLOOR);
        }
        assignRoomType();
        paint();
        paintWater();
        paintGrass();
        placeTraps();
        return true;
    }

    protected boolean initRooms() {
        this.rooms = new HashSet();
        split(new Rect(0, 0, 31, 31));
        if (this.rooms.size() < 8) {
            return false;
        }
        Room[] ra = (Room[]) this.rooms.toArray(new Room[0]);
        for (int i = 0; i < ra.length - 1; i++) {
            for (int j = i + 1; j < ra.length; j++) {
                ra[i].addNeigbour(ra[j]);
            }
        }
        return true;
    }

    protected void assignRoomType() {
        Iterator it;
        int specialRooms = 0;
        Iterator it2 = this.rooms.iterator();
        while (it2.hasNext()) {
            Room r = (Room) it2.next();
            if (r.type == Type.NULL && r.connected.size() == 1) {
                if (this.specials.size() > 0 && r.width() > 3 && r.height() > 3 && Random.Int((specialRooms * specialRooms) + 2) == 0) {
                    if (pitRoomNeeded) {
                        r.type = Type.PIT;
                        pitRoomNeeded = false;
                        this.specials.remove(Type.ARMORY);
                        this.specials.remove(Type.CRYPT);
                        this.specials.remove(Type.LABORATORY);
                        this.specials.remove(Type.LIBRARY);
                        this.specials.remove(Type.STATUE);
                        this.specials.remove(Type.TREASURY);
                        this.specials.remove(Type.VAULT);
                        this.specials.remove(Type.WEAK_FLOOR);
                    } else if (Dungeon.depth % 5 == 2 && this.specials.contains(Type.LABORATORY)) {
                        r.type = Type.LABORATORY;
                    } else if (Dungeon.depth < Dungeon.transmutation || !this.specials.contains(Type.MAGIC_WELL)) {
                        int n = this.specials.size();
                        r.type = (Type) this.specials.get(Math.min(Random.Int(n), Random.Int(n)));
                        if (r.type == Type.WEAK_FLOOR) {
                            weakFloorCreated = true;
                        }
                    } else {
                        r.type = Type.MAGIC_WELL;
                    }
                    Room.useType(r.type);
                    this.specials.remove(r.type);
                    specialRooms++;
                } else if (Random.Int(2) == 0) {
                    Collection neigbours = new HashSet();
                    it = r.neigbours.iterator();
                    while (it.hasNext()) {
                        Room n2 = (Room) it.next();
                        if (!(r.connected.containsKey(n2) || Room.SPECIALS.contains(n2.type) || n2.type == Type.PIT)) {
                            neigbours.add(n2);
                        }
                    }
                    if (neigbours.size() > 1) {
                        r.connect((Room) Random.element(neigbours));
                    }
                }
            }
        }
        int count = 0;
        it = this.rooms.iterator();
        while (it.hasNext()) {
            r = (Room) it.next();
            if (r.type == Type.NULL) {
                int connections = r.connected.size();
                if (connections != 0) {
                    if (Random.Int(connections * connections) == 0) {
                        r.type = Type.STANDARD;
                        count++;
                    } else {
                        r.type = Type.TUNNEL;
                    }
                }
            }
        }
        while (count < 4) {
            r = randomRoom(Type.TUNNEL, 1);
            if (r != null) {
                r.type = Type.STANDARD;
                count++;
            }
        }
    }

    protected void paintWater() {
        boolean[] lake = water();
        int i = 0;
        while (i < Level.LENGTH) {
            if (this.map[i] == 1 && lake[i]) {
                this.map[i] = 63;
            }
            i++;
        }
    }

    protected void paintGrass() {
        boolean[] grass = grass();
        if (this.feeling == Feeling.GRASS) {
            Iterator it = this.rooms.iterator();
            while (it.hasNext()) {
                Room room = (Room) it.next();
                if (!(room.type == Type.NULL || room.type == Type.PASSAGE || room.type == Type.TUNNEL)) {
                    grass[(room.left + 1) + ((room.top + 1) * 32)] = true;
                    grass[(room.right - 1) + ((room.top + 1) * 32)] = true;
                    grass[(room.left + 1) + ((room.bottom - 1) * 32)] = true;
                    grass[(room.right - 1) + ((room.bottom - 1) * 32)] = true;
                }
            }
        }
        int i = 33;
        while (i < 991) {
            if (this.map[i] == 1 && grass[i]) {
                int i2;
                int count = 1;
                for (int n : NEIGHBOURS8) {
                    if (grass[i + n]) {
                        count++;
                    }
                }
                int[] iArr = this.map;
                if (Random.Float() < ((float) count) / 12.0f) {
                    i2 = 15;
                } else {
                    i2 = 2;
                }
                iArr[i] = i2;
            }
            i++;
        }
    }

    protected void placeTraps() {
        int nTraps = nTraps();
        float[] trapChances = trapChances();
        for (int i = 0; i < nTraps; i++) {
            int trapPos = Random.Int(Level.LENGTH);
            if (this.map[trapPos] == 1) {
                switch (Random.chances(trapChances)) {
                    case WndUpdates.ID_SEWERS /*0*/:
                        this.map[trapPos] = 18;
                        break;
                    case WndUpdates.ID_PRISON /*1*/:
                        this.map[trapPos] = 20;
                        break;
                    case WndUpdates.ID_CAVES /*2*/:
                        this.map[trapPos] = 22;
                        break;
                    case WndUpdates.ID_METROPOLIS /*3*/:
                        this.map[trapPos] = 28;
                        break;
                    case WndUpdates.ID_HALLS /*4*/:
                        this.map[trapPos] = 31;
                        break;
                    case BuffIndicator.HUNGER /*5*/:
                        this.map[trapPos] = 33;
                        break;
                    case BuffIndicator.STARVATION /*6*/:
                        this.map[trapPos] = 38;
                        break;
                    case BuffIndicator.SLOW /*7*/:
                        this.map[trapPos] = 40;
                        break;
                    default:
                        break;
                }
            }
        }
    }

    protected int nTraps() {
        return Dungeon.depth <= 1 ? 0 : Random.Int(1, this.rooms.size() + Dungeon.depth);
    }

    protected float[] trapChances() {
        return new float[]{Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK};
    }

    protected void split(Rect rect) {
        int w = rect.width();
        int h = rect.height();
        int vw;
        if (w > this.maxRoomSize && h < this.minRoomSize) {
            vw = Random.Int(rect.left + 3, rect.right - 3);
            split(new Rect(rect.left, rect.top, vw, rect.bottom));
            split(new Rect(vw, rect.top, rect.right, rect.bottom));
        } else if (h > this.maxRoomSize && w < this.minRoomSize) {
            vh = Random.Int(rect.top + 3, rect.bottom - 3);
            split(new Rect(rect.left, rect.top, rect.right, vh));
            split(new Rect(rect.left, vh, rect.right, rect.bottom));
        } else if ((Math.random() <= ((double) ((this.minRoomSize * this.minRoomSize) / rect.square())) && w <= this.maxRoomSize && h <= this.maxRoomSize) || w < this.minRoomSize || h < this.minRoomSize) {
            this.rooms.add((Room) new Room().set(rect));
        } else if (Random.Float() < ((float) (w - 2)) / ((float) ((w + h) - 4))) {
            vw = Random.Int(rect.left + 3, rect.right - 3);
            split(new Rect(rect.left, rect.top, vw, rect.bottom));
            split(new Rect(vw, rect.top, rect.right, rect.bottom));
        } else {
            vh = Random.Int(rect.top + 3, rect.bottom - 3);
            split(new Rect(rect.left, rect.top, rect.right, vh));
            split(new Rect(rect.left, vh, rect.right, rect.bottom));
        }
    }

    protected void paint() {
        Iterator it = this.rooms.iterator();
        while (it.hasNext()) {
            Room r = (Room) it.next();
            if (r.type != Type.NULL) {
                placeDoors(r);
                r.type.paint(this, r);
            } else if (this.feeling == Feeling.CHASM && Random.Int(2) == 0) {
                Painter.fill(this, r, 4);
            }
        }
        it = this.rooms.iterator();
        while (it.hasNext()) {
            paintDoors((Room) it.next());
        }
    }

    private void placeDoors(Room r) {
        for (Room n : r.connected.keySet()) {
            if (((Door) r.connected.get(n)) == null) {
                Door door;
                Rect i = r.intersect(n);
                if (i.width() == 0) {
                    door = new Door(i.left, Random.Int(i.top + 1, i.bottom));
                } else {
                    door = new Door(Random.Int(i.left + 1, i.right), i.top);
                }
                r.connected.put(n, door);
                n.connected.put(r, door);
            }
        }
    }

    protected void paintDoors(Room r) {
        for (Room n : r.connected.keySet()) {
            if (!joinRooms(r, n)) {
                Door d = (Door) r.connected.get(n);
                int door = d.x + (d.y * 32);
                switch (C01031.$SwitchMap$com$watabou$pixeldungeon$levels$Room$Door$Type[d.type.ordinal()]) {
                    case WndUpdates.ID_PRISON /*1*/:
                        this.map[door] = 1;
                        break;
                    case WndUpdates.ID_CAVES /*2*/:
                        this.map[door] = tunnelTile();
                        break;
                    case WndUpdates.ID_METROPOLIS /*3*/:
                        if (Dungeon.depth > 1) {
                            int i;
                            boolean secret = (Dungeon.depth < 6 ? Random.Int(12 - Dungeon.depth) : Random.Int(6)) == 0;
                            int[] iArr = this.map;
                            if (secret) {
                                i = 16;
                            } else {
                                i = 5;
                            }
                            iArr[door] = i;
                            if (!secret) {
                                break;
                            }
                            this.secretDoors++;
                            break;
                        }
                        this.map[door] = 5;
                        break;
                    case WndUpdates.ID_HALLS /*4*/:
                        this.map[door] = 5;
                        break;
                    case BuffIndicator.HUNGER /*5*/:
                        this.map[door] = 16;
                        break;
                    case BuffIndicator.STARVATION /*6*/:
                        this.map[door] = Random.Int(3) == 0 ? 41 : 13;
                        break;
                    case BuffIndicator.SLOW /*7*/:
                        this.map[door] = 10;
                        break;
                    default:
                        break;
                }
            }
        }
    }

    protected boolean joinRooms(Room r, Room n) {
        if (r.type != Type.STANDARD || n.type != Type.STANDARD) {
            return false;
        }
        Rect w = r.intersect(n);
        if (w.left == w.right) {
            if (w.bottom - w.top < 3) {
                return false;
            }
            if (w.height() == Math.max(r.height(), n.height())) {
                return false;
            }
            if (r.width() + n.width() > this.maxRoomSize) {
                return false;
            }
            w.top++;
            w.bottom += 0;
            w.right++;
            Painter.fill(this, w.left, w.top, 1, w.height(), 1);
            return true;
        } else if (w.right - w.left < 3) {
            return false;
        } else {
            if (w.width() == Math.max(r.width(), n.width())) {
                return false;
            }
            if (r.height() + n.height() > this.maxRoomSize) {
                return false;
            }
            w.left++;
            w.right += 0;
            w.bottom++;
            Painter.fill(this, w.left, w.top, w.width(), 1, 1);
            return true;
        }
    }

    public int nMobs() {
        return ((Dungeon.depth % 5) + 2) + Random.Int(3);
    }

    protected void createMobs() {
        int nMobs = nMobs();
        for (int i = 0; i < nMobs; i++) {
            Mob mob = Bestiary.mob(Dungeon.depth);
            do {
                mob.pos = randomRespawnCell();
                if (Random.Int(10) < difficultyChamp()) {
                    Buff.affect(mob, Champ.class);
                }
            } while (mob.pos == -1);
            this.mobs.add(mob);
            Actor.occupyCell(mob);
        }
    }

    public int randomRespawnCell() {
        int count = 0;
        while (true) {
            count++;
            if (count > 10) {
                return -1;
            }
            Room room = randomRoom(Type.STANDARD, 10);
            if (room != null) {
                int cell = room.random();
                if (!Dungeon.visible[cell] && Actor.findChar(cell) == null && Level.passable[cell]) {
                    return cell;
                }
            }
        }
    }

    public int randomDestination() {
        while (true) {
            Room room = (Room) Random.element(this.rooms);
            if (room != null) {
                int cell = room.random();
                if (Level.passable[cell]) {
                    return cell;
                }
            }
        }
    }

    protected void createItems() {
        Item item;
        int nItems = 3;
        while (Random.Float() < 0.4f) {
            nItems++;
        }
        for (int i = 0; i < nItems; i++) {
            Heap.Type type;
            switch (Random.Int(20)) {
                case WndUpdates.ID_SEWERS /*0*/:
                    type = Heap.Type.SKELETON;
                    break;
                case WndUpdates.ID_PRISON /*1*/:
                case WndUpdates.ID_CAVES /*2*/:
                case WndUpdates.ID_METROPOLIS /*3*/:
                case WndUpdates.ID_HALLS /*4*/:
                    type = Heap.Type.CHEST;
                    break;
                case BuffIndicator.HUNGER /*5*/:
                    type = Dungeon.depth > 1 ? Heap.Type.MIMIC : Heap.Type.CHEST;
                    break;
                default:
                    type = Heap.Type.HEAP;
                    break;
            }
            drop(Generator.random(), randomDropCell()).type = type;
        }
        Iterator it = this.itemsToSpawn.iterator();
        while (it.hasNext()) {
            item = (Item) it.next();
            int cell = randomDropCell();
            if (item instanceof ScrollOfUpgrade) {
                while (true) {
                    if (this.map[cell] == 19 || this.map[cell] == 20) {
                        cell = randomDropCell();
                    }
                }
            }
            drop(item, cell).type = Heap.Type.HEAP;
        }
        item = Bones.get();
        if (item != null) {
            drop(item, randomDropCell()).type = Heap.Type.SKELETON;
        }
    }

    protected Room randomRoom(Type type, int tries) {
        for (int i = 0; i < tries; i++) {
            Room room = (Room) Random.element(this.rooms);
            if (room.type == type) {
                return room;
            }
        }
        return null;
    }

    public Room room(int pos) {
        Iterator it = this.rooms.iterator();
        while (it.hasNext()) {
            Room room = (Room) it.next();
            if (room.type != Type.NULL && room.inside(pos)) {
                return room;
            }
        }
        return null;
    }

    protected int randomDropCell() {
        while (true) {
            Room room = randomRoom(Type.STANDARD, 1);
            if (room != null) {
                int pos = room.random();
                if (passable[pos]) {
                    return pos;
                }
            }
        }
    }

    public int pitCell() {
        Iterator it = this.rooms.iterator();
        while (it.hasNext()) {
            Room room = (Room) it.next();
            if (room.type == Type.PIT) {
                return room.random();
            }
        }
        return super.pitCell();
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put("rooms", this.rooms);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        Collection<Bundlable> tmp = bundle.getCollection("rooms");
        this.rooms = new HashSet();
        for (Bundlable item : tmp) {
            this.rooms.add((Room) item);
        }
        Iterator it = this.rooms.iterator();
        while (it.hasNext()) {
            if (((Room) it.next()).type == Type.WEAK_FLOOR) {
                weakFloorCreated = true;
                return;
            }
        }
    }
}
