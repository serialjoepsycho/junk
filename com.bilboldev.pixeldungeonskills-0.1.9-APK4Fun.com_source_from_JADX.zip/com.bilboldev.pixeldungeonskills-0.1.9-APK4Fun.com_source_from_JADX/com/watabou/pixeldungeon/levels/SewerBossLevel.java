package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Scene;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Bones;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.mobs.Bestiary;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.levels.Room.Type;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.utils.Bundle;
import com.watabou.utils.Graph;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class SewerBossLevel extends RegularLevel {
    private static final String STAIRS = "stairs";
    private int stairs;

    public SewerBossLevel() {
        this.color1 = 4748860;
        this.color2 = 5871946;
        this.stairs = 0;
    }

    public String tilesTex() {
        return Assets.TILES_SEWERS;
    }

    public String waterTex() {
        return Assets.WATER_SEWERS;
    }

    protected boolean build() {
        Iterator it;
        initRooms();
        int retry = 0;
        int minDistance = (int) Math.sqrt((double) this.rooms.size());
        while (true) {
            int i = 0;
            while (true) {
                int innerRetry = i + 1;
                if (i <= 10) {
                    this.roomEntrance = (Room) Random.element(this.rooms);
                    if (this.roomEntrance.width() >= 4 && this.roomEntrance.height() >= 4) {
                        break;
                    }
                    i = innerRetry;
                } else {
                    return false;
                }
            }
            i = 0;
            while (true) {
                innerRetry = i + 1;
                if (i <= 10) {
                    this.roomExit = (Room) Random.element(this.rooms);
                    if (this.roomExit != this.roomEntrance && this.roomExit.width() >= 6 && this.roomExit.height() >= 6 && this.roomExit.top != 0) {
                        break;
                    }
                    i = innerRetry;
                } else {
                    return false;
                }
            }
            Graph.buildDistanceMap(this.rooms, this.roomExit);
            int distance = this.roomEntrance.distance();
            int retry2 = retry + 1;
            if (retry > 10) {
                retry = retry2;
                return false;
            } else if (distance >= minDistance) {
                break;
            } else {
                retry = retry2;
            }
        }
        this.roomEntrance.type = Type.ENTRANCE;
        this.roomExit.type = Type.BOSS_EXIT;
        Graph.buildDistanceMap(this.rooms, this.roomExit);
        Graph.setPrice(Graph.buildPath(this.rooms, this.roomEntrance, this.roomExit), this.roomEntrance.distance);
        Graph.buildDistanceMap(this.rooms, this.roomExit);
        List<Room> path = Graph.buildPath(this.rooms, this.roomEntrance, this.roomExit);
        Room room = this.roomEntrance;
        for (Room next : path) {
            room.connect(next);
            room = next;
        }
        if (this.roomExit.top == this.roomExit.connected.keySet().toArray()[0].bottom) {
            retry = retry2;
            return false;
        }
        it = this.rooms.iterator();
        while (it.hasNext()) {
            Room r = (Room) it.next();
            if (r.type == Type.NULL && r.connected.size() > 0) {
                r.type = Type.TUNNEL;
            }
        }
        Collection candidates = new ArrayList();
        it = this.roomExit.neigbours.iterator();
        while (it.hasNext()) {
            r = (Room) it.next();
            if (!this.roomExit.connected.containsKey(r) && (this.roomExit.left == r.right || this.roomExit.right == r.left || this.roomExit.bottom == r.top)) {
                candidates.add(r);
            }
        }
        if (candidates.size() > 0) {
            Room kingsRoom = (Room) Random.element(candidates);
            kingsRoom.connect(this.roomExit);
            kingsRoom.type = Type.RAT_KING;
        }
        paint();
        paintWater();
        paintGrass();
        placeTraps();
        retry = retry2;
        return true;
    }

    protected boolean[] water() {
        return Patch.generate(0.5f, 5);
    }

    protected boolean[] grass() {
        return Patch.generate(0.4f, 4);
    }

    protected void decorate() {
        int pos;
        int start = ((this.roomExit.top * 32) + this.roomExit.left) + 1;
        int end = (this.roomExit.width() + start) - 1;
        for (int i = start; i < end; i++) {
            if (i != this.exit) {
                this.map[i] = 12;
                this.map[i + 32] = 63;
            } else {
                this.map[i + 32] = 1;
            }
        }
        do {
            pos = this.roomEntrance.random();
        } while (pos == this.entrance);
        this.map[pos] = 29;
    }

    public void addVisuals(Scene scene) {
        SewerLevel.addVisuals(this, scene);
    }

    protected void createMobs() {
        Mob mob = Bestiary.mob(Dungeon.depth);
        mob.pos = this.roomExit.random();
        this.mobs.add(mob);
    }

    public Actor respawner() {
        return null;
    }

    protected void createItems() {
        Item item = Bones.get();
        if (item != null) {
            while (true) {
                int pos = this.roomEntrance.random();
                if (pos != this.entrance && this.map[pos] != 29) {
                    drop(item, pos).type = Heap.Type.SKELETON;
                    return;
                }
            }
        }
    }

    public void seal() {
        if (this.entrance != 0) {
            Level.set(this.entrance, 48);
            GameScene.updateMap(this.entrance);
            GameScene.ripple(this.entrance);
            this.stairs = this.entrance;
            this.entrance = 0;
        }
    }

    public void unseal() {
        if (this.stairs != 0) {
            this.entrance = this.stairs;
            this.stairs = 0;
            Level.set(this.entrance, 7);
            GameScene.updateMap(this.entrance);
        }
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(STAIRS, this.stairs);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.stairs = bundle.getInt(STAIRS);
    }

    public String tileName(int tile) {
        switch (tile) {
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Murky water";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case BuffIndicator.BARKSKIN /*24*/:
                return "Wet yellowish moss covers the floor.";
            default:
                return super.tileDesc(tile);
        }
    }
}
