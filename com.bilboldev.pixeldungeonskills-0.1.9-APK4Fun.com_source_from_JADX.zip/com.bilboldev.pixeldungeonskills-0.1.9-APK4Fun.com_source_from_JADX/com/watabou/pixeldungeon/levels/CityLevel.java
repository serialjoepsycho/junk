package com.watabou.pixeldungeon.levels;

import com.watabou.noosa.Scene;
import com.watabou.noosa.particles.Emitter;
import com.watabou.noosa.particles.Emitter.Factory;
import com.watabou.noosa.particles.PixelParticle;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.actors.mobs.npcs.Imp.Quest;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level.Feeling;
import com.watabou.pixeldungeon.levels.Room.Type;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;
import java.util.Iterator;

public class CityLevel extends RegularLevel {

    private static class Smoke extends Emitter {
        private static final Factory factory;
        private int pos;

        /* renamed from: com.watabou.pixeldungeon.levels.CityLevel.Smoke.1 */
        static class C01011 extends Factory {
            C01011() {
            }

            public void emit(Emitter emitter, int index, float x, float y) {
                ((SmokeParticle) emitter.recycle(SmokeParticle.class)).reset(x, y);
            }
        }

        static {
            factory = new C01011();
        }

        public Smoke(int pos) {
            this.pos = pos;
            PointF p = DungeonTilemap.tileCenterToWorld(pos);
            pos(p.f24x - 4.0f, p.f25y - Pickaxe.TIME_TO_MINE, 4.0f, 0.0f);
            pour(factory, 0.2f);
        }

        public void update() {
            boolean z = Dungeon.visible[this.pos];
            this.visible = z;
            if (z) {
                super.update();
            }
        }
    }

    public static final class SmokeParticle extends PixelParticle {
        public SmokeParticle() {
            color(0);
            this.speed.set(Random.Float(8.0f), -Random.Float(8.0f));
        }

        public void reset(float x, float y) {
            revive();
            this.x = x;
            this.y = y;
            this.lifespan = Pickaxe.TIME_TO_MINE;
            this.left = Pickaxe.TIME_TO_MINE;
        }

        public void update() {
            super.update();
            float p = this.left / this.lifespan;
            this.am = p > 0.8f ? Key.TIME_TO_UNLOCK - p : 0.25f * p;
            size(8.0f - (4.0f * p));
        }
    }

    public CityLevel() {
        this.color1 = 4941366;
        this.color2 = 15921906;
    }

    public String tilesTex() {
        return Assets.TILES_CITY;
    }

    public String waterTex() {
        return Assets.WATER_CITY;
    }

    protected boolean[] water() {
        return Patch.generate(this.feeling == Feeling.WATER ? 0.65f : 0.45f, 4);
    }

    protected boolean[] grass() {
        return Patch.generate(this.feeling == Feeling.GRASS ? 0.6f : 0.4f, 3);
    }

    protected void assignRoomType() {
        super.assignRoomType();
        Iterator it = this.rooms.iterator();
        while (it.hasNext()) {
            Room r = (Room) it.next();
            if (r.type == Type.TUNNEL) {
                r.type = Type.PASSAGE;
            }
        }
    }

    protected void decorate() {
        int pos;
        for (int i = 0; i < Level.LENGTH; i++) {
            if (this.map[i] == 1 && Random.Int(10) == 0) {
                this.map[i] = 24;
            } else if (this.map[i] == 4 && Random.Int(8) == 0) {
                this.map[i] = 12;
            }
        }
        do {
            pos = this.roomEntrance.random();
        } while (pos == this.entrance);
        this.map[pos] = 29;
    }

    protected void createItems() {
        super.createItems();
        Quest.spawn(this, this.roomEntrance);
    }

    public String tileName(int tile) {
        switch (tile) {
            case BuffIndicator.FROST /*15*/:
                return "High blooming flowers";
            case ItemSpriteSheet.POTION_IVORY /*63*/:
                return "Suspiciously colored water";
            default:
                return super.tileName(tile);
        }
    }

    public String tileDesc(int tile) {
        switch (tile) {
            case BuffIndicator.SLOW /*7*/:
                return "A ramp leads up to the upper depth.";
            case BuffIndicator.OOZE /*8*/:
                return "A ramp leads down to the lower depth.";
            case BuffIndicator.INVISIBLE /*12*/:
            case BuffIndicator.BARKSKIN /*24*/:
                return "Several tiles are missing here.";
            case BuffIndicator.WEAKNESS /*14*/:
                return "Thick carpet covers the floor.";
            case ItemSpriteSheet.RING_RUBY /*35*/:
            case ItemSpriteSheet.RING_AMETHYST /*36*/:
                return "The statue depicts some dwarf standing in a heroic stance.";
            case ItemSpriteSheet.SCROLL_SOWILO /*41*/:
                return "The rows of books on different disciplines fill the bookshelf.";
            default:
                return super.tileDesc(tile);
        }
    }

    public void addVisuals(Scene scene) {
        super.addVisuals(scene);
        addVisuals(this, scene);
    }

    public static void addVisuals(Level level, Scene scene) {
        for (int i = 0; i < Level.LENGTH; i++) {
            if (level.map[i] == 12) {
                scene.add(new Smoke(i));
            }
        }
    }
}
