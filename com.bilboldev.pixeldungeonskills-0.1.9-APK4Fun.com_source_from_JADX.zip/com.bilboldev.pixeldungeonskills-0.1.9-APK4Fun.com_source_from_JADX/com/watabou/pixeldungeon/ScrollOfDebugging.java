package com.watabou.pixeldungeon;

import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfEnchantment;
import java.util.ArrayList;

public class ScrollOfDebugging extends Item {
    public static final String AC_READ = "READ";

    public ScrollOfDebugging() {
        this.name = "Scroll of Debugging";
        this.image = 40;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_READ);
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action.equals(AC_READ)) {
            new ScrollOfEnchantment().collect();
        } else {
            super.execute(hero, action);
        }
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }
}
