package com.watabou.pixeldungeon.windows;

import com.watabou.gltextures.SmartTexture;
import com.watabou.gltextures.TextureCache;
import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Group;
import com.watabou.noosa.Image;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Statistics;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.Utils;
import java.util.Iterator;
import java.util.Locale;

public class WndHero extends WndTabbed {
    private static final int TAB_WIDTH = 40;
    private static final String TXT_BUFFS = "Buffs";
    private static final String TXT_DEPTH = "Maximum Depth";
    private static final String TXT_Difficulty = "Difficulty";
    private static final String TXT_EXP = "Experience";
    private static final String TXT_GOLD = "Gold Collected";
    private static final String TXT_HEALTH = "Health";
    private static final String TXT_MANA = "Mana";
    private static final String TXT_STATS = "Stats";
    private static final String TXT_STR = "Strength";
    private static final String TXT_Skill = "Skill Points";
    private static final int WIDTH = 120;
    private BuffsTab buffs;
    private TextureFilm film;
    private SmartTexture icons;
    private StatsTab stats;

    /* renamed from: com.watabou.pixeldungeon.windows.WndHero.1 */
    class C01871 extends LabeledTab {
        C01871(String label) {
            super(label);
        }

        protected void select(boolean value) {
            super.select(value);
            StatsTab access$000 = WndHero.this.stats;
            StatsTab access$0002 = WndHero.this.stats;
            boolean z = this.selected;
            access$0002.active = z;
            access$000.visible = z;
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndHero.2 */
    class C01882 extends LabeledTab {
        C01882(String label) {
            super(label);
        }

        protected void select(boolean value) {
            super.select(value);
            BuffsTab access$100 = WndHero.this.buffs;
            BuffsTab access$1002 = WndHero.this.buffs;
            boolean z = this.selected;
            access$1002.active = z;
            access$100.visible = z;
        }
    }

    private class BuffsTab extends Group {
        private static final int GAP = 2;
        private float pos;

        public BuffsTab() {
            Iterator it = Dungeon.hero.buffs().iterator();
            while (it.hasNext()) {
                buffSlot((Buff) it.next());
            }
        }

        private void buffSlot(Buff buff) {
            int index = buff.icon();
            if (index != -1) {
                Image icon = new Image(WndHero.this.icons);
                icon.frame(WndHero.this.film.get(Integer.valueOf(index)));
                icon.y = this.pos;
                add(icon);
                BitmapText txt = PixelScene.createText(buff.toString(), 8.0f);
                txt.x = icon.width + Pickaxe.TIME_TO_MINE;
                txt.y = this.pos + ((float) (((int) (icon.height - txt.baseLine())) / GAP));
                add(txt);
                this.pos += icon.height + Pickaxe.TIME_TO_MINE;
            }
        }

        public float height() {
            return this.pos;
        }
    }

    private class StatsTab extends Group {
        private static final int GAP = 5;
        private static final String TXT_CATALOGUS = "Catalogus";
        private static final String TXT_JOURNAL = "Journal";
        private static final String TXT_SKILL = "Skills";
        private static final String TXT_TITLE = "Level %d %s";
        private float pos;

        /* renamed from: com.watabou.pixeldungeon.windows.WndHero.StatsTab.1 */
        class C01891 extends RedButton {
            final /* synthetic */ WndHero val$this$0;

            C01891(String label, WndHero wndHero) {
                this.val$this$0 = wndHero;
                super(label);
            }

            protected void onClick() {
                WndHero.this.hide();
                GameScene.show(new WndCatalogus());
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndHero.StatsTab.2 */
        class C01902 extends RedButton {
            final /* synthetic */ WndHero val$this$0;

            C01902(String label, WndHero wndHero) {
                this.val$this$0 = wndHero;
                super(label);
            }

            protected void onClick() {
                WndHero.this.hide();
                GameScene.show(new WndJournal());
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndHero.StatsTab.3 */
        class C01913 extends RedButton {
            final /* synthetic */ WndHero val$this$0;

            C01913(String label, WndHero wndHero) {
                this.val$this$0 = wndHero;
                super(label);
            }

            protected void onClick() {
                WndHero.this.hide();
                GameScene.show(new WndSkill());
            }
        }

        public StatsTab() {
            Hero hero = Dungeon.hero;
            BitmapText title = PixelScene.createText(Utils.format(TXT_TITLE, Integer.valueOf(hero.lvl), hero.className()).toUpperCase(Locale.ENGLISH), 9.0f);
            title.hardlight(Window.TITLE_COLOR);
            title.measure();
            add(title);
            RedButton btnCatalogus = new C01891(TXT_CATALOGUS, WndHero.this);
            btnCatalogus.setRect(0.0f, title.y + title.height(), btnCatalogus.reqWidth() + Pickaxe.TIME_TO_MINE, btnCatalogus.reqHeight() + Pickaxe.TIME_TO_MINE);
            add(btnCatalogus);
            RedButton btnJournal = new C01902(TXT_JOURNAL, WndHero.this);
            btnJournal.setRect(btnCatalogus.right() + Key.TIME_TO_UNLOCK, btnCatalogus.top(), btnJournal.reqWidth() + Pickaxe.TIME_TO_MINE, btnJournal.reqHeight() + Pickaxe.TIME_TO_MINE);
            add(btnJournal);
            RedButton btnSkill = new C01913(TXT_SKILL, WndHero.this);
            btnSkill.setRect(btnJournal.right() + Key.TIME_TO_UNLOCK, btnJournal.top(), btnJournal.reqWidth() + Pickaxe.TIME_TO_MINE, btnJournal.reqHeight() + Pickaxe.TIME_TO_MINE);
            add(btnSkill);
            this.pos = btnCatalogus.bottom() + GasesImmunity.DURATION;
            statSlot(WndHero.TXT_STR, hero.STR());
            statSlot(WndHero.TXT_HEALTH, hero.HP + "/" + hero.HT);
            statSlot(WndHero.TXT_MANA, hero.MP + "/" + hero.MMP);
            statSlot(WndHero.TXT_EXP, hero.exp + "/" + hero.maxExp());
            statSlot(WndHero.TXT_Skill, hero.skillPoints);
            switch (hero.difficulty) {
                case WndUpdates.ID_SEWERS /*0*/:
                    statSlot(WndHero.TXT_Difficulty, "Normal");
                    break;
                case WndUpdates.ID_PRISON /*1*/:
                    statSlot(WndHero.TXT_Difficulty, "Easy");
                    break;
                case WndUpdates.ID_CAVES /*2*/:
                    statSlot(WndHero.TXT_Difficulty, "Hard");
                    break;
                case WndUpdates.ID_METROPOLIS /*3*/:
                    statSlot(WndHero.TXT_Difficulty, "Hell!");
                    break;
                case WndUpdates.ID_HALLS /*4*/:
                    statSlot(WndHero.TXT_Difficulty, "Suicide!!");
                    break;
            }
            this.pos += GasesImmunity.DURATION;
            statSlot(WndHero.TXT_GOLD, Statistics.goldCollected);
            statSlot(WndHero.TXT_DEPTH, Statistics.deepestFloor);
            this.pos += GasesImmunity.DURATION;
        }

        private void statSlot(String label, String value) {
            BitmapText txt = PixelScene.createText(label, 8.0f);
            txt.y = this.pos;
            add(txt);
            txt = PixelScene.createText(value, 8.0f);
            txt.measure();
            txt.x = PixelScene.align(78.0f);
            txt.y = this.pos;
            add(txt);
            this.pos += GasesImmunity.DURATION + txt.baseLine();
        }

        private void statSlot(String label, int value) {
            statSlot(label, Integer.toString(value));
        }

        public float height() {
            return this.pos;
        }
    }

    public WndHero() {
        this.icons = TextureCache.get(Assets.BUFFS_LARGE);
        this.film = new TextureFilm(this.icons, 16, 16);
        this.stats = new StatsTab();
        add(this.stats);
        this.buffs = new BuffsTab();
        add(this.buffs);
        add(new C01871(TXT_STATS));
        add(new C01882(TXT_BUFFS));
        Iterator it = this.tabs.iterator();
        while (it.hasNext()) {
            ((Tab) it.next()).setSize(40.0f, (float) tabHeight());
        }
        resize(WIDTH, (int) Math.max(this.stats.height(), this.buffs.height()));
        select(0);
    }
}
