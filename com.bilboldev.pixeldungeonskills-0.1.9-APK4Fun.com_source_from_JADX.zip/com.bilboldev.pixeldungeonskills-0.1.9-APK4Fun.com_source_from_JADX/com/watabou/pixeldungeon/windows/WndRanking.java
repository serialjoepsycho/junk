package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.ColorBlock;
import com.watabou.noosa.Game;
import com.watabou.noosa.Group;
import com.watabou.noosa.Image;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Statistics;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.actors.hero.Belongings;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.HeroSprite;
import com.watabou.pixeldungeon.ui.BadgesList;
import com.watabou.pixeldungeon.ui.Icons;
import com.watabou.pixeldungeon.ui.ItemSlot;
import com.watabou.pixeldungeon.ui.QuickSlot;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.ScrollPane;
import com.watabou.pixeldungeon.utils.Utils;
import java.util.Locale;

public class WndRanking extends WndTabbed {
    private static final int HEIGHT = 134;
    private static final int TAB_WIDTH = 40;
    private static final String TXT_BADGES = "Badges";
    private static final String TXT_ERROR = "Unable to load additional information";
    private static final String TXT_ITEMS = "Items";
    private static final String TXT_STATS = "Stats";
    private static final int WIDTH = 112;
    private Image busy;
    private String error;
    private Thread thread;

    /* renamed from: com.watabou.pixeldungeon.windows.WndRanking.1 */
    class C02051 extends Thread {
        final /* synthetic */ String val$gameFile;

        C02051(String str) {
            this.val$gameFile = str;
        }

        public void run() {
            try {
                Badges.loadGlobal();
                Dungeon.loadGame(this.val$gameFile);
            } catch (Exception e) {
                WndRanking.this.error = WndRanking.TXT_ERROR;
            }
        }
    }

    private class BadgesTab extends Group {
        public BadgesTab() {
            this.camera = WndRanking.this.camera;
            ScrollPane list = new BadgesList(false);
            add(list);
            list.setSize(112.0f, 134.0f);
        }
    }

    private class ItemButton extends Button {
        public static final int SIZE = 26;
        private ColorBlock bg;
        protected Item item;
        protected ItemSlot slot;

        public ItemButton(Item item) {
            this.item = item;
            this.slot.item(item);
            if (item.cursed && item.cursedKnown) {
                this.bg.ra = 0.2f;
                this.bg.ga = -0.1f;
            } else if (!item.isIdentified()) {
                this.bg.ra = 0.1f;
                this.bg.ba = 0.1f;
            }
        }

        protected void createChildren() {
            this.bg = new ColorBlock(26.0f, 26.0f, -11907772);
            add(this.bg);
            this.slot = new ItemSlot();
            add(this.slot);
            super.createChildren();
        }

        protected void layout() {
            this.bg.x = this.x;
            this.bg.y = this.y;
            this.slot.setRect(this.x, this.y, 26.0f, 26.0f);
            super.layout();
        }

        protected void onTouchDown() {
            this.bg.brightness(Sleep.SWS);
            Sample.INSTANCE.play(Assets.SND_CLICK, 0.7f, 0.7f, 1.2f);
        }

        protected void onTouchUp() {
            this.bg.brightness(Key.TIME_TO_UNLOCK);
        }

        protected void onClick() {
            Game.scene().add(new WndItem(null, this.item));
        }
    }

    private class ItemsTab extends Group {
        private int count;
        private float pos;

        public ItemsTab() {
            Belongings stuff = Dungeon.hero.belongings;
            if (stuff.weapon != null) {
                addItem(stuff.weapon);
            }
            if (stuff.armor != null) {
                addItem(stuff.armor);
            }
            if (stuff.ring1 != null) {
                addItem(stuff.ring1);
            }
            if (stuff.ring2 != null) {
                addItem(stuff.ring2);
            }
            Item primary = getQuickslot(QuickSlot.primaryValue);
            Item secondary = getQuickslot(QuickSlot.secondaryValue);
            if (this.count < 4 || primary == null || secondary == null) {
                if (primary != null) {
                    addItem(primary);
                }
                if (secondary != null) {
                    addItem(secondary);
                    return;
                }
                return;
            }
            ItemButton slot = new ItemButton(primary);
            slot.setRect(0.0f, this.pos, 26.0f, 26.0f);
            add(slot);
            slot = new ItemButton(secondary);
            slot.setRect(Key.TIME_TO_UNLOCK + 26.0f, this.pos, 26.0f, 26.0f);
            add(slot);
        }

        private void addItem(Item item) {
            LabelledItemButton slot = new LabelledItemButton(item);
            slot.setRect(0.0f, this.pos, (float) WndRanking.this.width, 26.0f);
            add(slot);
            this.pos += slot.height() + Key.TIME_TO_UNLOCK;
            this.count++;
        }

        private Item getQuickslot(Object value) {
            if ((value instanceof Item) && Dungeon.hero.belongings.backpack.contains((Item) value)) {
                return (Item) value;
            }
            if (value instanceof Class) {
                Item item = Dungeon.hero.belongings.getItem((Class) value);
                if (item != null) {
                    return item;
                }
            }
            return null;
        }
    }

    private class LabelledItemButton extends ItemButton {
        private BitmapText name;

        public LabelledItemButton(Item item) {
            super(item);
        }

        protected void createChildren() {
            super.createChildren();
            this.name = PixelScene.createText("?", 7.0f);
            add(this.name);
        }

        protected void layout() {
            super.layout();
            this.name.x = this.slot.right() + Pickaxe.TIME_TO_MINE;
            this.name.y = this.y + ((this.height - this.name.baseLine()) / Pickaxe.TIME_TO_MINE);
            String str = Utils.capitalize(this.item.name());
            this.name.text(str);
            this.name.measure();
            if (this.name.width() > this.width - this.name.x) {
                do {
                    str = str.substring(0, str.length() - 1);
                    this.name.text(str + "...");
                    this.name.measure();
                } while (this.name.width() > this.width - this.name.x);
            }
        }
    }

    private class RankingTab extends LabeledTab {
        private Group page;

        public RankingTab(String label, Group page) {
            super(label);
            this.page = page;
        }

        protected void select(boolean value) {
            super.select(value);
            if (this.page != null) {
                Group group = this.page;
                Group group2 = this.page;
                boolean z = this.selected;
                group2.active = z;
                group.visible = z;
            }
        }
    }

    private class StatsTab extends Group {
        private static final int GAP = 4;
        private static final String TXT_ALCHEMY = "Potions Cooked";
        private static final String TXT_ANKHS = "Ankhs Used";
        private static final String TXT_CHALLENGES = "Challenges";
        private static final String TXT_DEPTH = "Maximum Depth";
        private static final String TXT_DIFF = "Difficulty";
        private static final String TXT_DURATION = "Game Duration";
        private static final String TXT_ENEMIES = "Mobs Killed";
        private static final String TXT_FOOD = "Food Eaten";
        private static final String TXT_GOLD = "Gold Collected";
        private static final String TXT_HEALTH = "Health";
        private static final String TXT_STR = "Strength";
        private static final String TXT_TITLE = "Level %d %s (SPD)";

        /* renamed from: com.watabou.pixeldungeon.windows.WndRanking.StatsTab.1 */
        class C02061 extends RedButton {
            final /* synthetic */ WndRanking val$this$0;

            C02061(String label, WndRanking wndRanking) {
                this.val$this$0 = wndRanking;
                super(label);
            }

            protected void onClick() {
                Game.scene().add(new WndChallenges(Dungeon.challenges, false));
            }
        }

        public StatsTab() {
            String heroClass = Dungeon.hero.className();
            IconTitle title = new IconTitle();
            title.icon(HeroSprite.avatar(Dungeon.hero.heroClass, Dungeon.hero.tier()));
            title.label(Utils.format(TXT_TITLE, Integer.valueOf(Dungeon.hero.lvl), heroClass).toUpperCase(Locale.ENGLISH));
            title.setRect(0.0f, 0.0f, 112.0f, 0.0f);
            add(title);
            float pos = title.bottom();
            if (Dungeon.challenges > 0) {
                RedButton btnCatalogus = new C02061(TXT_CHALLENGES, WndRanking.this);
                btnCatalogus.setRect(0.0f, pos + 4.0f, btnCatalogus.reqWidth() + Pickaxe.TIME_TO_MINE, btnCatalogus.reqHeight() + Pickaxe.TIME_TO_MINE);
                add(btnCatalogus);
                pos = btnCatalogus.bottom();
            }
            pos = statSlot(this, TXT_ANKHS, Integer.toString(Statistics.ankhsUsed), statSlot(this, TXT_ALCHEMY, Integer.toString(Statistics.potionsCooked), statSlot(this, TXT_FOOD, Integer.toString(Statistics.foodEaten), statSlot(this, TXT_GOLD, Integer.toString(Statistics.goldCollected), statSlot(this, TXT_ENEMIES, Integer.toString(Statistics.enemiesSlain), statSlot(this, TXT_DEPTH, Integer.toString(Statistics.deepestFloor), statSlot(this, TXT_DURATION, Integer.toString((int) Statistics.duration), statSlot(this, TXT_HEALTH, Integer.toString(Dungeon.hero.HT), statSlot(this, TXT_STR, Integer.toString(Dungeon.hero.STR), pos + 8.0f)) + 4.0f) + 4.0f))) + 4.0f)));
            switch (Dungeon.hero.difficulty) {
                case WndUpdates.ID_SEWERS /*0*/:
                    pos = statSlot(this, TXT_DIFF, "Normal", pos);
                case WndUpdates.ID_PRISON /*1*/:
                    pos = statSlot(this, TXT_DIFF, "Easy", pos);
                case WndUpdates.ID_CAVES /*2*/:
                    pos = statSlot(this, TXT_DIFF, "Hard", pos);
                case WndUpdates.ID_METROPOLIS /*3*/:
                    pos = statSlot(this, TXT_DIFF, "Hell!", pos);
                case GAP /*4*/:
                    pos = statSlot(this, TXT_DIFF, "Suicide!!", pos);
                default:
            }
        }

        private float statSlot(Group parent, String label, String value, float pos) {
            BitmapText txt = PixelScene.createText(label, 7.0f);
            txt.y = pos;
            parent.add(txt);
            txt = PixelScene.createText(value, 7.0f);
            txt.measure();
            txt.x = PixelScene.align(72.799995f);
            txt.y = pos;
            parent.add(txt);
            return (4.0f + pos) + txt.baseLine();
        }
    }

    public WndRanking(String gameFile) {
        this.error = null;
        resize(WIDTH, HEIGHT);
        this.thread = new C02051(gameFile);
        this.thread.start();
        this.busy = Icons.BUSY.get();
        this.busy.origin.set(this.busy.width / Pickaxe.TIME_TO_MINE, this.busy.height / Pickaxe.TIME_TO_MINE);
        this.busy.angularSpeed = 720.0f;
        this.busy.x = (112.0f - this.busy.width) / Pickaxe.TIME_TO_MINE;
        this.busy.y = (134.0f - this.busy.height) / Pickaxe.TIME_TO_MINE;
        add(this.busy);
    }

    public void update() {
        super.update();
        if (this.thread != null && !this.thread.isAlive()) {
            this.thread = null;
            if (this.error == null) {
                remove(this.busy);
                createControls();
                return;
            }
            hide();
            Game.scene().add(new WndError(TXT_ERROR));
        }
    }

    private void createControls() {
        String[] labels = new String[]{TXT_STATS, TXT_ITEMS, TXT_BADGES};
        Group[] pages = new Group[]{new StatsTab(), new ItemsTab(), new BadgesTab()};
        for (int i = 0; i < pages.length; i++) {
            add(pages[i]);
            Tab tab = new RankingTab(labels[i], pages[i]);
            tab.setSize(40.0f, (float) tabHeight());
            add(tab);
        }
        select(0);
    }
}
