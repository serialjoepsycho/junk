package com.watabou.pixeldungeon.windows;

import com.watabou.gltextures.SmartTexture;
import com.watabou.gltextures.TextureCache;
import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Group;
import com.watabou.noosa.TextureFilm;
import com.watabou.noosa.tweeners.AlphaTweener;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.actors.mobs.npcs.Crab;
import com.watabou.pixeldungeon.actors.mobs.npcs.MirrorImage;
import com.watabou.pixeldungeon.actors.mobs.npcs.Rat;
import com.watabou.pixeldungeon.actors.mobs.npcs.Skeleton;
import com.watabou.pixeldungeon.effects.Pushing;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.watabou.pixeldungeon.items.wands.WandOfBlink;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;

public class WndSkill extends WndTabbed {
    private static final int TAB_WIDTH = 40;
    private static final String TXT_ACT = "Active";
    private static final String TXT_DEPTH = "Maximum Depth";
    private static final String TXT_EXP = "Experience";
    private static final String TXT_GOLD = "Gold Collected";
    private static final String TXT_HEALTH = "Health";
    private static final String TXT_PASS = "Passive";
    private static final String TXT_STR = "Strength";
    private static final String TXT_Skill = "Skill Points";
    private static final int WIDTH = 120;
    private BuffsTab buffs;
    private TextureFilm film;
    private SmartTexture icons;
    private StatsTab stats;

    /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.1 */
    class C02201 extends LabeledTab {
        C02201(String label) {
            super(label);
        }

        protected void select(boolean value) {
            super.select(value);
            StatsTab access$000 = WndSkill.this.stats;
            StatsTab access$0002 = WndSkill.this.stats;
            boolean z = this.selected;
            access$0002.active = z;
            access$000.visible = z;
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.2 */
    class C02212 extends LabeledTab {
        C02212(String label) {
            super(label);
        }

        protected void select(boolean value) {
            super.select(value);
            BuffsTab access$100 = WndSkill.this.buffs;
            BuffsTab access$1002 = WndSkill.this.buffs;
            boolean z = this.selected;
            access$1002.active = z;
            access$100.visible = z;
        }
    }

    private class BuffsTab extends Group {
        private static final int GAP = 2;
        private static final String TXT_TITLE = "%s Skills";
        final Hero hero;
        private float pos;

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.10 */
        class AnonymousClass10 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            AnonymousClass10(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.11 */
        class AnonymousClass11 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            AnonymousClass11(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
                if (BuffsTab.this.hero.isStarving()) {
                    GLog.m2n("You are too hungry to use Frost Shot", new Object[0]);
                } else if (BuffsTab.this.hero.MP > 16) {
                    Hero hero = BuffsTab.this.hero;
                    hero.MP -= 16;
                    GLog.m3p("Your next ranged attack will freeze your target", new Object[0]);
                    BuffsTab.this.hero.skillSecondActive = true;
                    BuffsTab.this.hero.skillSecondCooldown = 30;
                } else {
                    GLog.m1i("Not enough mana!", new Object[0]);
                }
                WndSkill.this.hide();
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.12 */
        class AnonymousClass12 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            AnonymousClass12(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.13 */
        class AnonymousClass13 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            AnonymousClass13(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
                if (BuffsTab.this.hero.isStarving()) {
                    GLog.m2n("You are too hungry to cast Shadow Clone", new Object[0]);
                } else if (BuffsTab.this.hero.MP > 18) {
                    Hero hero = BuffsTab.this.hero;
                    hero.MP -= 18;
                    GLog.m3p("You cast Shadow Clone", new Object[0]);
                    ArrayList<Integer> respawnPoints = new ArrayList();
                    for (int i : Level.NEIGHBOURS8) {
                        int p = BuffsTab.this.hero.pos + i;
                        if (Actor.findChar(p) == null && (Level.passable[p] || Level.avoid[p])) {
                            respawnPoints.add(Integer.valueOf(p));
                        }
                    }
                    for (int nImages = 1; nImages > 0 && respawnPoints.size() > 0; nImages--) {
                        int index = Random.index(respawnPoints);
                        Mob mob = new MirrorImage();
                        mob.duplicate(BuffsTab.this.hero);
                        GameScene.add(mob);
                        WandOfBlink.appear(mob, ((Integer) respawnPoints.get(index)).intValue());
                        respawnPoints.remove(index);
                    }
                    BuffsTab.this.hero.skillFirstCooldown = 65;
                } else {
                    GLog.m1i("Not enough mana!", new Object[0]);
                }
                WndSkill.this.hide();
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.14 */
        class AnonymousClass14 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            AnonymousClass14(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.15 */
        class AnonymousClass15 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            AnonymousClass15(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
                if (BuffsTab.this.hero.isStarving()) {
                    GLog.m2n("You are too hungry to disable a trap", new Object[0]);
                } else if (BuffsTab.this.hero.MP > 4) {
                    Hero hero = BuffsTab.this.hero;
                    hero.MP -= 4;
                    GLog.m3p("You will disable the next trap you walk on", new Object[0]);
                    BuffsTab.this.hero.skillSecondActive = true;
                    BuffsTab.this.hero.skillSecondCooldown = 10;
                } else {
                    GLog.m1i("Not enough mana!", new Object[0]);
                }
                WndSkill.this.hide();
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.16 */
        class AnonymousClass16 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            AnonymousClass16(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.1 */
        class C02221 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            C02221(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
                if (BuffsTab.this.hero.isStarving()) {
                    GLog.m1i("You are too hungry to cast Random Teleport", new Object[0]);
                } else if (BuffsTab.this.hero.MP > 8) {
                    GLog.m3p("You cast Random Teleport", new Object[0]);
                    ScrollOfTeleportation.teleportHero(BuffsTab.this.hero);
                    BuffsTab.this.hero.skillFirstCooldown = 15;
                    Hero hero = BuffsTab.this.hero;
                    hero.MP -= 8;
                } else {
                    GLog.m1i("Not enough mana!", new Object[0]);
                }
                WndSkill.this.hide();
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.2 */
        class C02232 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            C02232(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.3 */
        class C02243 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            C02243(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
                if (BuffsTab.this.hero.isStarving()) {
                    GLog.m1i("You are too hungry to summon", new Object[0]);
                } else if (BuffsTab.this.hero.MP > 15) {
                    BuffsTab.this.hero.skillSecondCooldown = 50;
                    int newPos = BuffsTab.this.hero.pos;
                    if (Actor.findChar(newPos) != null) {
                        Collection candidates = new ArrayList();
                        boolean[] passable = Level.passable;
                        for (int n : Level.NEIGHBOURS4) {
                            int c = BuffsTab.this.hero.pos + n;
                            if (passable[c] && Actor.findChar(c) == null) {
                                candidates.add(Integer.valueOf(c));
                            }
                        }
                        newPos = candidates.size() > 0 ? ((Integer) Random.element(candidates)).intValue() : -1;
                    }
                    if (newPos != -1) {
                        Hero hero = BuffsTab.this.hero;
                        hero.MP -= 15;
                        if (BuffsTab.this.hero.skillMeditation < 3) {
                            Mob rat = new Rat();
                            rat.spawn(BuffsTab.this.hero.skillMeditation);
                            rat.HP = rat.HT;
                            rat.pos = newPos;
                            GameScene.add(rat);
                            Actor.addDelayed(new Pushing(rat, BuffsTab.this.hero.pos, newPos), -1.0f);
                            rat.sprite.alpha(0.0f);
                            rat.sprite.parent.add(new AlphaTweener(rat.sprite, Key.TIME_TO_UNLOCK, 0.15f));
                            GLog.m3p("Rat summoned", new Object[0]);
                        } else if (BuffsTab.this.hero.skillMeditation < 6) {
                            Mob crab = new Crab();
                            crab.spawn(BuffsTab.this.hero.skillMeditation);
                            crab.HP = crab.HT;
                            crab.pos = newPos;
                            GameScene.add(crab);
                            Actor.addDelayed(new Pushing(crab, BuffsTab.this.hero.pos, newPos), -1.0f);
                            crab.sprite.alpha(0.0f);
                            crab.sprite.parent.add(new AlphaTweener(crab.sprite, Key.TIME_TO_UNLOCK, 0.15f));
                            GLog.m3p("Crab summoned", new Object[0]);
                        } else {
                            Mob skel = new Skeleton();
                            skel.spawn(BuffsTab.this.hero.skillMeditation);
                            skel.HP = skel.HT;
                            skel.pos = newPos;
                            GameScene.add(skel);
                            Actor.addDelayed(new Pushing(skel, BuffsTab.this.hero.pos, newPos), -1.0f);
                            skel.sprite.alpha(0.0f);
                            skel.sprite.parent.add(new AlphaTweener(skel.sprite, Key.TIME_TO_UNLOCK, 0.15f));
                            GLog.m3p("Skeleton summoned", new Object[0]);
                        }
                    } else {
                        GLog.m1i("No space to summon", new Object[0]);
                        BuffsTab.this.hero.skillSecondCooldown = 0;
                    }
                } else {
                    GLog.m1i("Not enough mana!", new Object[0]);
                }
                WndSkill.this.hide();
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.4 */
        class C02254 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            C02254(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.5 */
        class C02265 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            C02265(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
                if (BuffsTab.this.hero.isStarving()) {
                    GLog.m2n("You are too hungry to use Smash", new Object[0]);
                } else if (BuffsTab.this.hero.MP > 5) {
                    Hero hero = BuffsTab.this.hero;
                    hero.MP -= 5;
                    GLog.m3p("Your next melee attack will do more damage", new Object[0]);
                    BuffsTab.this.hero.skillFirstActive = true;
                    BuffsTab.this.hero.skillFirstCooldown = 11;
                } else {
                    GLog.m1i("Not enough mana!", new Object[0]);
                }
                WndSkill.this.hide();
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.6 */
        class C02276 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            C02276(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.7 */
        class C02287 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            C02287(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
                if (BuffsTab.this.hero.isStarving()) {
                    GLog.m2n("You are too hungry to use smite", new Object[0]);
                } else if (BuffsTab.this.hero.MP > 11) {
                    Hero hero = BuffsTab.this.hero;
                    hero.MP -= 11;
                    GLog.m3p("Your next melee attack will do way more damage but will leave you weak for a small duration", new Object[0]);
                    BuffsTab.this.hero.skillSecondActive = true;
                    BuffsTab.this.hero.skillSecondCooldown = 22;
                } else {
                    GLog.m1i("Not enough mana!", new Object[0]);
                }
                WndSkill.this.hide();
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.8 */
        class C02298 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            C02298(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.BuffsTab.9 */
        class C02309 extends RedButton {
            final /* synthetic */ WndSkill val$this$0;

            C02309(String label, WndSkill wndSkill) {
                this.val$this$0 = wndSkill;
                super(label);
            }

            protected void onClick() {
                if (BuffsTab.this.hero.isStarving()) {
                    GLog.m2n("You are too hungry to cast Flame Arrow", new Object[0]);
                } else if (BuffsTab.this.hero.MP > 12) {
                    Hero hero = BuffsTab.this.hero;
                    hero.MP -= 12;
                    GLog.m3p("Your next ranged attack will burn the target.", new Object[0]);
                    BuffsTab.this.hero.skillFirstActive = true;
                    BuffsTab.this.hero.skillFirstCooldown = 20;
                } else {
                    GLog.m1i("Not enough mana!", new Object[0]);
                }
                WndSkill.this.hide();
            }
        }

        public BuffsTab() {
            this.hero = Dungeon.hero;
            BitmapText title = PixelScene.createText(Utils.format(TXT_TITLE, this.hero.className()).toUpperCase(Locale.ENGLISH), 9.0f);
            title.hardlight(Window.TITLE_COLOR);
            title.measure();
            add(title);
            this.pos = (title.y + title.height()) + 11.0f;
            BitmapText txt;
            RedButton btnSkill;
            BitmapText txt2;
            if (this.hero.heroClass == HeroClass.MAGE) {
                txt = PixelScene.createText("Random Teleport - 8 MP", 9.0f);
                txt.y = this.pos;
                add(txt);
                if (this.hero.skillFirstCooldown == 0) {
                    btnSkill = new C02221("Cast", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                } else {
                    btnSkill = new C02232("Cool down", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                }
                this.pos += Pickaxe.TIME_TO_MINE;
                this.pos += 27.0f;
                txt2 = PixelScene.createText("Summon - 15 MP", 9.0f);
                txt2.y = this.pos;
                add(txt2);
                if (this.hero.skillSecondCooldown == 0) {
                    btnSkill = new C02243("Cast", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                } else {
                    btnSkill = new C02254("Cool down", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                }
                this.pos += Pickaxe.TIME_TO_MINE;
            } else if (this.hero.heroClass == HeroClass.WARRIOR) {
                txt = PixelScene.createText("Smash - 5 MP", 9.0f);
                txt.y = this.pos;
                add(txt);
                if (this.hero.skillFirstCooldown == 0) {
                    btnSkill = new C02265("Use", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                } else {
                    btnSkill = new C02276("Cool down", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                }
                this.pos += Pickaxe.TIME_TO_MINE;
                this.pos += 27.0f;
                txt2 = PixelScene.createText("Smite - 11 MP", 9.0f);
                txt2.y = this.pos;
                add(txt2);
                if (this.hero.skillSecondCooldown == 0) {
                    btnSkill = new C02287("Use", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                } else {
                    btnSkill = new C02298("Cool down", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                }
                this.pos += Pickaxe.TIME_TO_MINE;
            } else if (this.hero.heroClass == HeroClass.HUNTRESS) {
                txt = PixelScene.createText("Flame Arrow - 12 MP", 9.0f);
                txt.y = this.pos;
                add(txt);
                if (this.hero.skillFirstCooldown == 0) {
                    btnSkill = new C02309("Use", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                } else {
                    btnSkill = new AnonymousClass10("Cool down", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                }
                this.pos += Pickaxe.TIME_TO_MINE;
                this.pos += 27.0f;
                txt2 = PixelScene.createText("Frost Shot - 16 MP", 9.0f);
                txt2.y = this.pos;
                add(txt2);
                if (this.hero.skillSecondCooldown == 0) {
                    btnSkill = new AnonymousClass11("Use", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                } else {
                    btnSkill = new AnonymousClass12("Cool down", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                }
                this.pos += Pickaxe.TIME_TO_MINE;
            } else if (this.hero.heroClass == HeroClass.ROGUE) {
                txt = PixelScene.createText("Shadow Clone - 18 MP", 9.0f);
                txt.y = this.pos;
                add(txt);
                if (this.hero.skillFirstCooldown == 0) {
                    btnSkill = new AnonymousClass13("Cast", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                } else {
                    btnSkill = new AnonymousClass14("Cool down", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                }
                this.pos += Pickaxe.TIME_TO_MINE;
                this.pos += 27.0f;
                txt2 = PixelScene.createText("Disable Trap - 4 MP", 9.0f);
                txt2.y = this.pos;
                add(txt2);
                if (this.hero.skillSecondCooldown == 0) {
                    btnSkill = new AnonymousClass15("Use", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                } else {
                    btnSkill = new AnonymousClass16("Cool down", WndSkill.this);
                    btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                    add(btnSkill);
                }
                this.pos += Pickaxe.TIME_TO_MINE;
            }
        }

        public float height() {
            return this.pos;
        }
    }

    private class StatsTab extends Group {
        private static final int GAP = 6;
        private static final String TXT_CATALOGUS = "Catalogus";
        private static final String TXT_JOURNAL = "Journal";
        private static final String TXT_TITLE = "%s Skills";
        private float pos;

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.10 */
        class AnonymousClass10 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            AnonymousClass10(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillAccurancy + 1 > this.val$hero.lvl) {
                        GLog.m2n("Accuracy is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on Accuracy", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillAccurancy++;
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.11 */
        class AnonymousClass11 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            AnonymousClass11(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillRanged + 1 > this.val$hero.lvl) {
                        GLog.m2n("Ranged is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on Ranged", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillRanged++;
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.12 */
        class AnonymousClass12 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            AnonymousClass12(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillHunter + 1 > this.val$hero.lvl) {
                        GLog.m2n("Fletching is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on Fletching", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillHunter++;
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.1 */
        class C02311 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            C02311(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillStr + 1 > this.val$hero.lvl) {
                        GLog.m2n("Training is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on training", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillStr++;
                        if (this.val$hero.skillStr % 3 == 0) {
                            GLog.m3p("Your training pays off, +1 strength!", new Object[0]);
                            hero = this.val$hero;
                            hero.STR++;
                        }
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.2 */
        class C02322 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            C02322(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillMelee + 1 > this.val$hero.lvl) {
                        GLog.m2n("Melee is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on melee", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillMelee++;
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.3 */
        class C02333 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            C02333(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillEnd + 1 > this.val$hero.lvl) {
                        GLog.m2n("Endurance is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on endurance", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillEnd++;
                        hero = this.val$hero;
                        hero.HT += 3;
                        hero = this.val$hero;
                        hero.HP += 3;
                        GLog.m3p("+3 max HP!", new Object[0]);
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.4 */
        class C02344 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            C02344(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillLoot + 1 > this.val$hero.lvl) {
                        GLog.m2n("Looting is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on Looting", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillLoot++;
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.5 */
        class C02355 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            C02355(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillStealth + 1 > this.val$hero.lvl) {
                        GLog.m2n("Stealth is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on stealth", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillStealth++;
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.6 */
        class C02366 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            C02366(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillVenom + 1 > this.val$hero.lvl) {
                        GLog.m2n("Venom is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on Venom", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillVenom++;
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.7 */
        class C02377 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            C02377(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillMeditation + 1 > this.val$hero.lvl) {
                        GLog.m2n("Meditation is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on meditation", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillMeditation++;
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.8 */
        class C02388 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            C02388(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillWand + 1 > this.val$hero.lvl) {
                        GLog.m2n("Wand Mastery is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on wand mastery", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillWand++;
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        /* renamed from: com.watabou.pixeldungeon.windows.WndSkill.StatsTab.9 */
        class C02399 extends RedButton {
            final /* synthetic */ Hero val$hero;
            final /* synthetic */ WndSkill val$this$0;

            C02399(String label, WndSkill wndSkill, Hero hero) {
                this.val$this$0 = wndSkill;
                this.val$hero = hero;
                super(label);
            }

            protected void onClick() {
                if (this.val$hero.skillPoints > 0) {
                    if (this.val$hero.skillMana + 1 > this.val$hero.lvl) {
                        GLog.m2n("Spirituality is capped at your level, level to raise the cap.", new Object[0]);
                    } else {
                        GLog.m1i("Skill point used on Spirituality", new Object[0]);
                        Hero hero = this.val$hero;
                        hero.skillPoints--;
                        hero = this.val$hero;
                        hero.skillMana++;
                    }
                    WndSkill.this.hide();
                    GameScene.show(new WndSkill());
                }
            }
        }

        public StatsTab() {
            Hero hero = Dungeon.hero;
            BitmapText title = PixelScene.createText(Utils.format(TXT_TITLE, hero.className()).toUpperCase(Locale.ENGLISH), 9.0f);
            title.hardlight(Window.TITLE_COLOR);
            title.measure();
            add(title);
            this.pos = (title.y + title.height()) + Pickaxe.TIME_TO_MINE;
            statSlot(WndSkill.TXT_Skill, hero.skillPoints);
            this.pos += 6.0f;
            RedButton btnSkill;
            RedButton btnSkillMelee;
            RedButton btnSkillEnd;
            if (hero.heroClass == HeroClass.WARRIOR) {
                btnSkill = new C02311("+", WndSkill.this, hero);
                btnSkill.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkill);
                statSlot("Training", hero.skillStr);
                this.pos += 6.0f;
                btnSkillMelee = new C02322("+", WndSkill.this, hero);
                btnSkillMelee.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkillMelee);
                statSlot("Melee", hero.skillMelee);
                this.pos += 6.0f;
                btnSkillEnd = new C02333("+", WndSkill.this, hero);
                btnSkillEnd.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkillEnd);
                statSlot("Endurance", hero.skillEnd);
                this.pos += 6.0f;
            } else if (hero.heroClass == HeroClass.ROGUE) {
                btnSkill = new C02344("+", WndSkill.this, hero);
                btnSkill.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkill);
                statSlot("Looting", hero.skillLoot);
                this.pos += 6.0f;
                btnSkillMelee = new C02355("+", WndSkill.this, hero);
                btnSkillMelee.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkillMelee);
                statSlot("Stealth", hero.skillStealth);
                this.pos += 6.0f;
                btnSkillEnd = new C02366("+", WndSkill.this, hero);
                btnSkillEnd.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkillEnd);
                statSlot("Venom", hero.skillVenom);
                this.pos += 6.0f;
            } else if (hero.heroClass == HeroClass.MAGE) {
                btnSkill = new C02377("+", WndSkill.this, hero);
                btnSkill.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkill);
                statSlot("Meditation", hero.skillMeditation);
                this.pos += 6.0f;
                btnSkillMelee = new C02388("+", WndSkill.this, hero);
                btnSkillMelee.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkillMelee);
                statSlot("Wand Mastery", hero.skillWand);
                this.pos += 6.0f;
                btnSkillEnd = new C02399("+", WndSkill.this, hero);
                btnSkillEnd.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkillEnd);
                statSlot("Spirituality", hero.skillMana);
                this.pos += 6.0f;
            } else if (hero.heroClass == HeroClass.HUNTRESS) {
                btnSkill = new AnonymousClass10("+", WndSkill.this, hero);
                btnSkill.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkill);
                statSlot("Accuracy", hero.skillAccurancy);
                this.pos += 6.0f;
                btnSkillMelee = new AnonymousClass11("+", WndSkill.this, hero);
                btnSkillMelee.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkillMelee);
                statSlot("Ranged", hero.skillRanged);
                this.pos += 6.0f;
                btnSkillEnd = new AnonymousClass12("+", WndSkill.this, hero);
                btnSkillEnd.setRect(80.0f, this.pos, 8.0f, 8.0f);
                add(btnSkillEnd);
                statSlot("Fletching", hero.skillHunter);
                this.pos += 6.0f;
            }
        }

        private void statSlot(String label, float val, String value) {
            BitmapText txt = PixelScene.createText(label, 8.0f);
            txt.y = this.pos;
            add(txt);
            txt = PixelScene.createText(Utils.format(value, Float.valueOf(val)), 8.0f);
            txt.measure();
            txt.x = PixelScene.align(66.0f);
            txt.y = this.pos;
            add(txt);
            this.pos += 6.0f + txt.baseLine();
        }

        private void statSlot(String label, String value) {
            BitmapText txt = PixelScene.createText(label, 8.0f);
            txt.y = this.pos;
            add(txt);
            txt = PixelScene.createText(value, 8.0f);
            txt.measure();
            txt.x = PixelScene.align(66.0f);
            txt.y = this.pos;
            add(txt);
            this.pos += 6.0f + txt.baseLine();
        }

        private void statSlot(String label, int value) {
            statSlot(label, Integer.toString(value));
        }

        public float height() {
            return this.pos;
        }
    }

    public WndSkill() {
        this.icons = TextureCache.get(Assets.BUFFS_LARGE);
        this.film = new TextureFilm(this.icons, 16, 16);
        this.stats = new StatsTab();
        add(this.stats);
        this.buffs = new BuffsTab();
        add(this.buffs);
        add(new C02201(TXT_PASS));
        add(new C02212(TXT_ACT));
        Iterator it = this.tabs.iterator();
        while (it.hasNext()) {
            ((Tab) it.next()).setSize(40.0f, (float) tabHeight());
        }
        resize(WIDTH, (int) Math.max(this.stats.height(), this.buffs.height()));
        select(0);
    }
}
