package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.Window;

public class WndDonationsThanks extends WndTabbed {
    float GAP;
    Hero hero;
    float pos;

    public WndDonationsThanks(String message) {
        this.pos = GasesImmunity.DURATION;
        this.GAP = Pickaxe.TIME_TO_MINE;
        this.hero = Dungeon.hero;
        resize(ItemSpriteSheet.VIAL, 50);
        BitmapText title = PixelScene.createText("Donation Received", 9.0f);
        title.hardlight(Window.TITLE_COLOR);
        title.measure();
        add(title);
        this.pos = (title.y + title.height()) + Pickaxe.TIME_TO_MINE;
        BitmapTextMultiline info = PixelScene.createMultiline(6.0f);
        add(info);
        info.text(message);
        info.maxWidth = ItemSpriteSheet.VIAL;
        info.measure();
        info.y = this.pos;
        resize(ItemSpriteSheet.VIAL, (int) ((info.height() + info.y) + GasesImmunity.DURATION));
    }
}
