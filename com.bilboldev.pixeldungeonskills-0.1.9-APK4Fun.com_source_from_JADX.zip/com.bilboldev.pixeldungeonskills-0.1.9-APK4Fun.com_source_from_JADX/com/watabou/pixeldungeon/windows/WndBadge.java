package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.BitmapTextMultiline.LineSplitter;
import com.watabou.noosa.Image;
import com.watabou.pixeldungeon.Badges.Badge;
import com.watabou.pixeldungeon.effects.BadgeBanner;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.Window;
import java.util.Iterator;

public class WndBadge extends Window {
    private static final int MARGIN = 4;
    private static final int WIDTH = 120;

    public WndBadge(Badge badge) {
        Image icon = BadgeBanner.image(badge.image);
        icon.scale.set((float) Pickaxe.TIME_TO_MINE);
        add(icon);
        BitmapTextMultiline info = PixelScene.createMultiline(badge.description, 8.0f);
        info.maxWidth = ItemSpriteSheet.PASTY;
        info.measure();
        float w = Math.max(icon.width(), info.width()) + 8.0f;
        icon.x = (w - icon.width()) / Pickaxe.TIME_TO_MINE;
        icon.y = 4.0f;
        float pos = (icon.y + icon.height()) + 4.0f;
        info.getClass();
        Iterator it = new LineSplitter().split().iterator();
        while (it.hasNext()) {
            BitmapText line = (BitmapText) it.next();
            line.measure();
            line.x = PixelScene.align((w - line.width()) / Pickaxe.TIME_TO_MINE);
            line.y = PixelScene.align(pos);
            add(line);
            pos += line.height();
        }
        resize((int) w, (int) (pos + 4.0f));
        BadgeBanner.highlight(icon, badge.image);
    }
}
