package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.mobs.npcs.Imp;
import com.watabou.pixeldungeon.actors.mobs.npcs.Imp.Quest;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.quest.DwarfToken;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;

public class WndImp extends Window {
    private static final int BTN_HEIGHT = 20;
    private static final int GAP = 2;
    private static final String TXT_MESSAGE = "Oh yes! You are my hero!\nRegarding your reward, I don't have cash with me right now, but I have something better for you. This is my family heirloom ring: my granddad took it off a dead paladin's finger.";
    private static final String TXT_REWARD = "Take the ring";
    private static final int WIDTH = 120;

    /* renamed from: com.watabou.pixeldungeon.windows.WndImp.1 */
    class C01921 extends RedButton {
        final /* synthetic */ Imp val$imp;
        final /* synthetic */ DwarfToken val$tokens;

        C01921(String label, Imp imp, DwarfToken dwarfToken) {
            this.val$imp = imp;
            this.val$tokens = dwarfToken;
            super(label);
        }

        protected void onClick() {
            WndImp.this.takeReward(this.val$imp, this.val$tokens, Quest.reward);
        }
    }

    public WndImp(Imp imp, DwarfToken tokens) {
        IconTitle titlebar = new IconTitle();
        titlebar.icon(new ItemSprite(tokens.image(), null));
        titlebar.label(Utils.capitalize(tokens.name()));
        titlebar.setRect(0.0f, 0.0f, 120.0f, 0.0f);
        add(titlebar);
        BitmapTextMultiline message = PixelScene.createMultiline(TXT_MESSAGE, 6.0f);
        message.maxWidth = WIDTH;
        message.measure();
        message.y = titlebar.bottom() + Pickaxe.TIME_TO_MINE;
        add(message);
        RedButton btnReward = new C01921(TXT_REWARD, imp, tokens);
        btnReward.setRect(0.0f, (message.y + message.height()) + Pickaxe.TIME_TO_MINE, 120.0f, MindVision.DURATION);
        add(btnReward);
        resize(WIDTH, (int) btnReward.bottom());
    }

    private void takeReward(Imp imp, DwarfToken tokens, Item reward) {
        hide();
        tokens.detachAll(Dungeon.hero.belongings.backpack);
        reward.identify();
        if (reward.doPickUp(Dungeon.hero)) {
            GLog.m1i(Hero.TXT_YOU_NOW_HAVE, reward.name());
        } else {
            Dungeon.level.drop(reward, imp.pos).sprite.drop();
        }
        imp.flee();
        Quest.complete();
    }
}
