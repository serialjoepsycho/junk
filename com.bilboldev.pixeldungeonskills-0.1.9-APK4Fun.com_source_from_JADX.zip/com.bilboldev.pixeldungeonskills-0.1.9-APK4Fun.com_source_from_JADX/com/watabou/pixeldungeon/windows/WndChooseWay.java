package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.pixeldungeon.actors.hero.HeroSubClass;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.Utils;

public class WndChooseWay extends Window {
    private static final int BTN_HEIGHT = 18;
    private static final float GAP = 2.0f;
    private static final String TXT_CANCEL = "I'll decide later";
    private static final String TXT_MESSAGE = "Which way will you follow?";
    private static final int WIDTH = 120;

    /* renamed from: com.watabou.pixeldungeon.windows.WndChooseWay.1 */
    class C01721 extends RedButton {
        final /* synthetic */ TomeOfMastery val$tome;
        final /* synthetic */ HeroSubClass val$way1;

        C01721(String label, TomeOfMastery tomeOfMastery, HeroSubClass heroSubClass) {
            this.val$tome = tomeOfMastery;
            this.val$way1 = heroSubClass;
            super(label);
        }

        protected void onClick() {
            WndChooseWay.this.hide();
            this.val$tome.choose(this.val$way1);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndChooseWay.2 */
    class C01732 extends RedButton {
        final /* synthetic */ TomeOfMastery val$tome;
        final /* synthetic */ HeroSubClass val$way2;

        C01732(String label, TomeOfMastery tomeOfMastery, HeroSubClass heroSubClass) {
            this.val$tome = tomeOfMastery;
            this.val$way2 = heroSubClass;
            super(label);
        }

        protected void onClick() {
            WndChooseWay.this.hide();
            this.val$tome.choose(this.val$way2);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndChooseWay.3 */
    class C01743 extends RedButton {
        C01743(String label) {
            super(label);
        }

        protected void onClick() {
            WndChooseWay.this.hide();
        }
    }

    public WndChooseWay(TomeOfMastery tome, HeroSubClass way1, HeroSubClass way2) {
        IconTitle titlebar = new IconTitle();
        titlebar.icon(new ItemSprite(tome.image(), null));
        titlebar.label(tome.name());
        titlebar.setRect(0.0f, 0.0f, 120.0f, 0.0f);
        add(titlebar);
        Highlighter hl = new Highlighter(way1.desc() + "\n\n" + way2.desc() + "\n\n" + TXT_MESSAGE);
        BitmapTextMultiline normal = PixelScene.createMultiline(hl.text, 6.0f);
        normal.maxWidth = WIDTH;
        normal.measure();
        normal.x = titlebar.left();
        normal.y = titlebar.bottom() + GAP;
        add(normal);
        if (hl.isHighlighted()) {
            normal.mask = hl.inverted();
            BitmapTextMultiline highlighted = PixelScene.createMultiline(hl.text, 6.0f);
            highlighted.maxWidth = normal.maxWidth;
            highlighted.measure();
            highlighted.x = normal.x;
            highlighted.y = normal.y;
            add(highlighted);
            highlighted.mask = hl.mask;
            highlighted.hardlight(Window.TITLE_COLOR);
        }
        RedButton btnWay1 = new C01721(Utils.capitalize(way1.title()), tome, way1);
        btnWay1.setRect(0.0f, (normal.y + normal.height()) + GAP, 59.0f, 18.0f);
        add(btnWay1);
        RedButton btnWay2 = new C01732(Utils.capitalize(way2.title()), tome, way2);
        btnWay2.setRect(btnWay1.right() + GAP, btnWay1.top(), btnWay1.width(), 18.0f);
        add(btnWay2);
        RedButton btnCancel = new C01743(TXT_CANCEL);
        btnCancel.setRect(0.0f, btnWay2.bottom() + GAP, 120.0f, 18.0f);
        add(btnCancel);
        resize(WIDTH, (int) btnCancel.bottom());
    }
}
