package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapText;
import com.watabou.pixeldungeon.Challenges;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.ui.CheckBox;
import com.watabou.pixeldungeon.ui.Window;
import java.util.ArrayList;

public class WndChallenges extends Window {
    private static final int BTN_HEIGHT = 18;
    private static final int GAP = 1;
    private static final String TITLE = "Challenges";
    private static final int TTL_HEIGHT = 12;
    private static final int WIDTH = 108;
    private ArrayList<CheckBox> boxes;
    private boolean editable;

    public WndChallenges(int checked, boolean editable) {
        this.editable = editable;
        BitmapText title = PixelScene.createText(TITLE, 9.0f);
        title.hardlight(Window.TITLE_COLOR);
        title.measure();
        title.x = PixelScene.align(this.camera, (108.0f - title.width()) / Pickaxe.TIME_TO_MINE);
        title.y = PixelScene.align(this.camera, (12.0f - title.height()) / Pickaxe.TIME_TO_MINE);
        add(title);
        this.boxes = new ArrayList();
        float pos = 12.0f;
        for (int i = 0; i < Challenges.NAMES.length; i += GAP) {
            CheckBox cb = new CheckBox(Challenges.NAMES[i]);
            cb.checked((Challenges.MASKS[i] & checked) != 0);
            cb.active = editable;
            if (i > 0) {
                pos += Key.TIME_TO_UNLOCK;
            }
            cb.setRect(0.0f, pos, 108.0f, 18.0f);
            pos = cb.bottom();
            add(cb);
            this.boxes.add(cb);
        }
        resize(WIDTH, (int) pos);
    }

    public void onBackPressed() {
        if (this.editable) {
            int value = 0;
            for (int i = 0; i < this.boxes.size(); i += GAP) {
                if (((CheckBox) this.boxes.get(i)).checked()) {
                    value |= Challenges.MASKS[i];
                }
            }
            PixelDungeon.challenges(value);
        }
        super.onBackPressed();
    }
}
