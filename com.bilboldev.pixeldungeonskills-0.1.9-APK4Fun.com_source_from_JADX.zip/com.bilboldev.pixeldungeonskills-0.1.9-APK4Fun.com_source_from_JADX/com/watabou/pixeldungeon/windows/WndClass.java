package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.Group;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.hero.HeroSubClass;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.Utils;

public class WndClass extends WndTabbed {
    private static final int TAB_WIDTH = 50;
    private static final String TXT_MASTERY = "Mastery";
    private static final int WIDTH = 110;
    private HeroClass cl;
    private MasteryTab tabMastery;
    private PerksTab tabPerks;

    /* renamed from: com.watabou.pixeldungeon.windows.WndClass.1 */
    static /* synthetic */ class C01751 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass;

        static {
            $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass = new int[HeroClass.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.WARRIOR.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.MAGE.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.ROGUE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.HUNTRESS.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
        }
    }

    private class MasteryTab extends Group {
        private static final int MARGIN = 4;
        public float height;
        private BitmapTextMultiline highlighted;
        private BitmapTextMultiline normal;
        public float width;

        public MasteryTab() {
            String text = null;
            switch (C01751.$SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[WndClass.this.cl.ordinal()]) {
                case WndUpdates.ID_PRISON /*1*/:
                    text = HeroSubClass.GLADIATOR.desc() + "\n\n" + HeroSubClass.BERSERKER.desc();
                    break;
                case WndUpdates.ID_CAVES /*2*/:
                    text = HeroSubClass.BATTLEMAGE.desc() + "\n\n" + HeroSubClass.WARLOCK.desc();
                    break;
                case WndUpdates.ID_METROPOLIS /*3*/:
                    text = HeroSubClass.FREERUNNER.desc() + "\n\n" + HeroSubClass.ASSASSIN.desc();
                    break;
                case MARGIN /*4*/:
                    text = HeroSubClass.SNIPER.desc() + "\n\n" + HeroSubClass.WARDEN.desc();
                    break;
            }
            Highlighter hl = new Highlighter(text);
            this.normal = PixelScene.createMultiline(hl.text, 6.0f);
            this.normal.maxWidth = ItemSpriteSheet.ORE;
            this.normal.measure();
            this.normal.x = 4.0f;
            this.normal.y = 4.0f;
            add(this.normal);
            if (hl.isHighlighted()) {
                this.normal.mask = hl.inverted();
                this.highlighted = PixelScene.createMultiline(hl.text, 6.0f);
                this.highlighted.maxWidth = this.normal.maxWidth;
                this.highlighted.measure();
                this.highlighted.x = this.normal.x;
                this.highlighted.y = this.normal.y;
                add(this.highlighted);
                this.highlighted.mask = hl.mask;
                this.highlighted.hardlight(Window.TITLE_COLOR);
            }
            this.height = (this.normal.y + this.normal.height()) + 4.0f;
            this.width = (this.normal.x + this.normal.width()) + 4.0f;
        }
    }

    private class PerksTab extends Group {
        private static final String DOT = "\u007f";
        private static final int GAP = 4;
        private static final int MARGIN = 4;
        public float height;
        public float width;

        public PerksTab() {
            float dotWidth = 0.0f;
            String[] items = WndClass.this.cl.perks();
            float pos = 4.0f;
            for (int i = 0; i < items.length; i++) {
                if (i > 0) {
                    pos += 4.0f;
                }
                BitmapText dot = PixelScene.createText(DOT, 6.0f);
                dot.x = 4.0f;
                dot.y = pos;
                if (dotWidth == 0.0f) {
                    dot.measure();
                    dotWidth = dot.width();
                }
                add(dot);
                BitmapTextMultiline item = PixelScene.createMultiline(items[i], 6.0f);
                item.x = dot.x + dotWidth;
                item.y = pos;
                item.maxWidth = (int) (102.0f - dotWidth);
                item.measure();
                add(item);
                pos += item.height();
                float w = item.width();
                if (w > this.width) {
                    this.width = w;
                }
            }
            this.width += 4.0f + dotWidth;
            this.height = pos + 4.0f;
        }
    }

    private class RankingTab extends LabeledTab {
        private Group page;

        public RankingTab(String label, Group page) {
            super(label);
            this.page = page;
        }

        protected void select(boolean value) {
            super.select(value);
            if (this.page != null) {
                Group group = this.page;
                Group group2 = this.page;
                boolean z = this.selected;
                group2.active = z;
                group.visible = z;
            }
        }
    }

    public WndClass(HeroClass cl) {
        this.cl = cl;
        this.tabPerks = new PerksTab();
        add(this.tabPerks);
        Tab tab = new RankingTab(Utils.capitalize(cl.title()), this.tabPerks);
        tab.setSize(50.0f, (float) tabHeight());
        add(tab);
        if (Badges.isUnlocked(cl.masteryBadge())) {
            this.tabMastery = new MasteryTab();
            add(this.tabMastery);
            tab = new RankingTab(TXT_MASTERY, this.tabMastery);
            tab.setSize(50.0f, (float) tabHeight());
            add(tab);
            resize((int) Math.max(this.tabPerks.width, this.tabMastery.width), (int) Math.max(this.tabPerks.height, this.tabMastery.height));
        } else {
            resize((int) this.tabPerks.width, (int) this.tabPerks.height);
        }
        select(0);
    }
}
