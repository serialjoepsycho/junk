package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.Game;
import com.watabou.pixeldungeon.Rankings;
import com.watabou.pixeldungeon.Statistics;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Ankh;
import com.watabou.pixeldungeon.scenes.InterlevelScene;
import com.watabou.pixeldungeon.scenes.InterlevelScene.Mode;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;

public class WndResurrect extends Window {
    private static final int BTN_HEIGHT = 20;
    private static final float GAP = 2.0f;
    private static final String TXT_MESSAGE = "You died, but you were given another chance to win this dungeon. Will you take it?";
    private static final String TXT_NO = "No, I give up";
    private static final String TXT_YES = "Yes, I will fight!";
    private static final int WIDTH = 120;
    public static Object causeOfDeath;
    public static WndResurrect instance;

    /* renamed from: com.watabou.pixeldungeon.windows.WndResurrect.1 */
    class C02071 extends RedButton {
        C02071(String label) {
            super(label);
        }

        protected void onClick() {
            WndResurrect.this.hide();
            Statistics.ankhsUsed++;
            InterlevelScene.mode = Mode.RESURRECT;
            Game.switchScene(InterlevelScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndResurrect.2 */
    class C02082 extends RedButton {
        C02082(String label) {
            super(label);
        }

        protected void onClick() {
            WndResurrect.this.hide();
            Rankings.INSTANCE.submit(false);
            Hero.reallyDie(WndResurrect.causeOfDeath);
        }
    }

    public WndResurrect(Ankh ankh, Object causeOfDeath) {
        instance = this;
        causeOfDeath = causeOfDeath;
        IconTitle titlebar = new IconTitle();
        titlebar.icon(new ItemSprite(ankh.image(), null));
        titlebar.label(ankh.name());
        titlebar.setRect(0.0f, 0.0f, 120.0f, 0.0f);
        add(titlebar);
        BitmapTextMultiline message = PixelScene.createMultiline(TXT_MESSAGE, 6.0f);
        message.maxWidth = WIDTH;
        message.measure();
        message.y = titlebar.bottom() + GAP;
        add(message);
        RedButton btnYes = new C02071(TXT_YES);
        btnYes.setRect(0.0f, (message.y + message.height()) + GAP, 120.0f, MindVision.DURATION);
        add(btnYes);
        RedButton btnNo = new C02082(TXT_NO);
        btnNo.setRect(0.0f, btnYes.bottom() + GAP, 120.0f, MindVision.DURATION);
        add(btnNo);
        resize(WIDTH, (int) btnNo.bottom());
    }

    public void destroy() {
        super.destroy();
        instance = null;
    }

    public void onBackPressed() {
    }
}
