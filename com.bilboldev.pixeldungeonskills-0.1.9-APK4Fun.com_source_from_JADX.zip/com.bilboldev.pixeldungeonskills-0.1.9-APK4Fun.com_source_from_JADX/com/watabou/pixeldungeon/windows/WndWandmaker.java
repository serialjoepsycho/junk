package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.mobs.npcs.Wandmaker;
import com.watabou.pixeldungeon.actors.mobs.npcs.Wandmaker.Quest;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.wands.Wand;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;

public class WndWandmaker extends Window {
    private static final int BTN_HEIGHT = 20;
    private static final float GAP = 2.0f;
    private static final String TXT_BATTLE = "Battle wand";
    private static final String TXT_FARAWELL = "Good luck in your quest, %s!";
    private static final String TXT_MESSAGE = "Oh, I see you have succeeded! I do hope it hasn't troubled you too much. As I promised, you can choose one of my high quality wands.";
    private static final String TXT_NON_BATTLE = "Non-battle wand";
    private static final int WIDTH = 120;

    /* renamed from: com.watabou.pixeldungeon.windows.WndWandmaker.1 */
    class C02481 extends RedButton {
        final /* synthetic */ Item val$item;
        final /* synthetic */ Wandmaker val$wandmaker;

        C02481(String label, Wandmaker wandmaker, Item item) {
            this.val$wandmaker = wandmaker;
            this.val$item = item;
            super(label);
        }

        protected void onClick() {
            WndWandmaker.this.selectReward(this.val$wandmaker, this.val$item, Quest.wand1);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndWandmaker.2 */
    class C02492 extends RedButton {
        final /* synthetic */ Item val$item;
        final /* synthetic */ Wandmaker val$wandmaker;

        C02492(String label, Wandmaker wandmaker, Item item) {
            this.val$wandmaker = wandmaker;
            this.val$item = item;
            super(label);
        }

        protected void onClick() {
            WndWandmaker.this.selectReward(this.val$wandmaker, this.val$item, Quest.wand2);
        }
    }

    public WndWandmaker(Wandmaker wandmaker, Item item) {
        IconTitle titlebar = new IconTitle();
        titlebar.icon(new ItemSprite(item.image(), null));
        titlebar.label(Utils.capitalize(item.name()));
        titlebar.setRect(0.0f, 0.0f, 120.0f, 0.0f);
        add(titlebar);
        BitmapTextMultiline message = PixelScene.createMultiline(TXT_MESSAGE, 6.0f);
        message.maxWidth = WIDTH;
        message.measure();
        message.y = titlebar.bottom() + GAP;
        add(message);
        RedButton btnBattle = new C02481(TXT_BATTLE, wandmaker, item);
        btnBattle.setRect(0.0f, (message.y + message.height()) + GAP, 120.0f, MindVision.DURATION);
        add(btnBattle);
        RedButton btnNonBattle = new C02492(TXT_NON_BATTLE, wandmaker, item);
        btnNonBattle.setRect(0.0f, btnBattle.bottom() + GAP, 120.0f, MindVision.DURATION);
        add(btnNonBattle);
        resize(WIDTH, (int) btnNonBattle.bottom());
    }

    private void selectReward(Wandmaker wandmaker, Item item, Wand reward) {
        hide();
        item.detach(Dungeon.hero.belongings.backpack);
        reward.identify();
        if (reward.doPickUp(Dungeon.hero)) {
            GLog.m1i(Hero.TXT_YOU_NOW_HAVE, reward.name());
        } else {
            Dungeon.level.drop(reward, wandmaker.pos).sprite.drop();
        }
        wandmaker.yell(Utils.format(TXT_FARAWELL, Dungeon.hero.className()));
        wandmaker.destroy();
        wandmaker.sprite.die();
        Quest.complete();
    }
}
