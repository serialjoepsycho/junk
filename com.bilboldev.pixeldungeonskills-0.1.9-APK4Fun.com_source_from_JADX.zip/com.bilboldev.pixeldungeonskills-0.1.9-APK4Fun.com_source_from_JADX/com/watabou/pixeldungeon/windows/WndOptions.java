package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;

public class WndOptions extends Window {
    private static final int BUTTON_HEIGHT = 20;
    private static final int MARGIN = 2;
    private static final int WIDTH = 120;

    /* renamed from: com.watabou.pixeldungeon.windows.WndOptions.1 */
    class C01951 extends RedButton {
        final /* synthetic */ int val$index;

        C01951(String label, int i) {
            this.val$index = i;
            super(label);
        }

        protected void onClick() {
            WndOptions.this.hide();
            WndOptions.this.onSelect(this.val$index);
        }
    }

    public WndOptions(String title, String message, String... options) {
        BitmapTextMultiline tfTitle = PixelScene.createMultiline(title, 9.0f);
        tfTitle.hardlight(Window.TITLE_COLOR);
        tfTitle.y = Pickaxe.TIME_TO_MINE;
        tfTitle.x = Pickaxe.TIME_TO_MINE;
        tfTitle.maxWidth = ItemSpriteSheet.CARPACCIO;
        tfTitle.measure();
        add(tfTitle);
        BitmapTextMultiline tfMesage = PixelScene.createMultiline(message, 8.0f);
        tfMesage.maxWidth = ItemSpriteSheet.CARPACCIO;
        tfMesage.measure();
        tfMesage.x = Pickaxe.TIME_TO_MINE;
        tfMesage.y = (tfTitle.y + tfTitle.height()) + Pickaxe.TIME_TO_MINE;
        add(tfMesage);
        float pos = (tfMesage.y + tfMesage.height()) + Pickaxe.TIME_TO_MINE;
        for (int i = 0; i < options.length; i++) {
            RedButton btn = new C01951(options[i], i);
            btn.setRect(Pickaxe.TIME_TO_MINE, pos, 116.0f, MindVision.DURATION);
            add(btn);
            pos += 22.0f;
        }
        resize(WIDTH, (int) pos);
    }

    protected void onSelect(int index) {
    }
}
