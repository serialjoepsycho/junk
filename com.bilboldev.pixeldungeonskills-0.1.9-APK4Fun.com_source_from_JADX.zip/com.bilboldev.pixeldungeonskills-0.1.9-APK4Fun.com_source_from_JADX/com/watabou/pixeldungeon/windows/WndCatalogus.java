package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.potions.Potion;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.scrolls.Scroll;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.ScrollPane;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.Utils;
import java.util.ArrayList;
import java.util.Iterator;

public class WndCatalogus extends WndTabbed {
    private static final int HEIGHT_L = 128;
    private static final int HEIGHT_P = 160;
    private static final int ITEM_HEIGHT = 18;
    private static final int TAB_WIDTH = 50;
    private static final String TXT_POTIONS = "Potions";
    private static final String TXT_SCROLLS = "Scrolls";
    private static final String TXT_TITLE = "Catalogus";
    private static final int WIDTH_L = 128;
    private static final int WIDTH_P = 112;
    private static boolean showPotions;
    private ArrayList<ListItem> items;
    private ScrollPane list;
    private BitmapText txtTitle;

    /* renamed from: com.watabou.pixeldungeon.windows.WndCatalogus.1 */
    class C01691 extends ScrollPane {
        C01691(Component content) {
            super(content);
        }

        public void onClick(float x, float y) {
            int size = WndCatalogus.this.items.size();
            int i = 0;
            while (i < size && !((ListItem) WndCatalogus.this.items.get(i)).onClick(x, y)) {
                i++;
            }
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndCatalogus.2 */
    class C01702 extends LabeledTab {
        C01702(String label) {
            super(label);
        }

        protected void select(boolean value) {
            super.select(value);
            WndCatalogus.showPotions = value;
            WndCatalogus.this.updateList();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndCatalogus.3 */
    class C01713 extends LabeledTab {
        C01713(String label) {
            super(label);
        }

        protected void select(boolean value) {
            super.select(value);
            WndCatalogus.showPotions = !value;
            WndCatalogus.this.updateList();
        }
    }

    private static class ListItem extends Component {
        private boolean identified;
        private Item item;
        private BitmapText label;
        private ItemSprite sprite;

        public ListItem(Class<? extends Item> cl) {
            try {
                this.item = (Item) cl.newInstance();
                boolean isIdentified = this.item.isIdentified();
                this.identified = isIdentified;
                if (isIdentified) {
                    this.sprite.view(this.item.image(), null);
                    this.label.text(this.item.name());
                    return;
                }
                this.sprite.view(ItemSpriteSheet.SMTH, null);
                this.label.text(this.item.trueName());
                this.label.hardlight(13421772);
            } catch (Exception e) {
            }
        }

        protected void createChildren() {
            this.sprite = new ItemSprite();
            add(this.sprite);
            this.label = PixelScene.createText(8.0f);
            add(this.label);
        }

        protected void layout() {
            this.sprite.y = PixelScene.align(this.y + ((this.height - this.sprite.height) / Pickaxe.TIME_TO_MINE));
            this.label.x = this.sprite.x + this.sprite.width;
            this.label.y = PixelScene.align(this.y + ((this.height - this.label.baseLine()) / Pickaxe.TIME_TO_MINE));
        }

        public boolean onClick(float x, float y) {
            if (!this.identified || !inside(x, y)) {
                return false;
            }
            GameScene.show(new WndInfoItem(this.item));
            return true;
        }
    }

    static {
        showPotions = true;
    }

    public WndCatalogus() {
        int i = 0;
        this.items = new ArrayList();
        if (PixelDungeon.landscape()) {
            resize(WIDTH_L, WIDTH_L);
        } else {
            resize(WIDTH_P, HEIGHT_P);
        }
        this.txtTitle = PixelScene.createText(TXT_TITLE, 9.0f);
        this.txtTitle.hardlight(Window.TITLE_COLOR);
        this.txtTitle.measure();
        add(this.txtTitle);
        this.list = new C01691(new Component());
        add(this.list);
        this.list.setRect(0.0f, this.txtTitle.height(), (float) this.width, ((float) this.height) - this.txtTitle.height());
        boolean showPotions = showPotions;
        for (Tab tab : new Tab[]{new C01702(TXT_POTIONS), new C01713(TXT_SCROLLS)}) {
            tab.setSize(50.0f, (float) tabHeight());
            add(tab);
        }
        if (!showPotions) {
            i = 1;
        }
        select(i);
    }

    private void updateList() {
        BitmapText bitmapText = this.txtTitle;
        String str = TXT_TITLE;
        Object[] objArr = new Object[1];
        objArr[0] = showPotions ? TXT_POTIONS : TXT_SCROLLS;
        bitmapText.text(Utils.format(str, objArr));
        this.txtTitle.measure();
        this.txtTitle.x = PixelScene.align(PixelScene.uiCamera, (((float) this.width) - this.txtTitle.width()) / Pickaxe.TIME_TO_MINE);
        this.items.clear();
        Component content = this.list.content();
        content.clear();
        this.list.scrollTo(0.0f, 0.0f);
        float pos = 0.0f;
        Iterator it = (showPotions ? Potion.getKnown() : Scroll.getKnown()).iterator();
        while (it.hasNext()) {
            ListItem item = new ListItem((Class) it.next());
            item.setRect(0.0f, pos, (float) this.width, 18.0f);
            content.add(item);
            this.items.add(item);
            pos += item.height();
        }
        it = (showPotions ? Potion.getUnknown() : Scroll.getUnknown()).iterator();
        while (it.hasNext()) {
            item = new ListItem((Class) it.next());
            item.setRect(0.0f, pos, (float) this.width, 18.0f);
            content.add(item);
            this.items.add(item);
            pos += item.height();
        }
        content.setSize((float) this.width, pos);
    }
}
