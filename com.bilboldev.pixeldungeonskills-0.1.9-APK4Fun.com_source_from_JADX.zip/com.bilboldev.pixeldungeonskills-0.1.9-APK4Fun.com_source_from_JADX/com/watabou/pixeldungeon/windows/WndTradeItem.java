package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.mobs.npcs.Shopkeeper;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.items.EquipableItem;
import com.watabou.pixeldungeon.items.Gold;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.rings.RingOfHaggler.Haggling;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.ui.ItemSlot;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;

public class WndTradeItem extends Window {
    private static final int BTN_HEIGHT = 16;
    private static final float GAP = 2.0f;
    private static final String TXT_BOUGHT = "You've bought %s for %dg";
    private static final String TXT_BUY = "Buy for %dg";
    private static final String TXT_CANCEL = "Never mind";
    private static final String TXT_SALE = "FOR SALE: %s - %dg";
    private static final String TXT_SELL = "Sell for %dg";
    private static final String TXT_SELL_1 = "Sell 1 for %dg";
    private static final String TXT_SELL_ALL = "Sell all for %dg";
    private static final String TXT_SOLD = "You've sold your %s for %dg";
    private static final int WIDTH = 120;
    private WndBag owner;

    /* renamed from: com.watabou.pixeldungeon.windows.WndTradeItem.1 */
    class C02411 extends RedButton {
        final /* synthetic */ Item val$item;

        C02411(String label, Item item) {
            this.val$item = item;
            super(label);
        }

        protected void onClick() {
            WndTradeItem.this.sell(this.val$item);
            WndTradeItem.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndTradeItem.2 */
    class C02422 extends RedButton {
        final /* synthetic */ Item val$item;

        C02422(String label, Item item) {
            this.val$item = item;
            super(label);
        }

        protected void onClick() {
            WndTradeItem.this.sellOne(this.val$item);
            WndTradeItem.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndTradeItem.3 */
    class C02433 extends RedButton {
        final /* synthetic */ Item val$item;

        C02433(String label, Item item) {
            this.val$item = item;
            super(label);
        }

        protected void onClick() {
            WndTradeItem.this.sell(this.val$item);
            WndTradeItem.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndTradeItem.4 */
    class C02444 extends RedButton {
        C02444(String label) {
            super(label);
        }

        protected void onClick() {
            WndTradeItem.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndTradeItem.5 */
    class C02455 extends RedButton {
        final /* synthetic */ Heap val$heap;

        C02455(String label, Heap heap) {
            this.val$heap = heap;
            super(label);
        }

        protected void onClick() {
            WndTradeItem.this.hide();
            WndTradeItem.this.buy(this.val$heap);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndTradeItem.6 */
    class C02466 extends RedButton {
        C02466(String label) {
            super(label);
        }

        protected void onClick() {
            WndTradeItem.this.hide();
        }
    }

    public WndTradeItem(Item item, WndBag owner) {
        this.owner = owner;
        float pos = createDescription(item, false);
        if (item.quantity() == 1) {
            RedButton btnSell = new C02411(Utils.format(TXT_SELL, Integer.valueOf(item.price())), item);
            btnSell.setRect(0.0f, GAP + pos, 120.0f, ShadowBox.SIZE);
            add(btnSell);
            pos = btnSell.bottom();
        } else {
            int priceAll = item.price();
            RedButton btnSell1 = new C02422(Utils.format(TXT_SELL_1, Integer.valueOf(priceAll / item.quantity())), item);
            btnSell1.setRect(0.0f, GAP + pos, 120.0f, ShadowBox.SIZE);
            add(btnSell1);
            RedButton btnSellAll = new C02433(Utils.format(TXT_SELL_ALL, Integer.valueOf(priceAll)), item);
            btnSellAll.setRect(0.0f, btnSell1.bottom() + GAP, 120.0f, ShadowBox.SIZE);
            add(btnSellAll);
            pos = btnSellAll.bottom();
        }
        RedButton btnCancel = new C02444(TXT_CANCEL);
        btnCancel.setRect(0.0f, GAP + pos, 120.0f, ShadowBox.SIZE);
        add(btnCancel);
        resize(WIDTH, (int) btnCancel.bottom());
    }

    public WndTradeItem(Heap heap, boolean canBuy) {
        Item item = heap.peek();
        float pos = createDescription(item, true);
        int price = price(item);
        if (canBuy) {
            RedButton btnBuy = new C02455(Utils.format(TXT_BUY, Integer.valueOf(price)), heap);
            btnBuy.setRect(0.0f, GAP + pos, 120.0f, ShadowBox.SIZE);
            btnBuy.enable(price <= Dungeon.gold);
            add(btnBuy);
            RedButton btnCancel = new C02466(TXT_CANCEL);
            btnCancel.setRect(0.0f, btnBuy.bottom() + GAP, 120.0f, ShadowBox.SIZE);
            add(btnCancel);
            resize(WIDTH, (int) btnCancel.bottom());
            return;
        }
        resize(WIDTH, (int) pos);
    }

    public void hide() {
        super.hide();
        if (this.owner != null) {
            this.owner.hide();
            Shopkeeper.sell();
        }
    }

    private float createDescription(Item item, boolean forSale) {
        String format;
        IconTitle titlebar = new IconTitle();
        titlebar.icon(new ItemSprite(item.image(), item.glowing()));
        if (forSale) {
            format = Utils.format(TXT_SALE, item.toString(), Integer.valueOf(price(item)));
        } else {
            format = Utils.capitalize(item.toString());
        }
        titlebar.label(format);
        titlebar.setRect(0.0f, 0.0f, 120.0f, 0.0f);
        add(titlebar);
        if (item.levelKnown && item.level > 0) {
            titlebar.color(ItemSlot.UPGRADED);
        } else if (item.levelKnown && item.level < 0) {
            titlebar.color(ItemSlot.DEGRADED);
        }
        BitmapTextMultiline info = PixelScene.createMultiline(item.info(), 6.0f);
        info.maxWidth = WIDTH;
        info.measure();
        info.x = titlebar.left();
        info.y = titlebar.bottom() + GAP;
        add(info);
        return info.y + info.height();
    }

    private void sell(Item item) {
        Hero hero = Dungeon.hero;
        if (!item.isEquipped(hero) || ((EquipableItem) item).doUnequip(hero, false)) {
            item.detachAll(hero.belongings.backpack);
            new Gold(item.price()).doPickUp(hero);
            GLog.m1i(TXT_SOLD, item.name(), Integer.valueOf(price));
        }
    }

    private void sellOne(Item item) {
        if (item.quantity() <= 1) {
            sell(item);
            return;
        }
        Hero hero = Dungeon.hero;
        new Gold(item.detach(hero.belongings.backpack).price()).doPickUp(hero);
        GLog.m1i(TXT_SOLD, item.name(), Integer.valueOf(price));
    }

    private int price(Item item) {
        int price = (item.price() * 5) * ((Dungeon.depth / 5) + 1);
        if (Dungeon.hero.buff(Haggling.class) == null || price < 2) {
            return price;
        }
        return price / 2;
    }

    private void buy(Heap heap) {
        Hero hero = Dungeon.hero;
        Item item = heap.pickUp();
        Dungeon.gold -= price(item);
        GLog.m1i(TXT_BOUGHT, item.name(), Integer.valueOf(price));
        if (!item.doPickUp(hero)) {
            Dungeon.level.drop(item, heap.pos).sprite.drop();
        }
    }
}
