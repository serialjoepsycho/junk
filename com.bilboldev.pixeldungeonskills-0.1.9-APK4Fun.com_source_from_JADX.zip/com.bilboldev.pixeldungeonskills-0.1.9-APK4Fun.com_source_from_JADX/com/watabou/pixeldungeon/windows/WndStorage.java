package com.watabou.pixeldungeon.windows;

import android.graphics.RectF;
import com.watabou.gltextures.TextureCache;
import com.watabou.noosa.BitmapText;
import com.watabou.noosa.ColorBlock;
import com.watabou.noosa.Image;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.Storage;
import com.watabou.pixeldungeon.items.Gold;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.bags.Bag;
import com.watabou.pixeldungeon.items.bags.Keyring;
import com.watabou.pixeldungeon.items.bags.ScrollHolder;
import com.watabou.pixeldungeon.items.bags.SeedPouch;
import com.watabou.pixeldungeon.items.bags.WandHolster;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.wands.Wand;
import com.watabou.pixeldungeon.items.weapon.melee.MeleeWeapon;
import com.watabou.pixeldungeon.items.weapon.missiles.Boomerang;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.plants.Plant.Seed;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.ui.Icons;
import com.watabou.pixeldungeon.ui.ItemSlot;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.Utils;
import java.util.Iterator;

public class WndStorage extends WndTabbed {
    protected static final int COLS_L = 6;
    protected static final int COLS_P = 4;
    protected static final int SLOT_MARGIN = 1;
    protected static final int SLOT_SIZE = 28;
    protected static final int TAB_WIDTH = 25;
    protected static final int TITLE_HEIGHT = 12;
    private static Storage lastBag;
    private static Mode lastMode;
    protected int col;
    protected int count;
    private Listener listener;
    private Mode mode;
    private int nCols;
    private int nRows;
    public boolean noDegrade;
    protected int row;
    private String title;

    private class BagTab extends Tab {
        private Bag bag;
        private Image icon;

        public BagTab(Bag bag) {
            super();
            this.bag = bag;
            this.icon = icon();
            add(this.icon);
        }

        protected void select(boolean value) {
            super.select(value);
            this.icon.am = this.selected ? Key.TIME_TO_UNLOCK : 0.6f;
        }

        protected void layout() {
            super.layout();
            this.icon.copy(icon());
            this.icon.x = this.x + ((this.width - this.icon.width) / Pickaxe.TIME_TO_MINE);
            this.icon.y = ((this.y + ((this.height - this.icon.height) / Pickaxe.TIME_TO_MINE)) - Pickaxe.TIME_TO_MINE) - ((float) (this.selected ? 0 : WndStorage.SLOT_MARGIN));
            if (!this.selected && this.icon.y < this.y + GasesImmunity.DURATION) {
                RectF frame = this.icon.frame();
                frame.top += ((this.y + GasesImmunity.DURATION) - this.icon.y) / ((float) this.icon.texture.height);
                this.icon.frame(frame);
                this.icon.y = this.y + GasesImmunity.DURATION;
            }
        }

        private Image icon() {
            if (this.bag instanceof SeedPouch) {
                return Icons.get(Icons.SEED_POUCH);
            }
            if (this.bag instanceof ScrollHolder) {
                return Icons.get(Icons.SCROLL_HOLDER);
            }
            if (this.bag instanceof WandHolster) {
                return Icons.get(Icons.WAND_HOLSTER);
            }
            if (this.bag instanceof Keyring) {
                return Icons.get(Icons.KEYRING);
            }
            return Icons.get(Icons.BACKPACK);
        }
    }

    private class ItemButton extends ItemSlot {
        private static final int EQUIPPED = -10262949;
        private static final int NBARS = 3;
        private static final int NORMAL = -11907772;
        private ColorBlock bg;
        private ColorBlock[] durability;
        private Item item;

        public ItemButton(Item item) {
            super(item);
            this.item = item;
            if (item instanceof Gold) {
                this.bg.visible = false;
            }
            this.height = 28.0f;
            this.width = 28.0f;
        }

        protected void createChildren() {
            this.bg = new ColorBlock(28.0f, 28.0f, NORMAL);
            add(this.bg);
            super.createChildren();
        }

        protected void layout() {
            this.bg.x = this.x;
            this.bg.y = this.y;
            if (WndStorage.this.noDegrade) {
                this.durability = null;
            }
            if (this.durability != null) {
                for (int i = 0; i < NBARS; i += WndStorage.SLOT_MARGIN) {
                    this.durability[i].x = (this.x + Key.TIME_TO_UNLOCK) + ((float) (i * NBARS));
                    this.durability[i].y = (this.y + this.height) - CurareDart.DURATION;
                }
            }
            super.layout();
        }

        public void item(Item item) {
            int i = NORMAL;
            super.item(item);
            if (item != null) {
                ColorBlock colorBlock = this.bg;
                if (item.isEquipped(Dungeon.hero)) {
                    i = EQUIPPED;
                }
                colorBlock.texture(TextureCache.createSolid(i));
                if (item.cursed && item.cursedKnown) {
                    this.bg.ra = 0.2f;
                    this.bg.ga = -0.1f;
                } else if (!item.isIdentified()) {
                    this.bg.ra = 0.1f;
                    this.bg.ba = 0.1f;
                }
                if (item.name() == null) {
                    enable(false);
                    return;
                }
                boolean z = (WndStorage.this.mode == Mode.QUICKSLOT && item.defaultAction != null) || ((WndStorage.this.mode == Mode.FOR_SALE && item.price() > 0 && !(item.isEquipped(Dungeon.hero) && item.cursed)) || ((WndStorage.this.mode == Mode.UPGRADEABLE && item.isUpgradable()) || ((WndStorage.this.mode == Mode.UNIDENTIFED && !item.isIdentified()) || ((WndStorage.this.mode == Mode.WEAPON && ((item instanceof MeleeWeapon) || (item instanceof Boomerang))) || ((WndStorage.this.mode == Mode.ARMOR && (item instanceof Armor)) || ((WndStorage.this.mode == Mode.ENCHANTABLE && ((item instanceof MeleeWeapon) || (item instanceof Boomerang) || (item instanceof Armor))) || ((WndStorage.this.mode == Mode.WAND && (item instanceof Wand)) || ((WndStorage.this.mode == Mode.SEED && (item instanceof Seed)) || WndStorage.this.mode == Mode.ALL))))))));
                enable(z);
                return;
            }
            this.bg.color(NORMAL);
        }

        protected void onTouchDown() {
            this.bg.brightness(Sleep.SWS);
            Sample.INSTANCE.play(Assets.SND_CLICK, 0.7f, 0.7f, 1.2f);
        }

        protected void onTouchUp() {
            this.bg.brightness(Key.TIME_TO_UNLOCK);
        }

        protected void onClick() {
            if (WndStorage.this.listener != null) {
                WndStorage.this.hide();
                WndStorage.this.listener.onSelect(this.item);
                return;
            }
            WndStorage.this.add(new WndItemStorage(WndStorage.this, this.item));
        }

        protected boolean onLongClick() {
            return false;
        }
    }

    public interface Listener {
        void onSelect(Item item);
    }

    public enum Mode {
        ALL,
        UNIDENTIFED,
        UPGRADEABLE,
        QUICKSLOT,
        FOR_SALE,
        WEAPON,
        ARMOR,
        ENCHANTABLE,
        WAND,
        SEED
    }

    private static class Placeholder extends Item {
        public Placeholder(int image) {
            this.name = null;
            this.image = image;
        }

        public boolean isIdentified() {
            return true;
        }

        public boolean isEquipped(Hero hero) {
            return true;
        }
    }

    public WndStorage(Storage bag, Listener listener, Mode mode, String title) {
        boolean z;
        int i = SLOT_MARGIN;
        if (PixelDungeon.itemDeg()) {
            z = false;
        } else {
            z = true;
        }
        this.noDegrade = z;
        this.listener = listener;
        this.mode = mode;
        this.title = title;
        lastMode = mode;
        lastBag = bag;
        this.nCols = PixelDungeon.landscape() ? COLS_L : COLS_P;
        int i2 = 5 / this.nCols;
        if (5 % this.nCols <= 0) {
            i = 0;
        }
        this.nRows = i2 + i;
        int slotsWidth = (this.nCols * SLOT_SIZE) + ((this.nCols - 1) * SLOT_MARGIN);
        int slotsHeight = (this.nRows * SLOT_SIZE) + ((this.nRows - 1) * SLOT_MARGIN);
        if (title == null) {
            title = Utils.capitalize("Storage");
        }
        BitmapText txtTitle = PixelScene.createText(title, 9.0f);
        txtTitle.hardlight(Window.TITLE_COLOR);
        txtTitle.measure();
        txtTitle.x = (float) (((int) (((float) slotsWidth) - txtTitle.width())) / 2);
        txtTitle.y = (float) (((int) (12.0f - txtTitle.height())) / 2);
        add(txtTitle);
        placeItems(bag);
        resize(slotsWidth, slotsHeight + TITLE_HEIGHT);
        Storage stuff = Dungeon.hero.storage;
    }

    protected void placeItems(Storage container) {
        boolean backpack;
        if (container == Dungeon.hero.storage) {
            backpack = true;
        } else {
            backpack = false;
        }
        if (!backpack) {
            this.count = this.nCols;
            this.col = 0;
            this.row = SLOT_MARGIN;
        }
        Iterator it = container.backpack.items.iterator();
        while (it.hasNext()) {
            placeItem((Item) it.next());
        }
        while (true) {
            if (this.count - (backpack ? 0 : this.nCols) < 5) {
                placeItem(null);
            } else {
                return;
            }
        }
    }

    protected void placeItem(Item item) {
        add(new ItemButton(item).setPos((float) (this.col * 29), (float) ((this.row * 29) + TITLE_HEIGHT)));
        int i = this.col + SLOT_MARGIN;
        this.col = i;
        if (i >= this.nCols) {
            this.col = 0;
            this.row += SLOT_MARGIN;
        }
        this.count += SLOT_MARGIN;
    }

    public void onMenuPressed() {
        if (this.listener == null) {
            hide();
        }
    }

    public void onBackPressed() {
        if (this.listener != null) {
            this.listener.onSelect(null);
        }
        super.onBackPressed();
    }

    protected void onClick(Tab tab) {
        hide();
    }

    protected int tabHeight() {
        return 20;
    }
}
