package com.watabou.pixeldungeon.windows;

import android.os.Build.VERSION;
import com.watabou.noosa.Camera;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.ui.CheckBox;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Toolbar;
import com.watabou.pixeldungeon.ui.Window;

public class WndSettings extends Window {
    private static final int BTN_HEIGHT = 20;
    private static final int GAP = 2;
    private static final String TXT_BRIGHTNESS = "Brightness";
    private static final String TXT_IMMERSIVE = "Immersive mode";
    private static final String TXT_MUSIC = "Music";
    private static final String TXT_QUICKSLOT = "Second quickslot";
    private static final String TXT_SCALE_UP = "Scale up UI";
    private static final String TXT_SOUND = "Sound FX";
    private static final String TXT_SWITCH_LAND = "Switch to landscape";
    private static final String TXT_SWITCH_PORT = "Switch to portrait";
    private static final String TXT_ZOOM_DEFAULT = "Default Zoom";
    private static final String TXT_ZOOM_IN = "+";
    private static final String TXT_ZOOM_OUT = "-";
    private static final int WIDTH = 112;
    private RedButton btnZoomIn;
    private RedButton btnZoomOut;

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.10 */
    class AnonymousClass10 extends CheckBox {
        AnonymousClass10(String label) {
            super(label);
        }

        protected void onClick() {
            super.onClick();
            PixelDungeon.brightness(checked());
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.11 */
    class AnonymousClass11 extends CheckBox {
        AnonymousClass11(String label) {
            super(label);
        }

        protected void onClick() {
            super.onClick();
            PixelDungeon.secondSlot(checked());
            Toolbar.secondQuickslot(checked());
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.12 */
    class AnonymousClass12 extends RedButton {
        AnonymousClass12(String label) {
            super(label);
        }

        protected void onClick() {
            PixelDungeon.landscape(!PixelDungeon.landscape());
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.1 */
    class C02111 extends RedButton {
        C02111(String label) {
            super(label);
        }

        protected void onClick() {
            WndSettings.this.zoom(Camera.main.zoom - Key.TIME_TO_UNLOCK);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.2 */
    class C02122 extends RedButton {
        C02122(String label) {
            super(label);
        }

        protected void onClick() {
            WndSettings.this.zoom(Camera.main.zoom + Key.TIME_TO_UNLOCK);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.3 */
    class C02133 extends RedButton {
        C02133(String label) {
            super(label);
        }

        protected void onClick() {
            WndSettings.this.zoom(PixelScene.defaultZoom);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.4 */
    class C02144 extends CheckBox {
        C02144(String label) {
            super(label);
        }

        protected void onClick() {
            super.onClick();
            PixelDungeon.scaleUp(checked());
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.5 */
    class C02155 extends CheckBox {
        C02155(String label) {
            super(label);
        }

        protected void onClick() {
            super.onClick();
            PixelDungeon.immerse(checked());
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.6 */
    class C02166 extends CheckBox {
        C02166(String label) {
            super(label);
        }

        protected void onClick() {
            super.onClick();
            PixelDungeon.music(checked());
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.7 */
    class C02177 extends CheckBox {
        C02177(String label) {
            super(label);
        }

        protected void onClick() {
            super.onClick();
            PixelDungeon.soundFx(checked());
            Sample.INSTANCE.play(Assets.SND_CLICK);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.8 */
    class C02188 extends CheckBox {
        C02188(String label) {
            super(label);
        }

        protected void onClick() {
            super.onClick();
            PixelDungeon.fixedDay(checked());
            Sample.INSTANCE.play(Assets.SND_CLICK);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndSettings.9 */
    class C02199 extends CheckBox {
        C02199(String label) {
            super(label);
        }

        protected void onClick() {
            super.onClick();
            PixelDungeon.itemDeg(checked());
            Sample.INSTANCE.play(Assets.SND_CLICK);
        }
    }

    public WndSettings(boolean inGame) {
        CheckBox btnImmersive = null;
        if (inGame) {
            this.btnZoomOut = new C02111(TXT_ZOOM_OUT);
            add(this.btnZoomOut.setRect(0.0f, 0.0f, (float) BTN_HEIGHT, MindVision.DURATION));
            this.btnZoomIn = new C02122(TXT_ZOOM_IN);
            add(this.btnZoomIn.setRect((float) 92, 0.0f, (float) BTN_HEIGHT, MindVision.DURATION));
            add(new C02133(TXT_ZOOM_DEFAULT).setRect(this.btnZoomOut.right(), 0.0f, (112.0f - this.btnZoomIn.width()) - this.btnZoomOut.width(), MindVision.DURATION));
            updateEnabled();
        } else {
            CheckBox btnScaleUp = new C02144(TXT_SCALE_UP);
            btnScaleUp.setRect(0.0f, 0.0f, 112.0f, MindVision.DURATION);
            btnScaleUp.checked(PixelDungeon.scaleUp());
            add(btnScaleUp);
            btnImmersive = new C02155(TXT_IMMERSIVE);
            btnImmersive.setRect(0.0f, btnScaleUp.bottom() + Pickaxe.TIME_TO_MINE, 112.0f, MindVision.DURATION);
            btnImmersive.checked(PixelDungeon.immersed());
            btnImmersive.enable(VERSION.SDK_INT >= 19);
            add(btnImmersive);
        }
        CheckBox btnMusic = new C02166(TXT_MUSIC);
        btnMusic.setRect(0.0f, (btnImmersive != null ? btnImmersive.bottom() : MindVision.DURATION) + Pickaxe.TIME_TO_MINE, 112.0f, MindVision.DURATION);
        btnMusic.checked(PixelDungeon.music());
        add(btnMusic);
        CheckBox btnSound = new C02177(TXT_SOUND);
        btnSound.setRect(0.0f, btnMusic.bottom() + Pickaxe.TIME_TO_MINE, 112.0f, MindVision.DURATION);
        btnSound.checked(PixelDungeon.soundFx());
        add(btnSound);
        CheckBox btnDay = new C02188("Always Day");
        btnDay.setRect(0.0f, btnSound.bottom() + Pickaxe.TIME_TO_MINE, 112.0f, MindVision.DURATION);
        btnDay.checked(PixelDungeon.fixedDay());
        add(btnDay);
        if (inGame) {
            CheckBox btnDeg = new C02199("Item Degradation");
            btnDeg.setRect(0.0f, btnDay.bottom() + Pickaxe.TIME_TO_MINE, 112.0f, MindVision.DURATION);
            btnDeg.checked(PixelDungeon.itemDeg());
            add(btnDeg);
            CheckBox btnBrightness = new AnonymousClass10(TXT_BRIGHTNESS);
            btnBrightness.setRect(0.0f, btnDeg.bottom() + Pickaxe.TIME_TO_MINE, 112.0f, MindVision.DURATION);
            btnBrightness.checked(PixelDungeon.brightness());
            add(btnBrightness);
            CheckBox btnQuickslot = new AnonymousClass11(TXT_QUICKSLOT);
            btnQuickslot.setRect(0.0f, btnBrightness.bottom() + Pickaxe.TIME_TO_MINE, 112.0f, MindVision.DURATION);
            btnQuickslot.checked(PixelDungeon.secondSlot());
            Toolbar.secondQuickslot(PixelDungeon.secondSlot());
            add(btnQuickslot);
            resize(WIDTH, (int) btnQuickslot.bottom());
            return;
        }
        RedButton btnOrientation = new AnonymousClass12(orientationText());
        btnOrientation.setRect(0.0f, btnSound.bottom() + Pickaxe.TIME_TO_MINE, 112.0f, MindVision.DURATION);
        add(btnOrientation);
        resize(WIDTH, (int) btnOrientation.bottom());
    }

    private void zoom(float value) {
        Camera.main.zoom(value);
        PixelDungeon.zoom((int) (value - PixelScene.defaultZoom));
        updateEnabled();
    }

    private void updateEnabled() {
        boolean z;
        boolean z2 = true;
        float zoom = Camera.main.zoom;
        RedButton redButton = this.btnZoomIn;
        if (zoom < PixelScene.maxZoom) {
            z = true;
        } else {
            z = false;
        }
        redButton.enable(z);
        RedButton redButton2 = this.btnZoomOut;
        if (zoom <= PixelScene.minZoom) {
            z2 = false;
        }
        redButton2.enable(z2);
    }

    private String orientationText() {
        return PixelDungeon.landscape() ? TXT_SWITCH_PORT : TXT_SWITCH_LAND;
    }
}
