package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Heap.Type;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.ui.ItemSlot;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.Utils;

public class WndInfoItem extends Window {
    private static final float GAP = 2.0f;
    private static final String TXT_CHEST = "Chest";
    private static final String TXT_CRYSTAL_CHEST = "Crystal chest";
    private static final String TXT_INSIDE = "You can see %s inside, but to open the chest you need a golden key.";
    private static final String TXT_LOCKED_CHEST = "Locked chest";
    private static final String TXT_NEED_KEY = "You won't know what's inside until you open it! But to open it you need a golden key.";
    private static final String TXT_OWNER = "This ancient tomb may contain something useful, but its owner will most certainly object to checking.";
    private static final String TXT_REMAINS = "This is all that's left from one of your predecessors. Maybe it's worth checking for any valuables.";
    private static final String TXT_SKELETON = "Skeletal remains";
    private static final String TXT_TOMB = "Tomb";
    private static final String TXT_WONT_KNOW = "You won't know what's inside until you open it!";
    private static final int WIDTH = 120;

    public WndInfoItem(Heap heap) {
        if (heap.type == Type.HEAP || heap.type == Type.FOR_SALE) {
            Item item = heap.peek();
            int color = Window.TITLE_COLOR;
            if (item.levelKnown && item.level > 0) {
                color = ItemSlot.UPGRADED;
            } else if (item.levelKnown && item.level < 0) {
                color = ItemSlot.DEGRADED;
            }
            fillFields(item.image(), item.glowing(), color, item.toString(), item.info());
            return;
        }
        String title;
        String info;
        if (heap.type == Type.CHEST || heap.type == Type.MIMIC) {
            title = TXT_CHEST;
            info = TXT_WONT_KNOW;
        } else if (heap.type == Type.TOMB) {
            title = TXT_TOMB;
            info = TXT_OWNER;
        } else if (heap.type == Type.SKELETON) {
            title = TXT_SKELETON;
            info = TXT_REMAINS;
        } else if (heap.type == Type.CRYSTAL_CHEST) {
            title = TXT_CRYSTAL_CHEST;
            info = Utils.format(TXT_INSIDE, Utils.indefinite(heap.peek().name()));
        } else {
            title = TXT_LOCKED_CHEST;
            info = TXT_NEED_KEY;
        }
        fillFields(heap.image(), heap.glowing(), Window.TITLE_COLOR, title, info);
    }

    public WndInfoItem(Item item) {
        int color = Window.TITLE_COLOR;
        if (item.levelKnown && item.level > 0) {
            color = ItemSlot.UPGRADED;
        } else if (item.levelKnown && item.level < 0) {
            color = ItemSlot.DEGRADED;
        }
        fillFields(item.image(), item.glowing(), color, item.toString(), item.info());
    }

    private void fillFields(int image, Glowing glowing, int titleColor, String title, String info) {
        IconTitle titlebar = new IconTitle();
        titlebar.icon(new ItemSprite(image, glowing));
        titlebar.label(Utils.capitalize(title), titleColor);
        titlebar.setRect(0.0f, 0.0f, 120.0f, 0.0f);
        add(titlebar);
        BitmapTextMultiline txtInfo = PixelScene.createMultiline(info, 6.0f);
        txtInfo.maxWidth = WIDTH;
        txtInfo.measure();
        txtInfo.x = titlebar.left();
        txtInfo.y = titlebar.bottom() + GAP;
        add(txtInfo);
        resize(WIDTH, (int) (txtInfo.y + txtInfo.height()));
    }
}
