package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Image;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Journal;
import com.watabou.pixeldungeon.Journal.Feature;
import com.watabou.pixeldungeon.Journal.Record;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.ui.Icons;
import com.watabou.pixeldungeon.ui.ScrollPane;
import com.watabou.pixeldungeon.ui.Window;
import java.util.Collections;
import java.util.Iterator;

public class WndJournal extends Window {
    private static final int HEIGHT_L = 144;
    private static final int HEIGHT_P = 160;
    private static final int ITEM_HEIGHT = 18;
    private static final String TXT_TITLE = "Journal";
    private static final int WIDTH = 112;
    private ScrollPane list;
    private BitmapText txtTitle;

    private static class ListItem extends Component {
        private BitmapText depth;
        private BitmapText feature;
        private Image icon;

        public ListItem(Feature f, int d) {
            this.feature.text(f.desc);
            this.feature.measure();
            this.depth.text(Integer.toString(d));
            this.depth.measure();
            if (d == Dungeon.depth) {
                this.feature.hardlight(Window.TITLE_COLOR);
                this.depth.hardlight(Window.TITLE_COLOR);
            }
        }

        protected void createChildren() {
            this.feature = PixelScene.createText(9.0f);
            add(this.feature);
            this.depth = new BitmapText(PixelScene.font1x);
            add(this.depth);
            this.icon = Icons.get(Icons.DEPTH);
            add(this.icon);
        }

        protected void layout() {
            this.icon.x = this.width - this.icon.width;
            this.depth.x = (this.icon.x - Key.TIME_TO_UNLOCK) - this.depth.width();
            this.depth.y = PixelScene.align(this.y + ((this.height - this.depth.height()) / Pickaxe.TIME_TO_MINE));
            this.icon.y = this.depth.y - Key.TIME_TO_UNLOCK;
            this.feature.y = PixelScene.align((this.depth.y + this.depth.baseLine()) - this.feature.baseLine());
        }
    }

    public WndJournal() {
        resize(WIDTH, PixelDungeon.landscape() ? HEIGHT_L : HEIGHT_P);
        this.txtTitle = PixelScene.createText(TXT_TITLE, 9.0f);
        this.txtTitle.hardlight(Window.TITLE_COLOR);
        this.txtTitle.measure();
        this.txtTitle.x = PixelScene.align(PixelScene.uiCamera, (112.0f - this.txtTitle.width()) / Pickaxe.TIME_TO_MINE);
        add(this.txtTitle);
        Component content = new Component();
        Collections.sort(Journal.records);
        float pos = 0.0f;
        Iterator it = Journal.records.iterator();
        while (it.hasNext()) {
            Record rec = (Record) it.next();
            ListItem item = new ListItem(rec.feature, rec.depth);
            item.setRect(0.0f, pos, 112.0f, 18.0f);
            content.add(item);
            pos += item.height();
        }
        content.setSize(112.0f, pos);
        this.list = new ScrollPane(content);
        add(this.list);
        this.list.setRect(0.0f, this.txtTitle.height(), 112.0f, ((float) this.height) - this.txtTitle.height());
    }
}
