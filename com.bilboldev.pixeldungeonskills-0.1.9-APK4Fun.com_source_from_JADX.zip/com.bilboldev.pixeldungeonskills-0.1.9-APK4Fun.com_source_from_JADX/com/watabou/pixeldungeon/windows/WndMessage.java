package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.ui.Window;

public class WndMessage extends Window {
    private static final int MARGIN = 4;
    private static final int WIDTH_L = 144;
    private static final int WIDTH_P = 120;

    public WndMessage(String text) {
        BitmapTextMultiline info = PixelScene.createMultiline(text, 6.0f);
        info.maxWidth = (PixelDungeon.landscape() ? WIDTH_L : WIDTH_P) - 8;
        info.measure();
        info.y = 4.0f;
        info.x = 4.0f;
        add(info);
        resize(((int) info.width()) + 8, ((int) info.height()) + 8);
    }
}
