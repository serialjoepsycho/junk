package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.Image;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.ui.HealthBar;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.Utils;

public class IconTitle extends Component {
    private static final float FONT_SIZE = 9.0f;
    private static final float GAP = 2.0f;
    protected HealthBar health;
    private float healthLvl;
    protected Image imIcon;
    protected BitmapTextMultiline tfLabel;

    public IconTitle() {
        this.healthLvl = Float.NaN;
    }

    public IconTitle(Item item) {
        this(new ItemSprite(item.image(), item.glowing()), Utils.capitalize(item.toString()));
    }

    public IconTitle(Image icon, String label) {
        this.healthLvl = Float.NaN;
        icon(icon);
        label(label);
    }

    protected void createChildren() {
        this.imIcon = new Image();
        add(this.imIcon);
        this.tfLabel = PixelScene.createMultiline(FONT_SIZE);
        this.tfLabel.hardlight(Window.TITLE_COLOR);
        add(this.tfLabel);
        this.health = new HealthBar();
        add(this.health);
    }

    protected void layout() {
        this.health.visible = !Float.isNaN(this.healthLvl);
        this.imIcon.x = this.x;
        this.imIcon.y = this.y;
        this.tfLabel.x = PixelScene.align(PixelScene.uiCamera, (this.imIcon.x + this.imIcon.width()) + GAP);
        this.tfLabel.maxWidth = (int) (this.width - this.tfLabel.x);
        this.tfLabel.measure();
        this.tfLabel.y = PixelScene.align(PixelScene.uiCamera, this.imIcon.height > this.tfLabel.height() ? this.imIcon.y + ((this.imIcon.height() - this.tfLabel.baseLine()) / GAP) : this.imIcon.y);
        if (this.health.visible) {
            this.health.setRect(this.tfLabel.x, Math.max(this.tfLabel.y + this.tfLabel.height(), (this.imIcon.y + this.imIcon.height()) - this.health.height()), (float) this.tfLabel.maxWidth, 0.0f);
            this.height = this.health.bottom();
            return;
        }
        this.height = Math.max(this.imIcon.y + this.imIcon.height(), this.tfLabel.y + this.tfLabel.height());
    }

    public void icon(Image icon) {
        remove(this.imIcon);
        this.imIcon = icon;
        add(icon);
    }

    public void label(String label) {
        this.tfLabel.text(label);
    }

    public void label(String label, int color) {
        this.tfLabel.text(label);
        this.tfLabel.hardlight(color);
    }

    public void color(int color) {
        this.tfLabel.hardlight(color);
    }

    public void health(float value) {
        HealthBar healthBar = this.health;
        this.healthLvl = value;
        healthBar.level(value);
        layout();
    }
}
