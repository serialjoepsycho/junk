package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.NinePatch;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Chrome;
import com.watabou.pixeldungeon.Chrome.Type;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.mobs.npcs.Blacksmith;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.ui.ItemSlot;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndBag.Listener;
import com.watabou.pixeldungeon.windows.WndBag.Mode;

public class WndBlacksmith extends Window {
    private static final float BTN_GAP = 10.0f;
    private static final int BTN_SIZE = 36;
    private static final float GAP = 2.0f;
    private static final String TXT_PROMPT = "Ok, a deal is a deal, dat's what I can do for you: I can reforge 2 items and turn them into one of a better quality.";
    private static final String TXT_REFORGE = "Reforge them";
    private static final String TXT_SELECT = "Select an item to reforge";
    private static final int WIDTH = 116;
    private ItemButton btnItem1;
    private ItemButton btnItem2;
    private ItemButton btnPressed;
    private RedButton btnReforge;
    protected Listener itemSelector;

    public static class ItemButton extends Component {
        protected NinePatch bg;
        public Item item;
        protected ItemSlot slot;

        /* renamed from: com.watabou.pixeldungeon.windows.WndBlacksmith.ItemButton.1 */
        class C01681 extends ItemSlot {
            C01681() {
            }

            protected void onTouchDown() {
                ItemButton.this.bg.brightness(1.2f);
                Sample.INSTANCE.play(Assets.SND_CLICK);
            }

            protected void onTouchUp() {
                ItemButton.this.bg.resetColor();
            }

            protected void onClick() {
                ItemButton.this.onClick();
            }
        }

        public ItemButton() {
            this.item = null;
        }

        protected void createChildren() {
            super.createChildren();
            this.bg = Chrome.get(Type.BUTTON);
            add(this.bg);
            this.slot = new C01681();
            add(this.slot);
        }

        protected void onClick() {
        }

        protected void layout() {
            super.layout();
            this.bg.x = this.x;
            this.bg.y = this.y;
            this.bg.size(this.width, this.height);
            this.slot.setRect(this.x + WndBlacksmith.GAP, this.y + WndBlacksmith.GAP, this.width - 4.0f, this.height - 4.0f);
        }

        public void item(Item item) {
            ItemSlot itemSlot = this.slot;
            this.item = item;
            itemSlot.item(item);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndBlacksmith.1 */
    class C01641 extends ItemButton {
        C01641() {
        }

        protected void onClick() {
            WndBlacksmith.this.btnPressed = WndBlacksmith.this.btnItem1;
            GameScene.selectItem(WndBlacksmith.this.itemSelector, Mode.UPGRADEABLE, WndBlacksmith.TXT_SELECT);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndBlacksmith.2 */
    class C01652 extends ItemButton {
        C01652() {
        }

        protected void onClick() {
            WndBlacksmith.this.btnPressed = WndBlacksmith.this.btnItem2;
            GameScene.selectItem(WndBlacksmith.this.itemSelector, Mode.UPGRADEABLE, WndBlacksmith.TXT_SELECT);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndBlacksmith.3 */
    class C01663 extends RedButton {
        C01663(String label) {
            super(label);
        }

        protected void onClick() {
            Blacksmith.upgrade(WndBlacksmith.this.btnItem1.item, WndBlacksmith.this.btnItem2.item);
            WndBlacksmith.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndBlacksmith.4 */
    class C01674 implements Listener {
        C01674() {
        }

        public void onSelect(Item item) {
            if (item != null) {
                WndBlacksmith.this.btnPressed.item(item);
                if (WndBlacksmith.this.btnItem1.item != null && WndBlacksmith.this.btnItem2.item != null) {
                    String result = Blacksmith.verify(WndBlacksmith.this.btnItem1.item, WndBlacksmith.this.btnItem2.item);
                    if (result != null) {
                        GameScene.show(new WndMessage(result));
                        WndBlacksmith.this.btnReforge.enable(false);
                        return;
                    }
                    WndBlacksmith.this.btnReforge.enable(true);
                }
            }
        }
    }

    public WndBlacksmith(Blacksmith troll, Hero hero) {
        this.itemSelector = new C01674();
        IconTitle titlebar = new IconTitle();
        titlebar.icon(troll.sprite());
        titlebar.label(Utils.capitalize(troll.name));
        titlebar.setRect(0.0f, 0.0f, 116.0f, 0.0f);
        add(titlebar);
        BitmapTextMultiline message = PixelScene.createMultiline(TXT_PROMPT, 6.0f);
        message.maxWidth = WIDTH;
        message.measure();
        message.y = titlebar.bottom() + GAP;
        add(message);
        this.btnItem1 = new C01641();
        this.btnItem1.setRect(17.0f, (message.y + message.height()) + BTN_GAP, 36.0f, 36.0f);
        add(this.btnItem1);
        this.btnItem2 = new C01652();
        this.btnItem2.setRect(this.btnItem1.right() + BTN_GAP, this.btnItem1.top(), 36.0f, 36.0f);
        add(this.btnItem2);
        this.btnReforge = new C01663(TXT_REFORGE);
        this.btnReforge.enable(false);
        this.btnReforge.setRect(0.0f, this.btnItem1.bottom() + BTN_GAP, 116.0f, MindVision.DURATION);
        add(this.btnReforge);
        resize(WIDTH, (int) this.btnReforge.bottom());
    }
}
