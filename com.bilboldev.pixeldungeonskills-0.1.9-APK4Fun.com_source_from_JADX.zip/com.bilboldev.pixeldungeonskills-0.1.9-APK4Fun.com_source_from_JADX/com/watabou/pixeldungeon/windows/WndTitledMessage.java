package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.Image;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.ui.Window;

public class WndTitledMessage extends Window {
    private static final int GAP = 2;
    private static final int WIDTH_L = 144;
    private static final int WIDTH_P = 120;
    private BitmapTextMultiline highlighted;
    private BitmapTextMultiline normal;

    public WndTitledMessage(Image icon, String title, String message) {
        this(new IconTitle(icon, title), message);
    }

    public WndTitledMessage(Component titlebar, String message) {
        int width = PixelDungeon.landscape() ? WIDTH_L : WIDTH_P;
        titlebar.setRect(0.0f, 0.0f, (float) width, 0.0f);
        add(titlebar);
        Highlighter hl = new Highlighter(message);
        this.normal = PixelScene.createMultiline(hl.text, 6.0f);
        this.normal.maxWidth = width;
        this.normal.measure();
        this.normal.x = titlebar.left();
        this.normal.y = titlebar.bottom() + Pickaxe.TIME_TO_MINE;
        add(this.normal);
        if (hl.isHighlighted()) {
            this.normal.mask = hl.inverted();
            this.highlighted = PixelScene.createMultiline(hl.text, 6.0f);
            this.highlighted.maxWidth = this.normal.maxWidth;
            this.highlighted.measure();
            this.highlighted.x = this.normal.x;
            this.highlighted.y = this.normal.y;
            add(this.highlighted);
            this.highlighted.mask = hl.mask;
            this.highlighted.hardlight(Window.TITLE_COLOR);
        }
        resize(width, (int) (this.normal.y + this.normal.height()));
    }
}
