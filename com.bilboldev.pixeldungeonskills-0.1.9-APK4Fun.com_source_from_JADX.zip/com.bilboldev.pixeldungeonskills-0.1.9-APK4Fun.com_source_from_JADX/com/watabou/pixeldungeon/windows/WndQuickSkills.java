package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.tweeners.AlphaTweener;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.actors.mobs.npcs.Crab;
import com.watabou.pixeldungeon.actors.mobs.npcs.MirrorImage;
import com.watabou.pixeldungeon.actors.mobs.npcs.Rat;
import com.watabou.pixeldungeon.actors.mobs.npcs.Skeleton;
import com.watabou.pixeldungeon.effects.Pushing;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.watabou.pixeldungeon.items.wands.WandOfBlink;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Collection;

public class WndQuickSkills extends WndTabbed {
    float GAP;
    Hero hero;
    float pos;

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.10 */
    class AnonymousClass10 extends RedButton {
        AnonymousClass10(String label) {
            super(label);
        }

        protected void onClick() {
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.11 */
    class AnonymousClass11 extends RedButton {
        AnonymousClass11(String label) {
            super(label);
        }

        protected void onClick() {
            if (WndQuickSkills.this.hero.isStarving()) {
                GLog.m2n("You are too hungry to use Frost Shot", new Object[0]);
            } else if (WndQuickSkills.this.hero.MP > 16) {
                Hero hero = WndQuickSkills.this.hero;
                hero.MP -= 16;
                GLog.m3p("Your next ranged attack will freeze your target", new Object[0]);
                WndQuickSkills.this.hero.skillSecondActive = true;
                WndQuickSkills.this.hero.skillSecondCooldown = 30;
            } else {
                GLog.m1i("Not enough mana!", new Object[0]);
            }
            WndQuickSkills.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.12 */
    class AnonymousClass12 extends RedButton {
        AnonymousClass12(String label) {
            super(label);
        }

        protected void onClick() {
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.13 */
    class AnonymousClass13 extends RedButton {
        AnonymousClass13(String label) {
            super(label);
        }

        protected void onClick() {
            if (WndQuickSkills.this.hero.isStarving()) {
                GLog.m2n("You are too hungry to cast Shadow Clone", new Object[0]);
            } else if (WndQuickSkills.this.hero.MP > 18) {
                Hero hero = WndQuickSkills.this.hero;
                hero.MP -= 18;
                GLog.m3p("You cast Shadow Clone", new Object[0]);
                ArrayList<Integer> respawnPoints = new ArrayList();
                for (int i : Level.NEIGHBOURS8) {
                    int p = WndQuickSkills.this.hero.pos + i;
                    if (Actor.findChar(p) == null && (Level.passable[p] || Level.avoid[p])) {
                        respawnPoints.add(Integer.valueOf(p));
                    }
                }
                for (int nImages = 1; nImages > 0 && respawnPoints.size() > 0; nImages--) {
                    int index = Random.index(respawnPoints);
                    Mob mob = new MirrorImage();
                    mob.duplicate(WndQuickSkills.this.hero);
                    GameScene.add(mob);
                    WandOfBlink.appear(mob, ((Integer) respawnPoints.get(index)).intValue());
                    respawnPoints.remove(index);
                }
                WndQuickSkills.this.hero.skillFirstCooldown = 65;
            } else {
                GLog.m1i("Not enough mana!", new Object[0]);
            }
            WndQuickSkills.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.14 */
    class AnonymousClass14 extends RedButton {
        AnonymousClass14(String label) {
            super(label);
        }

        protected void onClick() {
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.15 */
    class AnonymousClass15 extends RedButton {
        AnonymousClass15(String label) {
            super(label);
        }

        protected void onClick() {
            if (WndQuickSkills.this.hero.isStarving()) {
                GLog.m2n("You are too hungry to disable a trap", new Object[0]);
            } else if (WndQuickSkills.this.hero.MP > 4) {
                Hero hero = WndQuickSkills.this.hero;
                hero.MP -= 4;
                GLog.m3p("You will disable the next trap you walk on", new Object[0]);
                WndQuickSkills.this.hero.skillSecondActive = true;
                WndQuickSkills.this.hero.skillSecondCooldown = 10;
            } else {
                GLog.m1i("Not enough mana!", new Object[0]);
            }
            WndQuickSkills.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.16 */
    class AnonymousClass16 extends RedButton {
        AnonymousClass16(String label) {
            super(label);
        }

        protected void onClick() {
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.1 */
    class C01961 extends RedButton {
        C01961(String label) {
            super(label);
        }

        protected void onClick() {
            if (WndQuickSkills.this.hero.isStarving()) {
                GLog.m1i("You are too hungry to cast Random Teleport", new Object[0]);
            } else if (WndQuickSkills.this.hero.MP > 8) {
                GLog.m3p("You cast Random Teleport", new Object[0]);
                ScrollOfTeleportation.teleportHero(WndQuickSkills.this.hero);
                WndQuickSkills.this.hero.skillFirstCooldown = 15;
                Hero hero = WndQuickSkills.this.hero;
                hero.MP -= 8;
            } else {
                GLog.m1i("Not enough mana!", new Object[0]);
            }
            WndQuickSkills.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.2 */
    class C01972 extends RedButton {
        C01972(String label) {
            super(label);
        }

        protected void onClick() {
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.3 */
    class C01983 extends RedButton {
        C01983(String label) {
            super(label);
        }

        protected void onClick() {
            if (WndQuickSkills.this.hero.isStarving()) {
                GLog.m1i("You are too hungry to summon", new Object[0]);
            } else if (WndQuickSkills.this.hero.MP > 15) {
                WndQuickSkills.this.hero.skillSecondCooldown = 50;
                int newPos = WndQuickSkills.this.hero.pos;
                if (Actor.findChar(newPos) != null) {
                    Collection candidates = new ArrayList();
                    boolean[] passable = Level.passable;
                    for (int n : Level.NEIGHBOURS4) {
                        int c = WndQuickSkills.this.hero.pos + n;
                        if (passable[c] && Actor.findChar(c) == null) {
                            candidates.add(Integer.valueOf(c));
                        }
                    }
                    newPos = candidates.size() > 0 ? ((Integer) Random.element(candidates)).intValue() : -1;
                }
                if (newPos != -1) {
                    Hero hero = WndQuickSkills.this.hero;
                    hero.MP -= 15;
                    if (WndQuickSkills.this.hero.skillMeditation < 3) {
                        Mob rat = new Rat();
                        rat.spawn(WndQuickSkills.this.hero.skillMeditation);
                        rat.HP = rat.HT;
                        rat.pos = newPos;
                        GameScene.add(rat);
                        Actor.addDelayed(new Pushing(rat, WndQuickSkills.this.hero.pos, newPos), -1.0f);
                        rat.sprite.alpha(0.0f);
                        rat.sprite.parent.add(new AlphaTweener(rat.sprite, Key.TIME_TO_UNLOCK, 0.15f));
                        GLog.m3p("Rat summoned", new Object[0]);
                    } else if (WndQuickSkills.this.hero.skillMeditation < 6) {
                        Mob crab = new Crab();
                        crab.spawn(WndQuickSkills.this.hero.skillMeditation);
                        crab.HP = crab.HT;
                        crab.pos = newPos;
                        GameScene.add(crab);
                        Actor.addDelayed(new Pushing(crab, WndQuickSkills.this.hero.pos, newPos), -1.0f);
                        crab.sprite.alpha(0.0f);
                        crab.sprite.parent.add(new AlphaTweener(crab.sprite, Key.TIME_TO_UNLOCK, 0.15f));
                        GLog.m3p("Crab summoned", new Object[0]);
                    } else {
                        Mob skel = new Skeleton();
                        skel.spawn(WndQuickSkills.this.hero.skillMeditation);
                        skel.HP = skel.HT;
                        skel.pos = newPos;
                        GameScene.add(skel);
                        Actor.addDelayed(new Pushing(skel, WndQuickSkills.this.hero.pos, newPos), -1.0f);
                        skel.sprite.alpha(0.0f);
                        skel.sprite.parent.add(new AlphaTweener(skel.sprite, Key.TIME_TO_UNLOCK, 0.15f));
                        GLog.m3p("Skeleton summoned", new Object[0]);
                    }
                } else {
                    GLog.m1i("No space to summon", new Object[0]);
                    WndQuickSkills.this.hero.skillSecondCooldown = 0;
                }
            } else {
                GLog.m1i("Not enough mana!", new Object[0]);
            }
            WndQuickSkills.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.4 */
    class C01994 extends RedButton {
        C01994(String label) {
            super(label);
        }

        protected void onClick() {
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.5 */
    class C02005 extends RedButton {
        C02005(String label) {
            super(label);
        }

        protected void onClick() {
            if (WndQuickSkills.this.hero.isStarving()) {
                GLog.m2n("You are too hungry to use Smash", new Object[0]);
            } else if (WndQuickSkills.this.hero.MP > 5) {
                Hero hero = WndQuickSkills.this.hero;
                hero.MP -= 5;
                GLog.m3p("Your next melee attack will do more damage", new Object[0]);
                WndQuickSkills.this.hero.skillFirstActive = true;
                WndQuickSkills.this.hero.skillFirstCooldown = 11;
            } else {
                GLog.m1i("Not enough mana!", new Object[0]);
            }
            WndQuickSkills.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.6 */
    class C02016 extends RedButton {
        C02016(String label) {
            super(label);
        }

        protected void onClick() {
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.7 */
    class C02027 extends RedButton {
        C02027(String label) {
            super(label);
        }

        protected void onClick() {
            if (WndQuickSkills.this.hero.isStarving()) {
                GLog.m2n("You are too hungry to use smite", new Object[0]);
            } else if (WndQuickSkills.this.hero.MP > 11) {
                Hero hero = WndQuickSkills.this.hero;
                hero.MP -= 11;
                GLog.m3p("Your next melee attack will do way more damage but will leave you weak for a small duration", new Object[0]);
                WndQuickSkills.this.hero.skillSecondActive = true;
                WndQuickSkills.this.hero.skillSecondCooldown = 22;
            } else {
                GLog.m1i("Not enough mana!", new Object[0]);
            }
            WndQuickSkills.this.hide();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.8 */
    class C02038 extends RedButton {
        C02038(String label) {
            super(label);
        }

        protected void onClick() {
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndQuickSkills.9 */
    class C02049 extends RedButton {
        C02049(String label) {
            super(label);
        }

        protected void onClick() {
            if (WndQuickSkills.this.hero.isStarving()) {
                GLog.m2n("You are too hungry to use Flame Arrow", new Object[0]);
            } else if (WndQuickSkills.this.hero.MP > 12) {
                Hero hero = WndQuickSkills.this.hero;
                hero.MP -= 12;
                GLog.m3p("Your next ranged attack will burn the target.", new Object[0]);
                WndQuickSkills.this.hero.skillFirstActive = true;
                WndQuickSkills.this.hero.skillFirstCooldown = 20;
            } else {
                GLog.m1i("Not enough mana!", new Object[0]);
            }
            WndQuickSkills.this.hide();
        }
    }

    public WndQuickSkills() {
        this.pos = GasesImmunity.DURATION;
        this.GAP = Pickaxe.TIME_TO_MINE;
        this.hero = Dungeon.hero;
        resize(ItemSpriteSheet.VIAL, 50);
        BitmapText txt;
        RedButton btnSkill;
        BitmapText txt2;
        if (this.hero.heroClass == HeroClass.MAGE) {
            txt = PixelScene.createText("Random Teleport - 8 MP", 9.0f);
            txt.y = this.pos;
            add(txt);
            if (this.hero.skillFirstCooldown == 0) {
                btnSkill = new C01961("Cast");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            } else {
                btnSkill = new C01972("Cool down");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            }
            this.pos += this.GAP;
            this.pos += this.GAP + 25.0f;
            txt2 = PixelScene.createText("Summon - 15 MP", 9.0f);
            txt2.y = this.pos;
            add(txt2);
            if (this.hero.skillSecondCooldown == 0) {
                btnSkill = new C01983("Cast");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            } else {
                btnSkill = new C01994("Cool down");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            }
            this.pos += this.GAP;
        } else if (this.hero.heroClass == HeroClass.WARRIOR) {
            txt = PixelScene.createText("Smash - 5 MP", 9.0f);
            txt.y = this.pos;
            add(txt);
            if (this.hero.skillFirstCooldown == 0) {
                btnSkill = new C02005("Use");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            } else {
                btnSkill = new C02016("Cool down");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            }
            this.pos += this.GAP;
            this.pos += this.GAP + 25.0f;
            txt2 = PixelScene.createText("Smite - 11 MP", 9.0f);
            txt2.y = this.pos;
            add(txt2);
            if (this.hero.skillSecondCooldown == 0) {
                btnSkill = new C02027("Use");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            } else {
                btnSkill = new C02038("Cool down");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            }
            this.pos += this.GAP;
        } else if (this.hero.heroClass == HeroClass.HUNTRESS) {
            txt = PixelScene.createText("Flame Arrow - 12 MP", 9.0f);
            txt.y = this.pos;
            add(txt);
            if (this.hero.skillFirstCooldown == 0) {
                btnSkill = new C02049("Use");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            } else {
                btnSkill = new AnonymousClass10("Cool down");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            }
            this.pos += this.GAP;
            this.pos += this.GAP + 25.0f;
            txt2 = PixelScene.createText("Frost Shot - 16 MP", 9.0f);
            txt2.y = this.pos;
            add(txt2);
            if (this.hero.skillSecondCooldown == 0) {
                btnSkill = new AnonymousClass11("Use");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            } else {
                btnSkill = new AnonymousClass12("Cool down");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            }
            this.pos += this.GAP;
        } else if (this.hero.heroClass == HeroClass.ROGUE) {
            txt = PixelScene.createText("Shadow Clone - 18 MP", 9.0f);
            txt.y = this.pos;
            add(txt);
            if (this.hero.skillFirstCooldown == 0) {
                btnSkill = new AnonymousClass13("Cast");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            } else {
                btnSkill = new AnonymousClass14("Cool down");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
            }
            this.pos += this.GAP;
            this.pos += this.GAP + 25.0f;
            txt2 = PixelScene.createText("Disable Trap - 4 MP", 9.0f);
            txt2.y = this.pos;
            add(txt2);
            if (this.hero.skillSecondCooldown == 0) {
                btnSkill = new AnonymousClass15("Use");
                btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
                add(btnSkill);
                return;
            }
            btnSkill = new AnonymousClass16("Cool down");
            btnSkill.setRect(80.0f, this.pos, 40.0f, TomeOfMastery.TIME_TO_READ);
            add(btnSkill);
        }
    }
}
