package com.watabou.pixeldungeon.windows;

import com.watabou.billing.IabHelper.OnIabPurchaseFinishedListener;
import com.watabou.billing.IabResult;
import com.watabou.billing.Purchase;
import com.watabou.noosa.BitmapText;
import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.Game;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;

public class WndDonations extends WndTabbed {
    float GAP;
    Hero hero;
    OnIabPurchaseFinishedListener mPurchaseFinishedListener;
    float pos;

    /* renamed from: com.watabou.pixeldungeon.windows.WndDonations.1 */
    class C01761 extends RedButton {
        C01761(String label) {
            super(label);
        }

        protected void onClick() {
            try {
                Game.mHelper.launchPurchaseFlow(Game.instance, "spd_donation1dollar", 10001, WndDonations.this.mPurchaseFinishedListener, BuildConfig.VERSION_NAME);
            } catch (Exception ex) {
                this.parent.add(new WndDonationsError(ex.getMessage()));
            }
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndDonations.2 */
    class C01772 extends RedButton {
        C01772(String label) {
            super(label);
        }

        protected void onClick() {
            try {
                Game.mHelper.launchPurchaseFlow(Game.instance, "spd_donation3dollar", 10001, WndDonations.this.mPurchaseFinishedListener, BuildConfig.VERSION_NAME);
            } catch (Exception ex) {
                this.parent.add(new WndDonationsError(ex.getMessage()));
            }
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndDonations.3 */
    class C01783 extends RedButton {
        C01783(String label) {
            super(label);
        }

        protected void onClick() {
            try {
                Game.mHelper.launchPurchaseFlow(Game.instance, "spd_donation5dollar", 10001, WndDonations.this.mPurchaseFinishedListener, BuildConfig.VERSION_NAME);
            } catch (Exception ex) {
                this.parent.add(new WndDonationsError(ex.getMessage()));
            }
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndDonations.4 */
    class C01794 implements OnIabPurchaseFinishedListener {
        C01794() {
        }

        public void onIabPurchaseFinished(IabResult result, Purchase purchase) {
            if (result.isFailure()) {
                WndDonations.this.parent.add(new WndDonationsError(result.getMessage()));
            } else if (purchase.getSku().equals("spd_donation1dollar")) {
                WndDonations.this.parent.add(new WndDonationsThanks("No donation is a small donation.\n Thanks :)"));
            } else if (purchase.getSku().equals("spd_donation3dollar")) {
                WndDonations.this.parent.add(new WndDonationsThanks("Thank you for supporting Skillful Pixel Dungeon :o"));
            } else if (purchase.getSku().equals("spd_donation5dollar")) {
                WndDonations.this.parent.add(new WndDonationsThanks("Thank you for the generous donation :O"));
            }
        }
    }

    public WndDonations() {
        this.pos = GasesImmunity.DURATION;
        this.GAP = Pickaxe.TIME_TO_MINE;
        this.hero = Dungeon.hero;
        this.mPurchaseFinishedListener = new C01794();
        resize(ItemSpriteSheet.VIAL, 50);
        BitmapText title = PixelScene.createText("Donations", 9.0f);
        title.hardlight(Window.TITLE_COLOR);
        title.measure();
        add(title);
        this.pos = (title.y + title.height()) + Pickaxe.TIME_TO_MINE;
        BitmapTextMultiline info = PixelScene.createMultiline(6.0f);
        add(info);
        info.text("If you like the game mod, please consider donating to support the developer and graphic designer of Skillful Pixel Dungeon.\nThe donations do not provide any ingame bonuses or features, however those who donate will be stored on google play services. This means that if donation rewards are added in the future, those who donated before will receive them.");
        info.maxWidth = ItemSpriteSheet.VIAL;
        info.measure();
        info.y = this.pos;
        if (Game.mHelper != null) {
            RedButton btnDonate1 = new C01761("Donate 1$     :)");
            btnDonate1.setRect(TomeOfMastery.TIME_TO_READ, (float) ((int) ((info.y + info.height()) + MindVision.DURATION)), 100.0f, TomeOfMastery.TIME_TO_READ);
            add(btnDonate1);
            RedButton btnDonate3 = new C01772("Donate 3$     :o");
            btnDonate3.setRect(TomeOfMastery.TIME_TO_READ, btnDonate1.centerY() + TomeOfMastery.TIME_TO_READ, 100.0f, TomeOfMastery.TIME_TO_READ);
            add(btnDonate3);
            RedButton btnDonate5 = new C01783("Donate 5$     :O");
            btnDonate5.setRect(TomeOfMastery.TIME_TO_READ, btnDonate3.centerY() + TomeOfMastery.TIME_TO_READ, 100.0f, TomeOfMastery.TIME_TO_READ);
            add(btnDonate5);
            resize(ItemSpriteSheet.HONEYPOT, (int) ((btnDonate5.centerY() + btnDonate5.height()) + TomeOfMastery.TIME_TO_READ));
            return;
        }
        info.text("If you like the game mod, please consider donating to support the developer and graphic designer of Skillful Pixel Dungeon.\nThe donations do not provide any ingame bonuses or features, however those who donate will be stored on google play services. This means that if donation rewards are added in the future, those who donated before will receive them.\n\nSomething is wrong... you can't donate :(");
        info.maxWidth = ItemSpriteSheet.VIAL;
        info.measure();
        info.y = this.pos;
        resize(ItemSpriteSheet.HONEYPOT, (int) ((info.y + info.height()) + TomeOfMastery.TIME_TO_READ));
    }
}
