package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.Game;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.InterlevelScene;
import com.watabou.pixeldungeon.scenes.InterlevelScene.Mode;
import com.watabou.pixeldungeon.scenes.RankingsScene;
import com.watabou.pixeldungeon.scenes.TitleScene;
import com.watabou.pixeldungeon.ui.Icons;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;
import java.io.IOException;

public class WndGame extends Window {
    private static final int BTN_HEIGHT = 20;
    private static final int GAP = 2;
    private static final String TXT_CHALLEGES = "Challenges";
    private static final String TXT_EXIT = "Exit Game";
    private static final String TXT_MENU = "Main Menu";
    private static final String TXT_RANKINGS = "Rankings";
    private static final String TXT_RETURN = "Return to Game";
    private static final String TXT_SETTINGS = "Settings";
    private static final String TXT_START = "Start New Game";
    private static final int WIDTH = 120;
    private int pos;

    /* renamed from: com.watabou.pixeldungeon.windows.WndGame.1 */
    class C01801 extends RedButton {
        C01801(String label) {
            super(label);
        }

        protected void onClick() {
            WndGame.this.hide();
            GameScene.show(new WndSettings(true));
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndGame.2 */
    class C01812 extends RedButton {
        C01812(String label) {
            super(label);
        }

        protected void onClick() {
            WndGame.this.hide();
            GameScene.show(new WndChallenges(Dungeon.challenges, false));
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndGame.3 */
    class C01823 extends RedButton {
        C01823(String label) {
            super(label);
        }

        protected void onClick() {
            Dungeon.hero = null;
            PixelDungeon.challenges(Dungeon.challenges);
            InterlevelScene.mode = Mode.DESCEND;
            InterlevelScene.noStory = true;
            Game.switchScene(InterlevelScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndGame.4 */
    class C01834 extends RedButton {
        C01834(String label) {
            super(label);
        }

        protected void onClick() {
            InterlevelScene.mode = Mode.DESCEND;
            Game.switchScene(RankingsScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndGame.5 */
    class C01845 extends RedButton {
        C01845(String label) {
            super(label);
        }

        protected void onClick() {
            try {
                Dungeon.saveAll();
            } catch (IOException e) {
            }
            Game.switchScene(TitleScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndGame.6 */
    class C01856 extends RedButton {
        C01856(String label) {
            super(label);
        }

        protected void onClick() {
            Game.instance.finish();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.windows.WndGame.7 */
    class C01867 extends RedButton {
        C01867(String label) {
            super(label);
        }

        protected void onClick() {
            WndGame.this.hide();
        }
    }

    public WndGame() {
        addButton(new C01801(TXT_SETTINGS));
        if (Dungeon.challenges > 0) {
            addButton(new C01812(TXT_CHALLEGES));
        }
        if (!Dungeon.hero.isAlive()) {
            RedButton btnStart = new C01823(TXT_START);
            addButton(btnStart);
            btnStart.icon(Icons.get(Dungeon.hero.heroClass));
            addButton(new C01834(TXT_RANKINGS));
        }
        addButtons(new C01845(TXT_MENU), new C01856(TXT_EXIT));
        addButton(new C01867(TXT_RETURN));
        resize(WIDTH, this.pos);
    }

    private void addButton(RedButton btn) {
        float f;
        add(btn);
        if (this.pos > 0) {
            int i = this.pos + GAP;
            this.pos = i;
            f = (float) i;
        } else {
            f = 0.0f;
        }
        btn.setRect(0.0f, f, 120.0f, MindVision.DURATION);
        this.pos += BTN_HEIGHT;
    }

    private void addButtons(RedButton btn1, RedButton btn2) {
        float f;
        add(btn1);
        if (this.pos > 0) {
            int i = this.pos + GAP;
            this.pos = i;
            f = (float) i;
        } else {
            f = 0.0f;
        }
        btn1.setRect(0.0f, f, 59.0f, MindVision.DURATION);
        add(btn2);
        btn2.setRect(btn1.right() + Pickaxe.TIME_TO_MINE, btn1.top(), (120.0f - btn1.right()) - Pickaxe.TIME_TO_MINE, MindVision.DURATION);
        this.pos += BTN_HEIGHT;
    }
}
