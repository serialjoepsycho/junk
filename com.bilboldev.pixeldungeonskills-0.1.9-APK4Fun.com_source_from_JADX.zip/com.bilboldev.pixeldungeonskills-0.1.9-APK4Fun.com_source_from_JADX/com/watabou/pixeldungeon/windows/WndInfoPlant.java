package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.pixeldungeon.plants.Plant;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.PlantSprite;
import com.watabou.pixeldungeon.ui.Window;

public class WndInfoPlant extends Window {
    private static final float GAP = 2.0f;
    private static final int WIDTH = 120;

    public WndInfoPlant(Plant plant) {
        IconTitle titlebar = new IconTitle();
        titlebar.icon(new PlantSprite(plant.image));
        titlebar.label(plant.plantName);
        titlebar.setRect(0.0f, 0.0f, 120.0f, 0.0f);
        add(titlebar);
        BitmapTextMultiline info = PixelScene.createMultiline(6.0f);
        add(info);
        info.text(plant.desc());
        info.maxWidth = WIDTH;
        info.measure();
        info.x = titlebar.left();
        info.y = titlebar.bottom() + GAP;
        resize(WIDTH, (int) (info.y + info.height()));
    }
}
