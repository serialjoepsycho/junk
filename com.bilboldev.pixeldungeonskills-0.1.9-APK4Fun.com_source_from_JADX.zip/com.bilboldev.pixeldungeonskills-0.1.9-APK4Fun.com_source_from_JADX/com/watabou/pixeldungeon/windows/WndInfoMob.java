package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.ui.HealthBar;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.Utils;

public class WndInfoMob extends WndTitledMessage {

    private static class MobTitle extends Component {
        private static final int GAP = 2;
        private BuffIndicator buffs;
        private HealthBar health;
        private CharSprite image;
        private BitmapText name;

        public MobTitle(Mob mob) {
            this.name = PixelScene.createText(Utils.capitalize(mob.name), 9.0f);
            this.name.hardlight(Window.TITLE_COLOR);
            this.name.measure();
            add(this.name);
            this.image = mob.sprite();
            add(this.image);
            this.health = new HealthBar();
            this.health.level(((float) mob.HP) / ((float) mob.HT));
            add(this.health);
            this.buffs = new BuffIndicator(mob);
            add(this.buffs);
        }

        protected void layout() {
            this.image.x = 0.0f;
            this.image.y = Math.max(0.0f, ((this.name.height() + Pickaxe.TIME_TO_MINE) + this.health.height()) - this.image.height);
            this.name.x = this.image.width + Pickaxe.TIME_TO_MINE;
            this.name.y = ((this.image.height - this.health.height()) - Pickaxe.TIME_TO_MINE) - this.name.baseLine();
            this.health.setRect(this.image.width + Pickaxe.TIME_TO_MINE, this.image.height - this.health.height(), (this.width - this.image.width) - Pickaxe.TIME_TO_MINE, this.health.height());
            this.buffs.setPos((this.name.x + this.name.width()) + Pickaxe.TIME_TO_MINE, (this.name.y + this.name.baseLine()) - 7.0f);
            this.height = this.health.bottom();
        }
    }

    public WndInfoMob(Mob mob) {
        super(new MobTitle(mob), desc(mob));
    }

    private static String desc(Mob mob) {
        StringBuilder builder = new StringBuilder(mob.description());
        builder.append("\n\n" + mob.state.status() + ".");
        return builder.toString();
    }
}
