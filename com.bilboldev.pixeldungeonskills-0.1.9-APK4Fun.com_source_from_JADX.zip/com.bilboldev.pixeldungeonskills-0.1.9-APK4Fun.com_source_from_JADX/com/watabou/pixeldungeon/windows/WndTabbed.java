package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Game;
import com.watabou.noosa.NinePatch;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Chrome;
import com.watabou.pixeldungeon.Chrome.Type;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.ui.Window;
import java.util.ArrayList;
import java.util.Iterator;

public class WndTabbed extends Window {
    protected Tab selected;
    protected ArrayList<Tab> tabs;

    protected class Tab extends Button {
        protected final int CUT;
        protected NinePatch bg;
        protected boolean selected;

        protected Tab() {
            this.CUT = 5;
        }

        protected void layout() {
            super.layout();
            if (this.bg != null) {
                this.bg.x = this.x;
                this.bg.y = this.y;
                this.bg.size(this.width, this.height);
            }
        }

        protected void select(boolean value) {
            this.selected = value;
            this.active = !value;
            if (this.bg != null) {
                remove(this.bg);
            }
            this.bg = Chrome.get(this.selected ? Type.TAB_SELECTED : Type.TAB_UNSELECTED);
            addToBack(this.bg);
            layout();
        }

        protected void onClick() {
            Sample.INSTANCE.play(Assets.SND_CLICK, 0.7f, 0.7f, 1.2f);
            WndTabbed.this.onClick(this);
        }
    }

    protected class LabeledTab extends Tab {
        private BitmapText btLabel;

        public LabeledTab(String label) {
            super();
            this.btLabel.text(label);
            this.btLabel.measure();
        }

        protected void createChildren() {
            super.createChildren();
            this.btLabel = PixelScene.createText(9.0f);
            add(this.btLabel);
        }

        protected void layout() {
            super.layout();
            this.btLabel.x = PixelScene.align(this.x + ((this.width - this.btLabel.width()) / Pickaxe.TIME_TO_MINE));
            this.btLabel.y = PixelScene.align(this.y + ((this.height - this.btLabel.baseLine()) / Pickaxe.TIME_TO_MINE)) - Key.TIME_TO_UNLOCK;
            if (!this.selected) {
                BitmapText bitmapText = this.btLabel;
                bitmapText.y -= Pickaxe.TIME_TO_MINE;
            }
        }

        protected void select(boolean value) {
            super.select(value);
            this.btLabel.am = this.selected ? Key.TIME_TO_UNLOCK : 0.6f;
        }
    }

    public WndTabbed() {
        super(0, 0, Chrome.get(Type.TAB_SET));
        this.tabs = new ArrayList();
    }

    protected Tab add(Tab tab) {
        float f;
        if (this.tabs.size() == 0) {
            f = (float) ((-this.chrome.marginLeft()) + 1);
        } else {
            f = ((Tab) this.tabs.get(this.tabs.size() - 1)).right();
        }
        tab.setPos(f, (float) this.height);
        tab.select(false);
        super.add(tab);
        this.tabs.add(tab);
        return tab;
    }

    public void select(int index) {
        select((Tab) this.tabs.get(index));
    }

    public void select(Tab tab) {
        if (tab != this.selected) {
            Iterator it = this.tabs.iterator();
            while (it.hasNext()) {
                Tab t = (Tab) it.next();
                if (t == this.selected) {
                    t.select(false);
                } else if (t == tab) {
                    t.select(true);
                }
            }
            this.selected = tab;
        }
    }

    public void resize(int w, int h) {
        this.width = w;
        this.height = h;
        this.chrome.size((float) (this.width + this.chrome.marginHor()), (float) (this.height + this.chrome.marginVer()));
        this.camera.resize((int) this.chrome.width, (this.chrome.marginTop() + this.height) + tabHeight());
        this.camera.f6x = ((int) (((float) Game.width) - this.camera.screenWidth())) / 2;
        this.camera.f7y = ((int) (((float) Game.height) - this.camera.screenHeight())) / 2;
        this.shadow.boxRect(((float) this.camera.f6x) / this.camera.zoom, ((float) this.camera.f7y) / this.camera.zoom, this.chrome.width(), this.chrome.height);
        Iterator it = this.tabs.iterator();
        while (it.hasNext()) {
            remove((Tab) it.next());
        }
        ArrayList<Tab> tabs = new ArrayList(this.tabs);
        this.tabs.clear();
        it = tabs.iterator();
        while (it.hasNext()) {
            add((Tab) it.next());
        }
    }

    protected int tabHeight() {
        return 25;
    }

    protected void onClick(Tab tab) {
        select(tab);
    }
}
