package com.watabou.pixeldungeon.windows;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.ui.ItemSlot;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.Utils;
import java.util.Iterator;

public class WndItem extends Window {
    private static final float BUTTON_HEIGHT = 16.0f;
    private static final float BUTTON_WIDTH = 36.0f;
    private static final float GAP = 2.0f;
    private static final int WIDTH = 120;

    /* renamed from: com.watabou.pixeldungeon.windows.WndItem.1 */
    class C01931 extends RedButton {
        final /* synthetic */ String val$action;
        final /* synthetic */ Item val$item;
        final /* synthetic */ WndBag val$owner;

        C01931(String label, Item item, String str, WndBag wndBag) {
            this.val$item = item;
            this.val$action = str;
            this.val$owner = wndBag;
            super(label);
        }

        protected void onClick() {
            this.val$item.execute(Dungeon.hero, this.val$action);
            WndItem.this.hide();
            this.val$owner.hide();
        }
    }

    public WndItem(WndBag owner, Item item) {
        IconTitle titlebar = new IconTitle();
        titlebar.icon(new ItemSprite(item.image(), item.glowing()));
        titlebar.label(Utils.capitalize(item.toString()));
        if (item.isUpgradable() && item.levelKnown) {
            titlebar.health(((float) item.durability()) / ((float) item.maxDurability()));
        }
        titlebar.setRect(0.0f, 0.0f, 120.0f, 0.0f);
        add(titlebar);
        if (item.levelKnown && item.level > 0) {
            titlebar.color(ItemSlot.UPGRADED);
        } else if (item.levelKnown && item.level < 0) {
            titlebar.color(ItemSlot.DEGRADED);
        }
        BitmapTextMultiline info = PixelScene.createMultiline(item.info(), 6.0f);
        info.maxWidth = WIDTH;
        info.measure();
        info.x = titlebar.left();
        info.y = titlebar.bottom() + GAP;
        add(info);
        float y = (info.y + info.height()) + GAP;
        float x = 0.0f;
        if (Dungeon.hero.isAlive() && owner != null) {
            Iterator it = item.actions(Dungeon.hero).iterator();
            while (it.hasNext()) {
                String action = (String) it.next();
                RedButton btn = new C01931(action, item, action, owner);
                btn.setSize(Math.max(BUTTON_WIDTH, btn.reqWidth()), BUTTON_HEIGHT);
                if (btn.width() + x > 120.0f) {
                    x = 0.0f;
                    y += 18.0f;
                }
                btn.setPos(x, y);
                add(btn);
                if (action == item.defaultAction) {
                    btn.textColor(Window.TITLE_COLOR);
                }
                x += btn.width() + GAP;
            }
        }
        resize(WIDTH, (int) ((x > 0.0f ? BUTTON_HEIGHT : 0.0f) + y));
    }
}
