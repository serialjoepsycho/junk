package com.watabou.pixeldungeon;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import com.watabou.gltextures.SmartTexture;
import com.watabou.gltextures.TextureCache;
import com.watabou.glwrap.Texture;
import com.watabou.noosa.Image;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.utils.Random;

public class LightMap extends Image {
    private int height2;
    private int pHeight;
    private int pWidth;
    private int[] pixels;
    private int width2;

    private class FogTexture extends SmartTexture {
        public FogTexture() {
            super(Bitmap.createBitmap(LightMap.this.width2, LightMap.this.height2, Config.ARGB_8888));
            filter(Texture.LINEAR, Texture.LINEAR);
            TextureCache.add(LightMap.class, this);
        }

        public void reload() {
            super.reload();
            LightMap.this.updateVisibility();
        }
    }

    public LightMap(int mapWidth, int mapHeight) {
        this.pWidth = mapWidth;
        this.pHeight = mapHeight;
        this.width2 = 1;
        while (this.width2 < this.pWidth) {
            this.width2 <<= 1;
        }
        this.height2 = 1;
        while (this.height2 < this.pHeight) {
            this.height2 <<= 1;
        }
        this.width = ((float) this.width2) * ShadowBox.SIZE;
        this.height = ((float) this.height2) * ShadowBox.SIZE;
        texture(new FogTexture());
        this.scale.set(ShadowBox.SIZE, ShadowBox.SIZE);
        updateVisibility();
    }

    public void updateVisibility() {
        if (this.pixels == null) {
            this.pixels = new int[(this.width2 * this.height2)];
        }
        for (int i = 0; i < this.pixels.length; i++) {
            if (Level.water[i]) {
                this.pixels[i] = 0;
            } else {
                this.pixels[i] = ((Level.solid[i] ? 68 : 0) + Random.Int(34)) << 24;
            }
        }
        this.texture.pixels(this.width2, this.height2, this.pixels);
    }
}
