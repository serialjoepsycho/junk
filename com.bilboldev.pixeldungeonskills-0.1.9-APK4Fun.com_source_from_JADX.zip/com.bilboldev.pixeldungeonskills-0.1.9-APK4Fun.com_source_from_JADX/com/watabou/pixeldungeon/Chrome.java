package com.watabou.pixeldungeon;

import com.watabou.noosa.NinePatch;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;

public class Chrome {

    /* renamed from: com.watabou.pixeldungeon.Chrome.1 */
    static /* synthetic */ class C00121 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$Chrome$Type;

        static {
            $SwitchMap$com$watabou$pixeldungeon$Chrome$Type = new int[Type.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$Chrome$Type[Type.WINDOW.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$Chrome$Type[Type.TOAST.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$Chrome$Type[Type.TOAST_TR.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$Chrome$Type[Type.BUTTON.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$Chrome$Type[Type.TAG.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$Chrome$Type[Type.SCROLL.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$Chrome$Type[Type.TAB_SET.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$Chrome$Type[Type.TAB_SELECTED.ordinal()] = 8;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$Chrome$Type[Type.TAB_UNSELECTED.ordinal()] = 9;
            } catch (NoSuchFieldError e9) {
            }
        }
    }

    public enum Type {
        TOAST,
        TOAST_TR,
        WINDOW,
        BUTTON,
        TAG,
        SCROLL,
        TAB_SET,
        TAB_SELECTED,
        TAB_UNSELECTED
    }

    public static NinePatch get(Type type) {
        switch (C00121.$SwitchMap$com$watabou$pixeldungeon$Chrome$Type[type.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                return new NinePatch(Assets.CHROME, 0, 0, 22, 22, 7);
            case WndUpdates.ID_CAVES /*2*/:
                return new NinePatch(Assets.CHROME, 22, 0, 18, 18, 5);
            case WndUpdates.ID_METROPOLIS /*3*/:
                return new NinePatch(Assets.CHROME, 40, 0, 18, 18, 5);
            case WndUpdates.ID_HALLS /*4*/:
                return new NinePatch(Assets.CHROME, 58, 0, 4, 4, 1);
            case BuffIndicator.HUNGER /*5*/:
                return new NinePatch(Assets.CHROME, 22, 18, 16, 14, 3);
            case BuffIndicator.STARVATION /*6*/:
                return new NinePatch(Assets.CHROME, 32, 32, 32, 32, 5, 11, 5, 11);
            case BuffIndicator.SLOW /*7*/:
                return new NinePatch(Assets.CHROME, 64, 0, 22, 22, 7, 7, 7, 7);
            case BuffIndicator.OOZE /*8*/:
                return new NinePatch(Assets.CHROME, 64, 22, 10, 14, 4, 7, 4, 6);
            case BuffIndicator.AMOK /*9*/:
                return new NinePatch(Assets.CHROME, 74, 22, 10, 14, 4, 7, 4, 6);
            default:
                return null;
        }
    }
}
