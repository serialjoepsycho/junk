package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Game;
import com.watabou.noosa.Gizmo;
import com.watabou.noosa.Image;
import com.watabou.noosa.ui.Button;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Heap.Type;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.plants.Plant;
import com.watabou.pixeldungeon.scenes.CellSelector.Listener;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.windows.WndBag;
import com.watabou.pixeldungeon.windows.WndBag.Mode;
import com.watabou.pixeldungeon.windows.WndCatalogus;
import com.watabou.pixeldungeon.windows.WndHero;
import com.watabou.pixeldungeon.windows.WndInfoCell;
import com.watabou.pixeldungeon.windows.WndInfoItem;
import com.watabou.pixeldungeon.windows.WndInfoMob;
import com.watabou.pixeldungeon.windows.WndInfoPlant;
import com.watabou.pixeldungeon.windows.WndMessage;
import com.watabou.pixeldungeon.windows.WndQuickSkills;
import com.watabou.pixeldungeon.windows.WndTradeItem;
import java.util.Iterator;

public class Toolbar extends Component {
    private static Listener informer;
    private static Toolbar instance;
    private Tool btnInfo;
    private Tool btnInventory;
    private Tool btnQuick1;
    private Tool btnQuick2;
    private Tool btnSearch;
    private Tool btnSkill;
    private Tool btnWait;
    private boolean lastEnabled;
    private PickedUpItem pickedUp;

    private static class Tool extends Button {
        private static final int BGCOLOR = 8093811;
        protected Image base;

        public Tool(int x, int y, int width, int height) {
            this.base.frame(x, y, width, height);
            this.width = (float) width;
            this.height = (float) height;
        }

        protected void createChildren() {
            super.createChildren();
            this.base = new Image(Assets.TOOLBAR);
            add(this.base);
        }

        protected void layout() {
            super.layout();
            this.base.x = this.x;
            this.base.y = this.y;
        }

        protected void onTouchDown() {
            this.base.brightness(1.4f);
        }

        protected void onTouchUp() {
            if (this.active) {
                this.base.resetColor();
            } else {
                this.base.tint(BGCOLOR, 0.7f);
            }
        }

        public void enable(boolean value) {
            if (value != this.active) {
                if (value) {
                    this.base.resetColor();
                } else {
                    this.base.tint(BGCOLOR, 0.7f);
                }
                this.active = value;
            }
        }
    }

    /* renamed from: com.watabou.pixeldungeon.ui.Toolbar.1 */
    class C01571 extends Tool {
        C01571(int x, int y, int width, int height) {
            super(x, y, width, height);
        }

        protected void onClick() {
            Dungeon.hero.rest(false);
        }

        protected boolean onLongClick() {
            Dungeon.hero.rest(true);
            return true;
        }
    }

    /* renamed from: com.watabou.pixeldungeon.ui.Toolbar.2 */
    class C01582 extends Tool {
        C01582(int x, int y, int width, int height) {
            super(x, y, width, height);
        }

        protected void onClick() {
            Dungeon.hero.search(true);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.ui.Toolbar.3 */
    class C01593 extends Tool {
        C01593(int x, int y, int width, int height) {
            super(x, y, width, height);
        }

        protected void onClick() {
            GameScene.show(new WndQuickSkills());
        }
    }

    /* renamed from: com.watabou.pixeldungeon.ui.Toolbar.4 */
    class C01604 extends Tool {
        C01604(int x, int y, int width, int height) {
            super(x, y, width, height);
        }

        protected void onClick() {
            GameScene.selectCell(Toolbar.informer);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.ui.Toolbar.5 */
    class C01615 extends Tool {
        private GoldIndicator gold;

        C01615(int x, int y, int width, int height) {
            super(x, y, width, height);
        }

        protected void onClick() {
            GameScene.show(new WndBag(Dungeon.hero.belongings.backpack, null, Mode.ALL, null));
        }

        protected boolean onLongClick() {
            GameScene.show(new WndCatalogus());
            return true;
        }

        protected void createChildren() {
            super.createChildren();
            this.gold = new GoldIndicator();
            add(this.gold);
        }

        protected void layout() {
            super.layout();
            this.gold.fill(this);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.ui.Toolbar.6 */
    static class C01626 implements Listener {
        C01626() {
        }

        public void onSelect(Integer cell) {
            if (cell != null) {
                if (cell.intValue() < 0 || cell.intValue() > Level.LENGTH || !(Dungeon.level.visited[cell.intValue()] || Dungeon.level.mapped[cell.intValue()])) {
                    GameScene.show(new WndMessage("You don't know what is there."));
                } else if (!Dungeon.visible[cell.intValue()]) {
                    GameScene.show(new WndInfoCell(cell.intValue()));
                } else if (cell.intValue() == Dungeon.hero.pos) {
                    GameScene.show(new WndHero());
                } else {
                    Mob mob = (Mob) Actor.findChar(cell.intValue());
                    if (mob != null) {
                        GameScene.show(new WndInfoMob(mob));
                        return;
                    }
                    Heap heap = (Heap) Dungeon.level.heaps.get(cell.intValue());
                    if (heap == null) {
                        Plant plant = (Plant) Dungeon.level.plants.get(cell.intValue());
                        if (plant != null) {
                            GameScene.show(new WndInfoPlant(plant));
                        } else {
                            GameScene.show(new WndInfoCell(cell.intValue()));
                        }
                    } else if (heap.type == Type.FOR_SALE && heap.size() == 1 && heap.peek().price() > 0) {
                        GameScene.show(new WndTradeItem(heap, false));
                    } else {
                        GameScene.show(new WndInfoItem(heap));
                    }
                }
            }
        }

        public String prompt() {
            return "Select a cell to examine";
        }
    }

    private static class PickedUpItem extends ItemSprite {
        private static final float DISTANCE = 16.0f;
        private static final float DURATION = 0.2f;
        private float dstX;
        private float dstY;
        private float left;

        public PickedUpItem() {
            originToCenter();
            this.visible = false;
            this.active = false;
        }

        public void reset(Item item, float dstX, float dstY) {
            view(item.image(), item.glowing());
            this.visible = true;
            this.active = true;
            this.dstX = dstX - 8.0f;
            this.dstY = dstY - 8.0f;
            this.left = DURATION;
            this.x = this.dstX - DISTANCE;
            this.y = this.dstY - DISTANCE;
            alpha(Key.TIME_TO_UNLOCK);
        }

        public void update() {
            super.update();
            float f = this.left - Game.elapsed;
            this.left = f;
            if (f <= 0.0f) {
                this.active = false;
                this.visible = false;
                return;
            }
            float p = this.left / DURATION;
            this.scale.set((float) Math.sqrt((double) p));
            float offset = DISTANCE * p;
            this.x = this.dstX - offset;
            this.y = this.dstY - offset;
        }
    }

    private static class QuickslotTool extends Tool {
        private QuickSlot slot;

        public QuickslotTool(int x, int y, int width, int height, boolean primary) {
            super(x, y, width, height);
            if (primary) {
                this.slot.primary();
            } else {
                this.slot.secondary();
            }
        }

        protected void createChildren() {
            super.createChildren();
            this.slot = new QuickSlot();
            add(this.slot);
        }

        protected void layout() {
            super.layout();
            this.slot.setRect(this.x + Key.TIME_TO_UNLOCK, this.y + Pickaxe.TIME_TO_MINE, this.width - Pickaxe.TIME_TO_MINE, this.height - Pickaxe.TIME_TO_MINE);
        }

        public void enable(boolean value) {
            this.slot.enable(value);
            super.enable(value);
        }
    }

    public Toolbar() {
        this.lastEnabled = true;
        instance = this;
        this.height = this.btnInventory.height();
        this.btnQuick2.visible = PixelDungeon.secondSlot();
    }

    protected void createChildren() {
        boolean z = false;
        Gizmo c01571 = new C01571(0, 7, 20, 24);
        this.btnWait = c01571;
        add(c01571);
        Gizmo c01582 = new C01582(20, 7, 20, 24);
        this.btnSearch = c01582;
        add(c01582);
        c01582 = new C01593(ItemSpriteSheet.HOLSTER, 7, 21, 24);
        this.btnSkill = c01582;
        add(c01582);
        c01582 = new C01604(40, 7, 21, 24);
        this.btnInfo = c01582;
        add(c01582);
        c01582 = new C01615(60, 7, 23, 24);
        this.btnInventory = c01582;
        add(c01582);
        c01582 = new QuickslotTool(83, 7, 22, 24, true);
        this.btnQuick1 = c01582;
        add(c01582);
        c01582 = new QuickslotTool(83, 7, 22, 24, false);
        this.btnQuick2 = c01582;
        add(c01582);
        Tool tool = this.btnQuick2;
        if (QuickSlot.secondaryValue != null) {
            z = true;
        }
        tool.visible = z;
        c01571 = new PickedUpItem();
        this.pickedUp = c01571;
        add(c01571);
    }

    protected void layout() {
        this.btnWait.setPos(this.x, this.y);
        this.btnSearch.setPos(this.btnWait.right(), this.y);
        this.btnInfo.setPos(this.btnSearch.right(), this.y);
        this.btnSkill.setPos(this.btnInfo.right(), this.y);
        this.btnQuick1.setPos(this.width - this.btnQuick1.width(), this.y);
        if (this.btnQuick2.visible) {
            this.btnQuick2.setPos(this.btnQuick1.left() - this.btnQuick2.width(), this.y);
            this.btnInventory.setPos(this.btnQuick2.left() - this.btnInventory.width(), this.y);
            return;
        }
        this.btnInventory.setPos(this.btnQuick1.left() - this.btnInventory.width(), this.y);
    }

    public void update() {
        super.update();
        if (this.lastEnabled != Dungeon.hero.ready) {
            this.lastEnabled = Dungeon.hero.ready;
            Iterator it = this.members.iterator();
            while (it.hasNext()) {
                Gizmo tool = (Gizmo) it.next();
                if (tool instanceof Tool) {
                    ((Tool) tool).enable(this.lastEnabled);
                }
            }
        }
        if (!Dungeon.hero.isAlive()) {
            this.btnInventory.enable(true);
        }
    }

    public void pickup(Item item) {
        this.pickedUp.reset(item, this.btnInventory.centerX(), this.btnInventory.centerY());
    }

    public static boolean secondQuickslot() {
        return instance.btnQuick2.visible;
    }

    public static void secondQuickslot(boolean value) {
        Tool tool = instance.btnQuick2;
        instance.btnQuick2.active = value;
        tool.visible = value;
        instance.layout();
    }

    static {
        informer = new C01626();
    }
}
