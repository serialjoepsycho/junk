package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.Gizmo;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Signal.Listener;
import java.util.regex.Pattern;

public class GameLog extends Component implements Listener<String> {
    private static final int MAX_MESSAGES = 3;
    private static final Pattern PUNCTUATION;
    private int lastColor;
    private BitmapTextMultiline lastEntry;

    static {
        PUNCTUATION = Pattern.compile(".*[.,;?! ]$");
    }

    public GameLog() {
        GLog.update.add(this);
        newLine();
    }

    public void newLine() {
        this.lastEntry = null;
    }

    public void onSignal(String text) {
        int color = CharSprite.DEFAULT;
        if (text.startsWith(GLog.POSITIVE)) {
            text = text.substring(GLog.POSITIVE.length());
            color = CharSprite.POSITIVE;
        } else if (text.startsWith(GLog.NEGATIVE)) {
            text = text.substring(GLog.NEGATIVE.length());
            color = CharSprite.NEGATIVE;
        } else if (text.startsWith(GLog.WARNING)) {
            text = text.substring(GLog.WARNING.length());
            color = ItemSlot.WARNING;
        } else if (text.startsWith(GLog.HIGHLIGHT)) {
            text = text.substring(GLog.HIGHLIGHT.length());
            color = CharSprite.NEUTRAL;
        }
        text = Utils.capitalize(text) + (PUNCTUATION.matcher(text).matches() ? BuildConfig.VERSION_NAME : ".");
        if (this.lastEntry == null || color != this.lastColor) {
            this.lastEntry = PixelScene.createMultiline(text, 6.0f);
            this.lastEntry.maxWidth = (int) this.width;
            this.lastEntry.measure();
            this.lastEntry.hardlight(color);
            this.lastColor = color;
            add(this.lastEntry);
        } else {
            String lastMessage = this.lastEntry.text();
            BitmapTextMultiline bitmapTextMultiline = this.lastEntry;
            if (lastMessage.length() != 0) {
                text = lastMessage + " " + text;
            }
            bitmapTextMultiline.text(text);
            this.lastEntry.measure();
        }
        if (this.length > MAX_MESSAGES) {
            remove((Gizmo) this.members.get(0));
        }
        layout();
    }

    protected void layout() {
        float pos = this.y;
        for (int i = this.length - 1; i >= 0; i--) {
            BitmapTextMultiline entry = (BitmapTextMultiline) this.members.get(i);
            entry.x = this.x;
            entry.y = pos - entry.height();
            pos -= entry.height();
        }
    }

    public void destroy() {
        GLog.update.remove(this);
        super.destroy();
    }
}
