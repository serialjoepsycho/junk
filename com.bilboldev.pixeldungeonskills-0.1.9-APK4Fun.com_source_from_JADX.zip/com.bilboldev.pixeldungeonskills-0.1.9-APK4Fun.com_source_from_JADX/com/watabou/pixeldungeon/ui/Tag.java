package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Game;
import com.watabou.noosa.NinePatch;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Chrome;
import com.watabou.pixeldungeon.Chrome.Type;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;

public class Tag extends Button {
    private float f21b;
    protected NinePatch bg;
    private float f22g;
    protected float lightness;
    private float f23r;

    public Tag(int color) {
        this.lightness = 0.0f;
        this.f23r = ((float) (color >> 16)) / 255.0f;
        this.f22g = ((float) ((color >> 8) & 255)) / 255.0f;
        this.f21b = ((float) (color & 255)) / 255.0f;
    }

    protected void createChildren() {
        super.createChildren();
        this.bg = Chrome.get(Type.TAG);
        add(this.bg);
    }

    protected void layout() {
        super.layout();
        this.bg.x = this.x;
        this.bg.y = this.y;
        this.bg.size(this.width, this.height);
    }

    public void flash() {
        this.lightness = Key.TIME_TO_UNLOCK;
    }

    public void update() {
        super.update();
        if (this.visible && ((double) this.lightness) > 0.5d) {
            float f = this.lightness - Game.elapsed;
            this.lightness = f;
            if (((double) f) > 0.5d) {
                NinePatch ninePatch = this.bg;
                NinePatch ninePatch2 = this.bg;
                float f2 = (this.lightness * Pickaxe.TIME_TO_MINE) - Key.TIME_TO_UNLOCK;
                this.bg.ba = f2;
                ninePatch2.ga = f2;
                ninePatch.ra = f2;
                this.bg.rm = (this.f23r * Pickaxe.TIME_TO_MINE) * (Key.TIME_TO_UNLOCK - this.lightness);
                this.bg.gm = (this.f22g * Pickaxe.TIME_TO_MINE) * (Key.TIME_TO_UNLOCK - this.lightness);
                this.bg.bm = (this.f21b * Pickaxe.TIME_TO_MINE) * (Key.TIME_TO_UNLOCK - this.lightness);
                return;
            }
            this.bg.hardlight(this.f23r, this.f22g, this.f21b);
        }
    }
}
