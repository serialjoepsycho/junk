package com.watabou.pixeldungeon.ui;

import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;

public class CheckBox extends RedButton {
    private boolean checked;

    public CheckBox(String label) {
        super(label);
        this.checked = false;
        icon(Icons.get(Icons.UNCHECKED));
    }

    protected void layout() {
        super.layout();
        float margin = (this.height - this.text.baseLine()) / Pickaxe.TIME_TO_MINE;
        this.text.x = PixelScene.align(PixelScene.uiCamera, this.x + margin);
        this.text.y = PixelScene.align(PixelScene.uiCamera, this.y + margin);
        margin = (this.height - this.icon.height) / Pickaxe.TIME_TO_MINE;
        this.icon.x = PixelScene.align(PixelScene.uiCamera, ((this.x + this.width) - margin) - this.icon.width);
        this.icon.y = PixelScene.align(PixelScene.uiCamera, this.y + margin);
    }

    public boolean checked() {
        return this.checked;
    }

    public void checked(boolean value) {
        if (this.checked != value) {
            this.checked = value;
            this.icon.copy(Icons.get(this.checked ? Icons.CHECKED : Icons.UNCHECKED));
        }
    }

    protected void onClick() {
        super.onClick();
        checked(!this.checked);
    }
}
