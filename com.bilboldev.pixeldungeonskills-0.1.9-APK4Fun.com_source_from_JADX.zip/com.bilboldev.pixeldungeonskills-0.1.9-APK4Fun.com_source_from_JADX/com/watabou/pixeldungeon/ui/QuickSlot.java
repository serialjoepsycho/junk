package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Image;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Belongings;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.weapon.missiles.Arrow;
import com.watabou.pixeldungeon.items.weapon.missiles.BombArrow;
import com.watabou.pixeldungeon.items.weapon.missiles.Bow;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.windows.WndBag.Listener;
import com.watabou.pixeldungeon.windows.WndBag.Mode;
import com.watabou.utils.Bundle;

public class QuickSlot extends Button implements Listener {
    private static final String QUICKSLOT1 = "quickslot";
    private static final String QUICKSLOT2 = "quickslot2";
    private static final String TXT_SELECT_ITEM = "Select an item for the quickslot";
    private static QuickSlot primary;
    public static Object primaryValue;
    private static QuickSlot secondary;
    public static Object secondaryValue;
    private Image crossB;
    private Image crossM;
    private Item itemInSlot;
    private Item lastItem;
    private Char lastTarget;
    private ItemSlot slot;
    private boolean targeting;

    /* renamed from: com.watabou.pixeldungeon.ui.QuickSlot.1 */
    class C01531 extends ItemSlot {
        C01531() {
        }

        protected void onClick() {
            if (QuickSlot.this.targeting) {
                GameScene.handleCell(QuickSlot.this.lastTarget.pos);
                return;
            }
            Item item = QuickSlot.this.select();
            if (item == QuickSlot.this.lastItem) {
                QuickSlot.this.useTargeting();
            } else {
                QuickSlot.this.lastItem = item;
            }
            item.execute(Dungeon.hero);
        }

        protected boolean onLongClick() {
            return QuickSlot.this.onLongClick();
        }

        protected void onTouchDown() {
            this.icon.lightness(0.7f);
        }

        protected void onTouchUp() {
            this.icon.resetColor();
        }
    }

    public QuickSlot() {
        this.targeting = false;
        this.lastItem = null;
        this.lastTarget = null;
    }

    public void primary() {
        primary = this;
        item(select());
    }

    public void secondary() {
        secondary = this;
        item(select());
    }

    public void destroy() {
        super.destroy();
        if (this == primary) {
            primary = null;
        } else {
            secondary = null;
        }
        this.lastItem = null;
        this.lastTarget = null;
    }

    protected void createChildren() {
        super.createChildren();
        this.slot = new C01531();
        add(this.slot);
        this.crossB = Icons.TARGET.get();
        this.crossB.visible = false;
        add(this.crossB);
        this.crossM = new Image();
        this.crossM.copy(this.crossB);
    }

    protected void layout() {
        super.layout();
        this.slot.fill(this);
        this.crossB.x = PixelScene.align(this.x + ((this.width - this.crossB.width) / Pickaxe.TIME_TO_MINE));
        this.crossB.y = PixelScene.align(this.y + ((this.height - this.crossB.height) / Pickaxe.TIME_TO_MINE));
    }

    protected void onClick() {
        GameScene.selectItem(this, Mode.QUICKSLOT, TXT_SELECT_ITEM);
    }

    protected boolean onLongClick() {
        GameScene.selectItem(this, Mode.QUICKSLOT, TXT_SELECT_ITEM);
        return true;
    }

    private Item select() {
        Object content = this == primary ? primaryValue : secondaryValue;
        if (content instanceof Item) {
            return (Item) content;
        }
        if (content == null) {
            return null;
        }
        Item item = Dungeon.hero.belongings.getItem((Class) content);
        if (item == null) {
            item = Item.virtual((Class) content);
        }
        return item;
    }

    public void onSelect(Item item) {
        if (item != null && !(item instanceof Bow)) {
            if (this == primary) {
                if (item.stackable) {
                    item = item.getClass();
                }
                primaryValue = item;
            } else {
                if (item.stackable) {
                    item = item.getClass();
                }
                secondaryValue = item;
            }
            refresh();
        }
    }

    public void item(Item item) {
        this.slot.item(item);
        this.itemInSlot = item;
        enableSlot();
    }

    public void enable(boolean value) {
        this.active = value;
        if (value) {
            enableSlot();
        } else {
            this.slot.enable(false);
        }
    }

    private void enableSlot() {
        ItemSlot itemSlot = this.slot;
        boolean z = !(this.itemInSlot instanceof Bow) && (!(((this.itemInSlot instanceof Arrow) || (this.itemInSlot instanceof BombArrow)) && Dungeon.hero.belongings.bow == null) && this.itemInSlot != null && this.itemInSlot.quantity() > 0 && (Dungeon.hero.belongings.backpack.contains(this.itemInSlot) || this.itemInSlot.isEquipped(Dungeon.hero)));
        itemSlot.enable(z);
    }

    private void useTargeting() {
        boolean z = this.lastTarget != null && this.lastTarget.isAlive() && Dungeon.visible[this.lastTarget.pos];
        this.targeting = z;
        if (!this.targeting) {
            return;
        }
        if (Actor.all().contains(this.lastTarget)) {
            this.lastTarget.sprite.parent.add(this.crossM);
            this.crossM.point(DungeonTilemap.tileToWorld(this.lastTarget.pos));
            this.crossB.visible = true;
            return;
        }
        this.lastTarget = null;
    }

    public static void refresh() {
        if (primary != null) {
            primary.item(primary.select());
        }
        if (secondary != null) {
            secondary.item(secondary.select());
        }
    }

    public static void target(Item item, Char target) {
        if (target == Dungeon.hero) {
            return;
        }
        if (item == primary.lastItem) {
            primary.lastTarget = target;
            HealthIndicator.instance.target(target);
        } else if (item == secondary.lastItem) {
            secondary.lastTarget = target;
            HealthIndicator.instance.target(target);
        }
    }

    public static void cancel() {
        if (primary != null && primary.targeting) {
            primary.crossB.visible = false;
            primary.crossM.remove();
            primary.targeting = false;
        }
        if (secondary != null && secondary.targeting) {
            secondary.crossB.visible = false;
            secondary.crossM.remove();
            secondary.targeting = false;
        }
    }

    public static void save(Bundle bundle) {
        Belongings stuff = Dungeon.hero.belongings;
        if ((primaryValue instanceof Class) && stuff.getItem((Class) primaryValue) != null) {
            bundle.put(QUICKSLOT1, ((Class) primaryValue).getName());
        }
        if ((secondaryValue instanceof Class) && stuff.getItem((Class) secondaryValue) != null && Toolbar.secondQuickslot()) {
            bundle.put(QUICKSLOT2, ((Class) secondaryValue).getName());
        }
    }

    public static void save(Bundle bundle, Item item) {
        if (item == primaryValue) {
            bundle.put(QUICKSLOT1, true);
        }
        if (item == secondaryValue && Toolbar.secondQuickslot()) {
            bundle.put(QUICKSLOT2, true);
        }
    }

    public static void restore(Bundle bundle) {
        primaryValue = null;
        secondaryValue = null;
        String qsClass = bundle.getString(QUICKSLOT1);
        if (qsClass != null) {
            try {
                primaryValue = Class.forName(qsClass);
            } catch (ClassNotFoundException e) {
            }
        }
        qsClass = bundle.getString(QUICKSLOT2);
        if (qsClass != null) {
            try {
                secondaryValue = Class.forName(qsClass);
            } catch (ClassNotFoundException e2) {
            }
        }
    }

    public static void restore(Bundle bundle, Item item) {
        if (bundle.getBoolean(QUICKSLOT1)) {
            primaryValue = item;
        }
        if (bundle.getBoolean(QUICKSLOT2)) {
            secondaryValue = item;
        }
    }

    public static void compress() {
        if ((primaryValue == null && secondaryValue != null) || primaryValue == secondaryValue) {
            primaryValue = secondaryValue;
            secondaryValue = null;
        }
    }
}
