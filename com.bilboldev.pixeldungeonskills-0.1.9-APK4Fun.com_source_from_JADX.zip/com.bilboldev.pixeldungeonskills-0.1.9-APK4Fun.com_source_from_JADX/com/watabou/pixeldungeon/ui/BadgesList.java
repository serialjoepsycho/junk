package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Game;
import com.watabou.noosa.Image;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Badges.Badge;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.effects.BadgeBanner;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.windows.WndBadge;
import java.util.ArrayList;

public class BadgesList extends ScrollPane {
    private ArrayList<ListItem> items;

    private class ListItem extends Component {
        private static final float HEIGHT = 20.0f;
        private Badge badge;
        private Image icon;
        private BitmapText label;

        public ListItem(Badge badge) {
            this.badge = badge;
            this.icon.copy(BadgeBanner.image(badge.image));
            this.label.text(badge.description);
        }

        protected void createChildren() {
            this.icon = new Image();
            add(this.icon);
            this.label = PixelScene.createText(6.0f);
            add(this.label);
        }

        protected void layout() {
            this.icon.x = this.x;
            this.icon.y = PixelScene.align(this.y + ((this.height - this.icon.height) / Pickaxe.TIME_TO_MINE));
            this.label.x = (this.icon.x + this.icon.width) + Pickaxe.TIME_TO_MINE;
            this.label.y = PixelScene.align(this.y + ((this.height - this.label.baseLine()) / Pickaxe.TIME_TO_MINE));
        }

        public boolean onClick(float x, float y) {
            if (!inside(x, y)) {
                return false;
            }
            Sample.INSTANCE.play(Assets.SND_CLICK, 0.7f, 0.7f, 1.2f);
            Game.scene().add(new WndBadge(this.badge));
            return true;
        }
    }

    public BadgesList(boolean global) {
        super(new Component());
        this.items = new ArrayList();
        for (Badge badge : Badges.filtered(global)) {
            if (badge.image != -1) {
                ListItem item = new ListItem(badge);
                this.content.add(item);
                this.items.add(item);
            }
        }
    }

    protected void layout() {
        super.layout();
        float pos = 0.0f;
        int size = this.items.size();
        for (int i = 0; i < size; i++) {
            ((ListItem) this.items.get(i)).setRect(0.0f, pos, this.width, MindVision.DURATION);
            pos += MindVision.DURATION;
        }
        this.content.setSize(this.width, pos);
    }

    public void onClick(float x, float y) {
        int size = this.items.size();
        int i = 0;
        while (i < size && !((ListItem) this.items.get(i)).onClick(x, y)) {
            i++;
        }
    }
}
