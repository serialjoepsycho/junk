package com.watabou.pixeldungeon.ui;

import com.watabou.gltextures.SmartTexture;
import com.watabou.gltextures.TextureCache;
import com.watabou.noosa.Image;
import com.watabou.noosa.TextureFilm;
import com.watabou.noosa.Visual;
import com.watabou.noosa.tweeners.AlphaTweener;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.utils.SparseArray;
import java.util.Iterator;

public class BuffIndicator extends Component {
    public static final int AMOK = 9;
    public static final int ARMOR = 20;
    public static final int BARKSKIN = 24;
    public static final int BLEEDING = 26;
    public static final int BLINDNESS = 16;
    public static final int COMBO = 17;
    public static final int CRIPPLE = 23;
    public static final int DEFERRED = 28;
    public static final int FIRE = 2;
    public static final int FROST = 15;
    public static final int FURY = 18;
    public static final int HEALING = 19;
    public static final int HEART = 21;
    public static final int HUNGER = 5;
    public static final int IMMUNITY = 25;
    public static final int INVISIBLE = 12;
    public static final int LEVITATION = 1;
    public static final int LIGHT = 22;
    public static final int MARK = 27;
    public static final int MIND_VISION = 0;
    public static final int NONE = -1;
    public static final int OOZE = 8;
    public static final int PARALYSIS = 4;
    public static final int POISON = 3;
    public static final int ROOTS = 11;
    public static final int SHADOWS = 13;
    public static final int SIZE = 7;
    public static final int SLOW = 7;
    public static final int STARVATION = 6;
    public static final int TERROR = 10;
    public static final int VERTIGO = 29;
    public static final int WEAKNESS = 14;
    private static BuffIndicator heroInstance;
    private Char ch;
    private TextureFilm film;
    private SparseArray<Image> icons;
    private SmartTexture texture;

    /* renamed from: com.watabou.pixeldungeon.ui.BuffIndicator.1 */
    class C01461 extends AlphaTweener {
        C01461(Visual image, float alpha, float time) {
            super(image, alpha, time);
        }

        protected void updateValues(float progress) {
            super.updateValues(progress);
            this.image.scale.set(Key.TIME_TO_UNLOCK + (GasesImmunity.DURATION * progress));
        }
    }

    public BuffIndicator(Char ch) {
        this.icons = new SparseArray();
        this.ch = ch;
        if (ch == Dungeon.hero) {
            heroInstance = this;
        }
    }

    public void destroy() {
        super.destroy();
        if (this == heroInstance) {
            heroInstance = null;
        }
    }

    protected void createChildren() {
        this.texture = TextureCache.get(Assets.BUFFS_SMALL);
        this.film = new TextureFilm(this.texture, SLOW, SLOW);
    }

    protected void layout() {
        clear();
        SparseArray<Image> newIcons = new SparseArray();
        Iterator it = this.ch.buffs().iterator();
        while (it.hasNext()) {
            int icon = ((Buff) it.next()).icon();
            if (icon != NONE) {
                Image img = new Image(this.texture);
                img.frame(this.film.get(Integer.valueOf(icon)));
                img.x = this.x + ((float) (this.members.size() * AMOK));
                img.y = this.y;
                add(img);
                newIcons.put(icon, img);
            }
        }
        int[] keyArray = this.icons.keyArray();
        int length = keyArray.length;
        for (int i = MIND_VISION; i < length; i += LEVITATION) {
            Integer key = Integer.valueOf(keyArray[i]);
            if (newIcons.get(key.intValue()) == null) {
                Image icon2 = (Image) this.icons.get(key.intValue());
                icon2.origin.set((float) CurareDart.DURATION);
                add(icon2);
                add(new C01461(icon2, 0.0f, 0.6f));
            }
        }
        this.icons = newIcons;
    }

    public static void refreshHero() {
        if (heroInstance != null) {
            heroInstance.layout();
        }
    }
}
