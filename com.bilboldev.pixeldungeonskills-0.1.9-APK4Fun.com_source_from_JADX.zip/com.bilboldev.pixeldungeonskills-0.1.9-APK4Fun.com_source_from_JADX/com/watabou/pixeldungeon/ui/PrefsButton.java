package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Image;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.windows.WndSettings;

public class PrefsButton extends Button {
    private Image image;

    public PrefsButton() {
        this.width = this.image.width;
        this.height = this.image.height;
    }

    protected void createChildren() {
        super.createChildren();
        this.image = Icons.PREFS.get();
        add(this.image);
    }

    protected void layout() {
        super.layout();
        this.image.x = this.x;
        this.image.y = this.y;
    }

    protected void onTouchDown() {
        this.image.brightness(Sleep.SWS);
        Sample.INSTANCE.play(Assets.SND_CLICK);
    }

    protected void onTouchUp() {
        this.image.resetColor();
    }

    protected void onClick() {
        this.parent.add(new WndSettings(false));
    }
}
