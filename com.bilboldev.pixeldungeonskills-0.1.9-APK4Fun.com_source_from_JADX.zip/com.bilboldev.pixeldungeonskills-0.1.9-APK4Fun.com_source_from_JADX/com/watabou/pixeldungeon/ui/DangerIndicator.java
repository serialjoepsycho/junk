package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Image;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;

public class DangerIndicator extends Tag {
    public static final int COLOR = 16731212;
    private int enemyIndex;
    private Image icon;
    private int lastNumber;
    private BitmapText number;

    public DangerIndicator() {
        super(COLOR);
        this.enemyIndex = 0;
        this.lastNumber = -1;
        setSize(24.0f, ShadowBox.SIZE);
        this.visible = false;
    }

    protected void createChildren() {
        super.createChildren();
        this.number = new BitmapText(PixelScene.font1x);
        add(this.number);
        this.icon = Icons.SKULL.get();
        add(this.icon);
    }

    protected void layout() {
        super.layout();
        this.icon.x = right() - TomeOfMastery.TIME_TO_READ;
        this.icon.y = this.y + ((this.height - this.icon.height) / Pickaxe.TIME_TO_MINE);
        placeNumber();
    }

    private void placeNumber() {
        this.number.x = (right() - 11.0f) - this.number.width();
        this.number.y = PixelScene.align(this.y + ((this.height - this.number.baseLine()) / Pickaxe.TIME_TO_MINE));
    }

    public void update() {
        boolean z = false;
        if (Dungeon.hero.isAlive()) {
            int v = Dungeon.hero.visibleEnemies();
            if (v != this.lastNumber) {
                this.lastNumber = v;
                if (this.lastNumber > 0) {
                    z = true;
                }
                this.visible = z;
                if (z) {
                    this.number.text(Integer.toString(this.lastNumber));
                    this.number.measure();
                    placeNumber();
                    flash();
                }
            }
        } else {
            this.visible = false;
        }
        super.update();
    }

    protected void onClick() {
        Char charR;
        Hero hero = Dungeon.hero;
        int i = this.enemyIndex;
        this.enemyIndex = i + 1;
        Char target = hero.visibleEnemy(i);
        HealthIndicator healthIndicator = HealthIndicator.instance;
        if (target == HealthIndicator.instance.target()) {
            charR = null;
        } else {
            charR = target;
        }
        healthIndicator.target(charR);
        Camera.main.target = null;
        Camera.main.focusOn(target.sprite);
    }
}
