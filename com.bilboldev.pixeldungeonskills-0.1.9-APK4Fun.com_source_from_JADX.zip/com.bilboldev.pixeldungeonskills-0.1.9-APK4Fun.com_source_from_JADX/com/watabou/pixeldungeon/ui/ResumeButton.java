package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Image;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;

public class ResumeButton extends Tag {
    private Image icon;

    public ResumeButton() {
        super(13489600);
        setSize(24.0f, 22.0f);
        this.visible = false;
    }

    protected void createChildren() {
        super.createChildren();
        this.icon = Icons.get(Icons.RESUME);
        add(this.icon);
    }

    protected void layout() {
        super.layout();
        this.icon.x = PixelScene.align(PixelScene.uiCamera, (this.x + Key.TIME_TO_UNLOCK) + ((this.width - this.icon.width) / Pickaxe.TIME_TO_MINE));
        this.icon.y = PixelScene.align(PixelScene.uiCamera, this.y + ((this.height - this.icon.height) / Pickaxe.TIME_TO_MINE));
    }

    public void update() {
        boolean prevVisible = this.visible;
        this.visible = Dungeon.hero.lastAction != null;
        if (this.visible && !prevVisible) {
            flash();
        }
        super.update();
    }

    protected void onClick() {
        Dungeon.hero.resume();
    }
}
