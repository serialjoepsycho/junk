package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Image;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.quest.Pickaxe;

public class BusyIndicator extends Image {
    public BusyIndicator() {
        copy(Icons.BUSY.get());
        this.origin.set(this.width / Pickaxe.TIME_TO_MINE, this.height / Pickaxe.TIME_TO_MINE);
        this.angularSpeed = 720.0f;
    }

    public void update() {
        super.update();
        boolean z = Dungeon.hero.isAlive() && !Dungeon.hero.ready;
        this.visible = z;
    }
}
