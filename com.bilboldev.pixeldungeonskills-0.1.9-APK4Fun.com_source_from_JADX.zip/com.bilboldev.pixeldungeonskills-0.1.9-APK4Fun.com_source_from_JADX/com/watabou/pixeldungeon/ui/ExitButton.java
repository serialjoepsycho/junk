package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Game;
import com.watabou.noosa.Image;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.scenes.TitleScene;

public class ExitButton extends Button {
    private Image image;

    public ExitButton() {
        this.width = this.image.width;
        this.height = this.image.height;
    }

    protected void createChildren() {
        super.createChildren();
        this.image = Icons.EXIT.get();
        add(this.image);
    }

    protected void layout() {
        super.layout();
        this.image.x = this.x;
        this.image.y = this.y;
    }

    protected void onTouchDown() {
        this.image.brightness(Sleep.SWS);
        Sample.INSTANCE.play(Assets.SND_CLICK);
    }

    protected void onTouchUp() {
        this.image.resetColor();
    }

    protected void onClick() {
        if (Game.scene() instanceof TitleScene) {
            Game.instance.finish();
        } else {
            PixelDungeon.switchNoFade(TitleScene.class);
        }
    }
}
