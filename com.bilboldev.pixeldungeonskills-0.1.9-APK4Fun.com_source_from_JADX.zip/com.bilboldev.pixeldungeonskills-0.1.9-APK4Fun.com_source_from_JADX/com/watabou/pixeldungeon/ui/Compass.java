package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Camera;
import com.watabou.noosa.Image;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.utils.PointF;

public class Compass extends Image {
    private static final float RADIUS = 12.0f;
    private static final float RAD_2_G = 57.295784f;
    private int cell;
    private PointF cellCenter;
    private PointF lastScroll;

    public Compass(int cell) {
        this.lastScroll = new PointF();
        copy(Icons.COMPASS.get());
        this.origin.set(this.width / Pickaxe.TIME_TO_MINE, RADIUS);
        this.cell = cell;
        this.cellCenter = DungeonTilemap.tileCenterToWorld(cell);
        this.visible = false;
    }

    public void update() {
        super.update();
        if (!this.visible) {
            boolean z = Dungeon.level.visited[this.cell] || Dungeon.level.mapped[this.cell];
            this.visible = z;
        }
        if (this.visible) {
            PointF scroll = Camera.main.scroll;
            if (!scroll.equals(this.lastScroll)) {
                this.lastScroll.set(scroll);
                PointF center = Camera.main.center().offset(scroll);
                this.angle = ((float) Math.atan2((double) (this.cellCenter.f24x - center.f24x), (double) (center.f25y - this.cellCenter.f25y))) * RAD_2_G;
            }
        }
    }
}
