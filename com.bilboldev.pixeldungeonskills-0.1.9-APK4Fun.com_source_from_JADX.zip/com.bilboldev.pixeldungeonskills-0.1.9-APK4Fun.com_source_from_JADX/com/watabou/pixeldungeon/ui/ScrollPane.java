package com.watabou.pixeldungeon.ui;

import com.watabou.input.Touchscreen.Touch;
import com.watabou.noosa.Camera;
import com.watabou.noosa.TouchArea;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.utils.Point;
import com.watabou.utils.PointF;

public class ScrollPane extends Component {
    protected Component content;
    protected TouchController controller;
    protected float maxX;
    protected float maxY;
    protected float minX;
    protected float minY;

    public class TouchController extends TouchArea {
        private float dragThreshold;
        private boolean dragging;
        private PointF lastPos;

        public TouchController() {
            super(0.0f, 0.0f, 0.0f, 0.0f);
            this.dragging = false;
            this.lastPos = new PointF();
            this.dragThreshold = PixelScene.defaultZoom * 8.0f;
        }

        protected void onClick(Touch touch) {
            if (this.dragging) {
                this.dragging = false;
                return;
            }
            PointF p = ScrollPane.this.content.camera.screenToCamera((int) touch.current.f24x, (int) touch.current.f25y);
            ScrollPane.this.onClick(p.f24x, p.f25y);
        }

        protected void onDrag(Touch t) {
            if (this.dragging) {
                Camera c = ScrollPane.this.content.camera;
                c.scroll.offset(PointF.diff(this.lastPos, t.current).invScale(c.zoom));
                if (c.scroll.f24x + this.width > ScrollPane.this.content.width()) {
                    c.scroll.f24x = ScrollPane.this.content.width() - this.width;
                }
                if (c.scroll.f24x < 0.0f) {
                    c.scroll.f24x = 0.0f;
                }
                if (c.scroll.f25y + this.height > ScrollPane.this.content.height()) {
                    c.scroll.f25y = ScrollPane.this.content.height() - this.height;
                }
                if (c.scroll.f25y < 0.0f) {
                    c.scroll.f25y = 0.0f;
                }
                this.lastPos.set(t.current);
            } else if (PointF.distance(t.current, t.start) > this.dragThreshold) {
                this.dragging = true;
                this.lastPos.set(t.current);
            }
        }
    }

    public ScrollPane(Component content) {
        this.content = content;
        addToBack(content);
        this.width = content.width();
        this.height = content.height();
        content.camera = new Camera(0, 0, 1, 1, PixelScene.defaultZoom);
        Camera.add(content.camera);
    }

    public void destroy() {
        super.destroy();
        Camera.remove(this.content.camera);
    }

    public void scrollTo(float x, float y) {
        this.content.camera.scroll.set(x, y);
    }

    protected void createChildren() {
        this.controller = new TouchController();
        add(this.controller);
    }

    protected void layout() {
        this.content.setPos(0.0f, 0.0f);
        this.controller.x = this.x;
        this.controller.y = this.y;
        this.controller.width = this.width;
        this.controller.height = this.height;
        Point p = camera().cameraToScreen(this.x, this.y);
        Camera cs = this.content.camera;
        cs.f6x = p.f18x;
        cs.f7y = p.f19y;
        cs.resize((int) this.width, (int) this.height);
    }

    public Component content() {
        return this.content;
    }

    public void onClick(float x, float y) {
    }
}
