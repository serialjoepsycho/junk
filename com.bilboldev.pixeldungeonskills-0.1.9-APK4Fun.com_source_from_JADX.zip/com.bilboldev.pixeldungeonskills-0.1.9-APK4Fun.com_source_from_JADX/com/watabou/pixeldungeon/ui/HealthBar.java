package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.ColorBlock;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;

public class HealthBar extends Component {
    private static final int COLOR_BG = -3407872;
    private static final int COLOR_LVL = -16716288;
    private static final int HEIGHT = 2;
    private ColorBlock hpBg;
    private ColorBlock hpLvl;
    private float level;

    protected void createChildren() {
        this.hpBg = new ColorBlock(Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, COLOR_BG);
        add(this.hpBg);
        this.hpLvl = new ColorBlock(Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, COLOR_LVL);
        add(this.hpLvl);
        this.height = Pickaxe.TIME_TO_MINE;
    }

    protected void layout() {
        ColorBlock colorBlock = this.hpBg;
        ColorBlock colorBlock2 = this.hpLvl;
        float f = this.x;
        colorBlock2.x = f;
        colorBlock.x = f;
        colorBlock = this.hpBg;
        colorBlock2 = this.hpLvl;
        f = this.y;
        colorBlock2.y = f;
        colorBlock.y = f;
        this.hpBg.size(this.width, Pickaxe.TIME_TO_MINE);
        this.hpLvl.size(this.width * this.level, Pickaxe.TIME_TO_MINE);
        this.height = Pickaxe.TIME_TO_MINE;
    }

    public void level(float value) {
        this.level = value;
        layout();
    }
}
