package com.watabou.pixeldungeon.ui;

import com.watabou.input.Keys;
import com.watabou.input.Keys.Key;
import com.watabou.input.Touchscreen.Touch;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Game;
import com.watabou.noosa.Group;
import com.watabou.noosa.NinePatch;
import com.watabou.noosa.TouchArea;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.Chrome;
import com.watabou.pixeldungeon.Chrome.Type;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Signal.Listener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Window extends Group implements Listener<Key> {
    public static final int TITLE_COLOR = 16777028;
    protected TouchArea blocker;
    protected NinePatch chrome;
    protected int height;
    protected ShadowBox shadow;
    protected int width;

    /* renamed from: com.watabou.pixeldungeon.ui.Window.1 */
    class C01631 extends TouchArea {
        C01631(float x, float y, float width, float height) {
            super(x, y, width, height);
        }

        protected void onClick(Touch touch) {
            if (!Window.this.chrome.overlapsScreenPoint((int) touch.current.f24x, (int) touch.current.f25y)) {
                Window.this.onBackPressed();
            }
        }
    }

    protected static class Highlighter {
        private static final Pattern HIGHLIGHTER;
        private static final Pattern STRIPPER;
        public boolean[] mask;
        public String text;

        static {
            HIGHLIGHTER = Pattern.compile("_(.*?)_");
            STRIPPER = Pattern.compile("[ \n]");
        }

        public Highlighter(String text) {
            String stripped = STRIPPER.matcher(text).replaceAll(BuildConfig.VERSION_NAME);
            this.mask = new boolean[stripped.length()];
            Matcher m = HIGHLIGHTER.matcher(stripped);
            int pos = 0;
            int lastMatch = 0;
            while (m.find()) {
                pos += m.start() - lastMatch;
                int groupLen = m.group(1).length();
                for (int i = pos; i < pos + groupLen; i++) {
                    this.mask[i] = true;
                }
                pos += groupLen;
                lastMatch = m.end();
            }
            m.reset(text);
            StringBuffer sb = new StringBuffer();
            while (m.find()) {
                m.appendReplacement(sb, m.group(1));
            }
            m.appendTail(sb);
            this.text = sb.toString();
        }

        public boolean[] inverted() {
            boolean[] result = new boolean[this.mask.length];
            for (int i = 0; i < result.length; i++) {
                result[i] = !this.mask[i];
            }
            return result;
        }

        public boolean isHighlighted() {
            for (boolean z : this.mask) {
                if (z) {
                    return true;
                }
            }
            return false;
        }
    }

    public Window() {
        this(0, 0, Chrome.get(Type.WINDOW));
    }

    public Window(int width, int height) {
        this(width, height, Chrome.get(Type.WINDOW));
    }

    public Window(int width, int height, NinePatch chrome) {
        this.blocker = new C01631(0.0f, 0.0f, (float) PixelScene.uiCamera.width, (float) PixelScene.uiCamera.height);
        this.blocker.camera = PixelScene.uiCamera;
        add(this.blocker);
        this.chrome = chrome;
        this.width = width;
        this.height = height;
        this.shadow = new ShadowBox();
        this.shadow.am = 0.5f;
        this.shadow.camera = PixelScene.uiCamera.visible ? PixelScene.uiCamera : Camera.main;
        add(this.shadow);
        chrome.x = (float) (-chrome.marginLeft());
        chrome.y = (float) (-chrome.marginTop());
        chrome.size((((float) width) - chrome.x) + ((float) chrome.marginRight()), (((float) height) - chrome.y) + ((float) chrome.marginBottom()));
        add(chrome);
        this.camera = new Camera(0, 0, (int) chrome.width, (int) chrome.height, PixelScene.defaultZoom);
        this.camera.f6x = ((int) (((float) Game.width) - (((float) this.camera.width) * this.camera.zoom))) / 2;
        this.camera.f7y = ((int) (((float) Game.height) - (((float) this.camera.height) * this.camera.zoom))) / 2;
        this.camera.scroll.set(chrome.x, chrome.y);
        Camera.add(this.camera);
        this.shadow.boxRect(((float) this.camera.f6x) / this.camera.zoom, ((float) this.camera.f7y) / this.camera.zoom, chrome.width(), chrome.height);
        Keys.event.add(this);
    }

    public void resize(int w, int h) {
        this.width = w;
        this.height = h;
        this.chrome.size((float) (this.width + this.chrome.marginHor()), (float) (this.height + this.chrome.marginVer()));
        this.camera.resize((int) this.chrome.width, (int) this.chrome.height);
        this.camera.f6x = ((int) (((float) Game.width) - this.camera.screenWidth())) / 2;
        this.camera.f7y = ((int) (((float) Game.height) - this.camera.screenHeight())) / 2;
        this.shadow.boxRect(((float) this.camera.f6x) / this.camera.zoom, ((float) this.camera.f7y) / this.camera.zoom, this.chrome.width(), this.chrome.height);
    }

    public void hide() {
        this.parent.erase(this);
        destroy();
    }

    public void destroy() {
        super.destroy();
        Camera.remove(this.camera);
        Keys.event.remove(this);
    }

    public void onSignal(Key key) {
        if (key.pressed) {
            switch (key.code) {
                case WndUpdates.ID_HALLS /*4*/:
                    onBackPressed();
                    break;
                case ItemSpriteSheet.MASTERY /*82*/:
                    onMenuPressed();
                    break;
            }
        }
        Keys.event.cancel();
    }

    public void onBackPressed() {
        hide();
    }

    public void onMenuPressed() {
    }
}
