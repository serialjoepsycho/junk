package com.watabou.pixeldungeon.ui;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Heap.Type;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;

public class LootIndicator extends Tag {
    private Item lastItem;
    private int lastQuantity;
    private ItemSlot slot;

    /* renamed from: com.watabou.pixeldungeon.ui.LootIndicator.1 */
    class C01521 extends ItemSlot {
        C01521() {
        }

        protected void onClick() {
            Dungeon.hero.handle(Dungeon.hero.pos);
        }
    }

    public LootIndicator() {
        super(2061772);
        this.lastItem = null;
        this.lastQuantity = 0;
        setSize(24.0f, 22.0f);
        this.visible = false;
    }

    protected void createChildren() {
        super.createChildren();
        this.slot = new C01521();
        this.slot.showParams(false);
        add(this.slot);
    }

    protected void layout() {
        super.layout();
        this.slot.setRect(this.x + Pickaxe.TIME_TO_MINE, this.y + CurareDart.DURATION, this.width - Pickaxe.TIME_TO_MINE, this.height - 6.0f);
    }

    public void update() {
        boolean z = true;
        if (Dungeon.hero.ready) {
            Heap heap = (Heap) Dungeon.level.heaps.get(Dungeon.hero.pos);
            if (heap != null) {
                Item item = (heap.type == Type.CHEST || heap.type == Type.MIMIC) ? ItemSlot.CHEST : heap.type == Type.LOCKED_CHEST ? ItemSlot.LOCKED_CHEST : heap.type == Type.TOMB ? ItemSlot.TOMB : heap.type == Type.SKELETON ? ItemSlot.SKELETON : heap.peek();
                if (!(item == this.lastItem && item.quantity() == this.lastQuantity)) {
                    this.lastItem = item;
                    this.lastQuantity = item.quantity();
                    this.slot.item(item);
                    flash();
                }
                this.visible = true;
            } else {
                this.lastItem = null;
                this.visible = false;
            }
        }
        ItemSlot itemSlot = this.slot;
        if (!(this.visible && Dungeon.hero.ready)) {
            z = false;
        }
        itemSlot.enable(z);
        super.update();
    }
}
