package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Image;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.windows.WndUpdates;

public enum Icons {
    SKULL,
    BUSY,
    COMPASS,
    PREFS,
    WARNING,
    TARGET,
    WATA,
    WARRIOR,
    MAGE,
    ROGUE,
    HUNTRESS,
    CLOSE,
    DEPTH,
    SLEEP,
    ALERT,
    SUPPORT,
    SUPPORTED,
    BACKPACK,
    SEED_POUCH,
    SCROLL_HOLDER,
    WAND_HOLSTER,
    KEYRING,
    CHECKED,
    UNCHECKED,
    EXIT,
    CHALLENGE_OFF,
    CHALLENGE_ON,
    RESUME;

    /* renamed from: com.watabou.pixeldungeon.ui.Icons.1 */
    static /* synthetic */ class C01471 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass;
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$ui$Icons;

        static {
            $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass = new int[HeroClass.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.WARRIOR.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.MAGE.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.ROGUE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.HUNTRESS.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            $SwitchMap$com$watabou$pixeldungeon$ui$Icons = new int[Icons.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.SKULL.ordinal()] = 1;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.BUSY.ordinal()] = 2;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.COMPASS.ordinal()] = 3;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.PREFS.ordinal()] = 4;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.WARNING.ordinal()] = 5;
            } catch (NoSuchFieldError e9) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.TARGET.ordinal()] = 6;
            } catch (NoSuchFieldError e10) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.WATA.ordinal()] = 7;
            } catch (NoSuchFieldError e11) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.WARRIOR.ordinal()] = 8;
            } catch (NoSuchFieldError e12) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.MAGE.ordinal()] = 9;
            } catch (NoSuchFieldError e13) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.ROGUE.ordinal()] = 10;
            } catch (NoSuchFieldError e14) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.HUNTRESS.ordinal()] = 11;
            } catch (NoSuchFieldError e15) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.CLOSE.ordinal()] = 12;
            } catch (NoSuchFieldError e16) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.DEPTH.ordinal()] = 13;
            } catch (NoSuchFieldError e17) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.SLEEP.ordinal()] = 14;
            } catch (NoSuchFieldError e18) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.ALERT.ordinal()] = 15;
            } catch (NoSuchFieldError e19) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.SUPPORT.ordinal()] = 16;
            } catch (NoSuchFieldError e20) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.SUPPORTED.ordinal()] = 17;
            } catch (NoSuchFieldError e21) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.BACKPACK.ordinal()] = 18;
            } catch (NoSuchFieldError e22) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.SCROLL_HOLDER.ordinal()] = 19;
            } catch (NoSuchFieldError e23) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.SEED_POUCH.ordinal()] = 20;
            } catch (NoSuchFieldError e24) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.WAND_HOLSTER.ordinal()] = 21;
            } catch (NoSuchFieldError e25) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.KEYRING.ordinal()] = 22;
            } catch (NoSuchFieldError e26) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.CHECKED.ordinal()] = 23;
            } catch (NoSuchFieldError e27) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.UNCHECKED.ordinal()] = 24;
            } catch (NoSuchFieldError e28) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.EXIT.ordinal()] = 25;
            } catch (NoSuchFieldError e29) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.CHALLENGE_OFF.ordinal()] = 26;
            } catch (NoSuchFieldError e30) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.CHALLENGE_ON.ordinal()] = 27;
            } catch (NoSuchFieldError e31) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Icons[Icons.RESUME.ordinal()] = 28;
            } catch (NoSuchFieldError e32) {
            }
        }
    }

    public Image get() {
        return get(this);
    }

    public static Image get(Icons type) {
        Image icon = new Image(Assets.ICONS);
        switch (C01471.$SwitchMap$com$watabou$pixeldungeon$ui$Icons[type.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                icon.frame(icon.texture.uvRect(0, 0, 8, 8));
                break;
            case WndUpdates.ID_CAVES /*2*/:
                icon.frame(icon.texture.uvRect(8, 0, 16, 8));
                break;
            case WndUpdates.ID_METROPOLIS /*3*/:
                icon.frame(icon.texture.uvRect(0, 8, 7, 13));
                break;
            case WndUpdates.ID_HALLS /*4*/:
                icon.frame(icon.texture.uvRect(30, 0, 46, 16));
                break;
            case BuffIndicator.HUNGER /*5*/:
                icon.frame(icon.texture.uvRect(46, 0, 58, 12));
                break;
            case BuffIndicator.STARVATION /*6*/:
                icon.frame(icon.texture.uvRect(0, 13, 16, 29));
                break;
            case BuffIndicator.SLOW /*7*/:
                icon.frame(icon.texture.uvRect(30, 16, 45, 26));
                break;
            case BuffIndicator.OOZE /*8*/:
                icon.frame(icon.texture.uvRect(0, 29, 16, 45));
                break;
            case BuffIndicator.AMOK /*9*/:
                icon.frame(icon.texture.uvRect(16, 29, 32, 45));
                break;
            case BuffIndicator.TERROR /*10*/:
                icon.frame(icon.texture.uvRect(32, 29, 48, 45));
                break;
            case BuffIndicator.ROOTS /*11*/:
                icon.frame(icon.texture.uvRect(48, 29, 64, 45));
                break;
            case BuffIndicator.INVISIBLE /*12*/:
                icon.frame(icon.texture.uvRect(0, 45, 13, 58));
                break;
            case BuffIndicator.SHADOWS /*13*/:
                icon.frame(icon.texture.uvRect(45, 12, 54, 20));
                break;
            case BuffIndicator.WEAKNESS /*14*/:
                icon.frame(icon.texture.uvRect(13, 45, 22, 53));
                break;
            case BuffIndicator.FROST /*15*/:
                icon.frame(icon.texture.uvRect(22, 45, 30, 53));
                break;
            case BuffIndicator.BLINDNESS /*16*/:
                icon.frame(icon.texture.uvRect(30, 45, 46, 61));
                break;
            case BuffIndicator.COMBO /*17*/:
                icon.frame(icon.texture.uvRect(46, 45, 62, 61));
                break;
            case BuffIndicator.FURY /*18*/:
                icon.frame(icon.texture.uvRect(58, 0, 68, 10));
                break;
            case BuffIndicator.HEALING /*19*/:
                icon.frame(icon.texture.uvRect(68, 0, 78, 10));
                break;
            case BuffIndicator.ARMOR /*20*/:
                icon.frame(icon.texture.uvRect(78, 0, 88, 10));
                break;
            case BuffIndicator.HEART /*21*/:
                icon.frame(icon.texture.uvRect(88, 0, 98, 10));
                break;
            case BuffIndicator.LIGHT /*22*/:
                icon.frame(icon.texture.uvRect(64, 29, 74, 39));
                break;
            case BuffIndicator.CRIPPLE /*23*/:
                icon.frame(icon.texture.uvRect(54, 12, 66, 24));
                break;
            case BuffIndicator.BARKSKIN /*24*/:
                icon.frame(icon.texture.uvRect(66, 12, 78, 24));
                break;
            case BuffIndicator.IMMUNITY /*25*/:
                icon.frame(icon.texture.uvRect(98, 0, ItemSpriteSheet.STEAK, 16));
                break;
            case ItemButton.SIZE /*26*/:
                icon.frame(icon.texture.uvRect(78, 16, ItemSpriteSheet.ORE, 40));
                break;
            case BuffIndicator.MARK /*27*/:
                icon.frame(icon.texture.uvRect(ItemSpriteSheet.ORE, 16, ItemSpriteSheet.KEYRING, 40));
                break;
            case BuffIndicator.DEFERRED /*28*/:
                icon.frame(icon.texture.uvRect(ItemSpriteSheet.STEAK, 0, ItemSpriteSheet.KEYRING, 11));
                break;
        }
        return icon;
    }

    public static Image get(HeroClass cl) {
        switch (C01471.$SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[cl.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                return get(WARRIOR);
            case WndUpdates.ID_CAVES /*2*/:
                return get(MAGE);
            case WndUpdates.ID_METROPOLIS /*3*/:
                return get(ROGUE);
            case WndUpdates.ID_HALLS /*4*/:
                return get(HUNTRESS);
            default:
                return null;
        }
    }
}
