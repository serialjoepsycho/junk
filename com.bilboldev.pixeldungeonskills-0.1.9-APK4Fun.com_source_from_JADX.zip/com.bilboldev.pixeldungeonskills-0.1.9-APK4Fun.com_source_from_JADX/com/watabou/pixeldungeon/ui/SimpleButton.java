package com.watabou.pixeldungeon.ui;

import com.watabou.input.Touchscreen.Touch;
import com.watabou.noosa.Image;
import com.watabou.noosa.TouchArea;
import com.watabou.noosa.Visual;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.items.keys.Key;

public class SimpleButton extends Component {
    private Image image;

    /* renamed from: com.watabou.pixeldungeon.ui.SimpleButton.1 */
    class C01541 extends TouchArea {
        C01541(Visual target) {
            super(target);
        }

        protected void onTouchDown(Touch touch) {
            SimpleButton.this.image.brightness(1.2f);
        }

        protected void onTouchUp(Touch touch) {
            SimpleButton.this.image.brightness(Key.TIME_TO_UNLOCK);
        }

        protected void onClick(Touch touch) {
            SimpleButton.this.onClick();
        }
    }

    public SimpleButton(Image image) {
        this.image.copy(image);
        this.width = image.width;
        this.height = image.height;
    }

    protected void createChildren() {
        this.image = new Image();
        add(this.image);
        add(new C01541(this.image));
    }

    protected void layout() {
        this.image.x = this.x;
        this.image.y = this.y;
    }

    protected void onClick() {
    }
}
