package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Game;
import com.watabou.noosa.Image;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.windows.WndUpdates;

public class Banner extends Image {
    private int color;
    private float fadeTime;
    private float showTime;
    private State state;
    private float time;

    /* renamed from: com.watabou.pixeldungeon.ui.Banner.1 */
    static /* synthetic */ class C01451 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$ui$Banner$State;

        static {
            $SwitchMap$com$watabou$pixeldungeon$ui$Banner$State = new int[State.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Banner$State[State.FADE_IN.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Banner$State[State.STATIC.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$ui$Banner$State[State.FADE_OUT.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    private enum State {
        FADE_IN,
        STATIC,
        FADE_OUT
    }

    public Banner(Image sample) {
        copy(sample);
        alpha(0.0f);
    }

    public Banner(Object tx) {
        super(tx);
        alpha(0.0f);
    }

    public void show(int color, float fadeTime, float showTime) {
        this.color = color;
        this.fadeTime = fadeTime;
        this.showTime = showTime;
        this.state = State.FADE_IN;
        this.time = fadeTime;
    }

    public void show(int color, float fadeTime) {
        show(color, fadeTime, Float.MAX_VALUE);
    }

    public void update() {
        super.update();
        this.time -= Game.elapsed;
        if (this.time >= 0.0f) {
            float p = this.time / this.fadeTime;
            switch (C01451.$SwitchMap$com$watabou$pixeldungeon$ui$Banner$State[this.state.ordinal()]) {
                case WndUpdates.ID_PRISON /*1*/:
                    tint(this.color, p);
                    alpha(Key.TIME_TO_UNLOCK - p);
                    return;
                case WndUpdates.ID_METROPOLIS /*3*/:
                    alpha(p);
                    return;
                default:
                    return;
            }
        }
        switch (C01451.$SwitchMap$com$watabou$pixeldungeon$ui$Banner$State[this.state.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                this.time = this.showTime;
                this.state = State.STATIC;
            case WndUpdates.ID_CAVES /*2*/:
                this.time = this.fadeTime;
                this.state = State.FADE_OUT;
            case WndUpdates.ID_METROPOLIS /*3*/:
                killAndErase();
            default:
        }
    }
}
