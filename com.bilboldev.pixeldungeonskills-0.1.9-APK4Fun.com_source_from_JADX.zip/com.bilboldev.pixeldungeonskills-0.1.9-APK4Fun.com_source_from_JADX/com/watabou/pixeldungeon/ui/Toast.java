package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Image;
import com.watabou.noosa.NinePatch;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.Chrome;
import com.watabou.pixeldungeon.Chrome.Type;
import com.watabou.pixeldungeon.scenes.PixelScene;

public class Toast extends Component {
    private static final float MARGIN_HOR = 2.0f;
    private static final float MARGIN_VER = 2.0f;
    protected NinePatch bg;
    protected SimpleButton close;
    protected BitmapText text;

    /* renamed from: com.watabou.pixeldungeon.ui.Toast.1 */
    class C01561 extends SimpleButton {
        C01561(Image image) {
            super(image);
        }

        protected void onClick() {
            Toast.this.onClose();
        }
    }

    public Toast(String text) {
        text(text);
        this.width = ((this.text.width() + this.close.width()) + ((float) this.bg.marginHor())) + 6.0f;
        this.height = (Math.max(this.text.height(), this.close.height()) + ((float) this.bg.marginVer())) + 4.0f;
    }

    protected void createChildren() {
        super.createChildren();
        this.bg = Chrome.get(Type.TOAST_TR);
        add(this.bg);
        this.close = new C01561(Icons.get(Icons.CLOSE));
        add(this.close);
        this.text = PixelScene.createText(8.0f);
        add(this.text);
    }

    protected void layout() {
        super.layout();
        this.bg.x = this.x;
        this.bg.y = this.y;
        this.bg.size(this.width, this.height);
        this.close.setPos((((this.bg.x + this.bg.width()) - ((float) (this.bg.marginHor() / 2))) - MARGIN_VER) - this.close.width(), this.y + ((this.height - this.close.height()) / MARGIN_VER));
        this.text.x = (this.close.left() - MARGIN_VER) - this.text.width();
        this.text.y = this.y + ((this.height - this.text.height()) / MARGIN_VER);
        PixelScene.align(this.text);
    }

    public void text(String txt) {
        this.text.text(txt);
        this.text.measure();
    }

    protected void onClose() {
    }
}
