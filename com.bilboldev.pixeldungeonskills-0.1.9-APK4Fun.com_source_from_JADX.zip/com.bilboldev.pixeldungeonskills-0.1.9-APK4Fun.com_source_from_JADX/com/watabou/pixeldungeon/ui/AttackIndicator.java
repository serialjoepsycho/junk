package com.watabou.pixeldungeon.ui;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class AttackIndicator extends Tag {
    private static final float DISABLED = 0.3f;
    private static final float ENABLED = 1.0f;
    private static AttackIndicator instance;
    private static Mob lastTarget;
    private ArrayList<Mob> candidates;
    private boolean enabled;
    private CharSprite sprite;

    static {
        lastTarget = null;
    }

    public AttackIndicator() {
        super(DangerIndicator.COLOR);
        this.sprite = null;
        this.candidates = new ArrayList();
        this.enabled = true;
        instance = this;
        setSize(24.0f, 24.0f);
        visible(false);
        enable(false);
    }

    protected void createChildren() {
        super.createChildren();
    }

    protected void layout() {
        super.layout();
        if (this.sprite != null) {
            this.sprite.x = this.x + ((this.width - this.sprite.width()) / Pickaxe.TIME_TO_MINE);
            this.sprite.y = this.y + ((this.height - this.sprite.height()) / Pickaxe.TIME_TO_MINE);
            PixelScene.align(this.sprite);
        }
    }

    public void update() {
        super.update();
        if (!Dungeon.hero.isAlive()) {
            visible(false);
            enable(false);
        } else if (!Dungeon.hero.ready) {
            enable(false);
        }
    }

    private void checkEnemies() {
        int heroPos = Dungeon.hero.pos;
        this.candidates.clear();
        int v = Dungeon.hero.visibleEnemies();
        for (int i = 0; i < v; i++) {
            Mob mob = Dungeon.hero.visibleEnemy(i);
            if (Level.adjacent(heroPos, mob.pos)) {
                this.candidates.add(mob);
            }
        }
        if (this.candidates.contains(lastTarget)) {
            if (!this.bg.visible) {
                flash();
            }
        } else if (this.candidates.isEmpty()) {
            lastTarget = null;
        } else {
            lastTarget = (Mob) Random.element(this.candidates);
            updateImage();
            flash();
        }
        visible(lastTarget != null);
        enable(this.bg.visible);
    }

    private void updateImage() {
        if (this.sprite != null) {
            this.sprite.killAndErase();
            this.sprite = null;
        }
        try {
            this.sprite = (CharSprite) lastTarget.spriteClass.newInstance();
            this.sprite.idle();
            this.sprite.paused = true;
            add(this.sprite);
            this.sprite.x = (this.x + ((this.width - this.sprite.width()) / Pickaxe.TIME_TO_MINE)) + ENABLED;
            this.sprite.y = this.y + ((this.height - this.sprite.height()) / Pickaxe.TIME_TO_MINE);
            PixelScene.align(this.sprite);
        } catch (Exception e) {
        }
    }

    private void enable(boolean value) {
        this.enabled = value;
        if (this.sprite != null) {
            this.sprite.alpha(value ? ENABLED : DISABLED);
        }
    }

    private void visible(boolean value) {
        this.bg.visible = value;
        if (this.sprite != null) {
            this.sprite.visible = value;
        }
    }

    protected void onClick() {
        if (this.enabled) {
            Dungeon.hero.handle(lastTarget.pos);
        }
    }

    public static void target(Char target) {
        lastTarget = (Mob) target;
        instance.updateImage();
        HealthIndicator.instance.target(target);
    }

    public static void updateState() {
        instance.checkEnemies();
    }
}
