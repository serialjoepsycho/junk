package com.watabou.pixeldungeon.ui;

import com.watabou.gltextures.TextureCache;
import com.watabou.noosa.Image;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.sprites.CharSprite;

public class HealthIndicator extends Component {
    private static final float HEIGHT = 2.0f;
    public static HealthIndicator instance;
    private Image bg;
    private Image level;
    private Char target;

    public HealthIndicator() {
        instance = this;
    }

    protected void createChildren() {
        this.bg = new Image(TextureCache.createSolid(-3407872));
        this.bg.scale.f25y = HEIGHT;
        add(this.bg);
        this.level = new Image(TextureCache.createSolid(-16724992));
        this.level.scale.f25y = HEIGHT;
        add(this.level);
    }

    public void update() {
        super.update();
        if (this.target != null && this.target.isAlive() && this.target.sprite.visible) {
            CharSprite sprite = this.target.sprite;
            this.bg.scale.f24x = sprite.width;
            this.level.scale.f24x = (sprite.width * ((float) this.target.HP)) / ((float) this.target.HT);
            Image image = this.bg;
            Image image2 = this.level;
            float f = sprite.x;
            image2.x = f;
            image.x = f;
            image = this.bg;
            f = (sprite.y - HEIGHT) - Key.TIME_TO_UNLOCK;
            this.level.y = f;
            image.y = f;
            this.visible = true;
            return;
        }
        this.visible = false;
    }

    public void target(Char ch) {
        if (ch == null || !ch.isAlive()) {
            this.target = null;
        } else {
            this.target = ch;
        }
    }

    public Char target() {
        return this.target;
    }
}
