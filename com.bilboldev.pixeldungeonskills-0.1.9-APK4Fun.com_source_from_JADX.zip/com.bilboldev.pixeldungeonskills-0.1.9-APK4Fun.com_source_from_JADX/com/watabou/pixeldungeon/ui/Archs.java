package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.Game;
import com.watabou.noosa.SkinnedBlock;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;

public class Archs extends Component {
    private static final float SCROLL_SPEED = 20.0f;
    private static float offsB;
    private static float offsF;
    private SkinnedBlock arcsBg;
    private SkinnedBlock arcsFg;
    public boolean reversed;

    public Archs() {
        this.reversed = false;
    }

    static {
        offsB = 0.0f;
        offsF = 0.0f;
    }

    protected void createChildren() {
        this.arcsBg = new SkinnedBlock(Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Assets.ARCS_BG);
        this.arcsBg.offsetTo(0.0f, offsB);
        add(this.arcsBg);
        this.arcsFg = new SkinnedBlock(Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Assets.ARCS_FG);
        this.arcsFg.offsetTo(0.0f, offsF);
        add(this.arcsFg);
    }

    protected void layout() {
        this.arcsBg.size(this.width, this.height);
        this.arcsBg.offset(((float) (this.arcsBg.texture.width / 4)) - ((this.width % ((float) this.arcsBg.texture.width)) / Pickaxe.TIME_TO_MINE), 0.0f);
        this.arcsFg.size(this.width, this.height);
        this.arcsFg.offset(((float) (this.arcsFg.texture.width / 4)) - ((this.width % ((float) this.arcsFg.texture.width)) / Pickaxe.TIME_TO_MINE), 0.0f);
    }

    public void update() {
        super.update();
        float shift = Game.elapsed * SCROLL_SPEED;
        if (this.reversed) {
            shift = -shift;
        }
        this.arcsBg.offset(0.0f, shift);
        this.arcsFg.offset(0.0f, Pickaxe.TIME_TO_MINE * shift);
        offsB = this.arcsBg.offsetY();
        offsF = this.arcsFg.offsetY();
    }
}
