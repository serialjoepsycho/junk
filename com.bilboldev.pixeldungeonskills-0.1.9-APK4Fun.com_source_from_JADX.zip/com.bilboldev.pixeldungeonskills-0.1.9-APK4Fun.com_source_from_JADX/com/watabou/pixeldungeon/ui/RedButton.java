package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Image;
import com.watabou.noosa.NinePatch;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Chrome;
import com.watabou.pixeldungeon.Chrome.Type;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.scenes.PixelScene;

public class RedButton extends Button {
    protected NinePatch bg;
    protected Image icon;
    protected BitmapText text;

    public RedButton(String label) {
        this.text.text(label);
        this.text.measure();
    }

    protected void createChildren() {
        super.createChildren();
        this.bg = Chrome.get(Type.BUTTON);
        add(this.bg);
        this.text = PixelScene.createText(9.0f);
        add(this.text);
    }

    protected void layout() {
        super.layout();
        this.bg.x = this.x;
        this.bg.y = this.y;
        this.bg.size(this.width, this.height);
        this.text.x = this.x + ((float) (((int) (this.width - this.text.width())) / 2));
        this.text.y = this.y + ((float) (((int) (this.height - this.text.baseLine())) / 2));
        if (this.icon != null) {
            this.icon.x = ((this.x + this.text.x) - this.icon.width()) - Pickaxe.TIME_TO_MINE;
            this.icon.y = this.y + ((this.height - this.icon.height()) / Pickaxe.TIME_TO_MINE);
        }
    }

    protected void onTouchDown() {
        this.bg.brightness(1.2f);
        Sample.INSTANCE.play(Assets.SND_CLICK);
    }

    protected void onTouchUp() {
        this.bg.resetColor();
    }

    public void enable(boolean value) {
        this.active = value;
        this.text.alpha(value ? Key.TIME_TO_UNLOCK : 0.3f);
    }

    public void text(String value) {
        this.text.text(value);
        this.text.measure();
        layout();
    }

    public void textColor(int value) {
        this.text.hardlight(value);
    }

    public void icon(Image icon) {
        if (this.icon != null) {
            remove(this.icon);
        }
        this.icon = icon;
        if (this.icon != null) {
            add(this.icon);
            layout();
        }
    }

    public float reqWidth() {
        return this.text.width() + 4.0f;
    }

    public float reqHeight() {
        return this.text.baseLine() + 4.0f;
    }
}
