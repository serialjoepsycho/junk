package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.melee.MeleeWeapon;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.utils.Utils;

public class ItemSlot extends Button {
    public static final Item CHEST;
    public static final int DEGRADED = 16729156;
    private static final float DISABLED = 0.3f;
    private static final float ENABLED = 1.0f;
    public static final Item LOCKED_CHEST;
    public static final Item SKELETON;
    public static final Item TOMB;
    private static final String TXT_CURSED = "";
    private static final String TXT_LEVEL = "%+d";
    private static final String TXT_STRENGTH = ":%d";
    private static final String TXT_TYPICAL_STR = "%d?";
    public static final int UPGRADED = 4521796;
    public static final int WARNING = 16746496;
    protected BitmapText bottomRight;
    protected ItemSprite icon;
    protected BitmapText topLeft;
    protected BitmapText topRight;

    /* renamed from: com.watabou.pixeldungeon.ui.ItemSlot.1 */
    static class C01481 extends Item {
        C01481() {
        }

        public int image() {
            return 11;
        }
    }

    /* renamed from: com.watabou.pixeldungeon.ui.ItemSlot.2 */
    static class C01492 extends Item {
        C01492() {
        }

        public int image() {
            return 12;
        }
    }

    /* renamed from: com.watabou.pixeldungeon.ui.ItemSlot.3 */
    static class C01503 extends Item {
        C01503() {
        }

        public int image() {
            return 13;
        }
    }

    /* renamed from: com.watabou.pixeldungeon.ui.ItemSlot.4 */
    static class C01514 extends Item {
        C01514() {
        }

        public int image() {
            return 0;
        }
    }

    static {
        CHEST = new C01481();
        LOCKED_CHEST = new C01492();
        TOMB = new C01503();
        SKELETON = new C01514();
    }

    public ItemSlot(Item item) {
        this();
        item(item);
    }

    protected void createChildren() {
        super.createChildren();
        this.icon = new ItemSprite();
        add(this.icon);
        this.topLeft = new BitmapText(PixelScene.font1x);
        add(this.topLeft);
        this.topRight = new BitmapText(PixelScene.font1x);
        add(this.topRight);
        this.bottomRight = new BitmapText(PixelScene.font1x);
        add(this.bottomRight);
    }

    protected void layout() {
        super.layout();
        this.icon.x = this.x + ((this.width - this.icon.width) / Pickaxe.TIME_TO_MINE);
        this.icon.y = this.y + ((this.height - this.icon.height) / Pickaxe.TIME_TO_MINE);
        if (this.topLeft != null) {
            this.topLeft.x = this.x;
            this.topLeft.y = this.y;
        }
        if (this.topRight != null) {
            this.topRight.x = this.x + (this.width - this.topRight.width());
            this.topRight.y = this.y;
        }
        if (this.bottomRight != null) {
            this.bottomRight.x = this.x + (this.width - this.bottomRight.width());
            this.bottomRight.y = this.y + (this.height - this.bottomRight.height());
        }
    }

    public void item(Item item) {
        if (item == null) {
            this.active = false;
            ItemSprite itemSprite = this.icon;
            BitmapText bitmapText = this.topLeft;
            BitmapText bitmapText2 = this.topRight;
            this.bottomRight.visible = false;
            bitmapText2.visible = false;
            bitmapText.visible = false;
            itemSprite.visible = false;
            return;
        }
        int typicalSTR;
        this.active = true;
        itemSprite = this.icon;
        bitmapText2 = this.topLeft;
        BitmapText bitmapText3 = this.topRight;
        this.bottomRight.visible = true;
        bitmapText3.visible = true;
        bitmapText2.visible = true;
        itemSprite.visible = true;
        this.icon.view(item.image(), item.glowing());
        this.topLeft.text(item.status());
        boolean isArmor = item instanceof Armor;
        boolean isWeapon = item instanceof Weapon;
        if (isArmor || isWeapon) {
            if (item.levelKnown || (isWeapon && !(item instanceof MeleeWeapon))) {
                this.topRight.text(Utils.format(TXT_STRENGTH, Integer.valueOf(isArmor ? ((Armor) item).STR : ((Weapon) item).STR)));
                if ((isArmor ? ((Armor) item).STR : ((Weapon) item).STR) > Dungeon.hero.STR()) {
                    this.topRight.hardlight(DEGRADED);
                } else {
                    this.topRight.resetColor();
                }
            } else {
                bitmapText2 = this.topRight;
                String str = TXT_TYPICAL_STR;
                Object[] objArr = new Object[1];
                if (isArmor) {
                    typicalSTR = ((Armor) item).typicalSTR();
                } else {
                    typicalSTR = ((MeleeWeapon) item).typicalSTR();
                }
                objArr[0] = Integer.valueOf(typicalSTR);
                bitmapText2.text(Utils.format(str, objArr));
                this.topRight.hardlight(WARNING);
            }
            this.topRight.measure();
        } else {
            this.topRight.text(null);
        }
        int level = item.visiblyUpgraded();
        if (level != 0 || (item.cursed && item.cursedKnown)) {
            this.bottomRight.text(item.levelKnown ? Utils.format(TXT_LEVEL, Integer.valueOf(level)) : TXT_CURSED);
            this.bottomRight.measure();
            bitmapText2 = this.bottomRight;
            if (level > 0) {
                typicalSTR = UPGRADED;
            } else {
                typicalSTR = DEGRADED;
            }
            bitmapText2.hardlight(typicalSTR);
        } else {
            this.bottomRight.text(null);
        }
        layout();
    }

    public void enable(boolean value) {
        this.active = value;
        float alpha = value ? ENABLED : DISABLED;
        this.icon.alpha(alpha);
        this.topLeft.alpha(alpha);
        this.topRight.alpha(alpha);
        this.bottomRight.alpha(alpha);
    }

    public void showParams(boolean value) {
        if (value) {
            add(this.topRight);
            add(this.bottomRight);
            return;
        }
        remove(this.topRight);
        remove(this.bottomRight);
    }
}
