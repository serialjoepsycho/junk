package com.watabou.pixeldungeon.ui;

import com.watabou.input.Touchscreen.Touch;
import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Image;
import com.watabou.noosa.NinePatch;
import com.watabou.noosa.TouchArea;
import com.watabou.noosa.Visual;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.particles.Emitter;
import com.watabou.noosa.ui.Button;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.particles.BloodParticle;
import com.watabou.pixeldungeon.items.keys.IronKey;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.HeroSprite;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.windows.WndGame;
import com.watabou.pixeldungeon.windows.WndHero;

public class StatusPane extends Component {
    private Image avatar;
    private Emitter blood;
    private MenuButton btnMenu;
    private BuffIndicator buffs;
    private Compass compass;
    private DangerIndicator danger;
    private BitmapText depth;
    private Image exp;
    private Image hp;
    private BitmapText keys;
    private int lastKeys;
    private int lastLvl;
    private int lastTier;
    private BitmapText level;
    private LootIndicator loot;
    private Image mp;
    private ResumeButton resume;
    private NinePatch shield;
    private boolean tagDanger;
    private boolean tagLoot;
    private boolean tagResume;

    /* renamed from: com.watabou.pixeldungeon.ui.StatusPane.1 */
    class C01551 extends TouchArea {
        C01551(float x, float y, float width, float height) {
            super(x, y, width, height);
        }

        protected void onClick(Touch touch) {
            Visual sprite = Dungeon.hero.sprite;
            if (!sprite.isVisible()) {
                Camera.main.focusOn(sprite);
            }
            GameScene.show(new WndHero());
        }
    }

    private static class MenuButton extends Button {
        private Image image;

        public MenuButton() {
            this.width = this.image.width + 4.0f;
            this.height = this.image.height + 4.0f;
        }

        protected void createChildren() {
            super.createChildren();
            this.image = new Image(Assets.STATUS, ItemSpriteSheet.STEAK, 3, 12, 11);
            add(this.image);
        }

        protected void layout() {
            super.layout();
            this.image.x = this.x + Pickaxe.TIME_TO_MINE;
            this.image.y = this.y + Pickaxe.TIME_TO_MINE;
        }

        protected void onTouchDown() {
            this.image.brightness(Sleep.SWS);
            Sample.INSTANCE.play(Assets.SND_CLICK);
        }

        protected void onTouchUp() {
            this.image.resetColor();
        }

        protected void onClick() {
            GameScene.show(new WndGame());
        }
    }

    public StatusPane() {
        this.lastTier = 0;
        this.lastLvl = -1;
        this.lastKeys = -1;
        this.tagDanger = false;
        this.tagLoot = false;
        this.tagResume = false;
    }

    protected void createChildren() {
        this.shield = new NinePatch(Assets.STATUS, 80, 0, 48, 0);
        add(this.shield);
        add(new C01551(0.0f, Key.TIME_TO_UNLOCK, 30.0f, 30.0f));
        this.btnMenu = new MenuButton();
        add(this.btnMenu);
        this.avatar = HeroSprite.avatar(Dungeon.hero.heroClass, this.lastTier);
        add(this.avatar);
        this.blood = new Emitter();
        this.blood.pos(this.avatar);
        this.blood.pour(BloodParticle.FACTORY, 0.3f);
        this.blood.autoKill = false;
        this.blood.on = false;
        add(this.blood);
        this.compass = new Compass(Dungeon.level.exit);
        add(this.compass);
        this.hp = new Image(Assets.HP_BAR);
        add(this.hp);
        this.mp = new Image(Assets.MP_BAR);
        add(this.mp);
        this.exp = new Image(Assets.XP_BAR);
        add(this.exp);
        this.level = new BitmapText(PixelScene.font1x);
        this.level.hardlight(16772004);
        add(this.level);
        this.depth = new BitmapText(Integer.toString(Dungeon.depth), PixelScene.font1x);
        this.depth.hardlight(13291458);
        this.depth.measure();
        add(this.depth);
        Dungeon.hero.belongings.countIronKeys();
        this.keys = new BitmapText(PixelScene.font1x);
        this.keys.hardlight(13291458);
        add(this.keys);
        this.danger = new DangerIndicator();
        add(this.danger);
        this.loot = new LootIndicator();
        add(this.loot);
        this.resume = new ResumeButton();
        add(this.resume);
        this.buffs = new BuffIndicator(Dungeon.hero);
        add(this.buffs);
    }

    protected void layout() {
        this.height = 32.0f;
        this.shield.size(this.width, this.shield.height);
        this.avatar.x = PixelScene.align(camera(), (this.shield.x + Invisibility.DURATION) - (this.avatar.width / Pickaxe.TIME_TO_MINE));
        this.avatar.y = PixelScene.align(camera(), (this.shield.y + ShadowBox.SIZE) - (this.avatar.height / Pickaxe.TIME_TO_MINE));
        this.compass.x = (this.avatar.x + (this.avatar.width / Pickaxe.TIME_TO_MINE)) - this.compass.origin.f24x;
        this.compass.y = (this.avatar.y + (this.avatar.height / Pickaxe.TIME_TO_MINE)) - this.compass.origin.f25y;
        this.hp.x = 30.0f;
        this.hp.y = CurareDart.DURATION;
        this.mp.x = 30.0f;
        this.mp.y = 8.0f;
        this.depth.x = ((this.width - 24.0f) - this.depth.width()) - 18.0f;
        this.depth.y = 6.0f;
        this.keys.y = 6.0f;
        layoutTags();
        this.buffs.setPos(35.0f, ShadowBox.SIZE);
        this.btnMenu.setPos(this.width - this.btnMenu.width(), Key.TIME_TO_UNLOCK);
    }

    private void layoutTags() {
        float pos = 18.0f;
        if (this.tagDanger) {
            this.danger.setPos(this.width - this.danger.width(), 18.0f);
            pos = this.danger.bottom() + Key.TIME_TO_UNLOCK;
        }
        if (this.tagLoot) {
            this.loot.setPos(this.width - this.loot.width(), pos);
            pos = this.loot.bottom() + Key.TIME_TO_UNLOCK;
        }
        if (this.tagResume) {
            this.resume.setPos(this.width - this.resume.width(), pos);
        }
    }

    public void update() {
        super.update();
        if (!(this.tagDanger == this.danger.visible && this.tagLoot == this.loot.visible && this.tagResume == this.resume.visible)) {
            this.tagDanger = this.danger.visible;
            this.tagLoot = this.loot.visible;
            this.tagResume = this.resume.visible;
            layoutTags();
        }
        float health = ((float) Dungeon.hero.HP) / ((float) Dungeon.hero.HT);
        if (health == 0.0f) {
            this.avatar.tint(0, 0.6f);
            this.blood.on = false;
        } else if (health < 0.25f) {
            this.avatar.tint(13369344, 0.4f);
            this.blood.on = true;
        } else {
            this.avatar.resetColor();
            this.blood.on = false;
        }
        this.hp.scale.f24x = health;
        this.mp.scale.f24x = ((float) Dungeon.hero.MP) / ((float) Dungeon.hero.MMP);
        this.exp.scale.f24x = ((this.width / this.exp.width) * ((float) Dungeon.hero.exp)) / ((float) Dungeon.hero.maxExp());
        if (Dungeon.hero.lvl != this.lastLvl) {
            if (this.lastLvl != -1) {
                Emitter emitter = (Emitter) recycle(Emitter.class);
                emitter.revive();
                emitter.pos(27.0f, 27.0f);
                emitter.burst(Speck.factory(1), 12);
            }
            this.lastLvl = Dungeon.hero.lvl;
            this.level.text(Integer.toString(this.lastLvl));
            this.level.measure();
            this.level.x = PixelScene.align(27.0f - (this.level.width() / Pickaxe.TIME_TO_MINE));
            this.level.y = PixelScene.align(27.5f - (this.level.baseLine() / Pickaxe.TIME_TO_MINE));
        }
        int k = IronKey.curDepthQuantity;
        if (k != this.lastKeys) {
            this.lastKeys = k;
            this.keys.text(Integer.toString(this.lastKeys));
            this.keys.measure();
            this.keys.x = ((this.width - 8.0f) - this.keys.width()) - 18.0f;
        }
        int tier = Dungeon.hero.tier();
        if (tier != this.lastTier) {
            this.lastTier = tier;
            this.avatar.copy(HeroSprite.avatar(Dungeon.hero.heroClass, tier));
        }
    }
}
