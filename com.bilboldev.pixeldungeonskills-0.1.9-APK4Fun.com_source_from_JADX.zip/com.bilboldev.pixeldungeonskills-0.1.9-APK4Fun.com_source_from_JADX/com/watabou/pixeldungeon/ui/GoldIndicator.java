package com.watabou.pixeldungeon.ui;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Game;
import com.watabou.noosa.ui.Component;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.CharSprite;

public class GoldIndicator extends Component {
    private static final float TIME = 2.0f;
    private int lastValue;
    private BitmapText tf;
    private float time;

    public GoldIndicator() {
        this.lastValue = 0;
    }

    protected void createChildren() {
        this.tf = new BitmapText(PixelScene.font1x);
        this.tf.hardlight(CharSprite.NEUTRAL);
        add(this.tf);
        this.visible = false;
    }

    protected void layout() {
        this.tf.x = this.x + ((this.width - this.tf.width()) / TIME);
        this.tf.y = bottom() - this.tf.height();
    }

    public void update() {
        float f = Key.TIME_TO_UNLOCK;
        super.update();
        if (this.visible) {
            this.time -= Game.elapsed;
            if (this.time > 0.0f) {
                BitmapText bitmapText = this.tf;
                if (this.time <= Key.TIME_TO_UNLOCK) {
                    f = (this.time * TIME) / TIME;
                }
                bitmapText.alpha(f);
            } else {
                this.visible = false;
            }
        }
        if (Dungeon.gold != this.lastValue) {
            this.lastValue = Dungeon.gold;
            this.tf.text(Integer.toString(this.lastValue));
            this.tf.measure();
            this.visible = true;
            this.time = TIME;
            layout();
        }
    }
}
