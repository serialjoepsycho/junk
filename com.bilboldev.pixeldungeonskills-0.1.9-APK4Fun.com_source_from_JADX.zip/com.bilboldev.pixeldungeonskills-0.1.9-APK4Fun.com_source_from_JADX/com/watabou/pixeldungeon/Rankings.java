package com.watabou.pixeldungeon;

import com.watabou.noosa.Game;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.SystemTime;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public enum Rankings {
    INSTANCE;
    
    public static final String DETAILS_FILE = "game_%d.dat";
    private static final String LATEST = "latest";
    public static final String RANKINGS_FILE = "rankings.dat";
    private static final String RECORDS = "records";
    public static final int TABLE_SIZE = 6;
    private static final String TOTAL = "total";
    private static final String WON = "won";
    private static final Comparator<Record> scoreComparator;
    public int lastRecord;
    public ArrayList<Record> records;
    public int totalNumber;
    public int wonNumber;

    /* renamed from: com.watabou.pixeldungeon.Rankings.1 */
    static class C00171 implements Comparator<Record> {
        C00171() {
        }

        public int compare(Record lhs, Record rhs) {
            return (int) Math.signum((float) (rhs.score - lhs.score));
        }
    }

    public static class Record implements Bundlable {
        private static final String GAME = "gameFile";
        private static final String REASON = "reason";
        private static final String SCORE = "score";
        private static final String TIER = "tier";
        private static final String WIN = "win";
        public int armorTier;
        public String gameFile;
        public HeroClass heroClass;
        public String info;
        public int score;
        public boolean win;

        public void restoreFromBundle(Bundle bundle) {
            this.info = bundle.getString(REASON);
            this.win = bundle.getBoolean(WIN);
            this.score = bundle.getInt(SCORE);
            this.heroClass = HeroClass.restoreInBundle(bundle);
            this.armorTier = bundle.getInt(TIER);
            this.gameFile = bundle.getString(GAME);
        }

        public void storeInBundle(Bundle bundle) {
            bundle.put(REASON, this.info);
            bundle.put(WIN, this.win);
            bundle.put(SCORE, this.score);
            this.heroClass.storeInBundle(bundle);
            bundle.put(TIER, this.armorTier);
            bundle.put(GAME, this.gameFile);
        }
    }

    static {
        scoreComparator = new C00171();
    }

    public void submit(boolean win) {
        load();
        Record rec = new Record();
        rec.info = Dungeon.resultDescription;
        rec.win = win;
        rec.heroClass = Dungeon.hero.heroClass;
        rec.armorTier = Dungeon.hero.tier();
        rec.score = score(win);
        String gameFile = Utils.format(DETAILS_FILE, Long.valueOf(SystemTime.now));
        try {
            Dungeon.saveGame(gameFile);
            rec.gameFile = gameFile;
        } catch (IOException e) {
            rec.gameFile = BuildConfig.VERSION_NAME;
        }
        this.records.add(rec);
        Collections.sort(this.records, scoreComparator);
        this.lastRecord = this.records.indexOf(rec);
        int size = this.records.size();
        if (size > TABLE_SIZE) {
            Record removedGame;
            if (this.lastRecord == size - 1) {
                removedGame = (Record) this.records.remove(size - 2);
                this.lastRecord--;
            } else {
                removedGame = (Record) this.records.remove(size - 1);
            }
            if (removedGame.gameFile.length() > 0) {
                Game.instance.deleteFile(removedGame.gameFile);
            }
        }
        this.totalNumber++;
        if (win) {
            this.wonNumber++;
        }
        Badges.validateGamesPlayed();
        save();
    }

    private int score(boolean win) {
        return (win ? 2 : 1) * (((Dungeon.hero.lvl * Dungeon.depth) * 100) + Statistics.goldCollected);
    }

    public void save() {
        Bundle bundle = new Bundle();
        bundle.put(RECORDS, this.records);
        bundle.put(LATEST, this.lastRecord);
        bundle.put(TOTAL, this.totalNumber);
        bundle.put(WON, this.wonNumber);
        try {
            OutputStream output = Game.instance.openFileOutput(RANKINGS_FILE, 0);
            Bundle.write(bundle, output);
            output.close();
        } catch (Exception e) {
        }
    }

    public void load() {
        if (this.records == null) {
            this.records = new ArrayList();
            try {
                Iterator it;
                InputStream input = Game.instance.openFileInput(RANKINGS_FILE);
                Bundle bundle = Bundle.read(input);
                input.close();
                for (Bundlable record : bundle.getCollection(RECORDS)) {
                    this.records.add((Record) record);
                }
                this.lastRecord = bundle.getInt(LATEST);
                this.totalNumber = bundle.getInt(TOTAL);
                if (this.totalNumber == 0) {
                    this.totalNumber = this.records.size();
                }
                this.wonNumber = bundle.getInt(WON);
                if (this.wonNumber == 0) {
                    it = this.records.iterator();
                    while (it.hasNext()) {
                        if (((Record) it.next()).win) {
                            this.wonNumber++;
                        }
                    }
                }
            } catch (Exception e) {
            }
        }
    }
}
