package com.watabou.pixeldungeon.scenes;

import android.opengl.GLES20;
import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Game;
import com.watabou.noosa.Gizmo;
import com.watabou.noosa.Image;
import com.watabou.noosa.audio.Music;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.effects.BannerSprites;
import com.watabou.pixeldungeon.effects.BannerSprites.Type;
import com.watabou.pixeldungeon.effects.Fireball;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.ui.Archs;
import com.watabou.pixeldungeon.ui.ExitButton;
import com.watabou.pixeldungeon.ui.PrefsButton;
import com.watabou.pixeldungeon.windows.WndDonations;

public class TitleScene extends PixelScene {
    private static final String TXT_ABOUT = "About";
    private static final String TXT_BADGES = "Badges";
    private static final String TXT_HIGHSCORES = "Rankings";
    private static final String TXT_PLAY = "Play";

    /* renamed from: com.watabou.pixeldungeon.scenes.TitleScene.1 */
    class C01301 extends Image {
        private float time;

        C01301(Image src) {
            super(src);
            this.time = 0.0f;
        }

        public void update() {
            super.update();
            float f = this.time + Game.elapsed;
            this.time = f;
            this.am = (float) Math.sin((double) (-f));
        }

        public void draw() {
            GLES20.glBlendFunc(770, 1);
            super.draw();
            GLES20.glBlendFunc(770, 771);
        }
    }

    private static class DashboardItem extends Button {
        private static final int IMAGE_SIZE = 32;
        public static final float SIZE = 48.0f;
        private Image image;
        private BitmapText label;

        public DashboardItem(String text, int index) {
            this.image.frame(this.image.texture.uvRect(index * IMAGE_SIZE, 0, (index + 1) * IMAGE_SIZE, IMAGE_SIZE));
            this.label.text(text);
            this.label.measure();
            setSize(SIZE, SIZE);
        }

        protected void createChildren() {
            super.createChildren();
            this.image = new Image(Assets.DASHBOARD);
            add(this.image);
            this.label = PixelScene.createText(9.0f);
            add(this.label);
        }

        protected void layout() {
            super.layout();
            this.image.x = PixelScene.align(this.x + ((this.width - this.image.width()) / Pickaxe.TIME_TO_MINE));
            this.image.y = PixelScene.align(this.y);
            this.label.x = PixelScene.align(this.x + ((this.width - this.label.width()) / Pickaxe.TIME_TO_MINE));
            this.label.y = PixelScene.align((this.image.y + this.image.height()) + Pickaxe.TIME_TO_MINE);
        }

        protected void onTouchDown() {
            this.image.brightness(Sleep.SWS);
            Sample.INSTANCE.play(Assets.SND_CLICK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, 0.8f);
        }

        protected void onTouchUp() {
            this.image.resetColor();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.TitleScene.2 */
    class C01312 extends DashboardItem {
        C01312(String text, int index) {
            super(text, index);
        }

        protected void onClick() {
            PixelDungeon.switchNoFade(BadgesScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.TitleScene.3 */
    class C01323 extends DashboardItem {
        C01323(String text, int index) {
            super(text, index);
        }

        protected void onClick() {
            PixelDungeon.switchNoFade(AboutScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.TitleScene.4 */
    class C01334 extends DashboardItem {
        C01334(String text, int index) {
            super(text, index);
        }

        protected void onClick() {
            PixelDungeon.switchNoFade(StartScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.TitleScene.5 */
    class C01345 extends DashboardItem {
        C01345(String text, int index) {
            super(text, index);
        }

        protected void onClick() {
            PixelDungeon.switchNoFade(RankingsScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.TitleScene.6 */
    class C01356 extends DashboardItem {
        C01356(String text, int index) {
            super(text, index);
        }

        protected void onClick() {
            this.parent.add(new WndDonations());
        }
    }

    public void create() {
        super.create();
        Music.INSTANCE.play(Assets.THEME, true);
        Music.INSTANCE.volume(Key.TIME_TO_UNLOCK);
        uiCamera.visible = false;
        int w = Camera.main.width;
        int h = Camera.main.height;
        Archs archs = new Archs();
        archs.setSize((float) w, (float) h);
        add(archs);
        Image title = BannerSprites.get(Type.PIXEL_DUNGEON);
        add(title);
        float height = title.height + (PixelDungeon.landscape() ? DashboardItem.SIZE : 96.0f);
        title.x = (((float) w) - title.width()) / Pickaxe.TIME_TO_MINE;
        title.y = (((float) h) - height) / Pickaxe.TIME_TO_MINE;
        placeTorch(title.x + 18.0f, title.y + MindVision.DURATION);
        placeTorch((title.x + title.width) - 18.0f, title.y + MindVision.DURATION);
        Image signs = new C01301(BannerSprites.get(Type.PIXEL_DUNGEON_SIGNS));
        signs.x = title.x;
        signs.y = title.y;
        add(signs);
        DashboardItem btnBadges = new C01312(TXT_BADGES, 3);
        add(btnBadges);
        DashboardItem btnAbout = new C01323(TXT_ABOUT, 1);
        add(btnAbout);
        DashboardItem btnPlay = new C01334(TXT_PLAY, 0);
        add(btnPlay);
        DashboardItem btnHighscores = new C01345(TXT_HIGHSCORES, 2);
        add(btnHighscores);
        DashboardItem btndonate = new C01356("Donate", 4);
        add(btndonate);
        if (PixelDungeon.landscape()) {
            float y = ((((float) h) + height) / Pickaxe.TIME_TO_MINE) - DashboardItem.SIZE;
            btnHighscores.setPos((((float) (w / 2)) - btnHighscores.width()) - (btnHighscores.width() / Pickaxe.TIME_TO_MINE), y);
            btnBadges.setPos(((float) (w / 2)) - (btnBadges.width() / Pickaxe.TIME_TO_MINE), y);
            btnPlay.setPos(btnHighscores.left() - btnPlay.width(), y);
            btnAbout.setPos(btnBadges.right(), y);
            btndonate.setPos(btnAbout.right(), y);
        } else {
            btnBadges.setPos(((float) (w / 2)) - btnBadges.width(), ((((float) h) + height) / Pickaxe.TIME_TO_MINE) - DashboardItem.SIZE);
            btnAbout.setPos((float) (w / 2), ((((float) h) + height) / Pickaxe.TIME_TO_MINE) - DashboardItem.SIZE);
            btnPlay.setPos(((float) (w / 2)) - btnPlay.width(), btnAbout.top() - DashboardItem.SIZE);
            btnHighscores.setPos((float) (w / 2), btnPlay.top());
            btndonate.setPos(((float) (w / 2)) - (btndonate.width() / Pickaxe.TIME_TO_MINE), btnAbout.top() + btnAbout.height());
        }
        BitmapText version = new BitmapText("v " + Game.version, font1x);
        version.measure();
        version.hardlight(CharSprite.DEFAULT);
        version.x = ((float) w) - version.width();
        version.y = (((float) h) - version.height()) - 9.0f;
        add(version);
        Gizmo bitmapText = new BitmapText("PD v 1.7.5a", font1x);
        bitmapText.measure();
        bitmapText.hardlight(6710886);
        bitmapText.x = ((float) w) - bitmapText.width();
        bitmapText.y = ((float) h) - bitmapText.height();
        add(bitmapText);
        PrefsButton btnPrefs = new PrefsButton();
        btnPrefs.setPos(0.0f, 0.0f);
        add(btnPrefs);
        ExitButton btnExit = new ExitButton();
        btnExit.setPos(((float) w) - btnExit.width(), 0.0f);
        add(btnExit);
        fadeIn();
    }

    private void placeTorch(float x, float y) {
        Fireball fb = new Fireball();
        fb.setPos(x, y);
        add(fb);
    }
}
