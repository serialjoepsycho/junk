package com.watabou.pixeldungeon.scenes;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Game;
import com.watabou.noosa.NinePatch;
import com.watabou.noosa.audio.Music;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Chrome;
import com.watabou.pixeldungeon.Chrome.Type;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.ui.Archs;
import com.watabou.pixeldungeon.ui.BadgesList;
import com.watabou.pixeldungeon.ui.ExitButton;
import com.watabou.pixeldungeon.ui.ScrollPane;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.utils.Callback;

public class BadgesScene extends PixelScene {
    private static final int MAX_PANE_WIDTH = 160;
    private static final String TXT_TITLE = "Your Badges";

    /* renamed from: com.watabou.pixeldungeon.scenes.BadgesScene.1 */
    class C01131 implements Callback {
        C01131() {
        }

        public void call() {
            if (Game.scene() == BadgesScene.this) {
                PixelDungeon.switchNoFade(BadgesScene.class);
            }
        }
    }

    public void create() {
        super.create();
        Music.INSTANCE.play(Assets.THEME, true);
        Music.INSTANCE.volume(Key.TIME_TO_UNLOCK);
        uiCamera.visible = false;
        int w = Camera.main.width;
        int h = Camera.main.height;
        Archs archs = new Archs();
        archs.setSize((float) w, (float) h);
        add(archs);
        int pw = Math.min(MAX_PANE_WIDTH, w - 6);
        int ph = h - 30;
        NinePatch panel = Chrome.get(Type.WINDOW);
        panel.size((float) pw, (float) ph);
        panel.x = (float) ((w - pw) / 2);
        panel.y = (float) ((h - ph) / 2);
        add(panel);
        BitmapText title = PixelScene.createText(TXT_TITLE, 9.0f);
        title.hardlight(Window.TITLE_COLOR);
        title.measure();
        title.x = PixelScene.align((((float) w) - title.width()) / Pickaxe.TIME_TO_MINE);
        title.y = PixelScene.align((panel.y - title.baseLine()) / Pickaxe.TIME_TO_MINE);
        add(title);
        Badges.loadGlobal();
        ScrollPane list = new BadgesList(true);
        add(list);
        list.setRect(panel.x + ((float) panel.marginLeft()), panel.y + ((float) panel.marginTop()), panel.innerWidth(), panel.innerHeight());
        ExitButton btnExit = new ExitButton();
        btnExit.setPos(((float) Camera.main.width) - btnExit.width(), 0.0f);
        add(btnExit);
        fadeIn();
        Badges.loadingListener = new C01131();
    }

    public void destroy() {
        Badges.saveGlobal();
        Badges.loadingListener = null;
        super.destroy();
    }

    protected void onBackPressed() {
        PixelDungeon.switchNoFade(TitleScene.class);
    }
}
