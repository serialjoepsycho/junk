package com.watabou.pixeldungeon.scenes;

import com.watabou.noosa.Game;
import com.watabou.pixeldungeon.windows.WndStory;

public class IntroScene extends PixelScene {
    private static final String TEXT = "Many heroes of all kinds ventured into the Dungeon before you. Some of them have returned with treasures and magical artifacts, most have never been heard of since. But none have succeeded in retrieving the Amulet of Yendor, which is told to be hidden in the depths of the Dungeon.\n\nYou consider yourself ready for the challenge, but most importantly, you feel that fortune smiles on you. It's time to start your own adventure!";

    /* renamed from: com.watabou.pixeldungeon.scenes.IntroScene.1 */
    class C01201 extends WndStory {
        C01201(String text) {
            super(text);
        }

        public void hide() {
            super.hide();
            Game.switchScene(InterlevelScene.class);
        }
    }

    public void create() {
        super.create();
        add(new C01201(TEXT));
        fadeIn();
    }
}
