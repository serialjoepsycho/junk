package com.watabou.pixeldungeon.scenes;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Image;
import com.watabou.noosa.audio.Music;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.Rankings;
import com.watabou.pixeldungeon.effects.Flare;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.ui.Archs;
import com.watabou.pixeldungeon.ui.ExitButton;
import com.watabou.pixeldungeon.ui.Icons;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.windows.WndError;
import com.watabou.pixeldungeon.windows.WndRanking;
import java.util.Iterator;

public class RankingsScene extends PixelScene {
    private static final int DEFAULT_COLOR = 13421772;
    private static final float GAP = 4.0f;
    private static final float MAX_ROW_WIDTH = 180.0f;
    private static final float ROW_HEIGHT_L = 22.0f;
    private static final float ROW_HEIGHT_P = 28.0f;
    private static final String TXT_NO_GAMES = "No games have been played yet.";
    private static final String TXT_NO_INFO = "No additional information";
    private static final String TXT_TITLE = "Top Rankings";
    private static final String TXT_TOTAL = "Games played: ";
    private Archs archs;

    public static class Record extends Button {
        private static final int FLARE_LOSE = 6710886;
        private static final int FLARE_WIN = 8947814;
        private static final float GAP = 4.0f;
        private static final int TEXT_LOSE = 13421772;
        private static final int TEXT_WIN = 16777096;
        private Image classIcon;
        private BitmapTextMultiline desc;
        private Flare flare;
        private BitmapText position;
        private com.watabou.pixeldungeon.Rankings.Record rec;
        private ItemSprite shield;

        public Record(int pos, boolean latest, com.watabou.pixeldungeon.Rankings.Record rec) {
            this.rec = rec;
            if (latest) {
                this.flare = new Flare(6, 24.0f);
                this.flare.angularSpeed = 90.0f;
                this.flare.color(rec.win ? FLARE_WIN : FLARE_LOSE);
                addToBack(this.flare);
            }
            this.position.text(Integer.toString(pos + 1));
            this.position.measure();
            this.desc.text(rec.info);
            this.desc.measure();
            if (rec.win) {
                this.shield.view(87, null);
                this.position.hardlight(TEXT_WIN);
                this.desc.hardlight(TEXT_WIN);
            } else {
                this.position.hardlight(TEXT_LOSE);
                this.desc.hardlight(TEXT_LOSE);
            }
            this.classIcon.copy(Icons.get(rec.heroClass));
        }

        protected void createChildren() {
            super.createChildren();
            this.shield = new ItemSprite(13, null);
            add(this.shield);
            this.position = new BitmapText(PixelScene.font1x);
            add(this.position);
            this.desc = PixelScene.createMultiline(9.0f);
            add(this.desc);
            this.classIcon = new Image();
            add(this.classIcon);
        }

        protected void layout() {
            super.layout();
            this.shield.x = this.x;
            this.shield.y = this.y + ((this.height - this.shield.height) / Pickaxe.TIME_TO_MINE);
            this.position.x = PixelScene.align(this.shield.x + ((this.shield.width - this.position.width()) / Pickaxe.TIME_TO_MINE));
            this.position.y = PixelScene.align((this.shield.y + ((this.shield.height - this.position.height()) / Pickaxe.TIME_TO_MINE)) + Key.TIME_TO_UNLOCK);
            if (this.flare != null) {
                this.flare.point(this.shield.center());
            }
            this.classIcon.x = PixelScene.align((this.x + this.width) - this.classIcon.width);
            this.classIcon.y = this.shield.y;
            this.desc.x = (this.shield.x + this.shield.width) + GAP;
            this.desc.maxWidth = (int) (this.classIcon.x - this.desc.x);
            this.desc.measure();
            this.desc.y = (this.position.y + this.position.baseLine()) - this.desc.baseLine();
        }

        protected void onClick() {
            if (this.rec.gameFile.length() > 0) {
                this.parent.add(new WndRanking(this.rec.gameFile));
            } else {
                this.parent.add(new WndError(RankingsScene.TXT_NO_INFO));
            }
        }
    }

    public void create() {
        super.create();
        Music.INSTANCE.play(Assets.THEME, true);
        Music.INSTANCE.volume(Key.TIME_TO_UNLOCK);
        uiCamera.visible = false;
        int w = Camera.main.width;
        int h = Camera.main.height;
        this.archs = new Archs();
        this.archs.setSize((float) w, (float) h);
        add(this.archs);
        Rankings.INSTANCE.load();
        BitmapText title;
        if (Rankings.INSTANCE.records.size() > 0) {
            float rowHeight = PixelDungeon.landscape() ? ROW_HEIGHT_L : ROW_HEIGHT_P;
            float left = ((((float) w) - Math.min(MAX_ROW_WIDTH, (float) w)) / Pickaxe.TIME_TO_MINE) + GAP;
            float top = PixelScene.align((((float) h) - (((float) Rankings.INSTANCE.records.size()) * rowHeight)) / Pickaxe.TIME_TO_MINE);
            title = PixelScene.createText("Top Rankings (SPD)", 9.0f);
            title.hardlight(Window.TITLE_COLOR);
            title.measure();
            title.x = PixelScene.align((((float) w) - title.width()) / Pickaxe.TIME_TO_MINE);
            title.y = PixelScene.align((top - title.height()) - GAP);
            add(title);
            int pos = 0;
            Iterator it = Rankings.INSTANCE.records.iterator();
            while (it.hasNext()) {
                Record row = new Record(pos, pos == Rankings.INSTANCE.lastRecord, (com.watabou.pixeldungeon.Rankings.Record) it.next());
                row.setRect(left, (((float) pos) * rowHeight) + top, ((float) w) - (Pickaxe.TIME_TO_MINE * left), rowHeight);
                add(row);
                pos++;
            }
            if (Rankings.INSTANCE.totalNumber >= 6) {
                BitmapText label = PixelScene.createText(TXT_TOTAL, 8.0f);
                label.hardlight(DEFAULT_COLOR);
                label.measure();
                add(label);
                BitmapText won = PixelScene.createText(Integer.toString(Rankings.INSTANCE.wonNumber), 8.0f);
                won.hardlight(Window.TITLE_COLOR);
                won.measure();
                add(won);
                BitmapText total = PixelScene.createText("/" + Rankings.INSTANCE.totalNumber, 8.0f);
                total.hardlight(DEFAULT_COLOR);
                total.measure();
                total.x = PixelScene.align((((float) w) - total.width()) / Pickaxe.TIME_TO_MINE);
                total.y = PixelScene.align(((((float) pos) * rowHeight) + top) + GAP);
                add(total);
                label.x = PixelScene.align((((float) w) - ((label.width() + won.width()) + total.width())) / Pickaxe.TIME_TO_MINE);
                won.x = label.x + label.width();
                total.x = won.x + won.width();
                float align = PixelScene.align(((((float) pos) * rowHeight) + top) + GAP);
                total.y = align;
                won.y = align;
                label.y = align;
            }
        } else {
            title = PixelScene.createText(TXT_NO_GAMES, 8.0f);
            title.hardlight(DEFAULT_COLOR);
            title.measure();
            title.x = PixelScene.align((((float) w) - title.width()) / Pickaxe.TIME_TO_MINE);
            title.y = PixelScene.align((((float) h) - title.height()) / Pickaxe.TIME_TO_MINE);
            add(title);
        }
        ExitButton btnExit = new ExitButton();
        btnExit.setPos(((float) Camera.main.width) - btnExit.width(), 0.0f);
        add(btnExit);
        fadeIn();
    }

    protected void onBackPressed() {
        PixelDungeon.switchNoFade(TitleScene.class);
    }
}
