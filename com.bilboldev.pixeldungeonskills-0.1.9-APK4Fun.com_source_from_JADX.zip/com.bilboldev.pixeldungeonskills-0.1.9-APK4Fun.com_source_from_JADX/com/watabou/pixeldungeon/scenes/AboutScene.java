package com.watabou.pixeldungeon.scenes;

import android.content.Intent;
import android.net.Uri;
import com.watabou.input.Touchscreen.Touch;
import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Game;
import com.watabou.noosa.Image;
import com.watabou.noosa.TouchArea;
import com.watabou.noosa.Visual;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.effects.Flare;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.Archs;
import com.watabou.pixeldungeon.ui.ExitButton;
import com.watabou.pixeldungeon.ui.Icons;
import com.watabou.pixeldungeon.ui.Window;

public class AboutScene extends PixelScene {
    private static final String LNK = "pixeldungeon.watabou.ru";
    private static final String TXT = "Code & graphics: Watabou\nMusic: Cube_Code\n\nThis game is inspired by Brian Walker's Brogue. Try it on Windows, Mac OS or Linux - it's awesome! ;)\n\nPlease visit official website for additional info:";
    private static final String TXTFirst = "SkillFull Pixel Dungeon is coded by BilbolDev\nBased on Pixel Dugeaon made by Watabou\n                                             ";

    /* renamed from: com.watabou.pixeldungeon.scenes.AboutScene.1 */
    class C01101 extends TouchArea {
        C01101(Visual target) {
            super(target);
        }

        protected void onClick(Touch touch) {
            Game.instance.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://pixeldungeon.watabou.ru")));
        }
    }

    public void create() {
        super.create();
        BitmapTextMultiline textfirst = PixelScene.createMultiline(TXTFirst, 8.0f);
        textfirst.maxWidth = Math.min(Camera.main.width, ItemSpriteSheet.VIAL);
        textfirst.measure();
        add(textfirst);
        textfirst.x = PixelScene.align((((float) Camera.main.width) - textfirst.width()) / Pickaxe.TIME_TO_MINE);
        textfirst.y = PixelScene.align((((float) Camera.main.height) - textfirst.height()) / Pickaxe.TIME_TO_MINE) - 40.0f;
        BitmapTextMultiline text = PixelScene.createMultiline(TXT, 8.0f);
        text.maxWidth = Math.min(Camera.main.width, ItemSpriteSheet.VIAL);
        text.measure();
        add(text);
        text.x = PixelScene.align((((float) Camera.main.width) - text.width()) / Pickaxe.TIME_TO_MINE);
        text.y = PixelScene.align((((float) Camera.main.height) - text.height()) / Pickaxe.TIME_TO_MINE) + 30.0f;
        BitmapTextMultiline link = PixelScene.createMultiline(LNK, 8.0f);
        link.maxWidth = Math.min(Camera.main.width, ItemSpriteSheet.VIAL);
        link.measure();
        link.hardlight(Window.TITLE_COLOR);
        add(link);
        link.x = text.x;
        link.y = text.y + text.height();
        add(new C01101(link));
        Image wata = Icons.WATA.get();
        wata.x = PixelScene.align((((float) Camera.main.width) - wata.width) / Pickaxe.TIME_TO_MINE);
        wata.y = (text.y - wata.height) - 8.0f;
        add(wata);
        new Flare(7, 64.0f).color(1122867, true).show(wata, 0.0f).angularSpeed = MindVision.DURATION;
        Archs archs = new Archs();
        archs.setSize((float) Camera.main.width, (float) Camera.main.height);
        addToBack(archs);
        ExitButton btnExit = new ExitButton();
        btnExit.setPos(((float) Camera.main.width) - btnExit.width(), 0.0f);
        add(btnExit);
        fadeIn();
    }

    protected void onBackPressed() {
        PixelDungeon.switchNoFade(TitleScene.class);
    }
}
