package com.watabou.pixeldungeon.scenes;

import com.watabou.input.Touchscreen.Touch;
import com.watabou.noosa.TouchArea;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.utils.GameMath;
import com.watabou.utils.PointF;

public class CellSelector extends TouchArea {
    private Touch another;
    private float dragThreshold;
    private boolean dragging;
    public boolean enabled;
    private PointF lastPos;
    public Listener listener;
    private boolean pinching;
    private float startSpan;
    private float startZoom;

    public interface Listener {
        void onSelect(Integer num);

        String prompt();
    }

    public CellSelector(DungeonTilemap map) {
        super(map);
        this.listener = null;
        this.pinching = false;
        this.dragging = false;
        this.lastPos = new PointF();
        this.camera = map.camera();
        this.dragThreshold = (PixelScene.defaultZoom * ShadowBox.SIZE) / Pickaxe.TIME_TO_MINE;
    }

    protected void onClick(Touch touch) {
        if (this.dragging) {
            this.dragging = false;
        } else {
            select(((DungeonTilemap) this.target).screenToTile((int) touch.current.f24x, (int) touch.current.f25y));
        }
    }

    public void select(int cell) {
        if (!this.enabled || this.listener == null || cell == -1) {
            GameScene.cancel();
            return;
        }
        this.listener.onSelect(Integer.valueOf(cell));
        GameScene.ready();
    }

    protected void onTouchDown(Touch t) {
        if (t != this.touch && this.another == null) {
            if (this.touch.down) {
                this.pinching = true;
                this.another = t;
                this.startSpan = PointF.distance(this.touch.current, this.another.current);
                this.startZoom = this.camera.zoom;
                this.dragging = false;
                return;
            }
            this.touch = t;
            onTouchDown(t);
        }
    }

    protected void onTouchUp(Touch t) {
        if (!this.pinching) {
            return;
        }
        if (t == this.touch || t == this.another) {
            this.pinching = false;
            int zoom = Math.round(this.camera.zoom);
            this.camera.zoom((float) zoom);
            PixelDungeon.zoom((int) (((float) zoom) - PixelScene.defaultZoom));
            this.dragging = true;
            if (t == this.touch) {
                this.touch = this.another;
            }
            this.another = null;
            this.lastPos.set(this.touch.current);
        }
    }

    protected void onDrag(Touch t) {
        this.camera.target = null;
        if (this.pinching) {
            this.camera.zoom(GameMath.gate(PixelScene.minZoom, (this.startZoom * PointF.distance(this.touch.current, this.another.current)) / this.startSpan, PixelScene.maxZoom));
        } else if (!this.dragging && PointF.distance(t.current, t.start) > this.dragThreshold) {
            this.dragging = true;
            this.lastPos.set(t.current);
        } else if (this.dragging) {
            this.camera.scroll.offset(PointF.diff(this.lastPos, t.current).invScale(this.camera.zoom));
            this.lastPos.set(t.current);
        }
    }

    public void cancel() {
        if (this.listener != null) {
            this.listener.onSelect(null);
        }
        GameScene.ready();
    }
}
