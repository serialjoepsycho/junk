package com.watabou.pixeldungeon.scenes;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.BitmapTextMultiline.LineSplitter;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Game;
import com.watabou.noosa.Gizmo;
import com.watabou.noosa.Group;
import com.watabou.noosa.Image;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.particles.Emitter;
import com.watabou.noosa.ui.Button;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Badges.Badge;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.GamesInProgress;
import com.watabou.pixeldungeon.GamesInProgress.Info;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.effects.BannerSprites;
import com.watabou.pixeldungeon.effects.BannerSprites.Type;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.scenes.InterlevelScene.Mode;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.ui.Archs;
import com.watabou.pixeldungeon.ui.ExitButton;
import com.watabou.pixeldungeon.ui.Icons;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndChallenges;
import com.watabou.pixeldungeon.windows.WndClass;
import com.watabou.pixeldungeon.windows.WndMessage;
import com.watabou.pixeldungeon.windows.WndOptions;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Callback;
import java.util.HashMap;
import java.util.Iterator;

public class StartScene extends PixelScene {
    private static final float BUTTON_HEIGHT = 24.0f;
    private static final float GAP = 2.0f;
    private static final float HEIGHT_L = 124.0f;
    private static final float HEIGHT_P = 220.0f;
    private static final String TXT_DPTH_LVL = "Depth: %d, level: %d";
    private static final String TXT_ERASE = "Erase current game";
    private static final String TXT_LOAD = "Load Game";
    private static final String TXT_NEW = "New Game";
    private static final String TXT_NO = "No, return to main menu";
    private static final String TXT_REALLY = "Do you really want to start new game?";
    private static final String TXT_UNLOCK = "To unlock this character class, slay the 3rd boss with any other class";
    private static final String TXT_WARNING = "Your current game progress will be erased.";
    private static final String TXT_WIN_THE_GAME = "To unlock \"Challenges\", win the game with any character class.";
    private static final String TXT_YES = "Yes, start new game";
    private static final float WIDTH_L = 224.0f;
    private static final float WIDTH_P = 116.0f;
    public static HeroClass curClass;
    private static HashMap<HeroClass, ClassShield> shields;
    private GameButton btnLoad;
    private GameButton btnNewGame;
    private float buttonX;
    private float buttonY;
    private boolean huntressUnlocked;
    private Group unlock;

    private static class GameButton extends RedButton {
        private static final int SECONDARY_COLOR_H = 16777096;
        private static final int SECONDARY_COLOR_N = 13291458;
        private BitmapText secondary;

        public GameButton(String primary) {
            super(primary);
            this.secondary.text(null);
        }

        protected void createChildren() {
            super.createChildren();
            this.secondary = PixelScene.createText(6.0f);
            add(this.secondary);
        }

        protected void layout() {
            super.layout();
            if (this.secondary.text().length() > 0) {
                this.text.y = PixelScene.align(this.y + (((this.height - this.text.height()) - this.secondary.baseLine()) / StartScene.GAP));
                this.secondary.x = PixelScene.align(this.x + ((this.width - this.secondary.width()) / StartScene.GAP));
                this.secondary.y = PixelScene.align(this.text.y + this.text.height());
                return;
            }
            this.text.y = PixelScene.align(this.y + ((this.height - this.text.baseLine()) / StartScene.GAP));
        }

        public void secondary(String text, boolean highlighted) {
            this.secondary.text(text);
            this.secondary.measure();
            this.secondary.hardlight(highlighted ? SECONDARY_COLOR_H : SECONDARY_COLOR_N);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.StartScene.1 */
    class C01221 extends GameButton {

        /* renamed from: com.watabou.pixeldungeon.scenes.StartScene.1.1 */
        class C01211 extends WndOptions {
            C01211(String title, String message, String... options) {
                super(title, message, options);
            }

            protected void onSelect(int index) {
                if (index == 0) {
                    StartScene.this.chooseDifficulty();
                }
            }
        }

        C01221(String primary) {
            super(primary);
        }

        protected void onClick() {
            if (GamesInProgress.check(StartScene.curClass) != null) {
                StartScene.this.add(new C01211(StartScene.TXT_REALLY, StartScene.TXT_WARNING, StartScene.TXT_YES, StartScene.TXT_NO));
                return;
            }
            StartScene.this.chooseDifficulty();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.StartScene.2 */
    class C01232 extends GameButton {
        C01232(String primary) {
            super(primary);
        }

        protected void onClick() {
            InterlevelScene.mode = Mode.CONTINUE;
            Game.switchScene(InterlevelScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.StartScene.3 */
    class C01243 implements Callback {
        C01243() {
        }

        public void call() {
            if (Game.scene() == StartScene.this) {
                PixelDungeon.switchNoFade(StartScene.class);
            }
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.StartScene.4 */
    class C01254 extends WndOptions {
        C01254(String title, String message, String... options) {
            super(title, message, options);
        }

        protected void onSelect(int index) {
            if (index == 0) {
                index = 1;
            } else if (index == 1) {
                index = 0;
            }
            StartScene.this.chooseDifficultyFinal(index);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.StartScene.5 */
    class C01265 extends WndOptions {
        final /* synthetic */ int val$diff;

        C01265(String title, String message, String[] options, int i) {
            this.val$diff = i;
            super(title, message, options);
        }

        protected void onSelect(int index) {
            if (index == 0) {
                StartScene.this.startNewGame(this.val$diff);
            }
        }
    }

    private class ChallengeButton extends Button {
        private Image image;

        /* renamed from: com.watabou.pixeldungeon.scenes.StartScene.ChallengeButton.1 */
        class C01271 extends WndChallenges {
            C01271(int checked, boolean editable) {
                super(checked, editable);
            }

            public void onBackPressed() {
                super.onBackPressed();
                ChallengeButton.this.image.copy(Icons.get(PixelDungeon.challenges() > 0 ? Icons.CHALLENGE_ON : Icons.CHALLENGE_OFF));
            }
        }

        public ChallengeButton() {
            this.width = this.image.width;
            this.height = this.image.height;
            this.image.am = Badges.isUnlocked(Badge.VICTORY) ? Key.TIME_TO_UNLOCK : 0.5f;
        }

        protected void createChildren() {
            super.createChildren();
            this.image = Icons.get(PixelDungeon.challenges() > 0 ? Icons.CHALLENGE_ON : Icons.CHALLENGE_OFF);
            add(this.image);
        }

        protected void layout() {
            super.layout();
            this.image.x = PixelScene.align(this.x);
            this.image.y = PixelScene.align(this.y);
        }

        protected void onClick() {
            if (Badges.isUnlocked(Badge.VICTORY)) {
                StartScene.this.add(new C01271(PixelDungeon.challenges(), true));
            } else {
                StartScene.this.add(new WndMessage(StartScene.TXT_WIN_THE_GAME));
            }
        }

        protected void onTouchDown() {
            Sample.INSTANCE.play(Assets.SND_CLICK);
        }
    }

    private class ClassShield extends Button {
        private static final int BASIC_HIGHLIGHTED = 13291458;
        private static final int BASIC_NORMAL = 4473924;
        private static final int HEIGHT = 28;
        private static final int MASTERY_HIGHLIGHTED = 16777096;
        private static final int MASTERY_NORMAL = 6710852;
        private static final float MIN_BRIGHTNESS = 0.6f;
        private static final int SCALE = 2;
        private static final int WIDTH = 24;
        private Image avatar;
        private float brightness;
        private HeroClass cl;
        private Emitter emitter;
        private int highlighted;
        private BitmapText name;
        private int normal;

        public ClassShield(HeroClass cl) {
            this.cl = cl;
            this.avatar.frame(cl.ordinal() * WIDTH, 0, WIDTH, HEIGHT);
            this.avatar.scale.set((float) StartScene.GAP);
            if (Badges.isUnlocked(cl.masteryBadge())) {
                this.normal = MASTERY_NORMAL;
                this.highlighted = MASTERY_HIGHLIGHTED;
            } else {
                this.normal = BASIC_NORMAL;
                this.highlighted = BASIC_HIGHLIGHTED;
            }
            this.name.text(cl.name());
            this.name.measure();
            this.name.hardlight(this.normal);
            this.brightness = MIN_BRIGHTNESS;
            updateBrightness();
        }

        protected void createChildren() {
            super.createChildren();
            this.avatar = new Image(Assets.AVATARS);
            add(this.avatar);
            this.name = PixelScene.createText(9.0f);
            add(this.name);
            this.emitter = new Emitter();
            add(this.emitter);
        }

        protected void layout() {
            super.layout();
            this.avatar.x = PixelScene.align(this.x + ((this.width - this.avatar.width()) / StartScene.GAP));
            this.avatar.y = PixelScene.align(this.y + (((this.height - this.avatar.height()) - this.name.height()) / StartScene.GAP));
            this.name.x = PixelScene.align(this.x + ((this.width - this.name.width()) / StartScene.GAP));
            this.name.y = (this.avatar.y + this.avatar.height()) + StartScene.GAP;
            this.emitter.pos(this.avatar.x, this.avatar.y, this.avatar.width(), this.avatar.height());
        }

        protected void onTouchDown() {
            this.emitter.revive();
            this.emitter.start(Speck.factory(SCALE), 0.05f, 7);
            Sample.INSTANCE.play(Assets.SND_CLICK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, 1.2f);
            StartScene.this.updateClass(this.cl);
        }

        public void update() {
            super.update();
            if (this.brightness < Key.TIME_TO_UNLOCK && this.brightness > MIN_BRIGHTNESS) {
                float f = this.brightness - Game.elapsed;
                this.brightness = f;
                if (f <= MIN_BRIGHTNESS) {
                    this.brightness = MIN_BRIGHTNESS;
                }
                updateBrightness();
            }
        }

        public void highlight(boolean value) {
            if (value) {
                this.brightness = Key.TIME_TO_UNLOCK;
                this.name.hardlight(this.highlighted);
            } else {
                this.brightness = 0.999f;
                this.name.hardlight(this.normal);
            }
            updateBrightness();
        }

        private void updateBrightness() {
            Image image = this.avatar;
            Image image2 = this.avatar;
            Image image3 = this.avatar;
            Image image4 = this.avatar;
            float f = this.brightness;
            image4.am = f;
            image3.rm = f;
            image2.bm = f;
            image.gm = f;
        }
    }

    static {
        shields = new HashMap();
    }

    public void create() {
        float width;
        float height;
        int length;
        super.create();
        Badges.loadGlobal();
        uiCamera.visible = false;
        int w = Camera.main.width;
        int h = Camera.main.height;
        if (PixelDungeon.landscape()) {
            width = WIDTH_L;
            height = HEIGHT_L;
        } else {
            width = WIDTH_P;
            height = HEIGHT_P;
        }
        float left = (((float) w) - width) / GAP;
        float top = (((float) h) - height) / GAP;
        float bottom = ((float) h) - top;
        Archs archs = new Archs();
        archs.setSize((float) w, (float) h);
        add(archs);
        Gizmo title = BannerSprites.get(Type.SELECT_YOUR_HERO);
        title.x = PixelScene.align((((float) w) - title.width()) / GAP);
        title.y = PixelScene.align(top);
        add(title);
        this.buttonX = left;
        this.buttonY = bottom - BUTTON_HEIGHT;
        this.btnNewGame = new C01221(TXT_NEW);
        add(this.btnNewGame);
        this.btnLoad = new C01232(TXT_LOAD);
        add(this.btnLoad);
        float centralHeight = (this.buttonY - title.y) - title.height();
        HeroClass[] classes = new HeroClass[]{HeroClass.WARRIOR, HeroClass.MAGE, HeroClass.ROGUE, HeroClass.HUNTRESS};
        for (HeroClass cl : classes) {
            Gizmo classShield = new ClassShield(cl);
            shields.put(cl, classShield);
            add(classShield);
        }
        float shieldW;
        float shieldH;
        int i;
        ChallengeButton challenge;
        if (PixelDungeon.landscape()) {
            shieldW = width / 4.0f;
            shieldH = Math.min(centralHeight, shieldW);
            top = (title.y + title.height) + ((centralHeight - shieldH) / GAP);
            i = 0;
            while (true) {
                length = classes.length;
                if (i >= r0) {
                    break;
                }
                ((ClassShield) shields.get(classes[i])).setRect((((float) i) * shieldW) + left, top, shieldW, shieldH);
                i++;
            }
            challenge = new ChallengeButton();
            challenge.setPos(((float) (w / 2)) - (challenge.width() / GAP), (top + shieldH) - (challenge.height() / GAP));
            add(challenge);
        } else {
            shieldW = width / GAP;
            shieldH = Math.min(centralHeight / GAP, 1.2f * shieldW);
            top = ((title.y + title.height()) + (centralHeight / GAP)) - shieldH;
            i = 0;
            while (true) {
                length = classes.length;
                if (i >= r0) {
                    break;
                }
                ((ClassShield) shields.get(classes[i])).setRect((((float) (i % 2)) * shieldW) + left, (((float) (i / 2)) * shieldH) + top, shieldW, shieldH);
                i++;
            }
            challenge = new ChallengeButton();
            challenge.setPos(((float) (w / 2)) - (challenge.width() / GAP), (top + shieldH) - (challenge.height() / GAP));
            add(challenge);
        }
        this.unlock = new Group();
        add(this.unlock);
        boolean isUnlocked = Badges.isUnlocked(Badge.BOSS_SLAIN_3);
        this.huntressUnlocked = isUnlocked;
        if (!isUnlocked) {
            BitmapTextMultiline text = PixelScene.createMultiline(TXT_UNLOCK, 9.0f);
            text.maxWidth = (int) width;
            text.measure();
            float pos = (bottom - BUTTON_HEIGHT) + ((BUTTON_HEIGHT - text.height()) / GAP);
            text.getClass();
            Iterator it = new LineSplitter().split().iterator();
            while (it.hasNext()) {
                Gizmo line = (BitmapText) it.next();
                line.measure();
                line.hardlight(CharSprite.NEUTRAL);
                line.x = PixelScene.align(((float) (w / 2)) - (line.width() / GAP));
                line.y = PixelScene.align(pos);
                this.unlock.add(line);
                pos += line.height();
            }
        }
        ExitButton btnExit = new ExitButton();
        btnExit.setPos(((float) Camera.main.width) - btnExit.width(), 0.0f);
        add(btnExit);
        curClass = null;
        updateClass(HeroClass.values()[PixelDungeon.lastClass()]);
        fadeIn();
        Badges.loadingListener = new C01243();
    }

    public void destroy() {
        Badges.saveGlobal();
        Badges.loadingListener = null;
        super.destroy();
    }

    private void updateClass(HeroClass cl) {
        if (curClass == cl) {
            add(new WndClass(cl));
            return;
        }
        if (curClass != null) {
            ((ClassShield) shields.get(curClass)).highlight(false);
        }
        HashMap hashMap = shields;
        curClass = cl;
        ((ClassShield) hashMap.get(cl)).highlight(true);
        if (cl != HeroClass.HUNTRESS || this.huntressUnlocked) {
            this.unlock.visible = false;
            Info info = GamesInProgress.check(curClass);
            if (info != null) {
                this.btnLoad.visible = true;
                this.btnLoad.secondary(Utils.format(TXT_DPTH_LVL, Integer.valueOf(info.depth), Integer.valueOf(info.level)), info.challenges);
                this.btnNewGame.visible = true;
                this.btnNewGame.secondary(TXT_ERASE, false);
                float w = ((((float) Camera.main.width) - GAP) / GAP) - this.buttonX;
                this.btnLoad.setRect(this.buttonX, this.buttonY, w, BUTTON_HEIGHT);
                this.btnNewGame.setRect(this.btnLoad.right() + GAP, this.buttonY, w, BUTTON_HEIGHT);
                return;
            }
            this.btnLoad.visible = false;
            this.btnNewGame.visible = true;
            this.btnNewGame.secondary(null, false);
            this.btnNewGame.setRect(this.buttonX, this.buttonY, ((float) Camera.main.width) - (this.buttonX * GAP), BUTTON_HEIGHT);
            return;
        }
        this.unlock.visible = true;
        this.btnLoad.visible = false;
        this.btnNewGame.visible = false;
    }

    private void chooseDifficulty() {
        add(new C01254("Game Difficulty", "Cannot be changed in game!", "Easy", "Normal", "Hard", "Hell!", "Suicide!!"));
    }

    private void chooseDifficultyFinal(int index) {
        String title = BuildConfig.VERSION_NAME;
        String Description = BuildConfig.VERSION_NAME;
        int diff = index;
        switch (index) {
            case WndUpdates.ID_SEWERS /*0*/:
                title = "Normal";
                Description = "- Similar to standard Pixel Dungeon";
                break;
            case WndUpdates.ID_PRISON /*1*/:
                title = "Easy";
                Description = "- Mobs have less HP\n- Mobs do less damage\n- Potion of Healing identified from start\n- Hero starts with 2 Potions of Healing\n- Hero starts with 2 extra rations\n- Low champion spawn rate";
                break;
            case WndUpdates.ID_CAVES /*2*/:
                title = "Hard";
                Description = "- Mobs have more HP\n-  Mobs do more damage\n- Healing potions heal 75% max HP only\n- Medium champion spawn rate";
                break;
            case WndUpdates.ID_METROPOLIS /*3*/:
                title = "Hell!";
                Description = "- Mobs have more HP\n-  Mobs do more damage\n- Hero has less HP\n- Healing potions heal 50% max HP only\n- High champion spawn rate";
                break;
            case WndUpdates.ID_HALLS /*4*/:
                title = "Suicide!!";
                Description = "- Mobs have even more HP\n-  Mobs do even more damage\n- Hero has even less HP\n- Healing potions heal 25% max HP only\n- Insane champion spawn rate";
                break;
        }
        add(new C01265(title, Description, new String[]{"Yes", "No"}, diff));
    }

    private void startNewGame(int diff) {
        Dungeon.hero = null;
        Dungeon.difficulty = diff;
        InterlevelScene.mode = Mode.DESCEND;
        if (PixelDungeon.intro()) {
            PixelDungeon.intro(false);
            Game.switchScene(IntroScene.class);
            return;
        }
        Game.switchScene(InterlevelScene.class);
    }

    protected void onBackPressed() {
        PixelDungeon.switchNoFade(TitleScene.class);
    }
}
