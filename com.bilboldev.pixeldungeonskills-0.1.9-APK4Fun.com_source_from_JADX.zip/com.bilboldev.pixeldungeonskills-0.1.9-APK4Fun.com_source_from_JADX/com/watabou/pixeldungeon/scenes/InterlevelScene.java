package com.watabou.pixeldungeon.scenes;

import com.watabou.noosa.BitmapText;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Game;
import com.watabou.noosa.audio.Music;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Statistics;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndError;
import com.watabou.pixeldungeon.windows.WndUpdates;
import java.io.FileNotFoundException;

public class InterlevelScene extends PixelScene {
    private static final String ERR_FILE_NOT_FOUND = "File not found. For some reason.";
    private static final String ERR_GENERIC = "Something went wrong...";
    private static final float TIME_TO_FADE = 0.3f;
    private static final String TXT_ASCENDING = "Ascending...";
    private static final String TXT_DESCENDING = "Descending...";
    private static final String TXT_FALLING = "Falling...";
    private static final String TXT_LOADING = "Loading...";
    private static final String TXT_RESURRECTING = "Resurrecting...";
    private static final String TXT_RETURNING = "Returning...";
    public static boolean fallIntoPit;
    public static Mode mode;
    public static boolean noStory;
    public static int returnDepth;
    public static int returnPos;
    private String error;
    private BitmapText message;
    private Phase phase;
    private Thread thread;
    private float timeLeft;

    /* renamed from: com.watabou.pixeldungeon.scenes.InterlevelScene.1 */
    class C01171 extends Thread {
        C01171() {
        }

        public void run() {
            try {
                Generator.reset();
                switch (C01193.$SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[InterlevelScene.mode.ordinal()]) {
                    case WndUpdates.ID_PRISON /*1*/:
                        InterlevelScene.this.descend();
                        break;
                    case WndUpdates.ID_CAVES /*2*/:
                        InterlevelScene.this.ascend();
                        break;
                    case WndUpdates.ID_METROPOLIS /*3*/:
                        InterlevelScene.this.restore();
                        break;
                    case WndUpdates.ID_HALLS /*4*/:
                        InterlevelScene.this.resurrect();
                        break;
                    case BuffIndicator.HUNGER /*5*/:
                        InterlevelScene.this.returnTo();
                        break;
                    case BuffIndicator.STARVATION /*6*/:
                        InterlevelScene.this.fall();
                        break;
                }
                if (Dungeon.depth % 5 == 0) {
                    Sample.INSTANCE.load(Assets.SND_BOSS);
                }
            } catch (FileNotFoundException e) {
                InterlevelScene.this.error = InterlevelScene.ERR_FILE_NOT_FOUND;
            } catch (Exception e2) {
                InterlevelScene.this.error = InterlevelScene.ERR_GENERIC + e2.getMessage() + "\n" + e2;
            }
            if (InterlevelScene.this.phase == Phase.STATIC && InterlevelScene.this.error == null) {
                InterlevelScene.this.phase = Phase.FADE_OUT;
                InterlevelScene.this.timeLeft = InterlevelScene.TIME_TO_FADE;
            }
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.InterlevelScene.2 */
    class C01182 extends WndError {
        C01182(String message) {
            super(message);
        }

        public void onBackPressed() {
            super.onBackPressed();
            Game.switchScene(StartScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.InterlevelScene.3 */
    static /* synthetic */ class C01193 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode;
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Phase;

        static {
            $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Phase = new int[Phase.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Phase[Phase.FADE_IN.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Phase[Phase.FADE_OUT.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Phase[Phase.STATIC.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode = new int[Mode.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[Mode.DESCEND.ordinal()] = 1;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[Mode.ASCEND.ordinal()] = 2;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[Mode.CONTINUE.ordinal()] = 3;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[Mode.RESURRECT.ordinal()] = 4;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[Mode.RETURN.ordinal()] = 5;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[Mode.FALL.ordinal()] = 6;
            } catch (NoSuchFieldError e9) {
            }
        }
    }

    public enum Mode {
        DESCEND,
        ASCEND,
        CONTINUE,
        RESURRECT,
        RETURN,
        FALL
    }

    private enum Phase {
        FADE_IN,
        STATIC,
        FADE_OUT
    }

    public InterlevelScene() {
        this.error = null;
    }

    static {
        noStory = false;
    }

    public void create() {
        super.create();
        String text = BuildConfig.VERSION_NAME;
        switch (C01193.$SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[mode.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                text = TXT_DESCENDING;
                break;
            case WndUpdates.ID_CAVES /*2*/:
                text = TXT_ASCENDING;
                break;
            case WndUpdates.ID_METROPOLIS /*3*/:
                text = TXT_LOADING;
                break;
            case WndUpdates.ID_HALLS /*4*/:
                text = TXT_RESURRECTING;
                break;
            case BuffIndicator.HUNGER /*5*/:
                text = TXT_RETURNING;
                break;
            case BuffIndicator.STARVATION /*6*/:
                text = TXT_FALLING;
                break;
        }
        this.message = PixelScene.createText(text, 9.0f);
        this.message.measure();
        this.message.x = (((float) Camera.main.width) - this.message.width()) / Pickaxe.TIME_TO_MINE;
        this.message.y = (((float) Camera.main.height) - this.message.height()) / Pickaxe.TIME_TO_MINE;
        add(this.message);
        this.phase = Phase.FADE_IN;
        this.timeLeft = TIME_TO_FADE;
        this.thread = new C01171();
        this.thread.start();
    }

    public void update() {
        super.update();
        float p = this.timeLeft / TIME_TO_FADE;
        float f;
        switch (C01193.$SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Phase[this.phase.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                this.message.alpha(Key.TIME_TO_UNLOCK - p);
                f = this.timeLeft - Game.elapsed;
                this.timeLeft = f;
                if (f > 0.0f) {
                    return;
                }
                if (this.thread.isAlive() || this.error != null) {
                    this.phase = Phase.STATIC;
                    return;
                }
                this.phase = Phase.FADE_OUT;
                this.timeLeft = TIME_TO_FADE;
            case WndUpdates.ID_CAVES /*2*/:
                this.message.alpha(p);
                if (mode == Mode.CONTINUE || (mode == Mode.DESCEND && Dungeon.depth == 1)) {
                    Music.INSTANCE.volume(p);
                }
                f = this.timeLeft - Game.elapsed;
                this.timeLeft = f;
                if (f <= 0.0f) {
                    Game.switchScene(GameScene.class);
                }
            case WndUpdates.ID_METROPOLIS /*3*/:
                if (this.error != null) {
                    add(new C01182(this.error));
                    this.error = null;
                }
            default:
        }
    }

    private void descend() throws Exception {
        Level level;
        Actor.fixTime();
        if (Dungeon.hero == null) {
            Dungeon.init();
            if (noStory) {
                Dungeon.chapters.add(Integer.valueOf(0));
                noStory = false;
            }
        } else {
            Dungeon.saveLevel();
        }
        if (Dungeon.depth >= Statistics.deepestFloor) {
            level = Dungeon.newLevel();
        } else {
            Dungeon.depth++;
            level = Dungeon.loadLevel(Dungeon.hero.heroClass);
        }
        Dungeon.switchLevel(level, level.entrance);
    }

    private void fall() throws Exception {
        Level level;
        Actor.fixTime();
        Dungeon.saveLevel();
        if (Dungeon.depth >= Statistics.deepestFloor) {
            level = Dungeon.newLevel();
        } else {
            Dungeon.depth++;
            level = Dungeon.loadLevel(Dungeon.hero.heroClass);
        }
        Dungeon.switchLevel(level, fallIntoPit ? level.pitCell() : level.randomRespawnCell());
    }

    private void ascend() throws Exception {
        Actor.fixTime();
        Dungeon.saveLevel();
        Dungeon.depth--;
        Level level = Dungeon.loadLevel(Dungeon.hero.heroClass);
        Dungeon.switchLevel(level, level.exit);
    }

    private void returnTo() throws Exception {
        Actor.fixTime();
        Dungeon.saveLevel();
        Dungeon.depth = returnDepth;
        Level level = Dungeon.loadLevel(Dungeon.hero.heroClass);
        Dungeon.switchLevel(level, Level.resizingNeeded ? level.adjustPos(returnPos) : returnPos);
    }

    private void restore() throws Exception {
        Actor.fixTime();
        Dungeon.loadGame(StartScene.curClass);
        if (Dungeon.depth == -1) {
            Dungeon.depth = Statistics.deepestFloor;
            Dungeon.switchLevel(Dungeon.loadLevel(StartScene.curClass), -1);
            return;
        }
        Level level = Dungeon.loadLevel(StartScene.curClass);
        Dungeon.switchLevel(level, Level.resizingNeeded ? level.adjustPos(Dungeon.hero.pos) : Dungeon.hero.pos);
    }

    private void resurrect() throws Exception {
        Actor.fixTime();
        if (Dungeon.bossLevel()) {
            Dungeon.hero.resurrect(Dungeon.depth);
            Dungeon.depth--;
            Level level = Dungeon.newLevel();
            Dungeon.switchLevel(level, level.entrance);
            return;
        }
        Dungeon.hero.resurrect(-1);
        Dungeon.resetLevel();
    }

    protected void onBackPressed() {
    }
}
