package com.watabou.pixeldungeon.scenes;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Game;
import com.watabou.noosa.Image;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.effects.Flare;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.scenes.InterlevelScene.Mode;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.utils.Random;

public class AmuletScene extends PixelScene {
    private static final int BTN_HEIGHT = 18;
    private static final float LARGE_GAP = 8.0f;
    private static final float SMALL_GAP = 2.0f;
    private static final String TXT = "You finally hold it in your hands, the Amulet of Yendor. Using its power you can take over the world or bring peace and prosperity to people or whatever. Anyway, your life will change forever and this game will end here. Or you can stay a mere mortal a little longer.";
    private static final String TXT_EXIT = "Let's call it a day";
    private static final String TXT_STAY = "I'm not done yet";
    private static final int WIDTH = 120;
    public static boolean noText;
    private Image amulet;
    private float timer;

    /* renamed from: com.watabou.pixeldungeon.scenes.AmuletScene.1 */
    class C01111 extends RedButton {
        C01111(String label) {
            super(label);
        }

        protected void onClick() {
            Dungeon.win(ResultDescriptions.WIN);
            Dungeon.deleteGame(Dungeon.hero.heroClass, true);
            Game.switchScene(AmuletScene.noText ? TitleScene.class : RankingsScene.class);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.AmuletScene.2 */
    class C01122 extends RedButton {
        C01122(String label) {
            super(label);
        }

        protected void onClick() {
            AmuletScene.this.onBackPressed();
        }
    }

    public AmuletScene() {
        this.timer = 0.0f;
    }

    static {
        noText = false;
    }

    public void create() {
        super.create();
        BitmapTextMultiline text = null;
        if (!noText) {
            text = PixelScene.createMultiline(TXT, LARGE_GAP);
            text.maxWidth = WIDTH;
            text.measure();
            add(text);
        }
        this.amulet = new Image(Assets.AMULET);
        add(this.amulet);
        RedButton btnExit = new C01111(TXT_EXIT);
        btnExit.setSize(120.0f, 18.0f);
        add(btnExit);
        RedButton btnStay = new C01122(TXT_STAY);
        btnStay.setSize(120.0f, 18.0f);
        add(btnStay);
        float height;
        if (noText) {
            height = (((this.amulet.height + LARGE_GAP) + btnExit.height()) + SMALL_GAP) + btnStay.height();
            this.amulet.x = PixelScene.align((((float) Camera.main.width) - this.amulet.width) / SMALL_GAP);
            this.amulet.y = PixelScene.align((((float) Camera.main.height) - height) / SMALL_GAP);
            btnExit.setPos((((float) Camera.main.width) - btnExit.width()) / SMALL_GAP, (this.amulet.y + this.amulet.height) + LARGE_GAP);
            btnStay.setPos(btnExit.left(), btnExit.bottom() + SMALL_GAP);
        } else {
            height = (((((this.amulet.height + LARGE_GAP) + text.height()) + LARGE_GAP) + btnExit.height()) + SMALL_GAP) + btnStay.height();
            this.amulet.x = PixelScene.align((((float) Camera.main.width) - this.amulet.width) / SMALL_GAP);
            this.amulet.y = PixelScene.align((((float) Camera.main.height) - height) / SMALL_GAP);
            text.x = PixelScene.align((((float) Camera.main.width) - text.width()) / SMALL_GAP);
            text.y = (this.amulet.y + this.amulet.height) + LARGE_GAP;
            btnExit.setPos((((float) Camera.main.width) - btnExit.width()) / SMALL_GAP, (text.y + text.height()) + LARGE_GAP);
            btnStay.setPos(btnExit.left(), btnExit.bottom() + SMALL_GAP);
        }
        new Flare(8, DashboardItem.SIZE).color(16768443, true).show(this.amulet, 0.0f).angularSpeed = 30.0f;
        fadeIn();
    }

    protected void onBackPressed() {
        InterlevelScene.mode = Mode.CONTINUE;
        Game.switchScene(InterlevelScene.class);
    }

    public void update() {
        super.update();
        float f = this.timer - Game.elapsed;
        this.timer = f;
        if (f < 0.0f) {
            this.timer = Random.Float(0.5f, GasesImmunity.DURATION);
            Speck star = (Speck) recycle(Speck.class);
            star.reset(0, this.amulet.x + 10.5f, this.amulet.y + 5.5f, ItemSpriteSheet.PICKAXE);
            add(star);
        }
    }
}
