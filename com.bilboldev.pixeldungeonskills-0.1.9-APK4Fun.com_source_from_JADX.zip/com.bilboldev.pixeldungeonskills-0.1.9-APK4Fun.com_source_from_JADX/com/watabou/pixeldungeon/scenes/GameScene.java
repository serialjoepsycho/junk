package com.watabou.pixeldungeon.scenes;

import com.watabou.noosa.Camera;
import com.watabou.noosa.Game;
import com.watabou.noosa.Gizmo;
import com.watabou.noosa.Group;
import com.watabou.noosa.SkinnedBlock;
import com.watabou.noosa.Visual;
import com.watabou.noosa.audio.Music;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.particles.Emitter;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.FogOfWar;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.Statistics;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.effects.BannerSprites;
import com.watabou.pixeldungeon.effects.BannerSprites.Type;
import com.watabou.pixeldungeon.effects.BlobEmitter;
import com.watabou.pixeldungeon.effects.EmoIcon;
import com.watabou.pixeldungeon.effects.Flare;
import com.watabou.pixeldungeon.effects.FloatingText;
import com.watabou.pixeldungeon.effects.Ripple;
import com.watabou.pixeldungeon.effects.SpellSprite;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.potions.Potion;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.wands.WandOfBlink;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.levels.Level.Feeling;
import com.watabou.pixeldungeon.levels.RegularLevel;
import com.watabou.pixeldungeon.levels.features.Chasm;
import com.watabou.pixeldungeon.plants.Plant;
import com.watabou.pixeldungeon.plants.Plant.Seed;
import com.watabou.pixeldungeon.scenes.CellSelector.Listener;
import com.watabou.pixeldungeon.scenes.InterlevelScene.Mode;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.DiscardedItemSprite;
import com.watabou.pixeldungeon.sprites.HeroSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.sprites.PlantSprite;
import com.watabou.pixeldungeon.ui.AttackIndicator;
import com.watabou.pixeldungeon.ui.Banner;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.ui.BusyIndicator;
import com.watabou.pixeldungeon.ui.GameLog;
import com.watabou.pixeldungeon.ui.HealthIndicator;
import com.watabou.pixeldungeon.ui.QuickSlot;
import com.watabou.pixeldungeon.ui.StatusPane;
import com.watabou.pixeldungeon.ui.Toast;
import com.watabou.pixeldungeon.ui.Toolbar;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndBag;
import com.watabou.pixeldungeon.windows.WndGame;
import com.watabou.pixeldungeon.windows.WndStory;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Random;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class GameScene extends PixelScene {
    private static final String TXT_CHASM = "Your steps echo across the dungeon.";
    private static final String TXT_GRASS = "The smell of vegetation is thick in the air.";
    private static final String TXT_NIGHT_MODE = "Be cautious, since the dungeon is even more dangerous at night!";
    private static final String TXT_SECRETS = "The atmosphere hints that this floor hides many secrets.";
    private static final String TXT_WATER = "You hear the water splashing around you.";
    private static final String TXT_WELCOME = "Welcome to the level %d of Pixel Dungeon!";
    private static final String TXT_WELCOME_BACK = "Welcome back to the level %d of Pixel Dungeon!";
    private static CellSelector cellSelector;
    private static final Listener defaultCellListener;
    static GameScene scene;
    private BusyIndicator busy;
    private Group effects;
    private Group emitters;
    private Group emoicons;
    private FogOfWar fog;
    private Group gases;
    private Group heaps;
    private HeroSprite hero;
    private GameLog log;
    private Group mobs;
    private Group plants;
    private Toast prompt;
    private Group ripples;
    private Group spells;
    private Group statuses;
    private Group terrain;
    private DungeonTilemap tiles;
    private Toolbar toolbar;
    private SkinnedBlock water;

    /* renamed from: com.watabou.pixeldungeon.scenes.GameScene.1 */
    class C01141 extends Toast {
        C01141(String text) {
            super(text);
        }

        protected void onClose() {
            GameScene.cancel();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.GameScene.2 */
    static class C01152 implements Listener {
        C01152() {
        }

        public void onSelect(Integer cell) {
            if (Dungeon.hero.handle(cell.intValue())) {
                Dungeon.hero.next();
            }
        }

        public String prompt() {
            return null;
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.GameScene.3 */
    static /* synthetic */ class C01163 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$levels$Level$Feeling;
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode;

        static {
            $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode = new int[Mode.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[Mode.RESURRECT.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[Mode.RETURN.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[Mode.FALL.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[Mode.DESCEND.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            $SwitchMap$com$watabou$pixeldungeon$levels$Level$Feeling = new int[Feeling.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$levels$Level$Feeling[Feeling.CHASM.ordinal()] = 1;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$levels$Level$Feeling[Feeling.WATER.ordinal()] = 2;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$levels$Level$Feeling[Feeling.GRASS.ordinal()] = 3;
            } catch (NoSuchFieldError e7) {
            }
        }
    }

    public void create() {
        int i;
        Music.INSTANCE.play(Assets.TUNE, true);
        Music.INSTANCE.volume(Key.TIME_TO_UNLOCK);
        PixelDungeon.lastClass(Dungeon.hero.heroClass.ordinal());
        super.create();
        Camera.main.zoom(defaultZoom + ((float) PixelDungeon.zoom()));
        scene = this;
        this.terrain = new Group();
        add(this.terrain);
        this.water = new SkinnedBlock(512.0f, 512.0f, Dungeon.level.waterTex());
        this.terrain.add(this.water);
        this.ripples = new Group();
        this.terrain.add(this.ripples);
        this.tiles = new DungeonTilemap();
        this.terrain.add(this.tiles);
        Dungeon.level.addVisuals(this);
        this.plants = new Group();
        add(this.plants);
        int size = Dungeon.level.plants.size();
        for (i = 0; i < size; i++) {
            addPlantSprite((Plant) Dungeon.level.plants.valueAt(i));
        }
        this.heaps = new Group();
        add(this.heaps);
        size = Dungeon.level.heaps.size();
        for (i = 0; i < size; i++) {
            addHeapSprite((Heap) Dungeon.level.heaps.valueAt(i));
        }
        this.emitters = new Group();
        this.effects = new Group();
        this.emoicons = new Group();
        this.mobs = new Group();
        add(this.mobs);
        Iterator it = Dungeon.level.mobs.iterator();
        while (it.hasNext()) {
            Mob mob = (Mob) it.next();
            addMobSprite(mob);
            if (Statistics.amuletObtained) {
                mob.beckon(Dungeon.hero.pos);
            }
        }
        add(this.emitters);
        add(this.effects);
        this.gases = new Group();
        add(this.gases);
        for (Blob blob : Dungeon.level.blobs.values()) {
            blob.emitter = null;
            addBlobSprite(blob);
        }
        this.fog = new FogOfWar(32, 32);
        this.fog.updateVisibility(Dungeon.visible, Dungeon.level.visited, Dungeon.level.mapped);
        add(this.fog);
        brightness(PixelDungeon.brightness());
        this.spells = new Group();
        add(this.spells);
        this.statuses = new Group();
        add(this.statuses);
        add(this.emoicons);
        this.hero = new HeroSprite();
        this.hero.place(Dungeon.hero.pos);
        this.hero.updateArmor();
        this.mobs.add(this.hero);
        add(new HealthIndicator());
        Gizmo cellSelector = new CellSelector(this.tiles);
        cellSelector = cellSelector;
        add(cellSelector);
        StatusPane sb = new StatusPane();
        sb.camera = uiCamera;
        sb.setSize((float) uiCamera.width, 0.0f);
        add(sb);
        this.toolbar = new Toolbar();
        this.toolbar.camera = uiCamera;
        this.toolbar.setRect(0.0f, ((float) uiCamera.height) - this.toolbar.height(), (float) uiCamera.width, this.toolbar.height());
        add(this.toolbar);
        AttackIndicator attack = new AttackIndicator();
        attack.camera = uiCamera;
        attack.setPos(((float) uiCamera.width) - attack.width(), this.toolbar.top() - attack.height());
        add(attack);
        this.log = new GameLog();
        this.log.camera = uiCamera;
        this.log.setRect(0.0f, this.toolbar.top(), attack.left(), 0.0f);
        add(this.log);
        if (Dungeon.depth < Statistics.deepestFloor) {
            GLog.m1i(TXT_WELCOME_BACK, Integer.valueOf(Dungeon.depth));
        } else {
            GLog.m1i(TXT_WELCOME, Integer.valueOf(Dungeon.depth));
            Sample.INSTANCE.play(Assets.SND_DESCEND);
        }
        switch (C01163.$SwitchMap$com$watabou$pixeldungeon$levels$Level$Feeling[Dungeon.level.feeling.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                GLog.m4w(TXT_CHASM, new Object[0]);
                break;
            case WndUpdates.ID_CAVES /*2*/:
                GLog.m4w(TXT_WATER, new Object[0]);
                break;
            case WndUpdates.ID_METROPOLIS /*3*/:
                GLog.m4w(TXT_GRASS, new Object[0]);
                break;
        }
        if ((Dungeon.level instanceof RegularLevel) && ((RegularLevel) Dungeon.level).secretDoors > Random.IntRange(3, 4)) {
            GLog.m4w(TXT_SECRETS, new Object[0]);
        }
        if (Dungeon.nightMode && !Dungeon.bossLevel()) {
            GLog.m4w(TXT_NIGHT_MODE, new Object[0]);
        }
        this.busy = new BusyIndicator();
        this.busy.camera = uiCamera;
        this.busy.x = Key.TIME_TO_UNLOCK;
        this.busy.y = sb.bottom() + Key.TIME_TO_UNLOCK;
        add(this.busy);
        switch (C01163.$SwitchMap$com$watabou$pixeldungeon$scenes$InterlevelScene$Mode[InterlevelScene.mode.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                WandOfBlink.appear(Dungeon.hero, Dungeon.level.entrance);
                new Flare(8, 32.0f).color(16777062, true).show(this.hero, Pickaxe.TIME_TO_MINE);
                break;
            case WndUpdates.ID_CAVES /*2*/:
                WandOfBlink.appear(Dungeon.hero, Dungeon.hero.pos);
                break;
            case WndUpdates.ID_METROPOLIS /*3*/:
                Chasm.heroLand();
                break;
            case WndUpdates.ID_HALLS /*4*/:
                switch (Dungeon.depth) {
                    case WndUpdates.ID_PRISON /*1*/:
                        WndStory.showChapter(0);
                        break;
                    case BuffIndicator.STARVATION /*6*/:
                        WndStory.showChapter(1);
                        break;
                    case BuffIndicator.ROOTS /*11*/:
                        WndStory.showChapter(2);
                        break;
                    case BuffIndicator.BLINDNESS /*16*/:
                        WndStory.showChapter(3);
                        break;
                    case BuffIndicator.LIGHT /*22*/:
                        WndStory.showChapter(4);
                        break;
                }
                if (Dungeon.hero.isAlive() && Dungeon.depth != 22) {
                    Badges.validateNoKilling();
                    break;
                }
        }
        ArrayList<Item> dropped = (ArrayList) Dungeon.droppedItems.get(Dungeon.depth);
        if (dropped != null) {
            it = dropped.iterator();
            while (it.hasNext()) {
                Item item = (Item) it.next();
                int pos = Dungeon.level.randomRespawnCell();
                if (item instanceof Potion) {
                    ((Potion) item).shatter(pos);
                } else if (item instanceof Seed) {
                    Dungeon.level.plant((Seed) item, pos);
                } else {
                    Dungeon.level.drop(item, pos);
                }
            }
            Dungeon.droppedItems.remove(Dungeon.depth);
        }
        Camera.main.target = this.hero;
        fadeIn();
    }

    public void destroy() {
        scene = null;
        Badges.saveGlobal();
        super.destroy();
    }

    public synchronized void pause() {
        try {
            Dungeon.saveAll();
            Badges.saveGlobal();
        } catch (IOException e) {
        }
    }

    public synchronized void update() {
        if (Dungeon.hero != null) {
            super.update();
            this.water.offset(0.0f, -5.0f * Game.elapsed);
            Actor.process();
            if (Dungeon.hero.ready && !Dungeon.hero.paralysed) {
                this.log.newLine();
            }
            cellSelector.enabled = Dungeon.hero.ready;
        }
    }

    protected void onBackPressed() {
        if (!cancel()) {
            add(new WndGame());
        }
    }

    protected void onMenuPressed() {
        if (Dungeon.hero.ready) {
            selectItem(null, WndBag.Mode.ALL, null);
        }
    }

    public void brightness(boolean value) {
        SkinnedBlock skinnedBlock = this.water;
        SkinnedBlock skinnedBlock2 = this.water;
        SkinnedBlock skinnedBlock3 = this.water;
        DungeonTilemap dungeonTilemap = this.tiles;
        DungeonTilemap dungeonTilemap2 = this.tiles;
        DungeonTilemap dungeonTilemap3 = this.tiles;
        float f = value ? Sleep.SWS : Key.TIME_TO_UNLOCK;
        dungeonTilemap3.bm = f;
        dungeonTilemap2.gm = f;
        dungeonTilemap.rm = f;
        skinnedBlock3.bm = f;
        skinnedBlock2.gm = f;
        skinnedBlock.rm = f;
        if (value) {
            this.fog.am = Pickaxe.TIME_TO_MINE;
            this.fog.aa = -1.0f;
            return;
        }
        this.fog.am = Key.TIME_TO_UNLOCK;
        this.fog.aa = 0.0f;
    }

    private void addHeapSprite(Heap heap) {
        ItemSprite sprite = (ItemSprite) this.heaps.recycle(ItemSprite.class);
        heap.sprite = sprite;
        sprite.revive();
        sprite.link(heap);
        this.heaps.add(sprite);
    }

    private void addDiscardedSprite(Heap heap) {
        heap.sprite = (DiscardedItemSprite) this.heaps.recycle(DiscardedItemSprite.class);
        heap.sprite.revive();
        heap.sprite.link(heap);
        this.heaps.add(heap.sprite);
    }

    private void addPlantSprite(Plant plant) {
        PlantSprite plantSprite = (PlantSprite) this.plants.recycle(PlantSprite.class);
        plant.sprite = plantSprite;
        plantSprite.reset(plant);
    }

    private void addBlobSprite(Blob gas) {
        if (gas.emitter == null) {
            this.gases.add(new BlobEmitter(gas));
        }
    }

    private void addMobSprite(Mob mob) {
        CharSprite sprite = mob.sprite();
        sprite.visible = Dungeon.visible[mob.pos];
        this.mobs.add(sprite);
        sprite.link(mob);
    }

    private void prompt(String text) {
        if (this.prompt != null) {
            this.prompt.killAndErase();
            this.prompt = null;
        }
        if (text != null) {
            this.prompt = new C01141(text);
            this.prompt.camera = uiCamera;
            this.prompt.setPos((((float) uiCamera.width) - this.prompt.width()) / Pickaxe.TIME_TO_MINE, (float) (uiCamera.height - 60));
            add(this.prompt);
        }
    }

    private void showBanner(Banner banner) {
        banner.camera = uiCamera;
        banner.x = PixelScene.align(uiCamera, (((float) uiCamera.width) - banner.width) / Pickaxe.TIME_TO_MINE);
        banner.y = PixelScene.align(uiCamera, (((float) uiCamera.height) - banner.height) / CurareDart.DURATION);
        add(banner);
    }

    public static void add(Plant plant) {
        if (scene != null) {
            scene.addPlantSprite(plant);
        }
    }

    public static void add(Blob gas) {
        Actor.add(gas);
        if (scene != null) {
            scene.addBlobSprite(gas);
        }
    }

    public static void add(Heap heap) {
        if (scene != null) {
            scene.addHeapSprite(heap);
        }
    }

    public static void discard(Heap heap) {
        if (scene != null) {
            scene.addDiscardedSprite(heap);
        }
    }

    public static void add(Mob mob) {
        Dungeon.level.mobs.add(mob);
        Actor.add(mob);
        Actor.occupyCell(mob);
        scene.addMobSprite(mob);
    }

    public static void add(Mob mob, float delay) {
        Dungeon.level.mobs.add(mob);
        Actor.addDelayed(mob, delay);
        Actor.occupyCell(mob);
        scene.addMobSprite(mob);
    }

    public static void add(EmoIcon icon) {
        scene.emoicons.add(icon);
    }

    public static void effect(Visual effect) {
        scene.effects.add(effect);
    }

    public static Ripple ripple(int pos) {
        Ripple ripple = (Ripple) scene.ripples.recycle(Ripple.class);
        ripple.reset(pos);
        return ripple;
    }

    public static SpellSprite spellSprite() {
        return (SpellSprite) scene.spells.recycle(SpellSprite.class);
    }

    public static Emitter emitter() {
        if (scene == null) {
            return null;
        }
        Emitter emitter = (Emitter) scene.emitters.recycle(Emitter.class);
        emitter.revive();
        return emitter;
    }

    public static FloatingText status() {
        return scene != null ? (FloatingText) scene.statuses.recycle(FloatingText.class) : null;
    }

    public static void pickUp(Item item) {
        scene.toolbar.pickup(item);
    }

    public static void updateMap() {
        if (scene != null) {
            scene.tiles.updated.set(0, 0, 32, 32);
        }
    }

    public static void updateMap(int cell) {
        if (scene != null) {
            scene.tiles.updated.union(cell % 32, cell / 32);
        }
    }

    public static void discoverTile(int pos, int oldValue) {
        if (scene != null) {
            scene.tiles.discover(pos, oldValue);
        }
    }

    public static void show(Window wnd) {
        cancelCellSelector();
        scene.add(wnd);
    }

    public static void afterObserve() {
        if (scene != null) {
            scene.fog.updateVisibility(Dungeon.visible, Dungeon.level.visited, Dungeon.level.mapped);
            Iterator it = Dungeon.level.mobs.iterator();
            while (it.hasNext()) {
                Mob mob = (Mob) it.next();
                mob.sprite.visible = Dungeon.visible[mob.pos];
            }
        }
    }

    public static void flash(int color) {
        scene.fadeIn(-16777216 | color, true);
    }

    public static void gameOver() {
        Banner gameOver = new Banner(BannerSprites.get(Type.GAME_OVER));
        gameOver.show(0, Key.TIME_TO_UNLOCK);
        scene.showBanner(gameOver);
        Sample.INSTANCE.play(Assets.SND_DEATH);
    }

    public static void bossSlain() {
        if (Dungeon.hero.isAlive()) {
            Banner bossSlain = new Banner(BannerSprites.get(Type.BOSS_SLAIN));
            bossSlain.show(CharSprite.DEFAULT, 0.3f, GasesImmunity.DURATION);
            scene.showBanner(bossSlain);
            Sample.INSTANCE.play(Assets.SND_BOSS);
        }
    }

    public static void handleCell(int cell) {
        cellSelector.select(cell);
    }

    public static void selectCell(Listener listener) {
        cellSelector.listener = listener;
        scene.prompt(listener.prompt());
    }

    private static boolean cancelCellSelector() {
        if (cellSelector.listener == null || cellSelector.listener == defaultCellListener) {
            return false;
        }
        cellSelector.cancel();
        return true;
    }

    public static WndBag selectItem(WndBag.Listener listener, WndBag.Mode mode, String title) {
        WndBag wnd;
        cancelCellSelector();
        if (mode == WndBag.Mode.SEED) {
            wnd = WndBag.seedPouch(listener, mode, title);
        } else {
            wnd = WndBag.lastBag(listener, mode, title);
        }
        scene.add(wnd);
        return wnd;
    }

    static boolean cancel() {
        if (Dungeon.hero.curAction == null && !Dungeon.hero.restoreHealth) {
            return cancelCellSelector();
        }
        Dungeon.hero.curAction = null;
        Dungeon.hero.restoreHealth = false;
        return true;
    }

    public static void ready() {
        selectCell(defaultCellListener);
        QuickSlot.cancel();
    }

    static {
        defaultCellListener = new C01152();
    }
}
