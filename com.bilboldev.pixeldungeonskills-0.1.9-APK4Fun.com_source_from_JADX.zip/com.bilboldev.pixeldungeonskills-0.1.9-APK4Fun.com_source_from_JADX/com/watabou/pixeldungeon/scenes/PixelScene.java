package com.watabou.pixeldungeon.scenes;

import android.opengl.GLES20;
import com.watabou.input.Touchscreen;
import com.watabou.noosa.BitmapText;
import com.watabou.noosa.BitmapText.Font;
import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.Camera;
import com.watabou.noosa.ColorBlock;
import com.watabou.noosa.Game;
import com.watabou.noosa.Scene;
import com.watabou.noosa.Visual;
import com.watabou.pixeldungeon.Badges.Badge;
import com.watabou.pixeldungeon.effects.BadgeBanner;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;

public class PixelScene extends Scene {
    public static final float MIN_HEIGHT_L = 160.0f;
    public static final float MIN_HEIGHT_P = 224.0f;
    public static final float MIN_WIDTH_L = 224.0f;
    public static final float MIN_WIDTH_P = 128.0f;
    public static float defaultZoom;
    public static Font font;
    public static Font font15x;
    public static Font font1x;
    public static Font font25x;
    public static Font font2x;
    public static Font font3x;
    public static float maxZoom;
    public static float minZoom;
    public static boolean noFade;
    public static float scale;
    public static Camera uiCamera;

    protected static class Fader extends ColorBlock {
        private static float FADE_TIME;
        private boolean light;
        private float time;

        static {
            FADE_TIME = Key.TIME_TO_UNLOCK;
        }

        public Fader(int color, boolean light) {
            super((float) PixelScene.uiCamera.width, (float) PixelScene.uiCamera.height, color);
            this.light = light;
            this.camera = PixelScene.uiCamera;
            alpha(Key.TIME_TO_UNLOCK);
            this.time = FADE_TIME;
        }

        public void update() {
            super.update();
            float f = this.time - Game.elapsed;
            this.time = f;
            if (f <= 0.0f) {
                alpha(0.0f);
                this.parent.remove(this);
                return;
            }
            alpha(this.time / FADE_TIME);
        }

        public void draw() {
            if (this.light) {
                GLES20.glBlendFunc(770, 1);
                super.draw();
                GLES20.glBlendFunc(770, 771);
                return;
            }
            super.draw();
        }
    }

    private static class PixelCamera extends Camera {
        public PixelCamera(float zoom) {
            super(((int) (((double) Game.width) - (Math.ceil((double) (((float) Game.width) / zoom)) * ((double) zoom)))) / 2, ((int) (((double) Game.height) - (Math.ceil((double) (((float) Game.height) / zoom)) * ((double) zoom)))) / 2, (int) Math.ceil((double) (((float) Game.width) / zoom)), (int) Math.ceil((double) (((float) Game.height) / zoom)), zoom);
        }

        protected void updateMatrix() {
            float sx = PixelScene.align(this, this.scroll.f24x + this.shakeX);
            float sy = PixelScene.align(this, this.scroll.f25y + this.shakeY);
            this.matrix[0] = this.zoom * invW2;
            this.matrix[5] = (-this.zoom) * invH2;
            this.matrix[12] = (-1.0f + (((float) this.x) * invW2)) - (this.matrix[0] * sx);
            this.matrix[13] = (Key.TIME_TO_UNLOCK - (((float) this.y) * invH2)) - (this.matrix[5] * sy);
        }
    }

    static {
        defaultZoom = 0.0f;
        noFade = false;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void create() {
        /*
        r11 = this;
        r10 = -1082130432; // 0xffffffffbf800000 float:-1.0 double:NaN;
        r9 = 0;
        r8 = 1065353216; // 0x3f800000 float:1.0 double:5.263544247E-315;
        super.create();
        r3 = 0;
        com.watabou.pixeldungeon.scenes.GameScene.scene = r3;
        r3 = com.watabou.pixeldungeon.PixelDungeon.landscape();
        if (r3 == 0) goto L_0x0043;
    L_0x0011:
        r1 = 1130364928; // 0x43600000 float:224.0 double:5.58474478E-315;
        r0 = 1126170624; // 0x43200000 float:160.0 double:5.564022167E-315;
    L_0x0015:
        r3 = com.watabou.noosa.Game.density;
        r4 = (double) r3;
        r6 = 4612811918334230528; // 0x4004000000000000 float:0.0 double:2.5;
        r4 = r4 * r6;
        r4 = java.lang.Math.ceil(r4);
        r3 = (int) r4;
        r3 = (float) r3;
        defaultZoom = r3;
    L_0x0023:
        r3 = com.watabou.noosa.Game.width;
        r3 = (float) r3;
        r4 = defaultZoom;
        r3 = r3 / r4;
        r3 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1));
        if (r3 < 0) goto L_0x0037;
    L_0x002d:
        r3 = com.watabou.noosa.Game.height;
        r3 = (float) r3;
        r4 = defaultZoom;
        r3 = r3 / r4;
        r3 = (r3 > r0 ? 1 : (r3 == r0 ? 0 : -1));
        if (r3 >= 0) goto L_0x0048;
    L_0x0037:
        r3 = defaultZoom;
        r3 = (r3 > r8 ? 1 : (r3 == r8 ? 0 : -1));
        if (r3 <= 0) goto L_0x0048;
    L_0x003d:
        r3 = defaultZoom;
        r3 = r3 - r8;
        defaultZoom = r3;
        goto L_0x0023;
    L_0x0043:
        r1 = 1124073472; // 0x43000000 float:128.0 double:5.55366086E-315;
        r0 = 1130364928; // 0x43600000 float:224.0 double:5.58474478E-315;
        goto L_0x0015;
    L_0x0048:
        r3 = com.watabou.pixeldungeon.PixelDungeon.scaleUp();
        if (r3 == 0) goto L_0x006a;
    L_0x004e:
        r3 = com.watabou.noosa.Game.width;
        r3 = (float) r3;
        r4 = defaultZoom;
        r4 = r4 + r8;
        r3 = r3 / r4;
        r3 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1));
        if (r3 < 0) goto L_0x006a;
    L_0x0059:
        r3 = com.watabou.noosa.Game.height;
        r3 = (float) r3;
        r4 = defaultZoom;
        r4 = r4 + r8;
        r3 = r3 / r4;
        r3 = (r3 > r0 ? 1 : (r3 == r0 ? 0 : -1));
        if (r3 < 0) goto L_0x006a;
    L_0x0064:
        r3 = defaultZoom;
        r3 = r3 + r8;
        defaultZoom = r3;
        goto L_0x004e;
    L_0x006a:
        minZoom = r8;
        r3 = defaultZoom;
        r4 = 1073741824; // 0x40000000 float:2.0 double:5.304989477E-315;
        r3 = r3 * r4;
        maxZoom = r3;
        r3 = new com.watabou.pixeldungeon.scenes.PixelScene$PixelCamera;
        r4 = defaultZoom;
        r3.<init>(r4);
        com.watabou.noosa.Camera.reset(r3);
        r2 = defaultZoom;
        r3 = com.watabou.noosa.Camera.createFullscreen(r2);
        uiCamera = r3;
        r3 = uiCamera;
        com.watabou.noosa.Camera.add(r3);
        r3 = font1x;
        if (r3 != 0) goto L_0x0110;
    L_0x008e:
        r3 = "font1x.png";
        r3 = com.watabou.utils.BitmapCache.get(r3);
        r4 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u007f";
        r3 = com.watabou.noosa.BitmapText.Font.colorMarked(r3, r9, r4);
        font1x = r3;
        r3 = font1x;
        r4 = 1086324736; // 0x40c00000 float:6.0 double:5.367157323E-315;
        r3.baseLine = r4;
        r3 = font1x;
        r3.tracking = r10;
        r3 = "font15x.png";
        r3 = com.watabou.utils.BitmapCache.get(r3);
        r4 = 12;
        r5 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u007f";
        r3 = com.watabou.noosa.BitmapText.Font.colorMarked(r3, r4, r9, r5);
        font15x = r3;
        r3 = font15x;
        r4 = 1091567616; // 0x41100000 float:9.0 double:5.39306059E-315;
        r3.baseLine = r4;
        r3 = font15x;
        r3.tracking = r10;
        r3 = "font2x.png";
        r3 = com.watabou.utils.BitmapCache.get(r3);
        r4 = 14;
        r5 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u007f";
        r3 = com.watabou.noosa.BitmapText.Font.colorMarked(r3, r4, r9, r5);
        font2x = r3;
        r3 = font2x;
        r4 = 1093664768; // 0x41300000 float:11.0 double:5.4034219E-315;
        r3.baseLine = r4;
        r3 = font2x;
        r3.tracking = r10;
        r3 = "font25x.png";
        r3 = com.watabou.utils.BitmapCache.get(r3);
        r4 = 17;
        r5 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u007f";
        r3 = com.watabou.noosa.BitmapText.Font.colorMarked(r3, r4, r9, r5);
        font25x = r3;
        r3 = font25x;
        r4 = 1095761920; // 0x41500000 float:13.0 double:5.413783207E-315;
        r3.baseLine = r4;
        r3 = font25x;
        r3.tracking = r10;
        r3 = "font3x.png";
        r3 = com.watabou.utils.BitmapCache.get(r3);
        r4 = 22;
        r5 = " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\u007f";
        r3 = com.watabou.noosa.BitmapText.Font.colorMarked(r3, r4, r9, r5);
        font3x = r3;
        r3 = font3x;
        r4 = 1099431936; // 0x41880000 float:17.0 double:5.431915495E-315;
        r3.baseLine = r4;
        r3 = font3x;
        r4 = -1073741824; // 0xffffffffc0000000 float:-2.0 double:NaN;
        r3.tracking = r4;
    L_0x0110:
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.watabou.pixeldungeon.scenes.PixelScene.create():void");
    }

    public void destroy() {
        super.destroy();
        Touchscreen.event.removeAll();
    }

    public static void chooseFont(float size) {
        chooseFont(size, defaultZoom);
    }

    public static void chooseFont(float size, float zoom) {
        float pt = size * zoom;
        if (pt >= 19.0f) {
            scale = pt / 19.0f;
            if (1.5d > ((double) scale) || scale >= Pickaxe.TIME_TO_MINE) {
                font = font3x;
                scale = (float) ((int) scale);
            } else {
                font = font25x;
                scale = (float) ((int) (pt / 14.0f));
            }
        } else if (pt >= 14.0f) {
            scale = pt / 14.0f;
            if (1.8d > ((double) scale) || scale >= Pickaxe.TIME_TO_MINE) {
                font = font25x;
                scale = (float) ((int) scale);
            } else {
                font = font2x;
                scale = (float) ((int) (pt / 12.0f));
            }
        } else if (pt >= 12.0f) {
            scale = pt / 12.0f;
            if (1.7d > ((double) scale) || scale >= Pickaxe.TIME_TO_MINE) {
                font = font2x;
                scale = (float) ((int) scale);
            } else {
                font = font15x;
                scale = (float) ((int) (pt / TomeOfMastery.TIME_TO_READ));
            }
        } else if (pt >= TomeOfMastery.TIME_TO_READ) {
            scale = pt / TomeOfMastery.TIME_TO_READ;
            if (1.4d > ((double) scale) || scale >= Pickaxe.TIME_TO_MINE) {
                font = font15x;
                scale = (float) ((int) scale);
            } else {
                font = font1x;
                scale = (float) ((int) (pt / 7.0f));
            }
        } else {
            font = font1x;
            scale = (float) Math.max(1, (int) (pt / 7.0f));
        }
        scale /= zoom;
    }

    public static BitmapText createText(float size) {
        return createText(null, size);
    }

    public static BitmapText createText(String text, float size) {
        chooseFont(size);
        BitmapText result = new BitmapText(text, font);
        result.scale.set(scale);
        return result;
    }

    public static BitmapTextMultiline createMultiline(float size) {
        return createMultiline(null, size);
    }

    public static BitmapTextMultiline createMultiline(String text, float size) {
        chooseFont(size);
        BitmapTextMultiline result = new BitmapTextMultiline(text, font);
        result.scale.set(scale);
        return result;
    }

    public static float align(Camera camera, float pos) {
        return ((float) ((int) (camera.zoom * pos))) / camera.zoom;
    }

    public static float align(float pos) {
        return ((float) ((int) (defaultZoom * pos))) / defaultZoom;
    }

    public static void align(Visual v) {
        Camera c = v.camera();
        v.f2x = align(c, v.f2x);
        v.f3y = align(c, v.f3y);
    }

    protected void fadeIn() {
        if (noFade) {
            noFade = false;
        } else {
            fadeIn(-16777216, false);
        }
    }

    protected void fadeIn(int color, boolean light) {
        add(new Fader(color, light));
    }

    public static void showBadge(Badge badge) {
        BadgeBanner banner = BadgeBanner.show(badge.image);
        banner.camera = uiCamera;
        banner.x = align(banner.camera, (((float) banner.camera.width) - banner.width) / Pickaxe.TIME_TO_MINE);
        banner.y = align(banner.camera, (((float) banner.camera.height) - banner.height) / CurareDart.DURATION);
        Game.scene().add(banner);
    }
}
