package com.watabou.pixeldungeon.scenes;

import com.watabou.gltextures.Gradient;
import com.watabou.gltextures.SmartTexture;
import com.watabou.glwrap.Matrix;
import com.watabou.glwrap.Quad;
import com.watabou.input.Touchscreen.Touch;
import com.watabou.noosa.Camera;
import com.watabou.noosa.ColorBlock;
import com.watabou.noosa.Game;
import com.watabou.noosa.Gizmo;
import com.watabou.noosa.Group;
import com.watabou.noosa.Image;
import com.watabou.noosa.MovieClip;
import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.MovieClip.Listener;
import com.watabou.noosa.NoosaScript;
import com.watabou.noosa.TextureFilm;
import com.watabou.noosa.TouchArea;
import com.watabou.noosa.Visual;
import com.watabou.noosa.audio.Music;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.ui.Archs;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Point;
import com.watabou.utils.Random;
import java.nio.FloatBuffer;

public class SurfaceScene extends PixelScene {
    private static final int BUTTON_HEIGHT = 20;
    private static final int FRAME_HEIGHT = 125;
    private static final int FRAME_MARGIN_TOP = 9;
    private static final int FRAME_MARGIN_X = 4;
    private static final int FRAME_WIDTH = 88;
    private static final int NCLOUDS = 5;
    private static final int NSTARS = 100;
    private static final int SKY_HEIGHT = 112;
    private static final int SKY_WIDTH = 80;
    private Camera viewport;

    /* renamed from: com.watabou.pixeldungeon.scenes.SurfaceScene.1 */
    class C01281 extends TouchArea {
        final /* synthetic */ Pet val$pet;

        C01281(Visual target, Pet pet) {
            this.val$pet = pet;
            super(target);
        }

        protected void onClick(Touch touch) {
            this.val$pet.jump();
        }
    }

    /* renamed from: com.watabou.pixeldungeon.scenes.SurfaceScene.2 */
    class C01292 extends RedButton {
        C01292(String label) {
            super(label);
        }

        protected void onClick() {
            Game.switchScene(TitleScene.class);
        }
    }

    private static class Avatar extends Image {
        private static final int HEIGHT = 28;
        private static final int WIDTH = 24;

        public Avatar(HeroClass cl) {
            super(Assets.AVATARS);
            frame(new TextureFilm(this.texture, WIDTH, HEIGHT).get(Integer.valueOf(cl.ordinal())));
        }
    }

    private static class Cloud extends Image {
        private static int lastIndex;

        static {
            lastIndex = -1;
        }

        public Cloud(float y, boolean dayTime) {
            int index;
            super(Assets.SURFACE);
            do {
                index = Random.Int(3);
            } while (index == lastIndex);
            switch (index) {
                case WndUpdates.ID_SEWERS /*0*/:
                    frame(SurfaceScene.FRAME_WIDTH, 0, 49, SurfaceScene.BUTTON_HEIGHT);
                    break;
                case WndUpdates.ID_PRISON /*1*/:
                    frame(SurfaceScene.FRAME_WIDTH, SurfaceScene.BUTTON_HEIGHT, 49, 22);
                    break;
                case WndUpdates.ID_CAVES /*2*/:
                    frame(SurfaceScene.FRAME_WIDTH, 42, 50, 18);
                    break;
            }
            lastIndex = index;
            this.y = y;
            this.scale.set(Key.TIME_TO_UNLOCK - (y / 112.0f));
            this.x = Random.Float(80.0f + width()) - width();
            this.speed.f24x = ((float) (dayTime ? 8 : -8)) * this.scale.f24x;
            if (dayTime) {
                tint(13430527, Key.TIME_TO_UNLOCK - this.scale.f25y);
                return;
            }
            this.bm = CurareDart.DURATION;
            this.gm = CurareDart.DURATION;
            this.rm = CurareDart.DURATION;
            this.ba = -2.1f;
            this.ga = -2.1f;
            this.ra = -2.1f;
        }

        public void update() {
            super.update();
            if (this.speed.f24x > 0.0f && this.x > 80.0f) {
                this.x = -width();
            } else if (this.speed.f24x < 0.0f && this.x < (-width())) {
                this.x = 80.0f;
            }
        }
    }

    private static class GrassPatch extends Image {
        public static final int HEIGHT = 14;
        public static final int WIDTH = 16;
        private double f20a;
        private double angle;
        private boolean forward;
        private float tx;
        private float ty;

        public GrassPatch(float tx, float ty, boolean forward) {
            super(Assets.SURFACE);
            this.f20a = (double) Random.Float(GasesImmunity.DURATION);
            frame((Random.Int(SurfaceScene.FRAME_MARGIN_X) * WIDTH) + SurfaceScene.FRAME_WIDTH, 60, WIDTH, HEIGHT);
            this.tx = tx;
            this.ty = ty;
            this.forward = forward;
        }

        public void update() {
            super.update();
            this.f20a += (double) Random.Float(Game.elapsed * GasesImmunity.DURATION);
            this.angle = (this.forward ? 0.2d : -0.2d) * (Math.cos(this.f20a) + 2.0d);
            this.scale.f25y = (float) Math.cos(this.angle);
            this.x = this.tx + (((float) Math.tan(this.angle)) * this.width);
            this.y = this.ty - (this.scale.f25y * this.height);
        }

        protected void updateMatrix() {
            super.updateMatrix();
            Matrix.skewX(this.matrix, (float) (this.angle / 0.01745329238474369d));
        }
    }

    private static class Pet extends MovieClip implements Listener {
        private Animation idle;
        private Animation jump;

        public Pet() {
            super(Assets.PET);
            TextureFilm frames = new TextureFilm(this.texture, 16, 16);
            this.idle = new Animation(2, true);
            this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1));
            this.jump = new Animation(10, false);
            Animation animation = this.jump;
            Object[] objArr = new Object[SurfaceScene.NCLOUDS];
            objArr[0] = Integer.valueOf(2);
            objArr[1] = Integer.valueOf(3);
            objArr[2] = Integer.valueOf(SurfaceScene.FRAME_MARGIN_X);
            objArr[3] = Integer.valueOf(SurfaceScene.NCLOUDS);
            objArr[SurfaceScene.FRAME_MARGIN_X] = Integer.valueOf(6);
            animation.frames(frames, objArr);
            this.listener = this;
            play(this.idle);
        }

        public void jump() {
            play(this.jump);
        }

        public void onComplete(Animation anim) {
            if (anim == this.jump) {
                play(this.idle);
            }
        }
    }

    private static class Sky extends Visual {
        private static final int[] day;
        private static final int[] night;
        private SmartTexture texture;
        private FloatBuffer verticesBuffer;

        static {
            day = new int[]{-12285697, -3346689};
            night = new int[]{-16772779, -13411968};
        }

        public Sky(boolean dayTime) {
            super(0.0f, 0.0f, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK);
            this.texture = new Gradient(dayTime ? day : night);
            vertices = new float[16];
            this.verticesBuffer = Quad.create();
            vertices[2] = 0.25f;
            vertices[6] = 0.25f;
            vertices[10] = 0.75f;
            vertices[14] = 0.75f;
            vertices[3] = 0.0f;
            vertices[7] = Key.TIME_TO_UNLOCK;
            vertices[11] = Key.TIME_TO_UNLOCK;
            vertices[15] = 0.0f;
            vertices[0] = 0.0f;
            vertices[1] = 0.0f;
            vertices[SurfaceScene.FRAME_MARGIN_X] = Key.TIME_TO_UNLOCK;
            vertices[SurfaceScene.NCLOUDS] = 0.0f;
            vertices[8] = Key.TIME_TO_UNLOCK;
            vertices[SurfaceScene.FRAME_MARGIN_TOP] = Key.TIME_TO_UNLOCK;
            vertices[12] = 0.0f;
            vertices[13] = Key.TIME_TO_UNLOCK;
            this.verticesBuffer.position(0);
            this.verticesBuffer.put(vertices);
        }

        public void draw() {
            super.draw();
            NoosaScript script = NoosaScript.get();
            this.texture.bind();
            script.camera(camera());
            script.uModel.valueM4(this.matrix);
            script.lighting(this.rm, this.gm, this.bm, this.am, this.ra, this.ga, this.ba, this.aa);
            script.drawQuad(this.verticesBuffer);
        }
    }

    public void create() {
        int i;
        super.create();
        Music.INSTANCE.play(Assets.HAPPY, true);
        Music.INSTANCE.volume(Key.TIME_TO_UNLOCK);
        uiCamera.visible = false;
        int w = Camera.main.width;
        int h = Camera.main.height;
        Archs archs = new Archs();
        archs.reversed = true;
        archs.setSize((float) w, (float) h);
        add(archs);
        float vx = PixelScene.align((float) ((w - 80) / 2));
        float vy = PixelScene.align((float) (((h - 112) - 20) / 2));
        Point s = Camera.main.cameraToScreen(vx, vy);
        this.viewport = new Camera(s.f18x, s.f19y, SKY_WIDTH, SKY_HEIGHT, defaultZoom);
        Camera.add(this.viewport);
        Gizmo window = new Group();
        window.camera = this.viewport;
        add(window);
        boolean dayTime = !Dungeon.nightMode;
        Gizmo sky = new Sky(dayTime);
        sky.scale.set(80.0f, 112.0f);
        window.add(sky);
        if (!dayTime) {
            for (i = 0; i < NSTARS; i++) {
                float size = Random.Float();
                sky = new ColorBlock(size, size, -1);
                sky.x = Random.Float(80.0f) - (size / Pickaxe.TIME_TO_MINE);
                sky.y = Random.Float(112.0f) - (size / Pickaxe.TIME_TO_MINE);
                sky.am = (Key.TIME_TO_UNLOCK - (sky.y / 112.0f)) * size;
                window.add(sky);
            }
        }
        for (i = 0; i < NCLOUDS; i++) {
            window.add(new Cloud((((float) (4 - i)) * (74.0f / GasesImmunity.DURATION)) + Random.Float(74.0f / GasesImmunity.DURATION), dayTime));
        }
        int nPatches = (int) ((sky.width() / ShadowBox.SIZE) + Key.TIME_TO_UNLOCK);
        for (i = 0; i < nPatches * FRAME_MARGIN_X; i++) {
            sky = new GrassPatch(((((float) i) - 0.75f) * ShadowBox.SIZE) / 4.0f, 113.0f, dayTime);
            sky.brightness(dayTime ? 0.7f : 0.4f);
            window.add(sky);
        }
        Avatar a = new Avatar(Dungeon.hero.heroClass);
        a.x = PixelScene.align((80.0f - a.width) / Pickaxe.TIME_TO_MINE);
        a.y = 112.0f - a.height;
        window.add(a);
        Gizmo pet = new Pet();
        pet.bm = 1.2f;
        pet.gm = 1.2f;
        pet.rm = 1.2f;
        pet.x = 42.0f;
        pet.y = 112.0f - pet.height;
        window.add(pet);
        window.add(new C01281(sky, pet));
        for (i = 0; i < nPatches; i++) {
            sky = new GrassPatch((((float) i) - 0.5f) * ShadowBox.SIZE, 112.0f, dayTime);
            sky.brightness(dayTime ? Key.TIME_TO_UNLOCK : 0.8f);
            window.add(sky);
        }
        Image frame = new Image(Assets.SURFACE);
        frame.frame(0, 0, FRAME_WIDTH, FRAME_HEIGHT);
        frame.x = vx - 4.0f;
        frame.y = vy - 9.0f;
        add(frame);
        if (dayTime) {
            a.brightness(1.2f);
            pet.brightness(1.2f);
        } else {
            frame.hardlight(14544639);
        }
        RedButton gameOver = new C01292("Game Over");
        gameOver.setSize(72.0f, MindVision.DURATION);
        gameOver.setPos(frame.x + 8.0f, (frame.y + frame.height) + 4.0f);
        add(gameOver);
        Badges.validateHappyEnd();
        fadeIn();
    }

    public void destroy() {
        Badges.saveGlobal();
        Camera.remove(this.viewport);
        super.destroy();
    }

    protected void onBackPressed() {
    }
}
