package com.watabou.pixeldungeon;

/* renamed from: com.watabou.pixeldungeon.R */
public final class C0016R {

    /* renamed from: com.watabou.pixeldungeon.R.attr */
    public static final class attr {
    }

    /* renamed from: com.watabou.pixeldungeon.R.drawable */
    public static final class drawable {
        public static final int ic_launcher = 2130837504;
    }

    /* renamed from: com.watabou.pixeldungeon.R.string */
    public static final class string {
        public static final int app_name = 2130903040;
    }
}
