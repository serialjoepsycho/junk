package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.Game;
import com.watabou.noosa.Image;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.plants.Plant;
import com.watabou.pixeldungeon.windows.WndUpdates;

public class PlantSprite extends Image {
    private static final float DELAY = 0.2f;
    private static TextureFilm frames;
    private int pos;
    private State state;
    private float time;

    /* renamed from: com.watabou.pixeldungeon.sprites.PlantSprite.1 */
    static /* synthetic */ class C01411 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$sprites$PlantSprite$State;

        static {
            $SwitchMap$com$watabou$pixeldungeon$sprites$PlantSprite$State = new int[State.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$PlantSprite$State[State.GROWING.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$PlantSprite$State[State.WITHERING.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
        }
    }

    private enum State {
        GROWING,
        NORMAL,
        WITHERING
    }

    public PlantSprite() {
        super(Assets.PLANTS);
        this.state = State.NORMAL;
        this.pos = -1;
        if (frames == null) {
            frames = new TextureFilm(this.texture, 16, 16);
        }
        this.origin.set(8.0f, 12.0f);
    }

    public PlantSprite(int image) {
        this();
        reset(image);
    }

    public void reset(Plant plant) {
        revive();
        reset(plant.image);
        alpha(Key.TIME_TO_UNLOCK);
        this.pos = plant.pos;
        this.x = (float) ((this.pos % 32) * 16);
        this.y = (float) ((this.pos / 32) * 16);
        this.state = State.GROWING;
        this.time = DELAY;
    }

    public void reset(int image) {
        frame(frames.get(Integer.valueOf(image)));
    }

    public void update() {
        super.update();
        boolean z = this.pos == -1 || Dungeon.visible[this.pos];
        this.visible = z;
        float f;
        switch (C01411.$SwitchMap$com$watabou$pixeldungeon$sprites$PlantSprite$State[this.state.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                f = this.time - Game.elapsed;
                this.time = f;
                if (f <= 0.0f) {
                    this.state = State.NORMAL;
                    this.scale.set((float) Key.TIME_TO_UNLOCK);
                    return;
                }
                this.scale.set(Key.TIME_TO_UNLOCK - (this.time / DELAY));
            case WndUpdates.ID_CAVES /*2*/:
                f = this.time - Game.elapsed;
                this.time = f;
                if (f <= 0.0f) {
                    super.kill();
                } else {
                    alpha(this.time / DELAY);
                }
            default:
        }
    }

    public void kill() {
        this.state = State.WITHERING;
        this.time = DELAY;
    }
}
