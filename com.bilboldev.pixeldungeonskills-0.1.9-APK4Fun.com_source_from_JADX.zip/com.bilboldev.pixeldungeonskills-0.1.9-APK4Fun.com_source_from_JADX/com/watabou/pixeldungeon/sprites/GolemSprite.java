package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.effects.particles.ElmoParticle;

public class GolemSprite extends MobSprite {
    public GolemSprite() {
        texture(Assets.GOLEM);
        TextureFilm frames = new TextureFilm(this.texture, 16, 16);
        this.idle = new Animation(4, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(12, true);
        this.run.frames(frames, Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5));
        this.attack = new Animation(10, false);
        this.attack.frames(frames, Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8));
        this.die = new Animation(15, false);
        this.die.frames(frames, Integer.valueOf(9), Integer.valueOf(10), Integer.valueOf(11), Integer.valueOf(12), Integer.valueOf(13));
        play(this.idle);
    }

    public int blood() {
        return -8359828;
    }

    public void onComplete(Animation anim) {
        if (anim == this.die) {
            emitter().burst(ElmoParticle.FACTORY, 4);
        }
        super.onComplete(anim);
    }
}
