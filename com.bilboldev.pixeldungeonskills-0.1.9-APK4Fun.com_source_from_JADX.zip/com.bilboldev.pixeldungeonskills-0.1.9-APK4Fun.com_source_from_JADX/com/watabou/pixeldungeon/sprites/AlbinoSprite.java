package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;

public class AlbinoSprite extends MobSprite {
    public AlbinoSprite() {
        texture(Assets.RAT);
        TextureFilm frames = new TextureFilm(this.texture, 16, 15);
        this.idle = new Animation(2, true);
        this.idle.frames(frames, Integer.valueOf(16), Integer.valueOf(16), Integer.valueOf(16), Integer.valueOf(17));
        this.run = new Animation(10, true);
        this.run.frames(frames, Integer.valueOf(22), Integer.valueOf(23), Integer.valueOf(24), Integer.valueOf(25), Integer.valueOf(26));
        this.attack = new Animation(15, false);
        this.attack.frames(frames, Integer.valueOf(18), Integer.valueOf(19), Integer.valueOf(20), Integer.valueOf(21));
        this.die = new Animation(10, false);
        this.die.frames(frames, Integer.valueOf(27), Integer.valueOf(28), Integer.valueOf(29), Integer.valueOf(30));
        play(this.idle);
    }
}
