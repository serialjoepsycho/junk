package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.tweeners.PosTweener;
import com.watabou.noosa.tweeners.Tweener;
import com.watabou.noosa.tweeners.Tweener.Listener;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Callback;
import com.watabou.utils.PointF;

public class MissileSprite extends ItemSprite implements Listener {
    private static final float SPEED = 240.0f;
    private Callback callback;

    public MissileSprite() {
        originToCenter();
    }

    public void reset(int from, int to, Item item, Callback listener) {
        if (item == null) {
            reset(from, to, 0, null, listener);
            return;
        }
        reset(from, to, item.image(), item.glowing(), listener);
    }

    public void reset(int from, int to, int image, Glowing glowing, Callback listener) {
        revive();
        view(image, glowing);
        this.callback = listener;
        point(DungeonTilemap.tileToWorld(from));
        PointF dest = DungeonTilemap.tileToWorld(to);
        PointF d = PointF.diff(dest, point());
        this.speed.set(d).normalize().scale(SPEED);
        if (image == 31 || image == ItemSpriteSheet.INCENDIARY_DART || image == ItemSpriteSheet.CURARE_DART || image == ItemSpriteSheet.JAVELIN || image == ItemSpriteSheet.Arrow || image == ItemSpriteSheet.BombArrow) {
            this.angularSpeed = 0.0f;
            this.angle = 135.0f - ((float) ((Math.atan2((double) d.f24x, (double) d.f25y) / 3.1415926d) * 180.0d));
        } else {
            float f = (image == 15 || image == ItemSpriteSheet.BOOMERANG) ? 1440.0f : 720.0f;
            this.angularSpeed = f;
        }
        PosTweener tweener = new PosTweener(this, dest, d.length() / SPEED);
        tweener.listener = this;
        this.parent.add(tweener);
    }

    public void onComplete(Tweener tweener) {
        kill();
        if (this.callback != null) {
            this.callback.call();
        }
    }
}
