package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.particles.Emitter;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.effects.Speck;

public class FetidRatSprite extends RatSprite {
    private Emitter cloud;

    public void link(Char ch) {
        super.link(ch);
        if (this.cloud == null) {
            this.cloud = emitter();
            this.cloud.pour(Speck.factory(ItemSpriteSheet.INCENDIARY_DART), 0.7f);
        }
    }

    public void update() {
        super.update();
        if (this.cloud != null) {
            this.cloud.visible = this.visible;
        }
    }

    public void die() {
        super.die();
        if (this.cloud != null) {
            this.cloud.on = false;
        }
    }
}
