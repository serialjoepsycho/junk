package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.npcs.MirrorImage;

public class MirrorSprite extends MobSprite {
    private static final int FRAME_HEIGHT = 15;
    private static final int FRAME_WIDTH = 12;

    public MirrorSprite() {
        texture(Dungeon.hero.heroClass.spritesheet());
        updateArmor(0);
        idle();
    }

    public void link(Char ch) {
        super.link(ch);
        updateArmor(((MirrorImage) ch).tier);
    }

    public void updateArmor(int tier) {
        TextureFilm film = new TextureFilm(HeroSprite.tiers(), Integer.valueOf(tier), FRAME_WIDTH, FRAME_HEIGHT);
        this.idle = new Animation(1, true);
        this.idle.frames(film, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(1));
        this.run = new Animation(20, true);
        this.run.frames(film, Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7));
        this.die = new Animation(20, false);
        this.die.frames(film, Integer.valueOf(0));
        this.attack = new Animation(FRAME_HEIGHT, false);
        this.attack.frames(film, Integer.valueOf(13), Integer.valueOf(14), Integer.valueOf(FRAME_HEIGHT), Integer.valueOf(0));
        idle();
    }
}
