package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.effects.Speck;

public class UndeadSprite extends MobSprite {
    public UndeadSprite() {
        texture(Assets.UNDEAD);
        TextureFilm frames = new TextureFilm(this.texture, 12, 16);
        this.idle = new Animation(12, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3));
        this.run = new Animation(15, true);
        this.run.frames(frames, Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9));
        this.attack = new Animation(15, false);
        this.attack.frames(frames, Integer.valueOf(14), Integer.valueOf(15), Integer.valueOf(16));
        this.die = new Animation(12, false);
        this.die.frames(frames, Integer.valueOf(10), Integer.valueOf(11), Integer.valueOf(12), Integer.valueOf(13));
        play(this.idle);
    }

    public void die() {
        super.die();
        if (Dungeon.visible[this.ch.pos]) {
            emitter().burst(Speck.factory(6), 3);
        }
    }

    public int blood() {
        return -3355444;
    }
}
