package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.utils.Random;

public class SheepSprite extends MobSprite {
    public SheepSprite() {
        texture(Assets.SHEEP);
        TextureFilm frames = new TextureFilm(this.texture, 16, 15);
        this.idle = new Animation(8, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(0));
        this.run = this.idle.clone();
        this.attack = this.idle.clone();
        this.die = new Animation(20, false);
        this.die.frames(frames, Integer.valueOf(0));
        play(this.idle);
        this.curFrame = Random.Int(this.curAnim.frames.length);
    }
}
