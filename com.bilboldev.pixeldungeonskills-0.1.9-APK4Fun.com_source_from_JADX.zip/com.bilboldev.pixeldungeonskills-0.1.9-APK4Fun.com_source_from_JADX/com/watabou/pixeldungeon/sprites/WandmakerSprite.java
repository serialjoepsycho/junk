package com.watabou.pixeldungeon.sprites;

import android.opengl.GLES20;
import com.watabou.noosa.Game;
import com.watabou.noosa.Gizmo;
import com.watabou.noosa.Group;
import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.effects.Halo;
import com.watabou.pixeldungeon.effects.particles.ElmoParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.utils.PointF;

public class WandmakerSprite extends MobSprite {
    private Shield shield;

    public class Shield extends Halo {
        private float phase;

        public Shield() {
            super(14.0f, 12298956, Key.TIME_TO_UNLOCK);
            this.am = -1.0f;
            this.aa = Key.TIME_TO_UNLOCK;
            this.phase = Key.TIME_TO_UNLOCK;
        }

        public void update() {
            super.update();
            if (this.phase < Key.TIME_TO_UNLOCK) {
                float f = this.phase - Game.elapsed;
                this.phase = f;
                if (f <= 0.0f) {
                    killAndErase();
                } else {
                    this.scale.set(((Pickaxe.TIME_TO_MINE - this.phase) * this.radius) / 64.0f);
                    this.am = this.phase * -1.0f;
                    this.aa = this.phase * Key.TIME_TO_UNLOCK;
                }
            }
            boolean z = WandmakerSprite.this.visible;
            this.visible = z;
            if (z) {
                PointF p = WandmakerSprite.this.center();
                point(p.f24x, p.f25y);
            }
        }

        public void draw() {
            GLES20.glBlendFunc(770, 1);
            super.draw();
            GLES20.glBlendFunc(770, 771);
        }

        public void putOut() {
            this.phase = 0.999f;
        }
    }

    public WandmakerSprite() {
        texture(Assets.MAKER);
        TextureFilm frames = new TextureFilm(this.texture, 12, 14);
        this.idle = new Animation(10, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(3), Integer.valueOf(3), Integer.valueOf(3), Integer.valueOf(3), Integer.valueOf(3), Integer.valueOf(2), Integer.valueOf(1));
        this.run = new Animation(20, true);
        this.run.frames(frames, Integer.valueOf(0));
        this.die = new Animation(20, false);
        this.die.frames(frames, Integer.valueOf(0));
        play(this.idle);
    }

    public void link(Char ch) {
        super.link(ch);
        if (this.shield == null) {
            Group group = this.parent;
            Gizmo shield = new Shield();
            this.shield = shield;
            group.add(shield);
        }
    }

    public void die() {
        super.die();
        if (this.shield != null) {
            this.shield.putOut();
        }
        emitter().start(ElmoParticle.FACTORY, 0.03f, 60);
    }
}
