package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;

public class CrabSprite extends MobSprite {
    public CrabSprite() {
        texture(Assets.CRAB);
        TextureFilm frames = new TextureFilm(this.texture, 16);
        this.idle = new Animation(5, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(2));
        this.run = new Animation(15, true);
        this.run.frames(frames, Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6));
        this.attack = new Animation(12, false);
        this.attack.frames(frames, Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9));
        this.die = new Animation(12, false);
        this.die.frames(frames, Integer.valueOf(10), Integer.valueOf(11), Integer.valueOf(12), Integer.valueOf(13));
        play(this.idle);
    }

    public int blood() {
        return -5504;
    }
}
