package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.effects.Splash;

public class YogSprite extends MobSprite {
    public YogSprite() {
        texture(Assets.YOG);
        TextureFilm frames = new TextureFilm(this.texture, 20, 19);
        this.idle = new Animation(10, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(3), Integer.valueOf(0), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(6), Integer.valueOf(5));
        this.run = new Animation(12, true);
        this.run.frames(frames, Integer.valueOf(0));
        this.attack = new Animation(12, false);
        this.attack.frames(frames, Integer.valueOf(0));
        this.die = new Animation(10, false);
        this.die.frames(frames, Integer.valueOf(0), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9));
        play(this.idle);
    }

    public void die() {
        super.die();
        Splash.at(center(), blood(), 12);
    }
}
