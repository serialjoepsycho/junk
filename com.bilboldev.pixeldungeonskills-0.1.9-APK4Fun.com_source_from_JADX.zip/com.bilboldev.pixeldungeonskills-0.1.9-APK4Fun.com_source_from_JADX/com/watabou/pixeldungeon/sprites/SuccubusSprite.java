package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.particles.ShadowParticle;

public class SuccubusSprite extends MobSprite {
    public SuccubusSprite() {
        texture(Assets.SUCCUBUS);
        TextureFilm frames = new TextureFilm(this.texture, 12, 15);
        this.idle = new Animation(8, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(1));
        this.run = new Animation(15, true);
        this.run.frames(frames, Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8));
        this.attack = new Animation(12, false);
        this.attack.frames(frames, Integer.valueOf(9), Integer.valueOf(10), Integer.valueOf(11));
        this.die = new Animation(10, false);
        this.die.frames(frames, Integer.valueOf(12));
        play(this.idle);
    }

    public void die() {
        super.die();
        emitter().burst(Speck.factory(11), 6);
        emitter().burst(ShadowParticle.UP, 8);
    }
}
