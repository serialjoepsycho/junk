package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;

public class RatSprite extends MobSprite {
    public RatSprite() {
        texture(Assets.RAT);
        TextureFilm frames = new TextureFilm(this.texture, 16, 15);
        this.idle = new Animation(2, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(10, true);
        this.run.frames(frames, Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9), Integer.valueOf(10));
        this.attack = new Animation(15, false);
        this.attack.frames(frames, Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(0));
        this.die = new Animation(10, false);
        this.die.frames(frames, Integer.valueOf(11), Integer.valueOf(12), Integer.valueOf(13), Integer.valueOf(14));
        play(this.idle);
    }
}
