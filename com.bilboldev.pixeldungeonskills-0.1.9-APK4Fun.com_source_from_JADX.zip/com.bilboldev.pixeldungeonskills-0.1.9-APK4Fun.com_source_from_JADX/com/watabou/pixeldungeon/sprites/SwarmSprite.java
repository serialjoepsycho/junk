package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;

public class SwarmSprite extends MobSprite {
    public SwarmSprite() {
        texture(Assets.SWARM);
        TextureFilm frames = new TextureFilm(this.texture, 16, 16);
        this.idle = new Animation(15, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5));
        this.run = new Animation(15, true);
        this.run.frames(frames, Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5));
        this.attack = new Animation(20, false);
        this.attack.frames(frames, Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9));
        this.die = new Animation(15, false);
        this.die.frames(frames, Integer.valueOf(10), Integer.valueOf(11), Integer.valueOf(12), Integer.valueOf(13), Integer.valueOf(14));
        play(this.idle);
    }

    public int blood() {
        return -7626633;
    }
}
