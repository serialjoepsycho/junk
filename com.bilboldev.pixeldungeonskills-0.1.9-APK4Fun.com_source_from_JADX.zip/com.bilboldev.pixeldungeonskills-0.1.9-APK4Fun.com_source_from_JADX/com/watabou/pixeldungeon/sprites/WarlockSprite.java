package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.mobs.Warlock;
import com.watabou.pixeldungeon.effects.MagicMissile;
import com.watabou.utils.Callback;

public class WarlockSprite extends MobSprite {

    /* renamed from: com.watabou.pixeldungeon.sprites.WarlockSprite.1 */
    class C01441 implements Callback {
        C01441() {
        }

        public void call() {
            ((Warlock) WarlockSprite.this.ch).onZapComplete();
        }
    }

    public WarlockSprite() {
        texture(Assets.WARLOCK);
        TextureFilm frames = new TextureFilm(this.texture, 12, 15);
        this.idle = new Animation(2, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(1));
        this.run = new Animation(15, true);
        this.run.frames(frames, Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4));
        this.attack = new Animation(12, false);
        this.attack.frames(frames, Integer.valueOf(0), Integer.valueOf(5), Integer.valueOf(6));
        this.zap = this.attack.clone();
        this.die = new Animation(15, false);
        this.die.frames(frames, Integer.valueOf(0), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(8), Integer.valueOf(9), Integer.valueOf(10));
        play(this.idle);
    }

    public void zap(int cell) {
        turnTo(this.ch.pos, cell);
        play(this.zap);
        MagicMissile.shadow(this.parent, this.ch.pos, cell, new C01441());
        Sample.INSTANCE.play(Assets.SND_ZAP);
    }

    public void onComplete(Animation anim) {
        if (anim == this.zap) {
            idle();
        }
        super.onComplete(anim);
    }
}
