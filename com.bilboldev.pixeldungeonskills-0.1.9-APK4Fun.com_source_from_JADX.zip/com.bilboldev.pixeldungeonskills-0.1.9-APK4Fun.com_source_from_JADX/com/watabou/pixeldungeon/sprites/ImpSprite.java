package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.npcs.Imp;
import com.watabou.pixeldungeon.effects.Speck;

public class ImpSprite extends MobSprite {
    public ImpSprite() {
        texture(Assets.IMP);
        TextureFilm frames = new TextureFilm(this.texture, 12, 14);
        this.idle = new Animation(10, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(3), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4));
        this.run = new Animation(20, true);
        this.run.frames(frames, Integer.valueOf(0));
        this.die = new Animation(10, false);
        this.die.frames(frames, Integer.valueOf(0), Integer.valueOf(3), Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(3), Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(0));
        play(this.idle);
    }

    public void link(Char ch) {
        super.link(ch);
        if (ch instanceof Imp) {
            alpha(0.4f);
        }
    }

    public void onComplete(Animation anim) {
        if (anim == this.die) {
            emitter().burst(Speck.factory(7), 15);
            killAndErase();
            return;
        }
        super.onComplete(anim);
    }
}
