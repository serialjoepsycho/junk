package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.Visual;
import com.watabou.noosa.tweeners.AlphaTweener;
import com.watabou.noosa.tweeners.ScaleTweener;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;

public class MobSprite extends CharSprite {
    private static final float FADE_TIME = 3.0f;
    private static final float FALL_TIME = 1.0f;

    /* renamed from: com.watabou.pixeldungeon.sprites.MobSprite.1 */
    class C01391 extends AlphaTweener {
        C01391(Visual image, float alpha, float time) {
            super(image, alpha, time);
        }

        protected void onComplete() {
            MobSprite.this.killAndErase();
            this.parent.erase(this);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.sprites.MobSprite.2 */
    class C01402 extends ScaleTweener {
        C01402(Visual visual, PointF scale, float time) {
            super(visual, scale, time);
        }

        protected void onComplete() {
            MobSprite.this.killAndErase();
            this.parent.erase(this);
        }

        protected void updateValues(float progress) {
            super.updateValues(progress);
            MobSprite.this.am = MobSprite.FALL_TIME - progress;
        }
    }

    public void update() {
        boolean z = this.ch != null && ((Mob) this.ch).state == ((Mob) this.ch).SLEEPEING;
        this.sleeping = z;
        super.update();
    }

    public void onComplete(Animation anim) {
        super.onComplete(anim);
        if (anim == this.die) {
            this.parent.add(new C01391(this, 0.0f, FADE_TIME));
        }
    }

    public void fall() {
        this.origin.set(this.width / Pickaxe.TIME_TO_MINE, this.height - 8.0f);
        this.angularSpeed = Random.Int(2) == 0 ? -720.0f : 720.0f;
        this.parent.add(new C01402(this, new PointF(0.0f, 0.0f), FALL_TIME));
    }
}
