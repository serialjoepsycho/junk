package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.Camera;
import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;

public class RottingFistSprite extends MobSprite {
    private static final float FALL_SPEED = 64.0f;

    public RottingFistSprite() {
        texture(Assets.ROTTING);
        TextureFilm frames = new TextureFilm(this.texture, 24, 17);
        this.idle = new Animation(2, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(3, true);
        this.run.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.attack = new Animation(2, false);
        this.attack.frames(frames, Integer.valueOf(0));
        this.die = new Animation(10, false);
        this.die.frames(frames, Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4));
        play(this.idle);
    }

    public void attack(int cell) {
        super.attack(cell);
        this.speed.set(0.0f, -64.0f);
        this.acc.set(0.0f, 256.0f);
    }

    public void onComplete(Animation anim) {
        super.onComplete(anim);
        if (anim == this.attack) {
            this.speed.set(0.0f);
            this.acc.set(0.0f);
            place(this.ch.pos);
            Camera.main.shake(4.0f, 0.2f);
        }
    }
}
