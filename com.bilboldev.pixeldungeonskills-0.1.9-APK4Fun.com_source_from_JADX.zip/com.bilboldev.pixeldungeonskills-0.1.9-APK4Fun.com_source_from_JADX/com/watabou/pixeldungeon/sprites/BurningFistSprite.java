package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.effects.MagicMissile;
import com.watabou.utils.Callback;

public class BurningFistSprite extends MobSprite {
    private int posToShoot;

    /* renamed from: com.watabou.pixeldungeon.sprites.BurningFistSprite.1 */
    class C01361 implements Callback {
        C01361() {
        }

        public void call() {
            BurningFistSprite.this.ch.onAttackComplete();
        }
    }

    public BurningFistSprite() {
        texture(Assets.BURNING);
        TextureFilm frames = new TextureFilm(this.texture, 24, 17);
        this.idle = new Animation(2, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(3, true);
        this.run.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.attack = new Animation(8, false);
        this.attack.frames(frames, Integer.valueOf(0), Integer.valueOf(5), Integer.valueOf(6));
        this.die = new Animation(10, false);
        this.die.frames(frames, Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4));
        play(this.idle);
    }

    public void attack(int cell) {
        this.posToShoot = cell;
        super.attack(cell);
    }

    public void onComplete(Animation anim) {
        if (anim == this.attack) {
            Sample.INSTANCE.play(Assets.SND_ZAP);
            MagicMissile.shadow(this.parent, this.ch.pos, this.posToShoot, new C01361());
            idle();
            return;
        }
        super.onComplete(anim);
    }
}
