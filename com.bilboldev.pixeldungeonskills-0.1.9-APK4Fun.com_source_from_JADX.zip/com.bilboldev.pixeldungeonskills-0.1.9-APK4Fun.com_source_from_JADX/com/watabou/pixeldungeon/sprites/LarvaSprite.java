package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.effects.Splash;

public class LarvaSprite extends MobSprite {
    public LarvaSprite() {
        texture(Assets.LARVA);
        TextureFilm frames = new TextureFilm(this.texture, 12, 8);
        this.idle = new Animation(5, true);
        this.idle.frames(frames, Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(5));
        this.run = new Animation(12, true);
        this.run.frames(frames, Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3));
        this.attack = new Animation(15, false);
        this.attack.frames(frames, Integer.valueOf(6), Integer.valueOf(5), Integer.valueOf(7));
        this.die = new Animation(10, false);
        this.die.frames(frames, Integer.valueOf(8));
        play(this.idle);
    }

    public int blood() {
        return 12307558;
    }

    public void die() {
        Splash.at(center(), blood(), 10);
        super.die();
    }
}
