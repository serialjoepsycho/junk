package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;

public class BatSprite extends MobSprite {
    public BatSprite() {
        texture(Assets.BAT);
        TextureFilm frames = new TextureFilm(this.texture, 15, 15);
        this.idle = new Animation(8, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(12, true);
        this.run.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.attack = new Animation(12, false);
        this.attack.frames(frames, Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(0), Integer.valueOf(1));
        this.die = new Animation(12, false);
        this.die.frames(frames, Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6));
        play(this.idle);
    }
}
