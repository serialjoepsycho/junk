package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.items.weapon.missiles.Shuriken;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.utils.Callback;

public class TenguSprite extends MobSprite {
    private Animation cast;

    /* renamed from: com.watabou.pixeldungeon.sprites.TenguSprite.1 */
    class C01431 implements Callback {
        C01431() {
        }

        public void call() {
            TenguSprite.this.ch.onAttackComplete();
        }
    }

    public TenguSprite() {
        texture(Assets.TENGU);
        TextureFilm frames = new TextureFilm(this.texture, 14, 16);
        this.idle = new Animation(2, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(15, false);
        this.run.frames(frames, Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(0));
        this.attack = new Animation(15, false);
        this.attack.frames(frames, Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(7), Integer.valueOf(0));
        this.cast = this.attack.clone();
        this.die = new Animation(8, false);
        this.die.frames(frames, Integer.valueOf(8), Integer.valueOf(9), Integer.valueOf(10), Integer.valueOf(10), Integer.valueOf(10), Integer.valueOf(10), Integer.valueOf(10), Integer.valueOf(10));
        play(this.run.clone());
    }

    public void move(int from, int to) {
        place(to);
        play(this.run);
        turnTo(from, to);
        this.isMoving = true;
        if (Level.water[to]) {
            GameScene.ripple(to);
        }
        this.ch.onMotionComplete();
    }

    public void attack(int cell) {
        if (Level.adjacent(cell, this.ch.pos)) {
            super.attack(cell);
            return;
        }
        ((MissileSprite) this.parent.recycle(MissileSprite.class)).reset(this.ch.pos, cell, new Shuriken(), new C01431());
        play(this.cast);
        turnTo(this.ch.pos, cell);
    }

    public void onComplete(Animation anim) {
        if (anim == this.run) {
            this.isMoving = false;
            idle();
            return;
        }
        super.onComplete(anim);
    }
}
