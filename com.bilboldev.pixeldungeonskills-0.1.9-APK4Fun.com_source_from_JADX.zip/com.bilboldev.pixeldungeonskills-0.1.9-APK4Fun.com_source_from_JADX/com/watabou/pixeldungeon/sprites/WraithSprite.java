package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;

public class WraithSprite extends MobSprite {
    public WraithSprite() {
        texture(Assets.WRAITH);
        TextureFilm frames = new TextureFilm(this.texture, 14, 15);
        this.idle = new Animation(5, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(10, true);
        this.run.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.attack = new Animation(10, false);
        this.attack.frames(frames, Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(3));
        this.die = new Animation(8, false);
        this.die.frames(frames, Integer.valueOf(0), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7));
        play(this.idle);
    }

    public int blood() {
        return -2013265920;
    }
}
