package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.noosa.particles.Emitter;
import com.watabou.noosa.particles.Emitter.Factory;
import com.watabou.noosa.particles.PixelParticle.Shrinking;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;

public class GooSprite extends MobSprite {
    private Animation jump;
    private Animation pump;
    private Emitter spray;

    public static class GooParticle extends Shrinking {
        public static final Factory FACTORY;

        /* renamed from: com.watabou.pixeldungeon.sprites.GooSprite.GooParticle.1 */
        static class C01381 extends Factory {
            C01381() {
            }

            public void emit(Emitter emitter, int index, float x, float y) {
                ((GooParticle) emitter.recycle(GooParticle.class)).reset(x, y);
            }
        }

        static {
            FACTORY = new C01381();
        }

        public GooParticle() {
            color(0);
            this.lifespan = 0.3f;
            this.acc.set(0.0f, 50.0f);
        }

        public void reset(float x, float y) {
            revive();
            this.x = x;
            this.y = y;
            this.left = this.lifespan;
            this.size = 4.0f;
            this.speed.polar(-Random.Float(PointF.PI), Random.Float(32.0f, DashboardItem.SIZE));
        }

        public void update() {
            float f = Key.TIME_TO_UNLOCK;
            super.update();
            float p = this.left / this.lifespan;
            if (p > 0.5f) {
                f = (Key.TIME_TO_UNLOCK - p) * Pickaxe.TIME_TO_MINE;
            }
            this.am = f;
        }
    }

    public GooSprite() {
        texture(Assets.GOO);
        TextureFilm frames = new TextureFilm(this.texture, 20, 14);
        this.idle = new Animation(10, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(10, true);
        this.run.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.pump = new Animation(20, true);
        this.pump.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.jump = new Animation(1, true);
        this.jump.frames(frames, Integer.valueOf(6));
        this.attack = new Animation(10, false);
        this.attack.frames(frames, Integer.valueOf(5), Integer.valueOf(0), Integer.valueOf(6));
        this.die = new Animation(10, false);
        this.die.frames(frames, Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4));
        play(this.idle);
    }

    public void pumpUp() {
        play(this.pump);
    }

    public void play(Animation anim, boolean force) {
        super.play(anim, force);
        if (anim == this.pump) {
            this.spray = centerEmitter();
            this.spray.pour(GooParticle.FACTORY, 0.04f);
        } else if (this.spray != null) {
            this.spray.on = false;
            this.spray = null;
        }
    }

    public int blood() {
        return -16777216;
    }
}
