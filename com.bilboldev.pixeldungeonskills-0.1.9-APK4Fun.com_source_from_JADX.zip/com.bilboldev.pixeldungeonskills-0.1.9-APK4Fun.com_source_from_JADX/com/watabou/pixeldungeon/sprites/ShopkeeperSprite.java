package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.noosa.particles.PixelParticle;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.scenes.PixelScene;

public class ShopkeeperSprite extends MobSprite {
    private PixelParticle coin;

    public ShopkeeperSprite() {
        texture(Assets.KEEPER);
        TextureFilm film = new TextureFilm(this.texture, 14, 14);
        this.idle = new Animation(10, true);
        this.idle.frames(film, Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0));
        this.run = this.idle.clone();
        this.die = this.idle.clone();
        this.attack = this.idle.clone();
        idle();
    }

    public void onComplete(Animation anim) {
        super.onComplete(anim);
        if (this.visible && anim == this.idle) {
            if (this.coin == null) {
                this.coin = new PixelParticle();
                this.parent.add(this.coin);
            }
            this.coin.reset(((float) (this.flipHorizontal ? 0 : 13)) + this.x, this.y + 7.0f, CharSprite.NEUTRAL, Key.TIME_TO_UNLOCK, 0.5f);
            this.coin.speed.f25y = -40.0f;
            this.coin.acc.f25y = PixelScene.MIN_HEIGHT_L;
        }
    }
}
