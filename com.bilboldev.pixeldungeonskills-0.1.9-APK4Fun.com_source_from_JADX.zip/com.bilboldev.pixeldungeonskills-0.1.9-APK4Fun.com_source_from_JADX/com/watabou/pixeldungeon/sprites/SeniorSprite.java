package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.utils.Random;

public class SeniorSprite extends MobSprite {
    private Animation kick;

    public SeniorSprite() {
        texture(Assets.MONK);
        TextureFilm frames = new TextureFilm(this.texture, 15, 14);
        this.idle = new Animation(6, true);
        this.idle.frames(frames, Integer.valueOf(18), Integer.valueOf(17), Integer.valueOf(18), Integer.valueOf(19));
        this.run = new Animation(15, true);
        this.run.frames(frames, Integer.valueOf(28), Integer.valueOf(29), Integer.valueOf(30), Integer.valueOf(31), Integer.valueOf(32), Integer.valueOf(33));
        this.attack = new Animation(12, false);
        this.attack.frames(frames, Integer.valueOf(20), Integer.valueOf(21), Integer.valueOf(20), Integer.valueOf(21));
        this.kick = new Animation(10, false);
        this.kick.frames(frames, Integer.valueOf(22), Integer.valueOf(23), Integer.valueOf(22));
        this.die = new Animation(15, false);
        this.die.frames(frames, Integer.valueOf(18), Integer.valueOf(24), Integer.valueOf(25), Integer.valueOf(25), Integer.valueOf(26), Integer.valueOf(27));
        play(this.idle);
    }

    public void attack(int cell) {
        super.attack(cell);
        if (Random.Float() < 0.3f) {
            play(this.kick);
        }
    }

    public void onComplete(Animation anim) {
        if (anim == this.kick) {
            anim = this.attack;
        }
        super.onComplete(anim);
    }
}
