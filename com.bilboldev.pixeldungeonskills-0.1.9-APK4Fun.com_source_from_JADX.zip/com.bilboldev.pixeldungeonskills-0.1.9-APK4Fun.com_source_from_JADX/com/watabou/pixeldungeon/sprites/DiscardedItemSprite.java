package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.Game;
import com.watabou.pixeldungeon.items.keys.Key;

public class DiscardedItemSprite extends ItemSprite {
    public DiscardedItemSprite() {
        originToCenter();
        this.angularSpeed = 720.0f;
    }

    public void drop() {
        this.scale.set((float) Key.TIME_TO_UNLOCK);
        this.am = Key.TIME_TO_UNLOCK;
    }

    public void update() {
        super.update();
        this.scale.set(this.scale.f24x * 0.9f);
        float f = this.am - Game.elapsed;
        this.am = f;
        if (f <= 0.0f) {
            remove();
        }
    }
}
