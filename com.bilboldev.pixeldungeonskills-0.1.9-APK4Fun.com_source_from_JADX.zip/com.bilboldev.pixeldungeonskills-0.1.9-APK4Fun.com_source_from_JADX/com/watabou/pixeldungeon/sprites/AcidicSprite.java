package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;

public class AcidicSprite extends ScorpioSprite {
    public AcidicSprite() {
        texture(Assets.SCORPIO);
        TextureFilm frames = new TextureFilm(this.texture, 18, 17);
        this.idle = new Animation(12, true);
        this.idle.frames(frames, Integer.valueOf(14), Integer.valueOf(14), Integer.valueOf(14), Integer.valueOf(14), Integer.valueOf(14), Integer.valueOf(14), Integer.valueOf(14), Integer.valueOf(14), Integer.valueOf(15), Integer.valueOf(16), Integer.valueOf(15), Integer.valueOf(16), Integer.valueOf(15), Integer.valueOf(16));
        this.run = new Animation(4, true);
        this.run.frames(frames, Integer.valueOf(19), Integer.valueOf(20));
        this.attack = new Animation(15, false);
        this.attack.frames(frames, Integer.valueOf(14), Integer.valueOf(17), Integer.valueOf(18));
        this.zap = this.attack.clone();
        this.die = new Animation(12, false);
        this.die.frames(frames, Integer.valueOf(14), Integer.valueOf(21), Integer.valueOf(22), Integer.valueOf(23), Integer.valueOf(24));
        play(this.idle);
    }

    public int blood() {
        return -10027230;
    }
}
