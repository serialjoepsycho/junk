package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.scenes.GameScene;

public class PiranhaSprite extends MobSprite {
    public PiranhaSprite() {
        texture(Assets.PIRANHA);
        TextureFilm frames = new TextureFilm(this.texture, 12, 16);
        this.idle = new Animation(8, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(1));
        this.run = new Animation(20, true);
        this.run.frames(frames, Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(1));
        this.attack = new Animation(20, false);
        this.attack.frames(frames, Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9), Integer.valueOf(10), Integer.valueOf(11));
        this.die = new Animation(4, false);
        this.die.frames(frames, Integer.valueOf(12), Integer.valueOf(13), Integer.valueOf(14));
        play(this.idle);
    }

    public void onComplete(Animation anim) {
        super.onComplete(anim);
        if (anim == this.attack) {
            GameScene.ripple(this.ch.pos);
        }
    }
}
