package com.watabou.pixeldungeon.sprites;

import android.graphics.Bitmap;
import com.watabou.gltextures.TextureCache;
import com.watabou.noosa.Game;
import com.watabou.noosa.MovieClip;
import com.watabou.noosa.TextureFilm;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.Gold;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;

public class ItemSprite extends MovieClip {
    private static final float DROP_INTERVAL = 0.4f;
    public static final int SIZE = 16;
    protected static TextureFilm film;
    private float dropInterval;
    private boolean glowUp;
    private Glowing glowing;
    public Heap heap;
    private float phase;

    public static class Glowing {
        public static final Glowing WHITE;
        public float blue;
        public float green;
        public float period;
        public float red;

        static {
            WHITE = new Glowing(CharSprite.DEFAULT, 0.6f);
        }

        public Glowing(int color) {
            this(color, Key.TIME_TO_UNLOCK);
        }

        public Glowing(int color, float period) {
            this.red = ((float) (color >> ItemSprite.SIZE)) / 255.0f;
            this.green = ((float) ((color >> 8) & 255)) / 255.0f;
            this.blue = ((float) (color & 255)) / 255.0f;
            this.period = period;
        }
    }

    public ItemSprite() {
        this(ItemSpriteSheet.SMTH, null);
    }

    public ItemSprite(Item item) {
        this(item.image(), item.glowing());
    }

    public ItemSprite(int image, Glowing glowing) {
        super(Assets.ITEMS);
        if (film == null) {
            film = new TextureFilm(this.texture, SIZE, SIZE);
        }
        view(image, glowing);
    }

    public void originToCenter() {
        this.origin.set(8.0f);
    }

    public void link() {
        link(this.heap);
    }

    public void link(Heap heap) {
        this.heap = heap;
        view(heap.image(), heap.glowing());
        place(heap.pos);
    }

    public void revive() {
        super.revive();
        this.speed.set(0.0f);
        this.acc.set(0.0f);
        this.dropInterval = 0.0f;
        this.heap = null;
    }

    public PointF worldToCamera(int cell) {
        return new PointF(((float) ((cell % 32) * SIZE)) + 0.0f, ((float) ((cell / 32) * SIZE)) + 0.0f);
    }

    public void place(int p) {
        point(worldToCamera(p));
    }

    public void drop() {
        if (!this.heap.isEmpty()) {
            this.dropInterval = DROP_INTERVAL;
            this.speed.set(0.0f, -100.0f);
            this.acc.set(0.0f, ((-this.speed.f25y) / DROP_INTERVAL) * Pickaxe.TIME_TO_MINE);
            if (this.visible && this.heap != null && (this.heap.peek() instanceof Gold)) {
                CellEmitter.center(this.heap.pos).burst(Speck.factory(14), 5);
                Sample.INSTANCE.play(Assets.SND_GOLD, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Random.Float(0.9f, 1.1f));
            }
        }
    }

    public void drop(int from) {
        if (this.heap.pos == from) {
            drop();
            return;
        }
        float px = this.x;
        float py = this.y;
        drop();
        place(from);
        this.speed.offset((px - this.x) / DROP_INTERVAL, (py - this.y) / DROP_INTERVAL);
    }

    public ItemSprite view(int image, Glowing glowing) {
        frame(film.get(Integer.valueOf(image)));
        this.glowing = glowing;
        if (glowing == null) {
            resetColor();
        }
        return this;
    }

    public void update() {
        float f;
        super.update();
        boolean z = this.heap == null || Dungeon.visible[this.heap.pos];
        this.visible = z;
        if (this.dropInterval > 0.0f) {
            f = this.dropInterval - Game.elapsed;
            this.dropInterval = f;
            if (f <= 0.0f) {
                this.speed.set(0.0f);
                this.acc.set(0.0f);
                place(this.heap.pos);
                if (this.visible) {
                    boolean water = Level.water[this.heap.pos];
                    if (water) {
                        GameScene.ripple(this.heap.pos);
                    } else {
                        int cell = Dungeon.level.map[this.heap.pos];
                        water = cell == 34 || cell == 42;
                    }
                    if (!(this.heap.peek() instanceof Gold)) {
                        Sample.INSTANCE.play(water ? Assets.SND_WATER : Assets.SND_STEP, 0.8f, 0.8f, 1.2f);
                    }
                }
            }
        }
        if (this.visible && this.glowing != null) {
            float value;
            if (this.glowUp) {
                f = this.phase + Game.elapsed;
                this.phase = f;
                if (f > this.glowing.period) {
                    this.glowUp = false;
                    this.phase = this.glowing.period;
                    value = (this.phase / this.glowing.period) * 0.6f;
                    f = Key.TIME_TO_UNLOCK - value;
                    this.bm = f;
                    this.gm = f;
                    this.rm = f;
                    this.ra = this.glowing.red * value;
                    this.ga = this.glowing.green * value;
                    this.ba = this.glowing.blue * value;
                }
            }
            if (!this.glowUp) {
                f = this.phase - Game.elapsed;
                this.phase = f;
                if (f < 0.0f) {
                    this.glowUp = true;
                    this.phase = 0.0f;
                }
            }
            value = (this.phase / this.glowing.period) * 0.6f;
            f = Key.TIME_TO_UNLOCK - value;
            this.bm = f;
            this.gm = f;
            this.rm = f;
            this.ra = this.glowing.red * value;
            this.ga = this.glowing.green * value;
            this.ba = this.glowing.blue * value;
        }
    }

    public static int pick(int index, int x, int y) {
        Bitmap bmp = TextureCache.get(Assets.ITEMS).bitmap;
        int rows = bmp.getWidth() / SIZE;
        return bmp.getPixel(((index % rows) * SIZE) + x, ((index / rows) * SIZE) + y);
    }
}
