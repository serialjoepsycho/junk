package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.mobs.Shaman;
import com.watabou.pixeldungeon.effects.Lightning;

public class ShamanSprite extends MobSprite {
    private int[] points;

    public ShamanSprite() {
        this.points = new int[2];
        texture(Assets.SHAMAN);
        TextureFilm frames = new TextureFilm(this.texture, 12, 15);
        this.idle = new Animation(2, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(1));
        this.run = new Animation(12, true);
        this.run.frames(frames, Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7));
        this.attack = new Animation(12, false);
        this.attack.frames(frames, Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(0));
        this.zap = this.attack.clone();
        this.die = new Animation(12, false);
        this.die.frames(frames, Integer.valueOf(8), Integer.valueOf(9), Integer.valueOf(10));
        play(this.idle);
    }

    public void zap(int pos) {
        this.points[0] = this.ch.pos;
        this.points[1] = pos;
        this.parent.add(new Lightning(this.points, 2, (Shaman) this.ch));
        turnTo(this.ch.pos, pos);
        play(this.zap);
    }
}
