package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;

public class ThiefSprite extends MobSprite {
    public ThiefSprite() {
        texture(Assets.THIEF);
        TextureFilm film = new TextureFilm(this.texture, 12, 13);
        this.idle = new Animation(1, true);
        this.idle.frames(film, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(15, true);
        this.run.frames(film, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(3), Integer.valueOf(4));
        this.die = new Animation(10, false);
        this.die.frames(film, Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9));
        this.attack = new Animation(12, false);
        this.attack.frames(film, Integer.valueOf(10), Integer.valueOf(11), Integer.valueOf(12), Integer.valueOf(0));
        idle();
    }
}
