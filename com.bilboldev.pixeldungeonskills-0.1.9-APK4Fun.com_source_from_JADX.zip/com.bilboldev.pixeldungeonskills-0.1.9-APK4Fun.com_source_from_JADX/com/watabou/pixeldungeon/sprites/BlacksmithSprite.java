package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.particles.Emitter;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.levels.Level;

public class BlacksmithSprite extends MobSprite {
    private Emitter emitter;

    public BlacksmithSprite() {
        texture(Assets.TROLL);
        TextureFilm frames = new TextureFilm(this.texture, 13, 16);
        this.idle = new Animation(15, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(2), Integer.valueOf(3));
        this.run = new Animation(20, true);
        this.run.frames(frames, Integer.valueOf(0));
        this.die = new Animation(20, false);
        this.die.frames(frames, Integer.valueOf(0));
        play(this.idle);
    }

    public void link(Char ch) {
        super.link(ch);
        this.emitter = new Emitter();
        this.emitter.autoKill = false;
        this.emitter.pos(this.x + 7.0f, this.y + 12.0f);
        this.parent.add(this.emitter);
    }

    public void update() {
        super.update();
        if (this.emitter != null) {
            this.emitter.visible = this.visible;
        }
    }

    public void onComplete(Animation anim) {
        super.onComplete(anim);
        if (this.visible && this.emitter != null && anim == this.idle) {
            this.emitter.burst(Speck.factory(ItemSpriteSheet.JAVELIN), 3);
            float volume = 0.2f / ((float) Level.distance(this.ch.pos, Dungeon.hero.pos));
            Sample.INSTANCE.play(Assets.SND_EVOKE, volume, volume, 0.8f);
        }
    }
}
