package com.watabou.pixeldungeon.sprites;

import android.graphics.RectF;
import com.watabou.gltextures.SmartTexture;
import com.watabou.gltextures.TextureCache;
import com.watabou.noosa.Camera;
import com.watabou.noosa.Image;
import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.utils.Callback;

public class HeroSprite extends CharSprite {
    private static final int FRAME_HEIGHT = 15;
    private static final int FRAME_WIDTH = 12;
    private static final int RUN_FRAMERATE = 20;
    private static TextureFilm tiers;
    private Animation fly;

    public HeroSprite() {
        link(Dungeon.hero);
        texture(Dungeon.hero.heroClass.spritesheet());
        updateArmor();
        idle();
    }

    public void updateArmor() {
        TextureFilm film = new TextureFilm(tiers(), Integer.valueOf(((Hero) this.ch).tier()), FRAME_WIDTH, FRAME_HEIGHT);
        this.idle = new Animation(1, true);
        this.idle.frames(film, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(1));
        this.run = new Animation(RUN_FRAMERATE, true);
        this.run.frames(film, Integer.valueOf(2), Integer.valueOf(3), Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(7));
        this.die = new Animation(RUN_FRAMERATE, false);
        this.die.frames(film, Integer.valueOf(8), Integer.valueOf(9), Integer.valueOf(10), Integer.valueOf(11), Integer.valueOf(FRAME_WIDTH), Integer.valueOf(11));
        this.attack = new Animation(FRAME_HEIGHT, false);
        this.attack.frames(film, Integer.valueOf(13), Integer.valueOf(14), Integer.valueOf(FRAME_HEIGHT), Integer.valueOf(0));
        this.zap = this.attack.clone();
        this.operate = new Animation(8, false);
        this.operate.frames(film, Integer.valueOf(16), Integer.valueOf(17), Integer.valueOf(16), Integer.valueOf(17));
        this.fly = new Animation(1, true);
        this.fly.frames(film, Integer.valueOf(18));
    }

    public void place(int p) {
        super.place(p);
        Camera.main.target = this;
    }

    public void move(int from, int to) {
        super.move(from, to);
        if (this.ch.flying) {
            play(this.fly);
        }
        Camera.main.target = this;
    }

    public void jump(int from, int to, Callback callback) {
        super.jump(from, to, callback);
        play(this.fly);
    }

    public void update() {
        this.sleeping = ((Hero) this.ch).restoreHealth;
        super.update();
    }

    public boolean sprint(boolean on) {
        this.run.delay = on ? 0.03125f : 0.05f;
        return on;
    }

    public static TextureFilm tiers() {
        if (tiers == null) {
            SmartTexture texture = TextureCache.get(Assets.ROGUE);
            tiers = new TextureFilm(texture, texture.width, FRAME_HEIGHT);
        }
        return tiers;
    }

    public static Image avatar(HeroClass cl, int armorTier) {
        RectF patch = tiers().get(Integer.valueOf(armorTier));
        Image avatar = new Image(cl.spritesheet());
        RectF frame = avatar.texture.uvRect(1, 0, FRAME_WIDTH, FRAME_HEIGHT);
        frame.offset(patch.left, patch.top);
        avatar.frame(frame);
        return avatar;
    }
}
