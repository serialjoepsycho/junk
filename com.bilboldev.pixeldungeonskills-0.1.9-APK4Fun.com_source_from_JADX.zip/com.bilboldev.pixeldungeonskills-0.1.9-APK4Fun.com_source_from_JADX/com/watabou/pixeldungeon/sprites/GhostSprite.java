package com.watabou.pixeldungeon.sprites;

import android.opengl.GLES20;
import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.particles.ShaftParticle;

public class GhostSprite extends MobSprite {
    public GhostSprite() {
        texture(Assets.GHOST);
        TextureFilm frames = new TextureFilm(this.texture, 14, 15);
        this.idle = new Animation(5, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(10, true);
        this.run.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.die = new Animation(20, false);
        this.die.frames(frames, Integer.valueOf(0));
        play(this.idle);
    }

    public void draw() {
        GLES20.glBlendFunc(770, 1);
        super.draw();
        GLES20.glBlendFunc(770, 771);
    }

    public void die() {
        super.die();
        emitter().start(ShaftParticle.FACTORY, 0.3f, 4);
        emitter().start(Speck.factory(2), 0.2f, 3);
    }

    public int blood() {
        return CharSprite.DEFAULT;
    }
}
