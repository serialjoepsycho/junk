package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.effects.DeathRay;

public class EyeSprite extends MobSprite {
    private int attackPos;

    public EyeSprite() {
        texture(Assets.EYE);
        TextureFilm frames = new TextureFilm(this.texture, 16, 18);
        this.idle = new Animation(8, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2));
        this.run = new Animation(12, true);
        this.run.frames(frames, Integer.valueOf(5), Integer.valueOf(6));
        this.attack = new Animation(8, false);
        this.attack.frames(frames, Integer.valueOf(4), Integer.valueOf(3));
        this.die = new Animation(8, false);
        this.die.frames(frames, Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9));
        play(this.idle);
    }

    public void attack(int pos) {
        this.attackPos = pos;
        super.attack(pos);
    }

    public void onComplete(Animation anim) {
        super.onComplete(anim);
        if (anim != this.attack) {
            return;
        }
        if (Dungeon.visible[this.ch.pos] || Dungeon.visible[this.attackPos]) {
            this.parent.add(new DeathRay(center(), DungeonTilemap.tileCenterToWorld(this.attackPos)));
        }
    }
}
