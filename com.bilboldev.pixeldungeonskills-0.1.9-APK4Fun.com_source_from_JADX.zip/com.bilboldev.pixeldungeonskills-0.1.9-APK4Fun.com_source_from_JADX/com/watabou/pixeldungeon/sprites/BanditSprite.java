package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;

public class BanditSprite extends MobSprite {
    public BanditSprite() {
        texture(Assets.THIEF);
        TextureFilm film = new TextureFilm(this.texture, 12, 13);
        this.idle = new Animation(1, true);
        this.idle.frames(film, Integer.valueOf(21), Integer.valueOf(21), Integer.valueOf(21), Integer.valueOf(22), Integer.valueOf(21), Integer.valueOf(21), Integer.valueOf(21), Integer.valueOf(21), Integer.valueOf(22));
        this.run = new Animation(15, true);
        this.run.frames(film, Integer.valueOf(21), Integer.valueOf(21), Integer.valueOf(23), Integer.valueOf(24), Integer.valueOf(24), Integer.valueOf(25));
        this.die = new Animation(10, false);
        this.die.frames(film, Integer.valueOf(25), Integer.valueOf(27), Integer.valueOf(28), Integer.valueOf(29), Integer.valueOf(30));
        this.attack = new Animation(12, false);
        this.attack.frames(film, Integer.valueOf(31), Integer.valueOf(32), Integer.valueOf(33));
        idle();
    }
}
