package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.effects.Speck;

public class DM300Sprite extends MobSprite {
    public DM300Sprite() {
        texture(Assets.DM300);
        TextureFilm frames = new TextureFilm(this.texture, 22, 20);
        this.idle = new Animation(10, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(1));
        this.run = new Animation(10, true);
        this.run.frames(frames, Integer.valueOf(2), Integer.valueOf(3));
        this.attack = new Animation(15, false);
        this.attack.frames(frames, Integer.valueOf(4), Integer.valueOf(5), Integer.valueOf(6));
        this.die = new Animation(20, false);
        this.die.frames(frames, Integer.valueOf(0), Integer.valueOf(7), Integer.valueOf(0), Integer.valueOf(7), Integer.valueOf(0), Integer.valueOf(7), Integer.valueOf(0), Integer.valueOf(7), Integer.valueOf(0), Integer.valueOf(7), Integer.valueOf(0), Integer.valueOf(7), Integer.valueOf(8));
        play(this.idle);
    }

    public void onComplete(Animation anim) {
        super.onComplete(anim);
        if (anim == this.die) {
            emitter().burst(Speck.factory(7), 15);
        }
    }

    public int blood() {
        return -120;
    }
}
