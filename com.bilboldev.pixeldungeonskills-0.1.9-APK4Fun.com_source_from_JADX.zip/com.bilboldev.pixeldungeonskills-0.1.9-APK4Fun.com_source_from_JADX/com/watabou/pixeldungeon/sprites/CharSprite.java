package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.Game;
import com.watabou.noosa.MovieClip;
import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.Visual;
import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.particles.Emitter;
import com.watabou.noosa.tweeners.PosTweener;
import com.watabou.noosa.tweeners.Tweener;
import com.watabou.noosa.tweeners.Tweener.Listener;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.effects.ChampBlackHalo;
import com.watabou.pixeldungeon.effects.ChampRedHalo;
import com.watabou.pixeldungeon.effects.ChampWhiteHalo;
import com.watabou.pixeldungeon.effects.ChampYellowHalo;
import com.watabou.pixeldungeon.effects.EmoIcon;
import com.watabou.pixeldungeon.effects.EmoIcon.Alert;
import com.watabou.pixeldungeon.effects.EmoIcon.Sleep;
import com.watabou.pixeldungeon.effects.FloatingText;
import com.watabou.pixeldungeon.effects.IceBlock;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.Splash;
import com.watabou.pixeldungeon.effects.TorchHalo;
import com.watabou.pixeldungeon.effects.particles.FlameParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.potions.PotionOfInvisibility;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Callback;
import com.watabou.utils.PointF;
import com.watabou.utils.Random;

public class CharSprite extends MovieClip implements Listener, MovieClip.Listener {
    public static final int DEFAULT = 16777215;
    private static final float FLASH_INTERVAL = 0.05f;
    private static final float MOVE_INTERVAL = 0.1f;
    public static final int NEGATIVE = 16711680;
    public static final int NEUTRAL = 16776960;
    public static final int POSITIVE = 65280;
    public static final int WARNING = 16746496;
    protected Callback animCallback;
    protected Animation attack;
    protected Emitter burning;
    public Char ch;
    public ChampBlackHalo champBlackHalo;
    public ChampRedHalo champRedHalo;
    public ChampWhiteHalo champWhiteHalo;
    public ChampYellowHalo champYellowHalo;
    protected Animation die;
    protected EmoIcon emo;
    private float flashTime;
    protected TorchHalo halo;
    protected IceBlock iceBlock;
    protected Animation idle;
    public boolean isMoving;
    private Callback jumpCallback;
    private Tweener jumpTweener;
    protected Emitter levitation;
    protected Tweener motion;
    protected Animation operate;
    protected Animation run;
    protected boolean sleeping;
    protected Animation zap;

    /* renamed from: com.watabou.pixeldungeon.sprites.CharSprite.1 */
    static /* synthetic */ class C01371 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State;

        static {
            $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State = new int[State.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[State.BURNING.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[State.LEVITATING.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[State.INVISIBLE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[State.PARALYSED.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[State.FROZEN.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[State.ILLUMINATED.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[State.CHAMPRED.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[State.CHAMPWHITE.ordinal()] = 8;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[State.CHAMPBLACK.ordinal()] = 9;
            } catch (NoSuchFieldError e9) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[State.CHAMPYELLOW.ordinal()] = 10;
            } catch (NoSuchFieldError e10) {
            }
        }
    }

    private static class JumpTweener extends Tweener {
        public PointF end;
        public float height;
        public PointF start;
        public Visual visual;

        public JumpTweener(Visual visual, PointF pos, float height, float time) {
            super(visual, time);
            this.visual = visual;
            this.start = visual.point();
            this.end = pos;
            this.height = height;
        }

        protected void updateValues(float progress) {
            this.visual.point(PointF.inter(this.start, this.end, progress).offset(0.0f, (((-this.height) * 4.0f) * progress) * (Key.TIME_TO_UNLOCK - progress)));
        }
    }

    public enum State {
        BURNING,
        LEVITATING,
        INVISIBLE,
        PARALYSED,
        FROZEN,
        ILLUMINATED,
        CHAMPRED,
        CHAMPBLACK,
        CHAMPWHITE,
        CHAMPYELLOW
    }

    public void NotAChamp() {
        if (this.champRedHalo != null) {
            this.champRedHalo.putOut();
        }
        if (this.champYellowHalo != null) {
            this.champYellowHalo.putOut();
        }
        if (this.champBlackHalo != null) {
            this.champBlackHalo.putOut();
        }
        if (this.champWhiteHalo != null) {
            this.champWhiteHalo.putOut();
        }
    }

    public CharSprite() {
        this.flashTime = 0.0f;
        this.sleeping = false;
        this.isMoving = false;
        this.listener = this;
    }

    public void link(Char ch) {
        this.ch = ch;
        ch.sprite = this;
        place(ch.pos);
        turnTo(ch.pos, Random.Int(Level.LENGTH));
        ch.updateSpriteState();
    }

    public PointF worldToCamera(int cell) {
        return new PointF(((((float) (cell % 32)) + 0.5f) * ShadowBox.SIZE) - (this.width * 0.5f), ((((float) (cell / 32)) + Key.TIME_TO_UNLOCK) * ShadowBox.SIZE) - this.height);
    }

    public void place(int cell) {
        point(worldToCamera(cell));
    }

    public void showStatus(int color, String text, Object... args) {
        if (this.visible) {
            if (args.length > 0) {
                text = Utils.format(text, args);
            }
            if (this.ch != null) {
                FloatingText.show(this.x + (this.width * 0.5f), this.y, this.ch.pos, text, color);
            } else {
                FloatingText.show(this.x + (this.width * 0.5f), this.y, text, color);
            }
        }
    }

    public void idle() {
        play(this.idle);
    }

    public void move(int from, int to) {
        play(this.run);
        this.motion = new PosTweener(this, worldToCamera(to), MOVE_INTERVAL);
        this.motion.listener = this;
        this.parent.add(this.motion);
        this.isMoving = true;
        turnTo(from, to);
        if (this.visible && Level.water[from] && !this.ch.flying) {
            GameScene.ripple(from);
        }
        this.ch.onMotionComplete();
    }

    public void interruptMotion() {
        if (this.motion != null) {
            onComplete(this.motion);
        }
    }

    public void attack(int cell) {
        turnTo(this.ch.pos, cell);
        play(this.attack);
    }

    public void attack(int cell, Callback callback) {
        this.animCallback = callback;
        turnTo(this.ch.pos, cell);
        play(this.attack);
    }

    public void operate(int cell) {
        turnTo(this.ch.pos, cell);
        play(this.operate);
    }

    public void zap(int cell) {
        turnTo(this.ch.pos, cell);
        play(this.zap);
    }

    public void turnTo(int from, int to) {
        int fx = from % 32;
        int tx = to % 32;
        if (tx > fx) {
            this.flipHorizontal = false;
        } else if (tx < fx) {
            this.flipHorizontal = true;
        }
    }

    public void jump(int from, int to, Callback callback) {
        this.jumpCallback = callback;
        int distance = Level.distance(from, to);
        this.jumpTweener = new JumpTweener(this, worldToCamera(to), (float) (distance * 4), ((float) distance) * MOVE_INTERVAL);
        this.jumpTweener.listener = this;
        this.parent.add(this.jumpTweener);
        turnTo(from, to);
    }

    public void die() {
        this.sleeping = false;
        play(this.die);
        if (this.emo != null) {
            this.emo.killAndErase();
        }
    }

    public Emitter emitter() {
        Emitter emitter = GameScene.emitter();
        emitter.pos((Visual) this);
        return emitter;
    }

    public Emitter centerEmitter() {
        Emitter emitter = GameScene.emitter();
        emitter.pos(center());
        return emitter;
    }

    public Emitter bottomEmitter() {
        Emitter emitter = GameScene.emitter();
        emitter.pos(this.x, this.y + this.height, this.width, 0.0f);
        return emitter;
    }

    public void burst(int color, int n) {
        if (this.visible) {
            Splash.at(center(), color, n);
        }
    }

    public void bloodBurstA(PointF from, int damage) {
        if (this.visible) {
            PointF c = center();
            Splash.at(c, PointF.angle(from, c), 1.5707963f, blood(), (int) Math.min(Math.sqrt(((double) damage) / ((double) this.ch.HT)) * 9.0d, 9.0d));
        }
    }

    public int blood() {
        return -4521984;
    }

    public void flash() {
        this.ga = Key.TIME_TO_UNLOCK;
        this.ba = Key.TIME_TO_UNLOCK;
        this.ra = Key.TIME_TO_UNLOCK;
        this.flashTime = FLASH_INTERVAL;
    }

    public void add(State state) {
        Visual torchHalo;
        switch (C01371.$SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[state.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                this.burning = emitter();
                this.burning.pour(FlameParticle.FACTORY, 0.06f);
                if (this.visible) {
                    Sample.INSTANCE.play(Assets.SND_BURNING);
                }
            case WndUpdates.ID_CAVES /*2*/:
                this.levitation = emitter();
                this.levitation.pour(Speck.factory(ItemSpriteSheet.BOOMERANG), 0.02f);
            case WndUpdates.ID_METROPOLIS /*3*/:
                PotionOfInvisibility.melt(this.ch);
            case WndUpdates.ID_HALLS /*4*/:
                this.paused = true;
            case BuffIndicator.HUNGER /*5*/:
                this.iceBlock = IceBlock.freeze(this);
                this.paused = true;
            case BuffIndicator.STARVATION /*6*/:
                torchHalo = new TorchHalo(this);
                this.halo = torchHalo;
                GameScene.effect(torchHalo);
            case BuffIndicator.SLOW /*7*/:
                torchHalo = new ChampRedHalo(this);
                this.champRedHalo = torchHalo;
                GameScene.effect(torchHalo);
            case BuffIndicator.OOZE /*8*/:
                torchHalo = new ChampWhiteHalo(this);
                this.champWhiteHalo = torchHalo;
                GameScene.effect(torchHalo);
            case BuffIndicator.AMOK /*9*/:
                torchHalo = new ChampBlackHalo(this);
                this.champBlackHalo = torchHalo;
                GameScene.effect(torchHalo);
            case BuffIndicator.TERROR /*10*/:
                torchHalo = new ChampYellowHalo(this);
                this.champYellowHalo = torchHalo;
                GameScene.effect(torchHalo);
            default:
        }
    }

    public void remove(State state) {
        switch (C01371.$SwitchMap$com$watabou$pixeldungeon$sprites$CharSprite$State[state.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                if (this.burning != null) {
                    this.burning.on = false;
                    this.burning = null;
                }
            case WndUpdates.ID_CAVES /*2*/:
                if (this.levitation != null) {
                    this.levitation.on = false;
                    this.levitation = null;
                }
            case WndUpdates.ID_METROPOLIS /*3*/:
                alpha(Key.TIME_TO_UNLOCK);
            case WndUpdates.ID_HALLS /*4*/:
                this.paused = false;
            case BuffIndicator.HUNGER /*5*/:
                if (this.iceBlock != null) {
                    this.iceBlock.melt();
                    this.iceBlock = null;
                }
                this.paused = false;
            case BuffIndicator.STARVATION /*6*/:
                if (this.halo != null) {
                    this.halo.putOut();
                }
            default:
        }
    }

    public void update() {
        super.update();
        if (this.paused && this.listener != null) {
            this.listener.onComplete(this.curAnim);
        }
        if (this.flashTime > 0.0f) {
            float f = this.flashTime - Game.elapsed;
            this.flashTime = f;
            if (f <= 0.0f) {
                resetColor();
            }
        }
        if (this.burning != null) {
            this.burning.visible = this.visible;
        }
        if (this.levitation != null) {
            this.levitation.visible = this.visible;
        }
        if (this.iceBlock != null) {
            this.iceBlock.visible = this.visible;
        }
        if (this.sleeping) {
            showSleep();
        } else {
            hideSleep();
        }
        if (this.emo != null) {
            this.emo.visible = this.visible;
        }
    }

    public void showSleep() {
        if (!(this.emo instanceof Sleep)) {
            if (this.emo != null) {
                this.emo.killAndErase();
            }
            this.emo = new Sleep(this);
        }
    }

    public void hideSleep() {
        if (this.emo instanceof Sleep) {
            this.emo.killAndErase();
            this.emo = null;
        }
    }

    public void showAlert() {
        if (!(this.emo instanceof Alert)) {
            if (this.emo != null) {
                this.emo.killAndErase();
            }
            this.emo = new Alert(this);
        }
    }

    public void hideAlert() {
        if (this.emo instanceof Alert) {
            this.emo.killAndErase();
            this.emo = null;
        }
    }

    public void kill() {
        super.kill();
        if (this.emo != null) {
            this.emo.killAndErase();
            this.emo = null;
        }
    }

    public void onComplete(Tweener tweener) {
        if (tweener == this.jumpTweener) {
            if (this.visible && Level.water[this.ch.pos] && !this.ch.flying) {
                GameScene.ripple(this.ch.pos);
            }
            if (this.jumpCallback != null) {
                this.jumpCallback.call();
            }
        } else if (tweener == this.motion) {
            this.isMoving = false;
            this.motion.killAndErase();
            this.motion = null;
        }
    }

    public void onComplete(Animation anim) {
        if (this.animCallback != null) {
            this.animCallback.call();
            this.animCallback = null;
        } else if (anim == this.attack) {
            idle();
            this.ch.onAttackComplete();
        } else if (anim == this.operate) {
            idle();
            this.ch.onOperateComplete();
        }
    }
}
