package com.watabou.pixeldungeon.sprites;

import com.watabou.noosa.MovieClip.Animation;
import com.watabou.noosa.TextureFilm;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.items.weapon.missiles.Dart;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.utils.Callback;

public class ScorpioSprite extends MobSprite {
    private int cellToAttack;

    /* renamed from: com.watabou.pixeldungeon.sprites.ScorpioSprite.1 */
    class C01421 implements Callback {
        C01421() {
        }

        public void call() {
            ScorpioSprite.this.ch.onAttackComplete();
        }
    }

    public ScorpioSprite() {
        texture(Assets.SCORPIO);
        TextureFilm frames = new TextureFilm(this.texture, 18, 17);
        this.idle = new Animation(12, true);
        this.idle.frames(frames, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(2));
        this.run = new Animation(8, true);
        this.run.frames(frames, Integer.valueOf(5), Integer.valueOf(5), Integer.valueOf(6), Integer.valueOf(6));
        this.attack = new Animation(15, false);
        this.attack.frames(frames, Integer.valueOf(0), Integer.valueOf(3), Integer.valueOf(4));
        this.zap = this.attack.clone();
        this.die = new Animation(12, false);
        this.die.frames(frames, Integer.valueOf(0), Integer.valueOf(7), Integer.valueOf(8), Integer.valueOf(9), Integer.valueOf(10));
        play(this.idle);
    }

    public int blood() {
        return -12255454;
    }

    public void attack(int cell) {
        if (Level.adjacent(cell, this.ch.pos)) {
            super.attack(cell);
            return;
        }
        this.cellToAttack = cell;
        turnTo(this.ch.pos, cell);
        play(this.zap);
    }

    public void onComplete(Animation anim) {
        if (anim == this.zap) {
            idle();
            ((MissileSprite) this.parent.recycle(MissileSprite.class)).reset(this.ch.pos, this.cellToAttack, new Dart(), new C01421());
            return;
        }
        super.onComplete(anim);
    }
}
