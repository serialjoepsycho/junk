package com.watabou.pixeldungeon.actors;

import android.util.SparseArray;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Statistics;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;

public abstract class Actor implements Bundlable {
    private static final String ID = "id";
    public static final float TICK = 1.0f;
    private static final String TIME = "time";
    private static HashSet<Actor> all;
    private static Char[] chars;
    private static Actor current;
    private static SparseArray<Actor> ids;
    private static float now;
    private int id;
    private float time;

    protected abstract boolean act();

    public Actor() {
        this.id = 0;
    }

    protected void spend(float time) {
        this.time += time;
    }

    protected void postpone(float time) {
        if (this.time < now + time) {
            this.time = now + time;
        }
    }

    protected float cooldown() {
        return this.time - now;
    }

    protected void diactivate() {
        this.time = Float.MAX_VALUE;
    }

    protected void onAdd() {
    }

    protected void onRemove() {
    }

    public void storeInBundle(Bundle bundle) {
        bundle.put(TIME, this.time);
        bundle.put(ID, this.id);
    }

    public void restoreFromBundle(Bundle bundle) {
        this.time = bundle.getFloat(TIME);
        this.id = bundle.getInt(ID);
    }

    public int id() {
        if (this.id > 0) {
            return this.id;
        }
        int max = 0;
        Iterator it = all.iterator();
        while (it.hasNext()) {
            Actor a = (Actor) it.next();
            if (a.id > max) {
                max = a.id;
            }
        }
        int i = max + 1;
        this.id = i;
        return i;
    }

    static {
        all = new HashSet();
        ids = new SparseArray();
        now = 0.0f;
        chars = new Char[Level.LENGTH];
    }

    public static void clear() {
        now = 0.0f;
        Arrays.fill(chars, null);
        all.clear();
        ids.clear();
    }

    public static void fixTime() {
        if (Dungeon.hero != null && all.contains(Dungeon.hero)) {
            Statistics.duration += now;
        }
        float min = Float.MAX_VALUE;
        Iterator it = all.iterator();
        while (it.hasNext()) {
            Actor a = (Actor) it.next();
            if (a.time < min) {
                min = a.time;
            }
        }
        it = all.iterator();
        while (it.hasNext()) {
            a = (Actor) it.next();
            a.time -= min;
        }
        now = 0.0f;
    }

    public static void init() {
        addDelayed(Dungeon.hero, -1.4E-45f);
        Iterator it = Dungeon.level.mobs.iterator();
        while (it.hasNext()) {
            add((Mob) it.next());
        }
        for (Blob blob : Dungeon.level.blobs.values()) {
            add(blob);
        }
        current = null;
    }

    public static void occupyCell(Char ch) {
        chars[ch.pos] = ch;
    }

    public static void freeCell(int pos) {
        chars[pos] = null;
    }

    public void next() {
        if (current == this) {
            current = null;
        }
    }

    public static void process() {
        if (current == null) {
            boolean doNext;
            do {
                now = Float.MAX_VALUE;
                current = null;
                Arrays.fill(chars, null);
                Iterator it = all.iterator();
                while (it.hasNext()) {
                    Actor actor = (Actor) it.next();
                    if (actor.time < now) {
                        now = actor.time;
                        current = actor;
                    }
                    if (actor instanceof Char) {
                        Char ch = (Char) actor;
                        chars[ch.pos] = ch;
                    }
                }
                if (current == null) {
                    doNext = false;
                    continue;
                } else if ((current instanceof Char) && ((Char) current).sprite.isMoving) {
                    current = null;
                    return;
                } else {
                    doNext = current.act();
                    if (doNext && !Dungeon.hero.isAlive()) {
                        doNext = false;
                        current = null;
                        continue;
                    }
                }
            } while (doNext);
        }
    }

    public static void add(Actor actor) {
        add(actor, now);
    }

    public static void addDelayed(Actor actor, float delay) {
        add(actor, now + delay);
    }

    private static void add(Actor actor, float time) {
        if (!all.contains(actor)) {
            if (actor.id > 0) {
                ids.put(actor.id, actor);
            }
            all.add(actor);
            actor.time += time;
            actor.onAdd();
            if (actor instanceof Char) {
                Char ch = (Char) actor;
                chars[ch.pos] = ch;
                Iterator it = ch.buffs().iterator();
                while (it.hasNext()) {
                    Buff buff = (Buff) it.next();
                    all.add(buff);
                    buff.onAdd();
                }
            }
        }
    }

    public static void remove(Actor actor) {
        if (actor != null) {
            all.remove(actor);
            actor.onRemove();
            if (actor.id > 0) {
                ids.remove(actor.id);
            }
        }
    }

    public static Char findChar(int pos) {
        return chars[pos];
    }

    public static Actor findById(int id) {
        return (Actor) ids.get(id);
    }

    public static HashSet<Actor> all() {
        return all;
    }
}
