package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.rings.GemStone;
import com.watabou.pixeldungeon.items.rings.RingOfMending.Rejuvenation;
import java.util.Iterator;

public class Regeneration extends Buff {
    private static final float REGENERATION_DELAY = 10.0f;

    public boolean act() {
        if (this.target.isAlive()) {
            if (this.target.HP >= this.target.HT || ((Hero) this.target).isStarving()) {
                if (!((Hero) this.target).isStarving() && (this.target instanceof Hero) && ((Dungeon.hero.belongings.ring1 instanceof GemStone) || (Dungeon.hero.belongings.ring2 instanceof GemStone))) {
                    if (Dungeon.hero.belongings.ring1 instanceof GemStone) {
                        if (((GemStone) Dungeon.hero.belongings.ring1).charge < 40) {
                            ((GemStone) Dungeon.hero.belongings.ring1).ChargeUp();
                        }
                    } else if ((Dungeon.hero.belongings.ring2 instanceof GemStone) && ((GemStone) Dungeon.hero.belongings.ring2).charge < 40) {
                        ((GemStone) Dungeon.hero.belongings.ring2).ChargeUp();
                    }
                }
            } else if (!(this.target instanceof Hero)) {
                r2 = this.target;
                r2.HP++;
            } else if (!(Dungeon.hero.belongings.ring1 instanceof GemStone) && !(Dungeon.hero.belongings.ring2 instanceof GemStone)) {
                r2 = this.target;
                r2.HP++;
            } else if (Dungeon.hero.belongings.ring1 instanceof GemStone) {
                if (((GemStone) Dungeon.hero.belongings.ring1).charge < 40) {
                    ((GemStone) Dungeon.hero.belongings.ring1).ChargeUp();
                } else {
                    r2 = this.target;
                    r2.HP++;
                }
            } else if (Dungeon.hero.belongings.ring2 instanceof GemStone) {
                if (((GemStone) Dungeon.hero.belongings.ring2).charge < 40) {
                    ((GemStone) Dungeon.hero.belongings.ring2).ChargeUp();
                } else {
                    r2 = this.target;
                    r2.HP++;
                }
            }
            int bonus = 0;
            Iterator it = this.target.buffs(Rejuvenation.class).iterator();
            while (it.hasNext()) {
                bonus += ((Rejuvenation) ((Buff) it.next())).level;
            }
            spend((float) (10.0d / Math.pow(1.2d, (double) bonus)));
        } else {
            diactivate();
        }
        return true;
    }
}
