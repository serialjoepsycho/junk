package com.watabou.pixeldungeon.actors.buffs;

public class FlavourBuff extends Buff {
    public boolean act() {
        detach();
        return true;
    }
}
