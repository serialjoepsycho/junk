package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.items.rings.RingOfElements.Resistance;

public class Vertigo extends FlavourBuff {
    public static final float DURATION = 10.0f;

    public int icon() {
        return 29;
    }

    public String toString() {
        return "Vertigo";
    }

    public static float duration(Char ch) {
        Resistance r = (Resistance) ch.buff(Resistance.class);
        if (r != null) {
            return DURATION * r.durationFactor();
        }
        return DURATION;
    }
}
