package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.sprites.CharSprite.State;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;

public class Champ extends Buff {
    private boolean bonusApplied;
    private boolean haloApplied;
    public int type;

    public Champ() {
        this.type = Random.Int(1, 5);
        this.bonusApplied = false;
        this.haloApplied = false;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put("type", this.type);
        bundle.put("bonusApplied", this.bonusApplied);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.type = bundle.getInt("type");
        this.bonusApplied = bundle.getBoolean("bonusApplied");
    }

    public boolean act() {
        Mob mob;
        if (this.bonusApplied) {
            if (!this.haloApplied) {
                this.haloApplied = true;
                switch (this.type) {
                    case WndUpdates.ID_PRISON /*1*/:
                        this.target.name = "Chief " + this.target.name;
                        mob = (Mob) this.target;
                        mob.defenseSkill = (int) (((double) mob.defenseSkill) * 1.3d);
                        if (this.target.sprite != null && this.target.sprite.champWhiteHalo == null) {
                            this.target.sprite.add(State.CHAMPWHITE);
                            break;
                        }
                    case WndUpdates.ID_CAVES /*2*/:
                        this.target.name = "Cursed " + this.target.name;
                        mob = (Mob) this.target;
                        mob.defenseSkill = (int) (((double) mob.defenseSkill) * 1.15d);
                        if (this.target.sprite != null && this.target.sprite.champBlackHalo == null) {
                            this.target.sprite.add(State.CHAMPBLACK);
                            break;
                        }
                    case WndUpdates.ID_METROPOLIS /*3*/:
                        mob = (Mob) this.target;
                        mob.defenseSkill = (int) (((double) mob.defenseSkill) * 1.2d);
                        if (this.target.sprite != null && this.target.sprite.champYellowHalo == null) {
                            this.target.sprite.add(State.CHAMPYELLOW);
                            break;
                        }
                    case WndUpdates.ID_HALLS /*4*/:
                        this.target.name = "Vamp " + this.target.name;
                        mob = (Mob) this.target;
                        mob.defenseSkill = (int) (((double) mob.defenseSkill) * 1.1d);
                        if (this.target.sprite != null && this.target.sprite.champRedHalo == null) {
                            this.target.sprite.add(State.CHAMPRED);
                            break;
                        }
                    default:
                        break;
                }
            }
        }
        Char charR;
        this.target.champ = this.type;
        this.bonusApplied = true;
        this.haloApplied = true;
        switch (this.type) {
            case WndUpdates.ID_PRISON /*1*/:
                this.target.name = "Chief " + this.target.name;
                charR = this.target;
                charR.HT *= 2;
                this.target.HP = this.target.HT;
                mob = (Mob) this.target;
                mob.defenseSkill = (int) (((double) mob.defenseSkill) * 1.3d);
                if (this.target.sprite != null && this.target.sprite.champWhiteHalo == null) {
                    this.target.sprite.add(State.CHAMPWHITE);
                    break;
                }
            case WndUpdates.ID_CAVES /*2*/:
                this.target.name = "Cursed " + this.target.name;
                charR = this.target;
                charR.HT = (int) (((double) charR.HT) * 1.5d);
                this.target.HP = this.target.HT;
                mob = (Mob) this.target;
                mob.defenseSkill = (int) (((double) mob.defenseSkill) * 1.15d);
                if (this.target.sprite != null && this.target.sprite.champBlackHalo == null) {
                    this.target.sprite.add(State.CHAMPBLACK);
                    break;
                }
            case WndUpdates.ID_METROPOLIS /*3*/:
                this.target.name = "Foul " + this.target.name;
                charR = this.target;
                charR.HT = (int) (((double) charR.HT) * 1.5d);
                this.target.HP = this.target.HT;
                mob = (Mob) this.target;
                mob.defenseSkill = (int) (((double) mob.defenseSkill) * 1.2d);
                if (this.target.sprite != null && this.target.sprite.champYellowHalo == null) {
                    this.target.sprite.add(State.CHAMPYELLOW);
                    break;
                }
            case WndUpdates.ID_HALLS /*4*/:
                break;
            case BuffIndicator.HUNGER /*5*/:
                this.type = 4;
                break;
        }
        this.target.name = "Vamperic " + this.target.name;
        charR = this.target;
        charR.HT = (int) (((double) charR.HT) * 1.5d);
        this.target.HP = this.target.HT;
        mob = (Mob) this.target;
        mob.defenseSkill = (int) (((double) mob.defenseSkill) * 1.1d);
        if (this.target.sprite != null && this.target.sprite.champRedHalo == null) {
            this.target.sprite.add(State.CHAMPRED);
        }
        spend(Key.TIME_TO_UNLOCK);
        if (!this.target.isAlive()) {
            detach();
        }
        return true;
    }
}
