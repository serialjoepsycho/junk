package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.Dungeon;

public class Blindness extends FlavourBuff {
    public void detach() {
        super.detach();
        Dungeon.observe();
    }

    public int icon() {
        return 16;
    }

    public String toString() {
        return "Blinded";
    }
}
