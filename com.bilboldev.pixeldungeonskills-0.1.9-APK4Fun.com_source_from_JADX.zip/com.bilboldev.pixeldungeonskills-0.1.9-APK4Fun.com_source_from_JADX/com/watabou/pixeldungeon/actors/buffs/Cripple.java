package com.watabou.pixeldungeon.actors.buffs;

public class Cripple extends FlavourBuff {
    public static final float DURATION = 10.0f;

    public int icon() {
        return 23;
    }

    public String toString() {
        return "Crippled";
    }
}
