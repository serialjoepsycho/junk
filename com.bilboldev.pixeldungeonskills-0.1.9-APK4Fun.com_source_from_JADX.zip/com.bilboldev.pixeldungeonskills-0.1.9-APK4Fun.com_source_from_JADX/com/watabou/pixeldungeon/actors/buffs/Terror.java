package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.utils.Bundle;

public class Terror extends FlavourBuff {
    public static final float DURATION = 10.0f;
    private static final String OBJECT = "object";
    public int object;

    public Terror() {
        this.object = 0;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(OBJECT, this.object);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.object = bundle.getInt(OBJECT);
    }

    public int icon() {
        return 10;
    }

    public String toString() {
        return "Terror";
    }

    public static void recover(Char target) {
        Buff terror = (Terror) target.buff(Terror.class);
        if (terror != null && terror.cooldown() < DURATION) {
            target.remove(terror);
        }
    }
}
