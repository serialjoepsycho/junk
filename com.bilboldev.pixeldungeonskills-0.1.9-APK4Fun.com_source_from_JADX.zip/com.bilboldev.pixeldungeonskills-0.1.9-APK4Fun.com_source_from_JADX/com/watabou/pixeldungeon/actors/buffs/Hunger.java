package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.Hero.Doom;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.items.rings.RingOfSatiety.Satiety;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;
import java.util.Iterator;

public class Hunger extends Buff implements Doom {
    public static final float HUNGRY = 260.0f;
    private static final String LEVEL = "level";
    public static final float STARVING = 360.0f;
    private static final float STEP = 10.0f;
    private static final String TXT_DEATH = "You starved to death...";
    private static final String TXT_HUNGRY = "You are hungry.";
    private static final String TXT_STARVING = "You are starving!";
    private float level;

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(LEVEL, this.level);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.level = bundle.getFloat(LEVEL);
    }

    public boolean act() {
        float step = STEP;
        if (this.target.isAlive()) {
            Hero hero = this.target;
            if (!isStarving()) {
                int bonus = 0;
                Iterator it = this.target.buffs(Satiety.class).iterator();
                while (it.hasNext()) {
                    bonus += ((Satiety) ((Buff) it.next())).level;
                }
                float newLevel = (this.level + STEP) - ((float) bonus);
                boolean statusUpdated = false;
                if (newLevel >= STARVING) {
                    GLog.m2n(TXT_STARVING, new Object[0]);
                    statusUpdated = true;
                    hero.interrupt();
                } else if (newLevel >= HUNGRY && this.level < HUNGRY) {
                    GLog.m4w(TXT_HUNGRY, new Object[0]);
                    statusUpdated = true;
                }
                this.level = newLevel;
                if (statusUpdated) {
                    BuffIndicator.refreshHero();
                }
            } else if (Random.Float() < 0.3f && (this.target.HP > 1 || !this.target.paralysed)) {
                GLog.m2n(TXT_STARVING, new Object[0]);
                hero.damage(1, this);
                hero.interrupt();
            }
            if (((Hero) this.target).heroClass == HeroClass.ROGUE) {
                step = 12.0f;
            }
            if (this.target.buff(Shadows.class) != null) {
                step *= Sleep.SWS;
            }
            spend(step);
        } else {
            diactivate();
        }
        return true;
    }

    public void satisfy(float energy) {
        this.level -= energy;
        if (this.level < 0.0f) {
            this.level = 0.0f;
        } else if (this.level > STARVING) {
            this.level = STARVING;
        }
        BuffIndicator.refreshHero();
    }

    public boolean isStarving() {
        return this.level >= STARVING;
    }

    public int icon() {
        if (this.level < HUNGRY) {
            return -1;
        }
        if (this.level < STARVING) {
            return 5;
        }
        return 6;
    }

    public String toString() {
        if (this.level < STARVING) {
            return "Hungry";
        }
        return "Starving";
    }

    public void onDeath() {
        Badges.validateDeathFromHunger();
        Dungeon.fail(Utils.format(ResultDescriptions.HUNGER, Integer.valueOf(Dungeon.depth)));
        GLog.m2n(TXT_DEATH, new Object[0]);
    }
}
