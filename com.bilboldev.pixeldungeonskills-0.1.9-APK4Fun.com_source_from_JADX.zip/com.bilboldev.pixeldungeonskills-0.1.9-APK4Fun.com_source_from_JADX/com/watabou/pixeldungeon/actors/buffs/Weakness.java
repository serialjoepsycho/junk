package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.rings.RingOfElements.Resistance;

public class Weakness extends FlavourBuff {
    private static final float DURATION = 40.0f;

    public int icon() {
        return 14;
    }

    public String toString() {
        return "Weakened";
    }

    public boolean attachTo(Char target) {
        if (!(target instanceof Hero) || !super.attachTo(target)) {
            return false;
        }
        Hero hero = (Hero) target;
        hero.weakened = true;
        hero.belongings.discharge();
        return true;
    }

    public void detach() {
        super.detach();
        ((Hero) this.target).weakened = false;
    }

    public static float duration(Char ch) {
        Resistance r = (Resistance) ch.buff(Resistance.class);
        if (r != null) {
            return DURATION * r.durationFactor();
        }
        return DURATION;
    }
}
