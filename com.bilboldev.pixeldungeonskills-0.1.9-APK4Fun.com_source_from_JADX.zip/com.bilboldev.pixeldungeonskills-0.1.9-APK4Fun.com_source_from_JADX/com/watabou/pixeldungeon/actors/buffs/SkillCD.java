package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.utils.GLog;

public class SkillCD extends Buff {
    public boolean act() {
        if (this.target.isAlive()) {
            Hero hero = this.target;
            if (!hero.skillFirstActive && hero.skillFirstCooldown > 0) {
                hero.skillFirstCooldown--;
                if (hero.skillFirstCooldown == 0) {
                    if (hero.heroClass == HeroClass.MAGE) {
                        GLog.m3p("Random Teleport Ready", new Object[0]);
                    } else if (hero.heroClass == HeroClass.WARRIOR) {
                        GLog.m3p("Smash Ready", new Object[0]);
                    } else if (hero.heroClass == HeroClass.ROGUE) {
                        GLog.m3p("Shadow Clone Ready", new Object[0]);
                    } else if (hero.heroClass == HeroClass.HUNTRESS) {
                        GLog.m3p("Flame Arrow Ready", new Object[0]);
                    }
                }
            }
            if (!hero.skillSecondActive && hero.skillSecondCooldown > 0) {
                hero.skillSecondCooldown--;
                if (hero.skillSecondCooldown == 0) {
                    if (hero.heroClass == HeroClass.MAGE) {
                        GLog.m3p("Summon Ready", new Object[0]);
                    } else if (hero.heroClass == HeroClass.WARRIOR) {
                        GLog.m3p("Smite Ready", new Object[0]);
                    } else if (hero.heroClass == HeroClass.ROGUE) {
                        GLog.m3p("Disable Trap Ready", new Object[0]);
                    } else if (hero.heroClass == HeroClass.HUNTRESS) {
                        GLog.m3p("Frost Shot Ready", new Object[0]);
                    }
                }
            }
            spend(10 - hero.skillMeditation > 1 ? (float) (10 - hero.skillMeditation) : Key.TIME_TO_UNLOCK);
        } else {
            diactivate();
        }
        return true;
    }
}
