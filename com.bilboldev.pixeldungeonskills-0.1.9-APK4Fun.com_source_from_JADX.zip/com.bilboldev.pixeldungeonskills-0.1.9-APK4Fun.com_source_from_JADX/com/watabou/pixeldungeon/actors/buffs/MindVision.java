package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.Dungeon;

public class MindVision extends FlavourBuff {
    public static final float DURATION = 20.0f;
    public int distance;

    public MindVision() {
        this.distance = 2;
    }

    public int icon() {
        return 0;
    }

    public String toString() {
        return "Mind vision";
    }

    public void detach() {
        super.detach();
        Dungeon.observe();
    }
}
