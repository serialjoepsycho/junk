package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero.Doom;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.rings.RingOfElements.Resistance;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Bundle;

public class Poison extends Buff implements Doom {
    private static final String LEFT = "left";
    protected float left;

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(LEFT, this.left);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.left = bundle.getFloat(LEFT);
    }

    public void set(float duration) {
        this.left = duration;
    }

    public int icon() {
        return 3;
    }

    public String toString() {
        return "Poisoned";
    }

    public boolean act() {
        if (this.target.isAlive()) {
            this.target.damage(((int) (this.left / CurareDart.DURATION)) + 1, this);
            spend(Key.TIME_TO_UNLOCK);
            float f = this.left - Key.TIME_TO_UNLOCK;
            this.left = f;
            if (f <= 0.0f) {
                detach();
            }
        } else {
            detach();
        }
        return true;
    }

    public static float durationFactor(Char ch) {
        Resistance r = (Resistance) ch.buff(Resistance.class);
        return r != null ? r.durationFactor() : Key.TIME_TO_UNLOCK;
    }

    public void onDeath() {
        Badges.validateDeathFromPoison();
        Dungeon.fail(Utils.format(ResultDescriptions.POISON, Integer.valueOf(Dungeon.depth)));
        GLog.m2n("You died from poison...", new Object[0]);
    }
}
