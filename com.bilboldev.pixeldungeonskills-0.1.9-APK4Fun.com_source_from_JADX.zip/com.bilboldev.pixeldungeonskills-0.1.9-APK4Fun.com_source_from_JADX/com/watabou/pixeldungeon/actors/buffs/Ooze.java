package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;

public class Ooze extends Buff {
    private static final String TXT_HERO_KILLED = "%s killed you...";
    public int damage;

    public Ooze() {
        this.damage = 1;
    }

    public int icon() {
        return 8;
    }

    public String toString() {
        return "Caustic ooze";
    }

    public boolean act() {
        if (this.target.isAlive()) {
            this.target.damage(this.damage, this);
            if (!this.target.isAlive() && this.target == Dungeon.hero) {
                Dungeon.fail(Utils.format(ResultDescriptions.OOZE, Integer.valueOf(Dungeon.depth)));
                GLog.m2n(TXT_HERO_KILLED, toString());
            }
            spend(Key.TIME_TO_UNLOCK);
        }
        if (Level.water[this.target.pos]) {
            detach();
        }
        return true;
    }
}
