package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;

public class Levitation extends FlavourBuff {
    public static final float DURATION = 20.0f;

    public boolean attachTo(Char target) {
        if (!super.attachTo(target)) {
            return false;
        }
        target.flying = true;
        Buff.detach(target, Roots.class);
        return true;
    }

    public void detach() {
        this.target.flying = false;
        Dungeon.level.press(this.target.pos, this.target);
        super.detach();
    }

    public int icon() {
        return 1;
    }

    public String toString() {
        return "Levitating";
    }
}
