package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.actors.Char;

public class Roots extends FlavourBuff {
    public boolean attachTo(Char target) {
        if (target.flying || !super.attachTo(target)) {
            return false;
        }
        target.rooted = true;
        return true;
    }

    public void detach() {
        this.target.rooted = false;
        super.detach();
    }

    public int icon() {
        return 11;
    }

    public String toString() {
        return "Rooted";
    }
}
