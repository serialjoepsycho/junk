package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.items.keys.Key;

public class Fury extends Buff {
    public static float LEVEL;

    static {
        LEVEL = 0.4f;
    }

    public boolean act() {
        if (((float) this.target.HP) > ((float) this.target.HT) * LEVEL) {
            detach();
        }
        spend(Key.TIME_TO_UNLOCK);
        return true;
    }

    public int icon() {
        return 18;
    }

    public String toString() {
        return "Fury";
    }
}
