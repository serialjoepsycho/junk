package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;

public class Light extends FlavourBuff {
    public static final int DISTANCE = 4;
    public static final float DURATION = 250.0f;

    public boolean attachTo(Char target) {
        if (!super.attachTo(target)) {
            return false;
        }
        if (Dungeon.level != null) {
            target.viewDistance = Math.max(Dungeon.level.viewDistance, DISTANCE);
            Dungeon.observe();
        }
        return true;
    }

    public void detach() {
        this.target.viewDistance = Dungeon.level.viewDistance;
        Dungeon.observe();
        super.detach();
    }

    public int icon() {
        return 22;
    }

    public String toString() {
        return "Illuminated";
    }
}
