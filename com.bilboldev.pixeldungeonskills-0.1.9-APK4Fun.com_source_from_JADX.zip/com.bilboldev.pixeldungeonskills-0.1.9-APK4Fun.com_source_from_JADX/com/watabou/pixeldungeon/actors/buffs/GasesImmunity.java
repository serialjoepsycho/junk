package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.actors.blobs.ToxicGas;
import java.util.HashSet;

public class GasesImmunity extends FlavourBuff {
    public static final float DURATION = 5.0f;
    public static final HashSet<Class<?>> IMMUNITIES;

    public int icon() {
        return 25;
    }

    public String toString() {
        return "Immune to gases";
    }

    static {
        IMMUNITIES = new HashSet();
        IMMUNITIES.add(Paralysis.class);
        IMMUNITIES.add(ToxicGas.class);
        IMMUNITIES.add(Vertigo.class);
    }
}
