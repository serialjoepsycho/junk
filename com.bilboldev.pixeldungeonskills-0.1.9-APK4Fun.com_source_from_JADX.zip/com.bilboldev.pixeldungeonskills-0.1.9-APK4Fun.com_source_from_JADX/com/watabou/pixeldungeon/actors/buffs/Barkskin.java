package com.watabou.pixeldungeon.actors.buffs;

import com.watabou.pixeldungeon.items.keys.Key;

public class Barkskin extends Buff {
    private int level;

    public Barkskin() {
        this.level = 0;
    }

    public boolean act() {
        if (this.target.isAlive()) {
            spend(Key.TIME_TO_UNLOCK);
            int i = this.level - 1;
            this.level = i;
            if (i <= 0) {
                detach();
            }
        } else {
            detach();
        }
        return true;
    }

    public int level() {
        return this.level;
    }

    public void level(int value) {
        if (this.level < value) {
            this.level = value;
        }
    }

    public int icon() {
        return 24;
    }

    public String toString() {
        return "Barkskin";
    }
}
