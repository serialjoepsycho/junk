package com.watabou.pixeldungeon.actors;

import com.watabou.noosa.Camera;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.actors.buffs.Amok;
import com.watabou.pixeldungeon.actors.buffs.Bleeding;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Burning;
import com.watabou.pixeldungeon.actors.buffs.Champ;
import com.watabou.pixeldungeon.actors.buffs.Charm;
import com.watabou.pixeldungeon.actors.buffs.Cripple;
import com.watabou.pixeldungeon.actors.buffs.Frost;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.buffs.Levitation;
import com.watabou.pixeldungeon.actors.buffs.Light;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.buffs.Paralysis;
import com.watabou.pixeldungeon.actors.buffs.Poison;
import com.watabou.pixeldungeon.actors.buffs.Roots;
import com.watabou.pixeldungeon.actors.buffs.Shadows;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.actors.buffs.Slow;
import com.watabou.pixeldungeon.actors.buffs.Speed;
import com.watabou.pixeldungeon.actors.buffs.Terror;
import com.watabou.pixeldungeon.actors.buffs.Vertigo;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.hero.HeroSubClass;
import com.watabou.pixeldungeon.actors.mobs.Bestiary;
import com.watabou.pixeldungeon.actors.mobs.Rat;
import com.watabou.pixeldungeon.actors.mobs.ZombieRat;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.PoisonParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.weapon.melee.DualSwords;
import com.watabou.pixeldungeon.items.weapon.melee.NecroBlade;
import com.watabou.pixeldungeon.items.weapon.missiles.Arrow;
import com.watabou.pixeldungeon.items.weapon.missiles.FrostBow;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.features.Door;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.CharSprite.State;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.ui.ItemSlot;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.GameMath;
import com.watabou.utils.Random;
import java.util.HashSet;
import java.util.Iterator;

public abstract class Char extends Actor {
    private static final String BUFFS = "buffs";
    private static final HashSet<Class<?>> EMPTY;
    private static final String POS = "pos";
    private static final String TAG_HP = "HP";
    private static final String TAG_HT = "HT";
    protected static final String TXT_DEFEAT = "%s defeated %s";
    protected static final String TXT_HIT = "%s hit %s";
    protected static final String TXT_KILL = "%s killed you...";
    private static final String TXT_OUT_OF_PARALYSIS = "The pain snapped %s out of paralysis";
    private static final String TXT_SMB_MISSED = "%s %s %s's attack";
    private static final String TXT_YOU_MISSED = "%s %s your attack";
    public int HP;
    public int HT;
    public int MMP;
    public int MP;
    protected float baseSpeed;
    private HashSet<Buff> buffs;
    public int champ;
    public boolean flying;
    public int invisible;
    public String name;
    public boolean paralysed;
    public int pos;
    public boolean rooted;
    public CharSprite sprite;
    public int viewDistance;

    public Char() {
        this.pos = 0;
        this.name = "mob";
        this.MP = 0;
        this.MMP = 1;
        this.champ = -1;
        this.baseSpeed = Key.TIME_TO_UNLOCK;
        this.paralysed = false;
        this.rooted = false;
        this.flying = false;
        this.invisible = 0;
        this.viewDistance = 8;
        this.buffs = new HashSet();
    }

    protected boolean act() {
        Dungeon.level.updateFieldOfView(this);
        return false;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(POS, this.pos);
        bundle.put(TAG_HP, this.HP);
        bundle.put(TAG_HT, this.HT);
        bundle.put("MP", this.MP);
        bundle.put("MMP", this.MMP);
        bundle.put(BUFFS, this.buffs);
        bundle.put("champ", this.champ);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.pos = bundle.getInt(POS);
        this.HP = bundle.getInt(TAG_HP);
        this.HT = bundle.getInt(TAG_HT);
        this.MP = bundle.getInt("MP");
        this.MMP = bundle.getInt("MMP");
        for (Bundlable b : bundle.getCollection(BUFFS)) {
            if (b != null) {
                ((Buff) b).attachTo(this);
            }
        }
        this.champ = bundle.getInt("champ");
    }

    public boolean attack(Char enemy) {
        boolean visibleFight;
        if (Dungeon.visible[this.pos] || Dungeon.visible[enemy.pos]) {
            visibleFight = true;
        } else {
            visibleFight = false;
        }
        if (hit(this, enemy, false)) {
            int dr;
            if (visibleFight) {
                GLog.m1i(TXT_HIT, this.name, enemy.name);
            }
            if ((this instanceof Hero) && ((Hero) this).rangedWeapon != null && ((Hero) this).subClass == HeroSubClass.SNIPER) {
                dr = 0;
            } else {
                dr = Random.IntRange(0, enemy.dr());
            }
            int dmg = damageRoll();
            if (enemy == Dungeon.hero) {
                switch (Dungeon.hero.difficulty) {
                    case WndUpdates.ID_PRISON /*1*/:
                        dmg = (int) (((double) dmg) * 0.75d);
                        break;
                    case WndUpdates.ID_CAVES /*2*/:
                        dmg = (int) (((double) dmg) * 1.1d);
                        break;
                    case WndUpdates.ID_METROPOLIS /*3*/:
                        dmg = (int) (((double) dmg) * 1.25d);
                        break;
                    case WndUpdates.ID_HALLS /*4*/:
                        dmg = (int) (((double) dmg) * 1.45d);
                        break;
                }
            }
            int effectiveDamage = enemy.defenseProc(this, attackProc(enemy, Math.max(dmg - dr, 0)));
            enemy.damage(effectiveDamage, this);
            if (visibleFight) {
                Sample.INSTANCE.play(Assets.SND_HIT, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Random.Float(0.8f, 1.25f));
            }
            if (enemy == Dungeon.hero) {
                Dungeon.hero.interrupt();
                if (effectiveDamage > enemy.HT / 4) {
                    Camera.main.shake(GameMath.gate(Key.TIME_TO_UNLOCK, (float) (effectiveDamage / (enemy.HT / 4)), GasesImmunity.DURATION), 0.3f);
                }
            }
            enemy.sprite.bloodBurstA(this.sprite.center(), effectiveDamage);
            enemy.sprite.flash();
            if ((this instanceof Hero) && ((Hero) this).rangedWeapon == null && (((Hero) this).belongings.weapon instanceof DualSwords) && enemy.isAlive()) {
                attackTwo(enemy);
            }
            if (enemy.isAlive() || !visibleFight) {
                return true;
            }
            if (enemy != Dungeon.hero) {
                GLog.m1i(TXT_DEFEAT, this.name, enemy.name);
                return true;
            } else if (Dungeon.hero.killerGlyph != null) {
                return true;
            } else {
                if (Bestiary.isBoss(this)) {
                    Dungeon.fail(Utils.format(ResultDescriptions.GLYPH, this.name, Integer.valueOf(Dungeon.depth)));
                } else {
                    Dungeon.fail(Utils.format(ResultDescriptions.MOB, Utils.indefinite(this.name), Integer.valueOf(Dungeon.depth)));
                }
                GLog.m2n(TXT_KILL, this.name);
                return true;
            }
        }
        if (visibleFight) {
            enemy.sprite.showStatus(CharSprite.NEUTRAL, enemy.defenseVerb(), new Object[0]);
            if (this == Dungeon.hero) {
                GLog.m1i(TXT_YOU_MISSED, enemy.name, defense);
                if ((this instanceof Hero) && ((Hero) this).rangedWeapon == null && (((Hero) this).belongings.weapon instanceof DualSwords) && enemy.isAlive()) {
                    attackTwo(enemy);
                }
            } else {
                GLog.m1i(TXT_SMB_MISSED, enemy.name, defense, this.name);
            }
            Sample.INSTANCE.play(Assets.SND_MISS);
        }
        return false;
    }

    public boolean attackTwo(Char enemy) {
        boolean visibleFight;
        if (Dungeon.visible[this.pos] || Dungeon.visible[enemy.pos]) {
            visibleFight = true;
        } else {
            visibleFight = false;
        }
        if (hit(this, enemy, false)) {
            int dr;
            if (visibleFight) {
                GLog.m1i(TXT_HIT, this.name, enemy.name);
            }
            if ((this instanceof Hero) && ((Hero) this).rangedWeapon != null && ((Hero) this).subClass == HeroSubClass.SNIPER) {
                dr = 0;
            } else {
                dr = Random.IntRange(0, enemy.dr());
            }
            int effectiveDamage = enemy.defenseProc(this, attackProc(enemy, Math.max(damageRoll() - dr, 0)));
            enemy.damage(effectiveDamage, this);
            if (visibleFight) {
                Sample.INSTANCE.play(Assets.SND_HIT, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, GasesImmunity.DURATION);
            }
            if (enemy == Dungeon.hero) {
                Dungeon.hero.interrupt();
                if (effectiveDamage > enemy.HT / 4) {
                    Camera.main.shake(GameMath.gate(Key.TIME_TO_UNLOCK, (float) (effectiveDamage / (enemy.HT / 4)), GasesImmunity.DURATION), 0.3f);
                }
            }
            enemy.sprite.bloodBurstA(this.sprite.center(), effectiveDamage);
            enemy.sprite.flash();
            if (enemy.isAlive() || !visibleFight) {
                return true;
            }
            if (enemy != Dungeon.hero) {
                GLog.m1i(TXT_DEFEAT, this.name, enemy.name);
                return true;
            } else if (Dungeon.hero.killerGlyph != null) {
                return true;
            } else {
                if (Bestiary.isBoss(this)) {
                    Dungeon.fail(Utils.format(ResultDescriptions.GLYPH, this.name, Integer.valueOf(Dungeon.depth)));
                } else {
                    Dungeon.fail(Utils.format(ResultDescriptions.MOB, Utils.indefinite(this.name), Integer.valueOf(Dungeon.depth)));
                }
                GLog.m2n(TXT_KILL, this.name);
                return true;
            }
        }
        if (visibleFight) {
            enemy.sprite.showStatus(CharSprite.NEUTRAL, enemy.defenseVerb(), new Object[0]);
            if (this == Dungeon.hero) {
                GLog.m1i(TXT_YOU_MISSED, enemy.name, defense);
            } else {
                GLog.m1i(TXT_SMB_MISSED, enemy.name, defense, this.name);
            }
            Sample.INSTANCE.play(Assets.SND_MISS);
        }
        return false;
    }

    public static boolean hit(Char attacker, Char defender, boolean magic) {
        float acuRoll = Random.Float((float) attacker.attackSkill(defender));
        float defRoll = Random.Float((float) defender.defenseSkill(attacker));
        if (magic) {
            acuRoll *= Pickaxe.TIME_TO_MINE;
        }
        return acuRoll >= defRoll;
    }

    public int attackSkill(Char target) {
        return 0;
    }

    public int defenseSkill(Char enemy) {
        return 0;
    }

    public String defenseVerb() {
        return "dodged";
    }

    public int dr() {
        return 0;
    }

    public int damageRoll() {
        return 1;
    }

    public int attackProc(Char enemy, int damage) {
        return damage;
    }

    public int defenseProc(Char enemy, int damage) {
        return damage;
    }

    public float speed() {
        return buff(Cripple.class) == null ? this.baseSpeed : this.baseSpeed * 0.5f;
    }

    public void damage(int dmg, Object src) {
        if (this.HP > 0) {
            Buff.detach(this, Frost.class);
            Class<?> srcClass = src.getClass();
            if (immunities().contains(srcClass)) {
                dmg = 0;
            } else if (resistances().contains(srcClass)) {
                dmg = Random.IntRange(0, dmg);
            }
            if (buff(Paralysis.class) != null && Random.Int(dmg) >= Random.Int(this.HP)) {
                Buff.detach(this, Paralysis.class);
                if (Dungeon.visible[this.pos]) {
                    GLog.m1i(TXT_OUT_OF_PARALYSIS, this.name);
                }
            }
            if (src instanceof Hero) {
                Hero heroSrc = (Hero) src;
                if ((heroSrc.rangedWeapon instanceof Arrow) && (heroSrc.belongings.bow instanceof FrostBow)) {
                    if (Random.Int(5) == 1) {
                        Buff.prolong(this, Frost.class, Frost.duration(this) * Random.Float(0.3f, 0.6f));
                    } else {
                        Buff.affect(this, Frost.class);
                    }
                }
                if (heroSrc.rangedWeapon != null && heroSrc.heroClass == HeroClass.HUNTRESS) {
                    if (heroSrc.skillSecondActive) {
                        Buff.prolong(this, Frost.class, Frost.duration(this) * Random.Float(0.3f, 0.6f));
                        heroSrc.skillSecondActive = false;
                        GLog.m3p("Target froze in its tracks!", new Object[0]);
                        heroSrc.sprite.showStatus(CharSprite.NEUTRAL, "Frost shot!", new Object[0]);
                    }
                    if (heroSrc.skillFirstActive) {
                        ((Burning) Buff.affect(this, Burning.class)).reignite(this);
                        heroSrc.skillFirstActive = false;
                        GLog.m3p("Target catches fire!", new Object[0]);
                        heroSrc.sprite.showStatus(CharSprite.NEUTRAL, "Flame Arrow!", new Object[0]);
                    }
                }
                if (heroSrc.skillVenom > 0 && Random.Int(0, 100) < heroSrc.skillVenom * 5) {
                    ((Poison) Buff.affect(this, Poison.class)).set((float) Random.Int((heroSrc.skillVenom / 2) + 1, heroSrc.skillVenom + 1));
                    heroSrc.skillSecondActive = false;
                }
            }
            this.HP -= dmg;
            if (dmg > 0 || (src instanceof Char)) {
                this.sprite.showStatus(this.HP > this.HT / 2 ? ItemSlot.WARNING : CharSprite.NEGATIVE, Integer.toString(dmg), new Object[0]);
            }
            if (this.HP <= 0) {
                die(src);
            }
        }
    }

    public void destroy() {
        this.HP = 0;
        Actor.remove(this);
        Actor.freeCell(this.pos);
    }

    public void die(Object src) {
        if (!(this instanceof Hero)) {
            if (Dungeon.hero.rangedWeapon == null && (Dungeon.hero.belongings.weapon instanceof NecroBlade)) {
                ((NecroBlade) Dungeon.hero.belongings.weapon).updateCharge(this.HT > 22 ? (int) Math.floor((double) (this.HT / 22)) : 1);
                GLog.m3p("NecroBlade absored a portion of " + this.name + "'s life energy.", new Object[0]);
            }
            if (!Bestiary.isBoss(this)) {
                if (!(this instanceof Rat)) {
                    if (!(this instanceof ZombieRat)) {
                        switch (Random.Int(20)) {
                            case WndUpdates.ID_PRISON /*1*/:
                                this.sprite.showStatus(CharSprite.NEUTRAL, "...", new Object[0]);
                                break;
                            case WndUpdates.ID_HALLS /*4*/:
                                this.sprite.showStatus(CharSprite.NEUTRAL, "Too strong...", new Object[0]);
                                break;
                            case BuffIndicator.HUNGER /*5*/:
                                this.sprite.showStatus(CharSprite.NEUTRAL, "C'est impossible!", new Object[0]);
                                break;
                            case BuffIndicator.STARVATION /*6*/:
                                this.sprite.showStatus(CharSprite.NEUTRAL, "I will be avenged...", new Object[0]);
                                break;
                            case BuffIndicator.SLOW /*7*/:
                                this.sprite.showStatus(CharSprite.NEUTRAL, "Mommy...", new Object[0]);
                                break;
                            case BuffIndicator.AMOK /*9*/:
                                this.sprite.showStatus(CharSprite.NEUTRAL, "Sacre bleu!", new Object[0]);
                                break;
                            default:
                                break;
                        }
                    }
                    switch (Random.Int(10)) {
                        case WndUpdates.ID_PRISON /*1*/:
                            this.sprite.showStatus(CharSprite.NEUTRAL, "You know nothing...", new Object[0]);
                            break;
                        case WndUpdates.ID_CAVES /*2*/:
                            this.sprite.showStatus(CharSprite.NEUTRAL, "The king's plan will work...", new Object[0]);
                            break;
                        case WndUpdates.ID_METROPOLIS /*3*/:
                            this.sprite.showStatus(CharSprite.NEUTRAL, "The world is ours... all of its cheese too...", new Object[0]);
                            break;
                        default:
                            break;
                    }
                }
                switch (Random.Int(10)) {
                    case WndUpdates.ID_PRISON /*1*/:
                        this.sprite.showStatus(CharSprite.NEUTRAL, "The Rat King will be victorious!", new Object[0]);
                        break;
                    case WndUpdates.ID_CAVES /*2*/:
                        this.sprite.showStatus(CharSprite.NEUTRAL, "The Rat King will avenge me!", new Object[0]);
                        break;
                    case WndUpdates.ID_METROPOLIS /*3*/:
                        this.sprite.showStatus(CharSprite.NEUTRAL, "The Rat King shall prevail!", new Object[0]);
                        break;
                    case WndUpdates.ID_HALLS /*4*/:
                        this.sprite.showStatus(CharSprite.NEUTRAL, "Forgive me my lord...", new Object[0]);
                        break;
                }
            }
        }
        this.sprite.showStatus(CharSprite.NEUTRAL, "I have failed...", new Object[0]);
        destroy();
        this.sprite.die();
    }

    public boolean isAlive() {
        return this.HP > 0;
    }

    protected void spend(float time) {
        float timeScale = Key.TIME_TO_UNLOCK;
        if (buff(Slow.class) != null) {
            timeScale = Key.TIME_TO_UNLOCK * 0.5f;
        }
        if (buff(Speed.class) != null) {
            timeScale *= Pickaxe.TIME_TO_MINE;
        }
        super.spend(time / timeScale);
    }

    public HashSet<Buff> buffs() {
        return this.buffs;
    }

    public <T extends Buff> HashSet<T> buffs(Class<T> c) {
        HashSet<T> filtered = new HashSet();
        Iterator it = this.buffs.iterator();
        while (it.hasNext()) {
            Buff b = (Buff) it.next();
            if (c.isInstance(b)) {
                filtered.add(b);
            }
        }
        return filtered;
    }

    public <T extends Buff> T buff(Class<T> c) {
        Iterator it = this.buffs.iterator();
        while (it.hasNext()) {
            Buff b = (Buff) it.next();
            if (c.isInstance(b)) {
                return b;
            }
        }
        return null;
    }

    public boolean isCharmedBy(Char ch) {
        int chID = ch.id();
        Iterator it = this.buffs.iterator();
        while (it.hasNext()) {
            Buff b = (Buff) it.next();
            if ((b instanceof Charm) && ((Charm) b).object == chID) {
                return true;
            }
        }
        return false;
    }

    public void add(Buff buff) {
        this.buffs.add(buff);
        Actor.add(buff);
        if (this.sprite == null) {
            return;
        }
        if (buff instanceof Poison) {
            CellEmitter.center(this.pos).burst(PoisonParticle.SPLASH, 5);
            this.sprite.showStatus(CharSprite.NEGATIVE, "poisoned", new Object[0]);
        } else if (buff instanceof Amok) {
            this.sprite.showStatus(CharSprite.NEGATIVE, "amok", new Object[0]);
        } else if (buff instanceof Slow) {
            this.sprite.showStatus(CharSprite.NEGATIVE, "slowed", new Object[0]);
        } else if (buff instanceof MindVision) {
            this.sprite.showStatus(CharSprite.POSITIVE, "mind", new Object[0]);
            this.sprite.showStatus(CharSprite.POSITIVE, "vision", new Object[0]);
        } else if (buff instanceof Paralysis) {
            this.sprite.add(State.PARALYSED);
            this.sprite.showStatus(CharSprite.NEGATIVE, "paralysed", new Object[0]);
        } else if (buff instanceof Terror) {
            this.sprite.showStatus(CharSprite.NEGATIVE, "frightened", new Object[0]);
        } else if (buff instanceof Roots) {
            this.sprite.showStatus(CharSprite.NEGATIVE, "rooted", new Object[0]);
        } else if (buff instanceof Cripple) {
            this.sprite.showStatus(CharSprite.NEGATIVE, "crippled", new Object[0]);
        } else if (buff instanceof Bleeding) {
            this.sprite.showStatus(CharSprite.NEGATIVE, "bleeding", new Object[0]);
        } else if (buff instanceof Vertigo) {
            this.sprite.showStatus(CharSprite.NEGATIVE, "dizzy", new Object[0]);
        } else if (buff instanceof Sleep) {
            this.sprite.idle();
        } else if (buff instanceof Burning) {
            this.sprite.add(State.BURNING);
        } else if (buff instanceof Levitation) {
            this.sprite.add(State.LEVITATING);
        } else if (buff instanceof Frost) {
            this.sprite.add(State.FROZEN);
        } else if (buff instanceof Champ) {
            switch (((Champ) buff).type) {
                case WndUpdates.ID_PRISON /*1*/:
                    this.sprite.add(State.CHAMPWHITE);
                case WndUpdates.ID_CAVES /*2*/:
                    this.sprite.add(State.CHAMPBLACK);
                case WndUpdates.ID_METROPOLIS /*3*/:
                    this.sprite.add(State.CHAMPYELLOW);
                case WndUpdates.ID_HALLS /*4*/:
                    this.sprite.add(State.CHAMPRED);
                default:
            }
        } else if (buff instanceof Invisibility) {
            if (!(buff instanceof Shadows)) {
                this.sprite.showStatus(CharSprite.POSITIVE, "invisible", new Object[0]);
            }
            this.sprite.add(State.INVISIBLE);
        }
    }

    public void remove(Buff buff) {
        this.buffs.remove(buff);
        Actor.remove(buff);
        if (buff instanceof Burning) {
            this.sprite.remove(State.BURNING);
        } else if (buff instanceof Levitation) {
            this.sprite.remove(State.LEVITATING);
        } else if ((buff instanceof Invisibility) && this.invisible <= 0) {
            this.sprite.remove(State.INVISIBLE);
        } else if (buff instanceof Paralysis) {
            this.sprite.remove(State.PARALYSED);
        } else if (buff instanceof Frost) {
            this.sprite.remove(State.FROZEN);
        }
    }

    public void remove(Class<? extends Buff> buffClass) {
        Iterator it = buffs(buffClass).iterator();
        while (it.hasNext()) {
            remove((Buff) it.next());
        }
    }

    protected void onRemove() {
        int i = 0;
        Buff[] buffArr = (Buff[]) this.buffs.toArray(new Buff[0]);
        int length = buffArr.length;
        while (i < length) {
            buffArr[i].detach();
            i++;
        }
    }

    public void updateSpriteState() {
        Iterator it = this.buffs.iterator();
        while (it.hasNext()) {
            Buff buff = (Buff) it.next();
            if (buff instanceof Burning) {
                this.sprite.add(State.BURNING);
            } else if (buff instanceof Levitation) {
                this.sprite.add(State.LEVITATING);
            } else if (buff instanceof Invisibility) {
                this.sprite.add(State.INVISIBLE);
            } else if (buff instanceof Paralysis) {
                this.sprite.add(State.PARALYSED);
            } else if (buff instanceof Frost) {
                this.sprite.add(State.FROZEN);
            } else if (buff instanceof Light) {
                this.sprite.add(State.ILLUMINATED);
            }
        }
    }

    public int stealth() {
        return 0;
    }

    public void move(int step) {
        if (Level.adjacent(step, this.pos) && buff(Vertigo.class) != null) {
            step = this.pos + Level.NEIGHBOURS8[Random.Int(8)];
            if (!((Level.passable[step] || Level.avoid[step]) && Actor.findChar(step) == null)) {
                return;
            }
        }
        if (Dungeon.level.map[this.pos] == 6) {
            Door.leave(this.pos);
        }
        this.pos = step;
        if (this.flying && Dungeon.level.map[this.pos] == 5) {
            Door.enter(this.pos);
        }
        if (this != Dungeon.hero) {
            this.sprite.visible = Dungeon.visible[this.pos];
        }
    }

    public int distance(Char other) {
        return Level.distance(this.pos, other.pos);
    }

    public void onMotionComplete() {
        next();
    }

    public void onAttackComplete() {
        next();
    }

    public void onOperateComplete() {
        next();
    }

    static {
        EMPTY = new HashSet();
    }

    public HashSet<Class<?>> resistances() {
        return EMPTY;
    }

    public HashSet<Class<?>> immunities() {
        return EMPTY;
    }
}
