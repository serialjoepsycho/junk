package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Burning;
import com.watabou.pixeldungeon.effects.BlobEmitter;
import com.watabou.pixeldungeon.effects.particles.FlameParticle;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;

public class Fire extends Blob {
    protected void evolve() {
        boolean[] flamable = Level.flamable;
        boolean observe = false;
        int pos = 33;
        while (pos < 991) {
            int fire;
            if (this.cur[pos] > 0) {
                burn(pos);
                fire = this.cur[pos] - 1;
                if (fire <= 0 && flamable[pos]) {
                    int oldTile = Dungeon.level.map[pos];
                    Level.set(pos, 9);
                    observe = true;
                    GameScene.updateMap(pos);
                    if (Dungeon.visible[pos]) {
                        GameScene.discoverTile(pos, oldTile);
                    }
                }
            } else if (!flamable[pos] || (this.cur[pos - 1] <= 0 && this.cur[pos + 1] <= 0 && this.cur[pos - 32] <= 0 && this.cur[pos + 32] <= 0)) {
                fire = 0;
            } else {
                fire = 4;
                burn(pos);
            }
            int i = this.volume;
            this.off[pos] = fire;
            this.volume = i + fire;
            pos++;
        }
        if (observe) {
            Dungeon.observe();
        }
    }

    private void burn(int pos) {
        Char ch = Actor.findChar(pos);
        if (ch != null) {
            ((Burning) Buff.affect(ch, Burning.class)).reignite(ch);
        }
        Heap heap = (Heap) Dungeon.level.heaps.get(pos);
        if (heap != null) {
            heap.burn();
        }
    }

    public void seed(int cell, int amount) {
        if (this.cur[cell] == 0) {
            this.volume += amount;
            this.cur[cell] = amount;
        }
    }

    public void use(BlobEmitter emitter) {
        super.use(emitter);
        emitter.start(FlameParticle.FACTORY, 0.03f, 0);
    }

    public String tileDesc() {
        return "A fire is raging here.";
    }
}
