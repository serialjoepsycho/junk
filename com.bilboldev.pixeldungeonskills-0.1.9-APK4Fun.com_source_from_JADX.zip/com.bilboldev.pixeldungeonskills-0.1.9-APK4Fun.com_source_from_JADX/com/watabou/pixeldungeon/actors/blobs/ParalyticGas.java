package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Paralysis;
import com.watabou.pixeldungeon.effects.BlobEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class ParalyticGas extends Blob {
    protected void evolve() {
        super.evolve();
        for (int i = 0; i < Level.LENGTH; i++) {
            if (this.cur[i] > 0) {
                Char ch = Actor.findChar(i);
                if (ch != null) {
                    Buff.prolong(ch, Paralysis.class, Paralysis.duration(ch));
                }
            }
        }
    }

    public void use(BlobEmitter emitter) {
        super.use(emitter);
        emitter.pour(Speck.factory(ItemSpriteSheet.INCENDIARY_DART), 0.6f);
    }

    public String tileDesc() {
        return "A cloud of paralytic gas is swirling here.";
    }
}
