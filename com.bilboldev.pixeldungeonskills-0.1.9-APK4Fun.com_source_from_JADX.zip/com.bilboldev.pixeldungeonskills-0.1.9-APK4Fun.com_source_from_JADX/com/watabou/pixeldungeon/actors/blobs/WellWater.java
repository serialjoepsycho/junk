package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Journal;
import com.watabou.pixeldungeon.Journal.Feature;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;

public class WellWater extends Blob {
    protected int pos;

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        for (int i = 0; i < Level.LENGTH; i++) {
            if (this.cur[i] > 0) {
                this.pos = i;
                return;
            }
        }
    }

    protected void evolve() {
        int[] iArr = this.off;
        int i = this.pos;
        int i2 = this.cur[this.pos];
        iArr[i] = i2;
        this.volume = i2;
        if (!Dungeon.visible[this.pos]) {
            return;
        }
        if (this instanceof WaterOfAwareness) {
            Journal.add(Feature.WELL_OF_AWARENESS);
        } else if (this instanceof WaterOfHealth) {
            Journal.add(Feature.WELL_OF_HEALTH);
        } else if (this instanceof WaterOfTransmutation) {
            Journal.add(Feature.WELL_OF_TRANSMUTATION);
        }
    }

    protected boolean affect() {
        if (this.pos == Dungeon.hero.pos && affectHero(Dungeon.hero)) {
            int[] iArr = this.off;
            int i = this.pos;
            this.cur[this.pos] = 0;
            iArr[i] = 0;
            this.volume = 0;
            return true;
        }
        Heap heap = (Heap) Dungeon.level.heaps.get(this.pos);
        if (heap == null) {
            return false;
        }
        Item oldItem = heap.peek();
        Item newItem = affectItem(oldItem);
        if (newItem != null) {
            if (newItem != oldItem) {
                if (oldItem.quantity() > 1) {
                    oldItem.quantity(oldItem.quantity() - 1);
                    heap.drop(newItem);
                } else {
                    heap.replace(oldItem, newItem);
                }
            }
            heap.sprite.link();
            iArr = this.off;
            i = this.pos;
            this.cur[this.pos] = 0;
            iArr[i] = 0;
            this.volume = 0;
            return true;
        }
        int newPlace;
        do {
            newPlace = this.pos + Level.NEIGHBOURS8[Random.Int(8)];
            if (Level.passable[newPlace]) {
                break;
            }
        } while (!Level.avoid[newPlace]);
        Dungeon.level.drop(heap.pickUp(), newPlace).sprite.drop(this.pos);
        return false;
    }

    protected boolean affectHero(Hero hero) {
        return false;
    }

    protected Item affectItem(Item item) {
        return null;
    }

    public void seed(int cell, int amount) {
        this.cur[this.pos] = 0;
        this.pos = cell;
        this.cur[this.pos] = amount;
        this.volume = amount;
    }

    public static void affectCell(int cell) {
        int i = 0;
        Class<?>[] waters = new Class[]{WaterOfHealth.class, WaterOfAwareness.class, WaterOfTransmutation.class};
        int length = waters.length;
        while (i < length) {
            WellWater water = (WellWater) Dungeon.level.blobs.get(waters[i]);
            if (water == null || water.volume <= 0 || water.pos != cell || !water.affect()) {
                i++;
            } else {
                Level.set(cell, 3);
                GameScene.updateMap(cell);
                return;
            }
        }
    }
}
