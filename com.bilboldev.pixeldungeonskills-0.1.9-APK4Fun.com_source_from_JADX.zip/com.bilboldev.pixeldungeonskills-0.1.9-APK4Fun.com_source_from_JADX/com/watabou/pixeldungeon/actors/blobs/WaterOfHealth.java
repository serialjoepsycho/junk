package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Journal;
import com.watabou.pixeldungeon.Journal.Feature;
import com.watabou.pixeldungeon.actors.buffs.Hunger;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.BlobEmitter;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.particles.ShaftParticle;
import com.watabou.pixeldungeon.items.DewVial;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.potions.PotionOfHealing;
import com.watabou.pixeldungeon.utils.GLog;

public class WaterOfHealth extends WellWater {
    private static final String TXT_PROCCED = "As you take a sip, you feel your wounds heal completely.";

    protected boolean affectHero(Hero hero) {
        Sample.INSTANCE.play(Assets.SND_DRINK);
        PotionOfHealing.heal(hero, 100);
        hero.belongings.uncurseEquipped();
        ((Hunger) hero.buff(Hunger.class)).satisfy(Hunger.STARVING);
        CellEmitter.get(this.pos).start(ShaftParticle.FACTORY, 0.2f, 3);
        Dungeon.hero.interrupt();
        GLog.m3p(TXT_PROCCED, new Object[0]);
        Journal.remove(Feature.WELL_OF_HEALTH);
        return true;
    }

    protected Item affectItem(Item item) {
        if (!(item instanceof DewVial) || ((DewVial) item).isFull()) {
            return null;
        }
        ((DewVial) item).fill();
        return item;
    }

    public void use(BlobEmitter emitter) {
        super.use(emitter);
        emitter.start(Speck.factory(0), 0.5f, 0);
    }

    public String tileDesc() {
        return "Power of health radiates from the water of this well. Take a sip from it to heal your wounds and satisfy hunger.";
    }
}
