package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Journal;
import com.watabou.pixeldungeon.Journal.Feature;
import com.watabou.pixeldungeon.effects.BlobEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.utils.Bundle;

public class Alchemy extends Blob {
    protected int pos;

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        for (int i = 0; i < Level.LENGTH; i++) {
            if (this.cur[i] > 0) {
                this.pos = i;
                return;
            }
        }
    }

    protected void evolve() {
        int[] iArr = this.off;
        int i = this.pos;
        int i2 = this.cur[this.pos];
        iArr[i] = i2;
        this.volume = i2;
        if (Dungeon.visible[this.pos]) {
            Journal.add(Feature.ALCHEMY);
        }
    }

    public void seed(int cell, int amount) {
        this.cur[this.pos] = 0;
        this.pos = cell;
        this.cur[this.pos] = amount;
        this.volume = amount;
    }

    public static void transmute(int cell) {
        Heap heap = (Heap) Dungeon.level.heaps.get(cell);
        if (heap != null) {
            Item result = heap.transmute();
            if (result != null) {
                Dungeon.level.drop(result, cell).sprite.drop(cell);
            }
        }
    }

    public void use(BlobEmitter emitter) {
        super.use(emitter);
        emitter.start(Speck.factory(12), 0.4f, 0);
    }
}
