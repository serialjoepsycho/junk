package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.Journal;
import com.watabou.pixeldungeon.Journal.Feature;
import com.watabou.pixeldungeon.actors.buffs.Awareness;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.BlobEmitter;
import com.watabou.pixeldungeon.effects.Identification;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Terrain;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.utils.GLog;

public class WaterOfAwareness extends WellWater {
    private static final String TXT_PROCCED = "As you take a sip, you feel the knowledge pours into your mind. Now you know everything about your equipped items. Also you sense all items on the level and know all its secrets.";

    protected boolean affectHero(Hero hero) {
        Sample.INSTANCE.play(Assets.SND_DRINK);
        this.emitter.parent.add(new Identification(DungeonTilemap.tileCenterToWorld(this.pos)));
        hero.belongings.observe();
        for (int i = 0; i < Level.LENGTH; i++) {
            int terr = Dungeon.level.map[i];
            if ((Terrain.flags[terr] & 8) != 0) {
                Level.set(i, Terrain.discover(terr));
                GameScene.updateMap(i);
                if (Dungeon.visible[i]) {
                    GameScene.discoverTile(i, terr);
                }
            }
        }
        Buff.affect(hero, Awareness.class, Pickaxe.TIME_TO_MINE);
        Dungeon.observe();
        Dungeon.hero.interrupt();
        GLog.m3p(TXT_PROCCED, new Object[0]);
        Journal.remove(Feature.WELL_OF_AWARENESS);
        return true;
    }

    protected Item affectItem(Item item) {
        if (item.isIdentified()) {
            return null;
        }
        item.identify();
        Badges.validateItemLevelAquired(item);
        this.emitter.parent.add(new Identification(DungeonTilemap.tileCenterToWorld(this.pos)));
        Journal.remove(Feature.WELL_OF_AWARENESS);
        return item;
    }

    public void use(BlobEmitter emitter) {
        super.use(emitter);
        emitter.pour(Speck.factory(3), 0.3f);
    }

    public String tileDesc() {
        return "Power of knowledge radiates from the water of this well. Take a sip from it to reveal all secrets of equipped items.";
    }
}
