package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.effects.BlobEmitter;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.utils.BArray;
import com.watabou.utils.Bundle;
import java.util.Arrays;

public class Blob extends Actor {
    private static final String CUR = "cur";
    public static final int HEIGHT = 32;
    public static final int LENGTH = 1024;
    private static final String START = "start";
    public static final int WIDTH = 32;
    public int[] cur;
    public BlobEmitter emitter;
    protected int[] off;
    public int volume;

    protected Blob() {
        this.volume = 0;
        this.cur = new int[LENGTH];
        this.off = new int[LENGTH];
        this.volume = 0;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        if (this.volume > 0) {
            int start = 0;
            while (start < LENGTH && this.cur[start] <= 0) {
                start++;
            }
            int end = 1023;
            while (end > start && this.cur[end] <= 0) {
                end--;
            }
            bundle.put(START, start);
            bundle.put(CUR, trim(start, end + 1));
        }
    }

    private int[] trim(int start, int end) {
        int len = end - start;
        int[] copy = new int[len];
        System.arraycopy(this.cur, start, copy, 0, len);
        return copy;
    }

    public void restoreFromBundle(Bundle bundle) {
        int i;
        super.restoreFromBundle(bundle);
        int[] data = bundle.getIntArray(CUR);
        if (data != null) {
            int start = bundle.getInt(START);
            for (i = 0; i < data.length; i++) {
                this.cur[i + start] = data[i];
                this.volume += data[i];
            }
        }
        if (Level.resizingNeeded) {
            int[] cur = new int[LENGTH];
            Arrays.fill(cur, 0);
            int loadedMapSize = Level.loadedMapSize;
            for (i = 0; i < loadedMapSize; i++) {
                System.arraycopy(this.cur, i * loadedMapSize, cur, i * WIDTH, loadedMapSize);
            }
            this.cur = cur;
        }
    }

    public boolean act() {
        spend(Key.TIME_TO_UNLOCK);
        if (this.volume > 0) {
            this.volume = 0;
            evolve();
            int[] tmp = this.off;
            this.off = this.cur;
            this.cur = tmp;
        }
        return true;
    }

    public void use(BlobEmitter emitter) {
        this.emitter = emitter;
    }

    protected void evolve() {
        boolean[] notBlocking = BArray.not(Level.solid, null);
        for (int i = 1; i < 31; i++) {
            int from = (i * WIDTH) + 1;
            int to = (from + WIDTH) - 2;
            for (int pos = from; pos < to; pos++) {
                if (notBlocking[pos]) {
                    int value;
                    int count = 1;
                    int sum = this.cur[pos];
                    if (notBlocking[pos - 1]) {
                        sum += this.cur[pos - 1];
                        count = 1 + 1;
                    }
                    if (notBlocking[pos + 1]) {
                        sum += this.cur[pos + 1];
                        count++;
                    }
                    if (notBlocking[pos - 32]) {
                        sum += this.cur[pos - 32];
                        count++;
                    }
                    if (notBlocking[pos + WIDTH]) {
                        sum += this.cur[pos + WIDTH];
                        count++;
                    }
                    if (sum >= count) {
                        value = (sum / count) - 1;
                    } else {
                        value = 0;
                    }
                    this.off[pos] = value;
                    this.volume += value;
                } else {
                    this.off[pos] = 0;
                }
            }
        }
    }

    public void seed(int cell, int amount) {
        int[] iArr = this.cur;
        iArr[cell] = iArr[cell] + amount;
        this.volume += amount;
    }

    public void clear(int cell) {
        this.volume -= this.cur[cell];
        this.cur[cell] = 0;
    }

    public String tileDesc() {
        return null;
    }

    public static <T extends Blob> T seed(int cell, int amount, Class<T> type) {
        try {
            T gas = (Blob) Dungeon.level.blobs.get(type);
            if (gas == null) {
                gas = (Blob) type.newInstance();
                Dungeon.level.blobs.put(type, gas);
            }
            gas.seed(cell, amount);
            return gas;
        } catch (Exception e) {
            PixelDungeon.reportException(e);
            return null;
        }
    }
}
