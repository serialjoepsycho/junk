package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero.Doom;
import com.watabou.pixeldungeon.effects.BlobEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Random;

public class ToxicGas extends Blob implements Doom {
    protected void evolve() {
        int i;
        super.evolve();
        int levelDamage = (Dungeon.depth * 5) + 5;
        for (i = 0; i < Level.LENGTH; i++) {
            if (this.cur[i] > 0) {
                Char ch = Actor.findChar(i);
                if (ch != null) {
                    int damage = (ch.HT + levelDamage) / 40;
                    if (Random.Int(40) < (ch.HT + levelDamage) % 40) {
                        damage++;
                    }
                    ch.damage(damage, this);
                }
            }
        }
        Blob blob = (Blob) Dungeon.level.blobs.get(ParalyticGas.class);
        if (blob != null) {
            int[] par = blob.cur;
            for (i = 0; i < Level.LENGTH; i++) {
                int t = this.cur[i];
                int p = par[i];
                if (p >= t) {
                    this.volume -= t;
                    this.cur[i] = 0;
                } else {
                    blob.volume -= p;
                    par[i] = 0;
                }
            }
        }
    }

    public void use(BlobEmitter emitter) {
        super.use(emitter);
        emitter.pour(Speck.factory(ItemSpriteSheet.TOMAHAWK), 0.6f);
    }

    public String tileDesc() {
        return "A greenish cloud of toxic gas is swirling here.";
    }

    public void onDeath() {
        Badges.validateDeathFromGas();
        Dungeon.fail(Utils.format(ResultDescriptions.GAS, Integer.valueOf(Dungeon.depth)));
        GLog.m2n("You died from a toxic gas..", new Object[0]);
    }
}
