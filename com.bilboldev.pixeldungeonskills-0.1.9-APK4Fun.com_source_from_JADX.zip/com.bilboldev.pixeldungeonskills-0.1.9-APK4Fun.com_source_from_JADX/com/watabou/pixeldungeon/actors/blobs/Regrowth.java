package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Roots;
import com.watabou.pixeldungeon.effects.BlobEmitter;
import com.watabou.pixeldungeon.effects.particles.LeafParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;

public class Regrowth extends Blob {
    protected void evolve() {
        super.evolve();
        if (this.volume > 0) {
            boolean mapUpdated = false;
            int i = 0;
            while (i < Level.LENGTH) {
                if (this.off[i] > 0) {
                    int c = Dungeon.level.map[i];
                    if (c == 1 || c == 9 || c == 24) {
                        int i2;
                        if (this.cur[i] > 9) {
                            i2 = 15;
                        } else {
                            i2 = 2;
                        }
                        Level.set(i, i2);
                        mapUpdated = true;
                    } else if (c == 2 && this.cur[i] > 9) {
                        Level.set(i, 15);
                        mapUpdated = true;
                    }
                    Char ch = Actor.findChar(i);
                    if (ch != null) {
                        Buff.prolong(ch, Roots.class, Key.TIME_TO_UNLOCK);
                    }
                }
                i++;
            }
            if (mapUpdated) {
                GameScene.updateMap();
                Dungeon.observe();
            }
        }
    }

    public void use(BlobEmitter emitter) {
        super.use(emitter);
        emitter.start(LeafParticle.LEVEL_SPECIFIC, 0.2f, 0);
    }
}
