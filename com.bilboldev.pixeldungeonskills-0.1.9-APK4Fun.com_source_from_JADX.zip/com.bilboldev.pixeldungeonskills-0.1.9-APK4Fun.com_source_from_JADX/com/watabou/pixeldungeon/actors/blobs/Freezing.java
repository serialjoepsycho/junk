package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Frost;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.SnowParticle;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.utils.Random;

public class Freezing {
    public static boolean affect(int cell, Fire fire) {
        Char ch = Actor.findChar(cell);
        if (ch != null) {
            Buff.prolong(ch, Frost.class, Frost.duration(ch) * Random.Float(Key.TIME_TO_UNLOCK, Sleep.SWS));
        }
        if (fire != null) {
            fire.clear(cell);
        }
        Heap heap = (Heap) Dungeon.level.heaps.get(cell);
        if (heap != null) {
            heap.freeze();
        }
        if (!Dungeon.visible[cell]) {
            return false;
        }
        CellEmitter.get(cell).start(SnowParticle.FACTORY, 0.2f, 6);
        return true;
    }
}
