package com.watabou.pixeldungeon.actors.blobs;

import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Roots;
import com.watabou.pixeldungeon.effects.BlobEmitter;
import com.watabou.pixeldungeon.effects.particles.WebParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;

public class Web extends Blob {
    protected void evolve() {
        for (int i = 0; i < Level.LENGTH; i++) {
            int offv = this.cur[i] > 0 ? this.cur[i] - 1 : 0;
            this.off[i] = offv;
            if (offv > 0) {
                this.volume += offv;
                Char ch = Actor.findChar(i);
                if (ch != null) {
                    Buff.prolong(ch, Roots.class, Key.TIME_TO_UNLOCK);
                }
            }
        }
    }

    public void use(BlobEmitter emitter) {
        super.use(emitter);
        emitter.pour(WebParticle.FACTORY, 0.4f);
    }

    public void seed(int cell, int amount) {
        int diff = amount - this.cur[cell];
        if (diff > 0) {
            this.cur[cell] = amount;
            this.volume += diff;
        }
    }

    public String tileDesc() {
        return "Everything is covered with a thick web here.";
    }
}
