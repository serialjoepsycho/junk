package com.watabou.pixeldungeon;

import com.watabou.noosa.Image;
import com.watabou.noosa.TextureFilm;
import com.watabou.noosa.Tilemap;
import com.watabou.noosa.Visual;
import com.watabou.noosa.tweeners.AlphaTweener;
import com.watabou.pixeldungeon.effects.ShadowBox;
import com.watabou.utils.Point;
import com.watabou.utils.PointF;

public class DungeonTilemap extends Tilemap {
    public static final int SIZE = 16;
    private static DungeonTilemap instance;

    /* renamed from: com.watabou.pixeldungeon.DungeonTilemap.1 */
    class C00141 extends AlphaTweener {
        final /* synthetic */ Image val$tile;

        C00141(Visual image, float alpha, float time, Image image2) {
            this.val$tile = image2;
            super(image, alpha, time);
        }

        protected void onComplete() {
            this.val$tile.killAndErase();
            killAndErase();
        }
    }

    public DungeonTilemap() {
        super(Dungeon.level.tilesTex(), new TextureFilm(Dungeon.level.tilesTex(), SIZE, SIZE));
        map(Dungeon.level.map, 32);
        instance = this;
    }

    public int screenToTile(int x, int y) {
        Point p = camera().screenToCamera(x, y).offset(point().negate()).invScale(ShadowBox.SIZE).floor();
        return (p.f18x < 0 || p.f18x >= 32 || p.f19y < 0 || p.f19y >= 32) ? -1 : p.f18x + (p.f19y * 32);
    }

    public boolean overlapsPoint(float x, float y) {
        return true;
    }

    public void discover(int pos, int oldValue) {
        Image tile = tile(oldValue);
        tile.point(tileToWorld(pos));
        float f = this.rm;
        tile.bm = f;
        tile.gm = f;
        tile.rm = f;
        f = this.ra;
        tile.ba = f;
        tile.ga = f;
        tile.ra = f;
        this.parent.add(tile);
        this.parent.add(new C00141(tile, 0.0f, 0.6f, tile));
    }

    public static PointF tileToWorld(int pos) {
        return new PointF((float) (pos % 32), (float) (pos / 32)).scale(ShadowBox.SIZE);
    }

    public static PointF tileCenterToWorld(int pos) {
        return new PointF((((float) (pos % 32)) + 0.5f) * ShadowBox.SIZE, (((float) (pos / 32)) + 0.5f) * ShadowBox.SIZE);
    }

    public static Image tile(int index) {
        Image img = new Image(instance.texture);
        img.frame(instance.tileset.get(Integer.valueOf(index)));
        return img;
    }

    public boolean overlapsScreenPoint(int x, int y) {
        return true;
    }
}
