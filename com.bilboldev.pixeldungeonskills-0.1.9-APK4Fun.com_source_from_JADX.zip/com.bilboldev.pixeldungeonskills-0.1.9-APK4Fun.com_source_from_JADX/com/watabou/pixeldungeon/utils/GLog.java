package com.watabou.pixeldungeon.utils;

import android.util.Log;
import com.watabou.utils.Signal;

public class GLog {
    public static final String HIGHLIGHT = "@@ ";
    public static final String NEGATIVE = "-- ";
    public static final String POSITIVE = "++ ";
    public static final String TAG = "GAME";
    public static final String WARNING = "** ";
    public static Signal<String> update;

    static {
        update = new Signal();
    }

    public static void m1i(String text, Object... args) {
        if (args.length > 0) {
            text = Utils.format(text, args);
        }
        Log.i(TAG, text);
        update.dispatch(text);
    }

    public static void m3p(String text, Object... args) {
        m1i(POSITIVE + text, args);
    }

    public static void m2n(String text, Object... args) {
        m1i(NEGATIVE + text, args);
    }

    public static void m4w(String text, Object... args) {
        m1i(WARNING + text, args);
    }

    public static void m0h(String text, Object... args) {
        m1i(HIGHLIGHT + text, args);
    }
}
