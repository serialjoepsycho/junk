package com.watabou.pixeldungeon;

import com.watabou.noosa.Game;
import com.watabou.pixeldungeon.GamesInProgress.Info;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Amok;
import com.watabou.pixeldungeon.actors.buffs.Light;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.mobs.npcs.Blacksmith;
import com.watabou.pixeldungeon.actors.mobs.npcs.Ghost.Quest;
import com.watabou.pixeldungeon.actors.mobs.npcs.Imp;
import com.watabou.pixeldungeon.actors.mobs.npcs.Wandmaker;
import com.watabou.pixeldungeon.items.Ankh;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.potions.Potion;
import com.watabou.pixeldungeon.items.rings.Ring;
import com.watabou.pixeldungeon.items.scrolls.Scroll;
import com.watabou.pixeldungeon.items.wands.Wand;
import com.watabou.pixeldungeon.levels.CavesBossLevel;
import com.watabou.pixeldungeon.levels.CavesLevel;
import com.watabou.pixeldungeon.levels.CityBossLevel;
import com.watabou.pixeldungeon.levels.CityLevel;
import com.watabou.pixeldungeon.levels.DeadEndLevel;
import com.watabou.pixeldungeon.levels.HallsBossLevel;
import com.watabou.pixeldungeon.levels.HallsLevel;
import com.watabou.pixeldungeon.levels.LastLevel;
import com.watabou.pixeldungeon.levels.LastShopLevel;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.PrisonBossLevel;
import com.watabou.pixeldungeon.levels.PrisonLevel;
import com.watabou.pixeldungeon.levels.Room;
import com.watabou.pixeldungeon.levels.SewerBossLevel;
import com.watabou.pixeldungeon.levels.SewerLevel;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.StartScene;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.ui.QuickSlot;
import com.watabou.pixeldungeon.utils.BArray;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndResurrect;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.PathFinder;
import com.watabou.utils.Random;
import com.watabou.utils.SparseArray;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;

public class Dungeon {
    private static final String BADGES = "badges";
    private static final String CHALLENGES = "challenges";
    private static final String CHAPTERS = "chapters";
    private static final String DEPTH = "depth";
    private static final String DROPPED = "dropped%d";
    private static final String DV = "dewVial";
    private static final String GOLD = "gold";
    private static final String HERO = "hero";
    private static final String LEVEL = "level";
    private static final String MG_DEPTH_FILE = "mage%d.dat";
    private static final String MG_GAME_FILE = "mage.dat";
    private static final String POS = "potionsOfStrength";
    private static final String QUESTS = "quests";
    private static final String RG_DEPTH_FILE = "depth%d.dat";
    private static final String RG_GAME_FILE = "game.dat";
    private static final String RN_DEPTH_FILE = "ranger%d.dat";
    private static final String RN_GAME_FILE = "ranger.dat";
    private static final String SOE = "scrollsOfEnchantment";
    private static final String SOU = "scrollsOfEnhancement";
    private static final String VERSION = "version";
    private static final String WR_DEPTH_FILE = "warrior%d.dat";
    private static final String WR_GAME_FILE = "warrior.dat";
    private static final String WT = "transmutation";
    public static int challenges;
    public static HashSet<Integer> chapters;
    public static int depth;
    public static boolean dewVial;
    public static int difficulty;
    public static SparseArray<ArrayList<Item>> droppedItems;
    public static int gold;
    public static Hero hero;
    public static Level level;
    public static boolean nightMode;
    private static boolean[] passable;
    public static int potionOfStrength;
    public static String resultDescription;
    public static int scrollsOfEnchantment;
    public static int scrollsOfUpgrade;
    public static int transmutation;
    public static boolean[] visible;

    /* renamed from: com.watabou.pixeldungeon.Dungeon.1 */
    static /* synthetic */ class C00131 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass;

        static {
            $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass = new int[HeroClass.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.WARRIOR.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.MAGE.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.HUNTRESS.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    static {
        visible = new boolean[Level.LENGTH];
        passable = new boolean[Level.LENGTH];
    }

    public static void init() {
        challenges = PixelDungeon.challenges();
        Actor.clear();
        PathFinder.setMapSize(32, 32);
        Scroll.initLabels();
        Potion.initColors();
        Wand.initWoods();
        Ring.initGems();
        Statistics.reset();
        Journal.reset();
        depth = 0;
        gold = 0;
        droppedItems = new SparseArray();
        potionOfStrength = 0;
        scrollsOfUpgrade = 0;
        scrollsOfEnchantment = 0;
        dewVial = true;
        transmutation = Random.IntRange(6, 14);
        chapters = new HashSet();
        Quest.reset();
        Wandmaker.Quest.reset();
        Blacksmith.Quest.reset();
        Imp.Quest.reset();
        Room.shuffleTypes();
        QuickSlot.primaryValue = null;
        QuickSlot.secondaryValue = null;
        hero = new Hero();
        hero.difficulty = difficulty;
        hero.live();
        Badges.reset();
        StartScene.curClass.initHero(hero);
    }

    public static boolean isChallenged(int mask) {
        return (challenges & mask) != 0;
    }

    public static Level newLevel() {
        Level level;
        boolean z = true;
        level = null;
        Actor.clear();
        depth++;
        if (depth > Statistics.deepestFloor) {
            Statistics.deepestFloor = depth;
            if (Statistics.qualifiedForNoKilling) {
                Statistics.completedWithNoKilling = true;
            } else {
                Statistics.completedWithNoKilling = false;
            }
        }
        Arrays.fill(visible, false);
        switch (depth) {
            case WndUpdates.ID_PRISON /*1*/:
            case WndUpdates.ID_CAVES /*2*/:
            case WndUpdates.ID_METROPOLIS /*3*/:
            case WndUpdates.ID_HALLS /*4*/:
                level = new SewerLevel();
                break;
            case BuffIndicator.HUNGER /*5*/:
                level = new SewerBossLevel();
                break;
            case BuffIndicator.STARVATION /*6*/:
            case BuffIndicator.SLOW /*7*/:
            case BuffIndicator.OOZE /*8*/:
            case BuffIndicator.AMOK /*9*/:
                level = new PrisonLevel();
                break;
            case BuffIndicator.TERROR /*10*/:
                level = new PrisonBossLevel();
                break;
            case BuffIndicator.ROOTS /*11*/:
            case BuffIndicator.INVISIBLE /*12*/:
            case BuffIndicator.SHADOWS /*13*/:
            case BuffIndicator.WEAKNESS /*14*/:
                level = new CavesLevel();
                break;
            case BuffIndicator.FROST /*15*/:
                level = new CavesBossLevel();
                break;
            case BuffIndicator.BLINDNESS /*16*/:
            case BuffIndicator.COMBO /*17*/:
            case BuffIndicator.FURY /*18*/:
            case BuffIndicator.HEALING /*19*/:
                level = new CityLevel();
                break;
            case BuffIndicator.ARMOR /*20*/:
                level = new CityBossLevel();
                break;
            case BuffIndicator.HEART /*21*/:
                level = new LastShopLevel();
                break;
            case BuffIndicator.LIGHT /*22*/:
            case BuffIndicator.CRIPPLE /*23*/:
            case BuffIndicator.BARKSKIN /*24*/:
                level = new HallsLevel();
                break;
            case BuffIndicator.IMMUNITY /*25*/:
                level = new HallsBossLevel();
                break;
            case ItemButton.SIZE /*26*/:
                level = new LastLevel();
                break;
            default:
                level = new DeadEndLevel();
                Statistics.deepestFloor--;
                break;
        }
        level.create();
        if (bossLevel()) {
            z = false;
        }
        Statistics.qualifiedForNoKilling = z;
        return level;
    }

    public static void resetLevel() {
        Actor.clear();
        Arrays.fill(visible, false);
        level.reset();
        switchLevel(level, level.entrance);
    }

    public static boolean shopOnLevel() {
        return depth == 6 || depth == 11 || depth == 16;
    }

    public static boolean bossLevel() {
        return bossLevel(depth);
    }

    public static boolean bossLevel(int depth) {
        return depth == 5 || depth == 10 || depth == 15 || depth == 20 || depth == 25;
    }

    public static void switchLevel(Level level, int pos) {
        boolean z = new Date().getHours() < 7 && !PixelDungeon.fixedDay();
        nightMode = z;
        level = level;
        Actor.init();
        if (level.respawner() != null) {
            Actor.add(level.respawner());
        }
        Hero hero = hero;
        if (pos == -1) {
            pos = level.exit;
        }
        hero.pos = pos;
        Light light = (Light) hero.buff(Light.class);
        hero.viewDistance = light == null ? level.viewDistance : Math.max(4, level.viewDistance);
        observe();
    }

    public static void dropToChasm(Item item) {
        int depth = depth + 1;
        ArrayList<Item> dropped = (ArrayList) droppedItems.get(depth);
        if (dropped == null) {
            SparseArray sparseArray = droppedItems;
            dropped = new ArrayList();
            sparseArray.put(depth, dropped);
        }
        dropped.add(item);
    }

    public static boolean posNeeded() {
        return chance(new int[]{4, 2, 9, 4, 14, 6, 19, 8, 24, 9}, potionOfStrength);
    }

    public static boolean souNeeded() {
        return chance(new int[]{5, 3, 10, 6, 15, 9, 20, 12, 25, 13}, scrollsOfUpgrade);
    }

    public static boolean soeNeeded() {
        return Random.Int((scrollsOfEnchantment + 1) * 12) < depth;
    }

    private static boolean chance(int[] quota, int number) {
        for (int i = 0; i < quota.length; i += 2) {
            int qDepth = quota[i];
            if (depth <= qDepth) {
                if (Random.Float() < ((float) (quota[i + 1] - number)) / ((float) ((qDepth - depth) + 1))) {
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public static String gameFile(HeroClass cl) {
        switch (C00131.$SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[cl.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                return WR_GAME_FILE;
            case WndUpdates.ID_CAVES /*2*/:
                return MG_GAME_FILE;
            case WndUpdates.ID_METROPOLIS /*3*/:
                return RN_GAME_FILE;
            default:
                return RG_GAME_FILE;
        }
    }

    private static String depthFile(HeroClass cl) {
        switch (C00131.$SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[cl.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                return WR_DEPTH_FILE;
            case WndUpdates.ID_CAVES /*2*/:
                return MG_DEPTH_FILE;
            case WndUpdates.ID_METROPOLIS /*3*/:
                return RN_DEPTH_FILE;
            default:
                return RG_DEPTH_FILE;
        }
    }

    public static void saveGame(String fileName) throws IOException {
        try {
            Bundle bundle = new Bundle();
            bundle.put(VERSION, Game.version);
            bundle.put(CHALLENGES, challenges);
            bundle.put(HERO, hero);
            bundle.put(GOLD, gold);
            bundle.put(DEPTH, depth);
            for (int d : droppedItems.keyArray()) {
                bundle.put(String.format(DROPPED, new Object[]{Integer.valueOf(d)}), (Collection) droppedItems.get(d));
            }
            bundle.put(POS, potionOfStrength);
            bundle.put(SOU, scrollsOfUpgrade);
            bundle.put(SOE, scrollsOfEnchantment);
            bundle.put(DV, dewVial);
            bundle.put(WT, transmutation);
            int[] ids = new int[chapters.size()];
            Iterator it = chapters.iterator();
            int count = 0;
            while (it.hasNext()) {
                int count2 = count + 1;
                ids[count] = ((Integer) it.next()).intValue();
                count = count2;
            }
            bundle.put(CHAPTERS, ids);
            Bundle quests = new Bundle();
            Quest.storeInBundle(quests);
            Wandmaker.Quest.storeInBundle(quests);
            Blacksmith.Quest.storeInBundle(quests);
            Imp.Quest.storeInBundle(quests);
            bundle.put(QUESTS, quests);
            Room.storeRoomsInBundle(bundle);
            Statistics.storeInBundle(bundle);
            Journal.storeInBundle(bundle);
            QuickSlot.save(bundle);
            Scroll.save(bundle);
            Potion.save(bundle);
            Wand.save(bundle);
            Ring.save(bundle);
            Bundle badges = new Bundle();
            Badges.saveLocal(badges);
            bundle.put(BADGES, badges);
            OutputStream output = Game.instance.openFileOutput(fileName, 0);
            Bundle.write(bundle, output);
            output.close();
        } catch (Exception e) {
            GamesInProgress.setUnknown(hero.heroClass);
        }
    }

    public static void saveLevel() throws IOException {
        Bundle bundle = new Bundle();
        bundle.put(LEVEL, level);
        OutputStream output = Game.instance.openFileOutput(Utils.format(depthFile(hero.heroClass), Integer.valueOf(depth)), 0);
        Bundle.write(bundle, output);
        output.close();
    }

    public static void saveAll() throws IOException {
        if (hero.isAlive()) {
            Actor.fixTime();
            saveGame(gameFile(hero.heroClass));
            saveLevel();
            GamesInProgress.set(hero.heroClass, depth, hero.lvl, challenges != 0);
        } else if (WndResurrect.instance != null) {
            WndResurrect.instance.hide();
            Hero.reallyDie(WndResurrect.causeOfDeath);
        }
    }

    public static void loadGame(HeroClass cl) throws IOException {
        loadGame(gameFile(cl), true);
    }

    public static void loadGame(String fileName) throws IOException {
        loadGame(fileName, false);
    }

    public static void loadGame(String fileName, boolean fullLoad) throws IOException {
        Bundle bundle = gameBundle(fileName);
        challenges = bundle.getInt(CHALLENGES);
        level = null;
        depth = -1;
        if (fullLoad) {
            PathFinder.setMapSize(32, 32);
        }
        Scroll.restore(bundle);
        Potion.restore(bundle);
        Wand.restore(bundle);
        Ring.restore(bundle);
        potionOfStrength = bundle.getInt(POS);
        scrollsOfUpgrade = bundle.getInt(SOU);
        scrollsOfEnchantment = bundle.getInt(SOE);
        dewVial = bundle.getBoolean(DV);
        transmutation = bundle.getInt(WT);
        if (fullLoad) {
            chapters = new HashSet();
            int[] ids = bundle.getIntArray(CHAPTERS);
            if (ids != null) {
                for (int id : ids) {
                    chapters.add(Integer.valueOf(id));
                }
            }
            Bundle quests = bundle.getBundle(QUESTS);
            if (quests.isNull()) {
                Quest.reset();
                Wandmaker.Quest.reset();
                Blacksmith.Quest.reset();
                Imp.Quest.reset();
            } else {
                Quest.restoreFromBundle(quests);
                Wandmaker.Quest.restoreFromBundle(quests);
                Blacksmith.Quest.restoreFromBundle(quests);
                Imp.Quest.restoreFromBundle(quests);
            }
            Room.restoreRoomsFromBundle(bundle);
        }
        Bundle badges = bundle.getBundle(BADGES);
        if (badges.isNull()) {
            Badges.reset();
        } else {
            Badges.loadLocal(badges);
        }
        QuickSlot.restore(bundle);
        String version = bundle.getString(VERSION);
        hero = null;
        hero = (Hero) bundle.get(HERO);
        QuickSlot.compress();
        gold = bundle.getInt(GOLD);
        depth = bundle.getInt(DEPTH);
        Statistics.restoreFromBundle(bundle);
        Journal.restoreFromBundle(bundle);
        droppedItems = new SparseArray();
        for (int i = 2; i <= Statistics.deepestFloor + 1; i++) {
            ArrayList<Item> dropped = new ArrayList();
            for (Bundlable b : bundle.getCollection(String.format(DROPPED, new Object[]{Integer.valueOf(i)}))) {
                dropped.add((Item) b);
            }
            if (!dropped.isEmpty()) {
                droppedItems.put(i, dropped);
            }
        }
    }

    public static Level loadLevel(HeroClass cl) throws IOException {
        level = null;
        Actor.clear();
        InputStream input = Game.instance.openFileInput(Utils.format(depthFile(cl), Integer.valueOf(depth)));
        Bundle bundle = Bundle.read(input);
        input.close();
        return (Level) bundle.get(LEVEL);
    }

    public static void deleteGame(HeroClass cl, boolean deleteLevels) {
        Game.instance.deleteFile(gameFile(cl));
        if (deleteLevels) {
            int depth = 1;
            while (true) {
                if (!Game.instance.deleteFile(Utils.format(depthFile(cl), Integer.valueOf(depth)))) {
                    break;
                }
                depth++;
            }
        }
        GamesInProgress.delete(cl);
    }

    public static Bundle gameBundle(String fileName) throws IOException {
        InputStream input = Game.instance.openFileInput(fileName);
        Bundle bundle = Bundle.read(input);
        input.close();
        return bundle;
    }

    public static void preview(Info info, Bundle bundle) {
        info.depth = bundle.getInt(DEPTH);
        info.challenges = bundle.getInt(CHALLENGES) != 0;
        if (info.depth == -1) {
            info.depth = bundle.getInt("maxDepth");
        }
        Hero.preview(info, bundle.getBundle(HERO));
    }

    public static void fail(String desc) {
        resultDescription = desc;
        if (hero.belongings.getItem(Ankh.class) == null) {
            Rankings.INSTANCE.submit(false);
        }
    }

    public static void win(String desc) {
        hero.belongings.identify();
        if (challenges != 0) {
            Badges.validateChampion();
        }
        resultDescription = desc;
        Rankings.INSTANCE.submit(true);
    }

    public static void observe() {
        if (level != null) {
            level.updateFieldOfView(hero);
            System.arraycopy(Level.fieldOfView, 0, visible, 0, visible.length);
            BArray.or(level.visited, visible, level.visited);
            GameScene.afterObserve();
        }
    }

    public static int findPath(Char ch, int from, int to, boolean[] pass, boolean[] visible) {
        if (!Level.adjacent(from, to)) {
            if (ch.flying || ch.buff(Amok.class) != null) {
                BArray.or(pass, Level.avoid, passable);
            } else {
                System.arraycopy(pass, 0, passable, 0, Level.LENGTH);
            }
            Iterator it = Actor.all().iterator();
            while (it.hasNext()) {
                Actor actor = (Actor) it.next();
                if (actor instanceof Char) {
                    int pos = ((Char) actor).pos;
                    if (visible[pos]) {
                        passable[pos] = false;
                    }
                }
            }
            return PathFinder.getStep(from, to, passable);
        } else if (Actor.findChar(to) == null && (pass[to] || Level.avoid[to])) {
            return to;
        } else {
            return -1;
        }
    }

    public static int flee(Char ch, int cur, int from, boolean[] pass, boolean[] visible) {
        if (ch.flying) {
            BArray.or(pass, Level.avoid, passable);
        } else {
            System.arraycopy(pass, 0, passable, 0, Level.LENGTH);
        }
        Iterator it = Actor.all().iterator();
        while (it.hasNext()) {
            Actor actor = (Actor) it.next();
            if (actor instanceof Char) {
                int pos = ((Char) actor).pos;
                if (visible[pos]) {
                    passable[pos] = false;
                }
            }
        }
        passable[cur] = true;
        return PathFinder.getStepBack(cur, from, passable);
    }
}
