package com.watabou.pixeldungeon.items;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.utils.GLog;
import java.util.ArrayList;
import java.util.Iterator;

public class BombTriggerBeacon extends Item {
    public static final float TIME_TO_USE = 1.0f;
    private static final Glowing WHITE;

    public BombTriggerBeacon() {
        this.name = "bomb trigger beacon";
        this.image = 85;
        this.unique = true;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.remove(Item.AC_THROW);
        if (!actions.contains("Detonate")) {
            actions.add("Detonate");
        }
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action == "Detonate") {
            GLog.m1i("Beacon sends out a signal...", new Object[0]);
            for (int i = 0; i < Dungeon.level.heaps.size(); i++) {
                Heap heap = (Heap) Dungeon.level.heaps.get(Dungeon.level.heaps.keyAt(i));
                Iterator it = heap.items.iterator();
                while (it.hasNext()) {
                    Item item = (Item) it.next();
                    if (item instanceof RemoteBombGround) {
                        ((RemoteBombGround) item).explode();
                    }
                }
                heap.removeRemoteBombs();
                if (heap.isEmpty()) {
                    heap.destroy();
                } else if (heap.sprite != null) {
                    heap.sprite.view(heap.image(), heap.glowing());
                }
            }
            Dungeon.observe();
            hero.spend(GasesImmunity.DURATION);
            return;
        }
        super.execute(hero, action);
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    static {
        WHITE = new Glowing(CharSprite.DEFAULT);
    }

    public String info() {
        return "A remote trigger that can detonate thrown remote bombs. It looks a bit worn out... its signal might not reach all the bombs from the first attempt.";
    }
}
