package com.watabou.pixeldungeon.items;

import com.watabou.noosa.Game;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.wands.WandOfBlink;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.InterlevelScene;
import com.watabou.pixeldungeon.scenes.InterlevelScene.Mode;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Bundle;
import java.util.ArrayList;

public class LloydsBeacon extends Item {
    public static final String AC_RETURN = "RETURN";
    public static final String AC_SET = "SET";
    private static final String DEPTH = "depth";
    private static final String POS = "pos";
    public static final float TIME_TO_USE = 1.0f;
    private static final String TXT_CREATURES = "Psychic aura of neighbouring creatures doesn't allow you to use the lloyd's beacon at this moment.";
    private static final String TXT_INFO = "Lloyd's beacon is an intricate magic device, that allows you to return to a place you have already been.";
    private static final String TXT_PREVENTING = "Strong magic aura of this place prevents you from using the lloyd's beacon!";
    private static final String TXT_RETURN = "The lloyd's beacon is successfully set at your current location, now you can return here anytime.";
    private static final String TXT_SET = "\n\nThis beacon was set somewhere on the level %d of Pixel Dungeon.";
    private static final Glowing WHITE;
    private int returnDepth;
    private int returnPos;

    public LloydsBeacon() {
        this.returnDepth = -1;
        this.name = "lloyd's beacon";
        this.image = 85;
        this.unique = true;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(DEPTH, this.returnDepth);
        if (this.returnDepth != -1) {
            bundle.put(POS, this.returnPos);
        }
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.returnDepth = bundle.getInt(DEPTH);
        this.returnPos = bundle.getInt(POS);
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_SET);
        if (this.returnDepth != -1) {
            actions.add(AC_RETURN);
        }
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action == AC_SET || action == AC_RETURN) {
            if (Dungeon.bossLevel()) {
                hero.spend(TIME_TO_USE);
                GLog.m4w(TXT_PREVENTING, new Object[0]);
                return;
            }
            for (int i : Level.NEIGHBOURS8) {
                if (Actor.findChar(hero.pos + i) != null) {
                    GLog.m4w(TXT_CREATURES, new Object[0]);
                    return;
                }
            }
        }
        if (action == AC_SET) {
            this.returnDepth = Dungeon.depth;
            this.returnPos = hero.pos;
            hero.spend(TIME_TO_USE);
            hero.busy();
            hero.sprite.operate(hero.pos);
            Sample.INSTANCE.play(Assets.SND_BEACON);
            GLog.m1i(TXT_RETURN, new Object[0]);
        } else if (action != AC_RETURN) {
            super.execute(hero, action);
        } else if (this.returnDepth == Dungeon.depth) {
            reset();
            WandOfBlink.appear(hero, this.returnPos);
            Dungeon.level.press(this.returnPos, hero);
            Dungeon.observe();
        } else {
            InterlevelScene.mode = Mode.RETURN;
            InterlevelScene.returnDepth = this.returnDepth;
            InterlevelScene.returnPos = this.returnPos;
            reset();
            Game.switchScene(InterlevelScene.class);
        }
    }

    public void reset() {
        this.returnDepth = -1;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    static {
        WHITE = new Glowing(CharSprite.DEFAULT);
    }

    public Glowing glowing() {
        return this.returnDepth != -1 ? WHITE : null;
    }

    public String info() {
        String str;
        StringBuilder append = new StringBuilder().append(TXT_INFO);
        if (this.returnDepth == -1) {
            str = BuildConfig.VERSION_NAME;
        } else {
            str = Utils.format(TXT_SET, Integer.valueOf(this.returnDepth));
        }
        return append.append(str).toString();
    }
}
