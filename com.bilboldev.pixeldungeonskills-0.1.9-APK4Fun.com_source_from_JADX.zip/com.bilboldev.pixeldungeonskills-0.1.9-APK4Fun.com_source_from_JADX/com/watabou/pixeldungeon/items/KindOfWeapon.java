package com.watabou.pixeldungeon.items;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.ui.QuickSlot;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class KindOfWeapon extends EquipableItem {
    protected static final float TIME_TO_EQUIP = 1.0f;
    private static final String TXT_EQUIP_CURSED = "you wince as your grip involuntarily tightens around your %s";
    public int MAX;
    public int MIN;

    public KindOfWeapon() {
        this.MIN = 0;
        this.MAX = 1;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(isEquipped(hero) ? EquipableItem.AC_UNEQUIP : EquipableItem.AC_EQUIP);
        return actions;
    }

    public boolean isEquipped(Hero hero) {
        return hero.belongings.weapon == this;
    }

    public boolean doEquip(Hero hero) {
        detachAll(hero.belongings.backpack);
        if (hero.belongings.weapon == null || hero.belongings.weapon.doUnequip(hero, true)) {
            hero.belongings.weapon = this;
            activate(hero);
            QuickSlot.refresh();
            this.cursedKnown = true;
            if (this.cursed) {
                EquipableItem.equipCursed(hero);
                GLog.m2n(TXT_EQUIP_CURSED, name());
            }
            hero.spendAndNext(TIME_TO_EQUIP);
            return true;
        }
        collect(hero.belongings.backpack);
        return false;
    }

    public boolean doUnequip(Hero hero, boolean collect, boolean single) {
        if (!super.doUnequip(hero, collect, single)) {
            return false;
        }
        hero.belongings.weapon = null;
        return true;
    }

    public void activate(Hero hero) {
    }

    public int damageRoll(Hero owner) {
        return Random.NormalIntRange(this.MIN, this.MAX);
    }

    public float acuracyFactor(Hero hero) {
        return TIME_TO_EQUIP;
    }

    public float speedFactor(Hero hero) {
        return TIME_TO_EQUIP;
    }

    public void proc(Char attacker, Char defender, int damage) {
    }
}
