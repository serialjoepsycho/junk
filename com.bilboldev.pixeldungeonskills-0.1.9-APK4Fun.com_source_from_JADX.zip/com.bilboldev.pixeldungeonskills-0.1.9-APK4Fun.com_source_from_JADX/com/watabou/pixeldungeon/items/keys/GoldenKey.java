package com.watabou.pixeldungeon.items.keys;

public class GoldenKey extends Key {
    public GoldenKey() {
        this.name = "golden key";
        this.image = 10;
    }

    public String info() {
        return "The notches on this golden key are tiny and intricate. Maybe it can open some chest lock?";
    }
}
