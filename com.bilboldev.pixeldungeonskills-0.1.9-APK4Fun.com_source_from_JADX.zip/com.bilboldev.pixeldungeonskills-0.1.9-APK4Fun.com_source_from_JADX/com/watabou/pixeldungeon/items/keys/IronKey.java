package com.watabou.pixeldungeon.items.keys;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.bags.Bag;
import com.watabou.pixeldungeon.utils.Utils;

public class IronKey extends Key {
    private static final String TXT_FROM_DEPTH = "iron key from depth %d";
    public static int curDepthQuantity;

    public IronKey() {
        this.name = "iron key";
        this.image = 9;
    }

    static {
        curDepthQuantity = 0;
    }

    public boolean collect(Bag bag) {
        boolean result = super.collect(bag);
        if (result && this.depth == Dungeon.depth && Dungeon.hero != null) {
            Dungeon.hero.belongings.countIronKeys();
        }
        return result;
    }

    public void onDetach() {
        if (this.depth == Dungeon.depth) {
            Dungeon.hero.belongings.countIronKeys();
        }
    }

    public String toString() {
        return Utils.format(TXT_FROM_DEPTH, Integer.valueOf(this.depth));
    }

    public String info() {
        return "The notches on this ancient iron key are well worn; its leather lanyard is battered by age. What door might it open?";
    }
}
