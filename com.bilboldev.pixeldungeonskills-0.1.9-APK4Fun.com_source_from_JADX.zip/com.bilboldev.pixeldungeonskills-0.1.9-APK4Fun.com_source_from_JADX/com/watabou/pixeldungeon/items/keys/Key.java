package com.watabou.pixeldungeon.items.keys;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.utils.Bundle;

public class Key extends Item {
    private static final String DEPTH = "depth";
    public static final float TIME_TO_UNLOCK = 1.0f;
    public int depth;

    public Key() {
        this.stackable = false;
        this.depth = Dungeon.depth;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(DEPTH, this.depth);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.depth = bundle.getInt(DEPTH);
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String status() {
        return this.depth + "\u007f";
    }
}
