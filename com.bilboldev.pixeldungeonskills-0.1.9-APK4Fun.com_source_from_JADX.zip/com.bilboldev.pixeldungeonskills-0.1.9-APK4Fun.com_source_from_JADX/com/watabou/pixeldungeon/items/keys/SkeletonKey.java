package com.watabou.pixeldungeon.items.keys;

public class SkeletonKey extends Key {
    public SkeletonKey() {
        this.name = "skeleton key";
        this.image = 8;
    }

    public String info() {
        return "This key looks serious: its head is shaped like a skull. Probably it can open some serious door.";
    }
}
