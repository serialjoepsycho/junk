package com.watabou.pixeldungeon.items;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Paralysis;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.BlastParticle;
import com.watabou.pixeldungeon.effects.particles.SmokeParticle;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.utils.Random;

public class Bomb extends Item {
    public Bomb() {
        this.name = "bomb";
        this.image = ItemSpriteSheet.BOMB;
        this.defaultAction = Item.AC_THROW;
        this.stackable = true;
    }

    protected void onThrow(int cell) {
        if (Level.pit[cell]) {
            super.onThrow(cell);
            return;
        }
        Sample.INSTANCE.play(Assets.SND_BLAST, Pickaxe.TIME_TO_MINE);
        if (Dungeon.visible[cell]) {
            CellEmitter.center(cell).burst(BlastParticle.FACTORY, 30);
        }
        boolean terrainAffected = false;
        for (int n : Level.NEIGHBOURS9) {
            int c = cell + n;
            if (c >= 0 && c < Level.LENGTH) {
                if (Dungeon.visible[c]) {
                    CellEmitter.get(c).burst(SmokeParticle.FACTORY, 4);
                }
                if (Level.flamable[c]) {
                    Level.set(c, 9);
                    GameScene.updateMap(c);
                    terrainAffected = true;
                }
                Char ch = Actor.findChar(c);
                if (ch != null) {
                    int dmg = Random.Int(Dungeon.depth + 1, (Dungeon.depth * 2) + 10) - Random.Int(ch.dr());
                    if (dmg > 0) {
                        ch.damage(dmg, this);
                        if (ch.isAlive()) {
                            Buff.prolong(ch, Paralysis.class, Pickaxe.TIME_TO_MINE);
                        }
                    }
                }
            }
        }
        if (terrainAffected) {
            Dungeon.observe();
        }
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public Item random() {
        this.quantity = Random.IntRange(1, 3);
        return this;
    }

    public int price() {
        return this.quantity * 10;
    }

    public String info() {
        return "This is a relatively small bomb, filled with black powder. Conveniently, its fuse is lit automatically when the bomb is thrown.";
    }
}
