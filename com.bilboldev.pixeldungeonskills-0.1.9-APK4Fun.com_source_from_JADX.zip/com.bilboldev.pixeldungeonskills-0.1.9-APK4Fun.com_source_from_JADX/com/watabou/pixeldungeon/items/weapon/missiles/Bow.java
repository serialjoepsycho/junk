package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.EquipableItem;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import java.util.ArrayList;

public class Bow extends MissileWeapon {
    public boolean doEquip(Hero hero) {
        if (hero.belongings.bow == null) {
            hero.belongings.bow = this;
            hero.spendAndNext(Key.TIME_TO_UNLOCK);
            detach(hero.belongings.backpack);
            updateQuickslot();
        } else {
            if (hero.belongings.bow.doUnequip(hero, true, false)) {
                doEquip(hero);
            } else {
                collect(hero.belongings.backpack);
            }
            updateQuickslot();
        }
        return true;
    }

    public boolean doUnequip(Hero hero, boolean collect, boolean single) {
        if (collect(hero.belongings.backpack)) {
            hero.belongings.bow = null;
            updateQuickslot();
            return true;
        }
        updateQuickslot();
        return false;
    }

    public Bow() {
        this(1);
    }

    public Bow(int number) {
        this.name = "bow";
        this.image = ItemSpriteSheet.Bow;
        this.MIN = 1;
        this.MAX = 1;
        this.stackable = false;
        this.quantity = number;
    }

    public String desc() {
        return "This bow can be used to fire arrows.";
    }

    public Item random() {
        this.quantity = 1;
        return this;
    }

    public int price() {
        return this.quantity * 15;
    }

    public void doDrop(Hero hero) {
        if (hero.belongings.bow == this) {
            hero.belongings.bow = null;
        }
        super.doDrop(hero);
    }

    public boolean isEquipped(Hero hero) {
        return hero.belongings.bow == this;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.remove(Item.AC_THROW);
        actions.remove(EquipableItem.AC_EQUIP);
        if (Dungeon.hero.belongings.bow != this) {
            if (!actions.contains(EquipableItem.AC_EQUIP)) {
                actions.add(EquipableItem.AC_EQUIP);
            }
        } else if (!actions.contains(EquipableItem.AC_UNEQUIP)) {
            actions.add(EquipableItem.AC_UNEQUIP);
        }
        return actions;
    }
}
