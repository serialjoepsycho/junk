package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Bleeding;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.utils.Random;

public class Tamahawk extends MissileWeapon {
    public Tamahawk() {
        this(1);
    }

    public Tamahawk(int number) {
        this.name = "tomahawk";
        this.image = ItemSpriteSheet.TOMAHAWK;
        this.STR = 17;
        this.MIN = 4;
        this.MAX = 20;
        this.quantity = number;
    }

    public void proc(Char attacker, Char defender, int damage) {
        super.proc(attacker, defender, damage);
        ((Bleeding) Buff.affect(defender, Bleeding.class)).set(damage);
    }

    public String desc() {
        return "This throwing axe is not that heavy, but it still requires significant strength to be used effectively.";
    }

    public Item random() {
        this.quantity = Random.Int(5, 12);
        return this;
    }

    public int price() {
        return this.quantity * 20;
    }
}
