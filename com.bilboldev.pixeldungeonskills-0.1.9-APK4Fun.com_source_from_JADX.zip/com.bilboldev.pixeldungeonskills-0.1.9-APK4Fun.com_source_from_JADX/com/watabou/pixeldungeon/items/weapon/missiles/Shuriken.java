package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.items.Item;
import com.watabou.utils.Random;

public class Shuriken extends MissileWeapon {
    public Shuriken() {
        this(1);
    }

    public Shuriken(int number) {
        this.name = "shuriken";
        this.image = 15;
        this.STR = 13;
        this.MIN = 2;
        this.MAX = 6;
        this.DLY = 0.5f;
        this.quantity = number;
    }

    public String desc() {
        return "Star-shaped pieces of metal with razor-sharp blades do significant damage when they hit a target. They can be thrown at very high rate.";
    }

    public Item random() {
        this.quantity = Random.Int(5, 15);
        return this;
    }

    public int price() {
        return this.quantity * 15;
    }
}
