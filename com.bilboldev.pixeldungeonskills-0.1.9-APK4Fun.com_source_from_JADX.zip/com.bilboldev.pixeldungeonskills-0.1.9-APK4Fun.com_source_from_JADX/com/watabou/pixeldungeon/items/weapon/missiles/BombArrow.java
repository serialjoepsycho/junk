package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Paralysis;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.BlastParticle;
import com.watabou.pixeldungeon.effects.particles.SmokeParticle;
import com.watabou.pixeldungeon.items.EquipableItem;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class BombArrow extends MissileWeapon {
    public BombArrow() {
        this(1);
    }

    protected void onThrow(int cell) {
        if (Level.pit[cell]) {
            super.onThrow(cell);
            return;
        }
        Sample.INSTANCE.play(Assets.SND_BLAST, Pickaxe.TIME_TO_MINE);
        if (Dungeon.visible[cell]) {
            CellEmitter.center(cell).burst(BlastParticle.FACTORY, 30);
        }
        boolean terrainAffected = false;
        for (int n : Level.NEIGHBOURS9) {
            int c = cell + n;
            if (c >= 0 && c < Level.LENGTH) {
                if (Dungeon.visible[c]) {
                    CellEmitter.get(c).burst(SmokeParticle.FACTORY, 4);
                }
                if (Level.flamable[c]) {
                    Level.set(c, 9);
                    GameScene.updateMap(c);
                    terrainAffected = true;
                }
                Char ch = Actor.findChar(c);
                if (ch != null) {
                    int dmg = Random.Int(Dungeon.depth + 1, (Dungeon.depth * 2) + 10) - Random.Int(ch.dr());
                    if (dmg > 0) {
                        ch.damage(dmg, this);
                        if (ch.isAlive()) {
                            Buff.prolong(ch, Paralysis.class, Pickaxe.TIME_TO_MINE);
                        }
                    }
                }
            }
        }
        if (terrainAffected) {
            Dungeon.observe();
        }
    }

    public BombArrow(int number) {
        this.name = "bomb arrow";
        this.image = ItemSpriteSheet.BombArrow;
        this.MIN = 4;
        this.MAX = 7;
        this.stackable = true;
        this.quantity = number;
    }

    public String info() {
        return desc();
    }

    public String desc() {
        return "Bomb arrows deliver a sack of gun power that ignites on impact. They require an equipped bow.";
    }

    public Item random() {
        this.quantity = Random.Int(1, 2);
        return this;
    }

    public int price() {
        return this.quantity * 35;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (Dungeon.hero.belongings.bow == null) {
            actions.remove(Item.AC_THROW);
        } else if (!actions.contains(Item.AC_THROW)) {
            actions.add(Item.AC_THROW);
        }
        actions.remove(EquipableItem.AC_EQUIP);
        return actions;
    }
}
