package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.blobs.Fire;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Burning;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.utils.Random;

public class IncendiaryDart extends MissileWeapon {
    public IncendiaryDart() {
        this(1);
    }

    public IncendiaryDart(int number) {
        this.name = "incendiary dart";
        this.image = ItemSpriteSheet.INCENDIARY_DART;
        this.STR = 12;
        this.MIN = 1;
        this.MAX = 2;
        this.quantity = number;
    }

    protected void onThrow(int cell) {
        Char enemy = Actor.findChar(cell);
        if (enemy == null || enemy == curUser) {
            if (Level.flamable[cell]) {
                GameScene.add(Blob.seed(cell, 4, Fire.class));
            } else {
                super.onThrow(cell);
            }
        } else if (!curUser.shoot(enemy, this)) {
            Dungeon.level.drop(this, cell).sprite.drop();
        }
    }

    public void proc(Char attacker, Char defender, int damage) {
        ((Burning) Buff.affect(defender, Burning.class)).reignite(defender);
        super.proc(attacker, defender, damage);
    }

    public String desc() {
        return "The spike on each of these darts is designed to pin it to its target while the unstable compounds strapped to its length burst into brilliant flames.";
    }

    public Item random() {
        this.quantity = Random.Int(3, 6);
        return this;
    }

    public int price() {
        return this.quantity * 10;
    }
}
