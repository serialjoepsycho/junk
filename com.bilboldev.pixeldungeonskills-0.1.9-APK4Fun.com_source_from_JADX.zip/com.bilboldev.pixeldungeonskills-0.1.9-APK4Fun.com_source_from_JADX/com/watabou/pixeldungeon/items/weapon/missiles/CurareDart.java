package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Paralysis;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.utils.Random;

public class CurareDart extends MissileWeapon {
    public static final float DURATION = 3.0f;

    public CurareDart() {
        this(1);
    }

    public CurareDart(int number) {
        this.name = "curare dart";
        this.image = ItemSpriteSheet.CURARE_DART;
        this.STR = 14;
        this.MIN = 1;
        this.MAX = 3;
        this.quantity = number;
    }

    public void proc(Char attacker, Char defender, int damage) {
        Buff.prolong(defender, Paralysis.class, DURATION);
        super.proc(attacker, defender, damage);
    }

    public String desc() {
        return "These little evil darts don't do much damage but they can paralyze the target leaving it helpless and motionless for some time.";
    }

    public Item random() {
        this.quantity = Random.Int(2, 5);
        return this;
    }

    public int price() {
        return this.quantity * 12;
    }
}
