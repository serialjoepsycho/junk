package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.items.EquipableItem;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.windows.WndOptions;
import java.util.ArrayList;

public class MissileWeapon extends Weapon {
    private static final String TXT_MISSILES = "Missile weapon";
    private static final String TXT_NO = "No, I changed my mind";
    private static final String TXT_R_U_SURE = "Do you really want to equip it as a melee weapon?";
    private static final String TXT_YES = "Yes, I know what I'm doing";

    /* renamed from: com.watabou.pixeldungeon.items.weapon.missiles.MissileWeapon.1 */
    class C01001 extends WndOptions {
        final /* synthetic */ Hero val$hero;

        C01001(String title, String message, String[] options, Hero hero) {
            this.val$hero = hero;
            super(title, message, options);
        }

        protected void onSelect(int index) {
            if (index == 0) {
                super.doEquip(this.val$hero);
            }
        }
    }

    public MissileWeapon() {
        this.stackable = true;
        this.levelKnown = true;
        this.defaultAction = Item.AC_THROW;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (!(hero.heroClass == HeroClass.HUNTRESS || hero.heroClass == HeroClass.ROGUE)) {
            actions.remove(EquipableItem.AC_EQUIP);
            actions.remove(EquipableItem.AC_UNEQUIP);
        }
        return actions;
    }

    protected void onThrow(int cell) {
        Char enemy = Actor.findChar(cell);
        if (enemy == null || enemy == curUser) {
            super.onThrow(cell);
        } else if (!curUser.shoot(enemy, this)) {
            miss(cell);
        }
    }

    protected void miss(int cell) {
        super.onThrow(cell);
    }

    public void proc(Char attacker, Char defender, int damage) {
        super.proc(attacker, defender, damage);
        Hero hero = (Hero) attacker;
        if (hero.rangedWeapon != null || !this.stackable) {
            return;
        }
        if (this.quantity == 1) {
            doUnequip(hero, false, false);
        } else {
            detach(null);
        }
    }

    public boolean doEquip(Hero hero) {
        GameScene.show(new C01001(TXT_MISSILES, TXT_R_U_SURE, new String[]{TXT_YES, TXT_NO}, hero));
        return false;
    }

    public Item random() {
        return this;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String info() {
        StringBuilder info = new StringBuilder(desc());
        info.append("\n\nAverage damage of this weapon equals to " + (this.MIN + ((this.MAX - this.MIN) / 2)) + " points per hit. ");
        if (Dungeon.hero.belongings.backpack.items.contains(this)) {
            if (this.STR > Dungeon.hero.STR()) {
                info.append("Because of your inadequate strength the accuracy and speed of your attack with this " + this.name + " is decreased.");
            }
            if (this.STR < Dungeon.hero.STR()) {
                info.append("Because of your excess strength the damage of your attack with this " + this.name + " is increased.");
            }
        }
        if (isEquipped(Dungeon.hero)) {
            info.append("\n\nYou hold the " + this.name + " at the ready.");
        }
        return info.toString();
    }
}
