package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.EquipableItem;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class Arrow extends MissileWeapon {
    public Arrow() {
        this(1);
    }

    public Arrow(int number) {
        this.name = "arrow";
        this.image = ItemSpriteSheet.Arrow;
        this.MIN = 3;
        this.MAX = 5;
        this.stackable = true;
        this.quantity = number;
    }

    public String desc() {
        return "Arrows are more powerful and accurate than darts, but they require an equipped bow.";
    }

    public Item random() {
        this.quantity = Random.Int(2, 5);
        return this;
    }

    public int price() {
        return this.quantity * 5;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (Dungeon.hero.belongings.bow == null) {
            actions.remove(Item.AC_THROW);
        } else if (!actions.contains(Item.AC_THROW)) {
            actions.add(Item.AC_THROW);
        }
        actions.remove(EquipableItem.AC_EQUIP);
        return actions;
    }
}
