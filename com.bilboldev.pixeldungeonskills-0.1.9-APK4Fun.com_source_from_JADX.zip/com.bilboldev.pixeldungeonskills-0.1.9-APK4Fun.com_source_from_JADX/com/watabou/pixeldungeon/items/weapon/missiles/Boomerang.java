package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.sprites.MissileSprite;

public class Boomerang extends MissileWeapon {
    private boolean throwEquiped;

    public Boomerang() {
        this.name = "boomerang";
        this.image = ItemSpriteSheet.BOOMERANG;
        this.STR = 10;
        this.MIN = 1;
        this.MAX = 4;
        this.stackable = false;
    }

    public boolean isUpgradable() {
        return true;
    }

    public Item upgrade() {
        return upgrade(false);
    }

    public Item upgrade(boolean enchant) {
        this.MIN++;
        this.MAX += 2;
        super.upgrade(enchant);
        updateQuickslot();
        return this;
    }

    public Item degrade() {
        this.MIN--;
        this.MAX -= 2;
        return super.degrade();
    }

    public int maxDurability(int lvl) {
        return (lvl < 16 ? 16 - lvl : 1) * 7;
    }

    public void proc(Char attacker, Char defender, int damage) {
        super.proc(attacker, defender, damage);
        if ((attacker instanceof Hero) && ((Hero) attacker).rangedWeapon == this) {
            circleBack(defender.pos, (Hero) attacker);
        }
    }

    protected void miss(int cell) {
        circleBack(cell, curUser);
    }

    private void circleBack(int from, Hero owner) {
        ((MissileSprite) curUser.sprite.parent.recycle(MissileSprite.class)).reset(from, curUser.pos, curItem, null);
        if (this.throwEquiped) {
            owner.belongings.weapon = this;
            owner.spend(-1.0f);
        } else if (!collect(curUser.belongings.backpack)) {
            Dungeon.level.drop(this, owner.pos).sprite.drop();
        }
    }

    public void cast(Hero user, int dst) {
        this.throwEquiped = isEquipped(user);
        super.cast(user, dst);
    }

    public String desc() {
        return "Thrown to the enemy this flat curved wooden missile will return to the hands of its thrower.";
    }
}
