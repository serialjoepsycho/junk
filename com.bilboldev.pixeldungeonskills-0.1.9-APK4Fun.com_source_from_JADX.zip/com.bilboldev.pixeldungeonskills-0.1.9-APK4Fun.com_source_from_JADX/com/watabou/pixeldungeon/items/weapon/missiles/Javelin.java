package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Cripple;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.utils.Random;

public class Javelin extends MissileWeapon {
    public Javelin() {
        this(1);
    }

    public Javelin(int number) {
        this.name = "javelin";
        this.image = ItemSpriteSheet.JAVELIN;
        this.STR = 15;
        this.MIN = 2;
        this.MAX = 15;
        this.quantity = number;
    }

    public void proc(Char attacker, Char defender, int damage) {
        super.proc(attacker, defender, damage);
        Buff.prolong(defender, Cripple.class, TomeOfMastery.TIME_TO_READ);
    }

    public String desc() {
        return "This length of metal is weighted to keep the spike at its tip foremost as it sails through the air.";
    }

    public Item random() {
        this.quantity = Random.Int(5, 15);
        return this;
    }

    public int price() {
        return this.quantity * 15;
    }
}
