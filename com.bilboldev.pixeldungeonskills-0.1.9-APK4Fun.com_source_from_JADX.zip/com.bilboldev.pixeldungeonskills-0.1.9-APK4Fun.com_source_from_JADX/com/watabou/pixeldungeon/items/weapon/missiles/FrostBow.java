package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class FrostBow extends Bow {
    public boolean doEquip(Hero hero) {
        if (hero.belongings.bow == null) {
            hero.belongings.bow = this;
            hero.spendAndNext(Key.TIME_TO_UNLOCK);
            detach(hero.belongings.backpack);
            updateQuickslot();
        } else {
            if (hero.belongings.bow.doUnequip(hero, true, false)) {
                doEquip(hero);
            } else {
                collect(hero.belongings.backpack);
            }
            updateQuickslot();
        }
        return true;
    }

    public boolean doUnequip(Hero hero, boolean collect, boolean single) {
        if (collect(hero.belongings.backpack)) {
            hero.belongings.bow = null;
            updateQuickslot();
            return true;
        }
        updateQuickslot();
        return false;
    }

    public FrostBow() {
        this(1);
    }

    public FrostBow(int number) {
        this.name = "frost bow";
        this.image = ItemSpriteSheet.ForstBow;
        this.MIN = 1;
        this.MAX = 1;
        this.stackable = false;
        this.quantity = number;
    }

    public String desc() {
        return "A magically enchanted bow that may freeze targets.";
    }

    public int price() {
        return this.quantity * 25;
    }
}
