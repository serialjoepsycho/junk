package com.watabou.pixeldungeon.items.weapon.missiles;

import com.watabou.pixeldungeon.items.Item;
import com.watabou.utils.Random;

public class Dart extends MissileWeapon {
    public Dart() {
        this(1);
    }

    public Dart(int number) {
        this.name = "dart";
        this.image = 31;
        this.MIN = 1;
        this.MAX = 4;
        this.quantity = number;
    }

    public String desc() {
        return "These simple metal spikes are weighted to fly true and sting their prey with a flick of the wrist.";
    }

    public Item random() {
        this.quantity = Random.Int(5, 15);
        return this;
    }

    public int price() {
        return this.quantity * 2;
    }
}
