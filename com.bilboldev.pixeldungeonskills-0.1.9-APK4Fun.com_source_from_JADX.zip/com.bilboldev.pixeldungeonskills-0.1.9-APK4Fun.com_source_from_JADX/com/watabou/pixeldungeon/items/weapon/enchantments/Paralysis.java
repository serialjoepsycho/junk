package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Paralysis extends Enchantment {
    private static final String TXT_STUNNING = "Stunning %s";
    private static Glowing YELLOW;

    static {
        YELLOW = new Glowing(13412932);
    }

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        int level = Math.max(0, weapon.level);
        if (Random.Int(level + 8) < 7) {
            return false;
        }
        Buff.prolong(defender, com.watabou.pixeldungeon.actors.buffs.Paralysis.class, Random.Float(Key.TIME_TO_UNLOCK, Sleep.SWS + ((float) level)));
        return true;
    }

    public Glowing glowing() {
        return YELLOW;
    }

    public String name(String weaponName) {
        return String.format(TXT_STUNNING, new Object[]{weaponName});
    }
}
