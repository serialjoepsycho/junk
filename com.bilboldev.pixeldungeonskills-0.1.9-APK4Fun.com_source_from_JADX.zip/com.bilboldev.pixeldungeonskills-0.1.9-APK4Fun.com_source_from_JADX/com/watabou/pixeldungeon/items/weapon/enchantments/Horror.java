package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Terror;
import com.watabou.pixeldungeon.actors.buffs.Vertigo;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Horror extends Enchantment {
    private static Glowing GREY = null;
    private static final String TXT_ELDRITCH = "Eldritch %s";

    static {
        GREY = new Glowing(2236962);
    }

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        if (Random.Int(Math.max(0, weapon.level) + 5) < 4) {
            return false;
        }
        if (defender == Dungeon.hero) {
            Buff.affect(defender, Vertigo.class, Vertigo.duration(defender));
        } else {
            ((Terror) Buff.affect(defender, Terror.class, TomeOfMastery.TIME_TO_READ)).object = attacker.id();
        }
        return true;
    }

    public Glowing glowing() {
        return GREY;
    }

    public String name(String weaponName) {
        return String.format(TXT_ELDRITCH, new Object[]{weaponName});
    }
}
