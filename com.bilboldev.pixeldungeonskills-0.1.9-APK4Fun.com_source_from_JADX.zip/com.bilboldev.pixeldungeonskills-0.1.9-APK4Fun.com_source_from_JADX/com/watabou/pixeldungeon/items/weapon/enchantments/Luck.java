package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;

public class Luck extends Enchantment {
    private static Glowing GREEN = null;
    private static final String TXT_LUCKY = "Lucky %s";

    static {
        GREEN = new Glowing(CharSprite.POSITIVE);
    }

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        int level = Math.max(0, weapon.level);
        int dmg = damage;
        for (int i = 1; i <= level + 1; i++) {
            dmg = Math.max(dmg, attacker.damageRoll() - i);
        }
        if (dmg <= damage) {
            return false;
        }
        defender.damage(dmg - damage, this);
        return true;
    }

    public String name(String weaponName) {
        return String.format(TXT_LUCKY, new Object[]{weaponName});
    }

    public Glowing glowing() {
        return GREEN;
    }
}
