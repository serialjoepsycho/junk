package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;

public class Instability extends Enchantment {
    private static final String TXT_UNSTABLE = "Unstable %s";

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        return Enchantment.random().proc(weapon, attacker, defender, damage);
    }

    public String name(String weaponName) {
        return String.format(TXT_UNSTABLE, new Object[]{weaponName});
    }
}
