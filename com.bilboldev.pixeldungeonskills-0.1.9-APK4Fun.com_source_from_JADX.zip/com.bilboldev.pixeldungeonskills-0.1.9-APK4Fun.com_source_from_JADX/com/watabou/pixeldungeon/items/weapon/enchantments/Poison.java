package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Poison extends Enchantment {
    private static Glowing PURPLE = null;
    private static final String TXT_VENOMOUS = "Venomous %s";

    static {
        PURPLE = new Glowing(4456618);
    }

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        int level = Math.max(0, weapon.level);
        if (Random.Int(level + 3) < 2) {
            return false;
        }
        ((com.watabou.pixeldungeon.actors.buffs.Poison) Buff.affect(defender, com.watabou.pixeldungeon.actors.buffs.Poison.class)).set(com.watabou.pixeldungeon.actors.buffs.Poison.durationFactor(defender) * ((float) (level + 1)));
        return true;
    }

    public Glowing glowing() {
        return PURPLE;
    }

    public String name(String weaponName) {
        return String.format(TXT_VENOMOUS, new Object[]{weaponName});
    }
}
