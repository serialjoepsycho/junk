package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.effects.Lightning;
import com.watabou.pixeldungeon.effects.particles.SparkParticle;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.traps.LightningTrap;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

public class Shock extends Enchantment {
    private static final String TXT_SHOCKING = "Shocking %s";
    private ArrayList<Char> affected;
    private int nPoints;
    private int[] points;

    public Shock() {
        this.affected = new ArrayList();
        this.points = new int[20];
    }

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        if (Random.Int(Math.max(0, weapon.level) + 4) < 3) {
            return false;
        }
        this.points[0] = attacker.pos;
        this.nPoints = 1;
        this.affected.clear();
        this.affected.add(attacker);
        hit(defender, Random.Int(1, damage / 2));
        attacker.sprite.parent.add(new Lightning(this.points, this.nPoints, null));
        return true;
    }

    public String name(String weaponName) {
        return String.format(TXT_SHOCKING, new Object[]{weaponName});
    }

    private void hit(Char ch, int damage) {
        if (damage >= 1) {
            int i;
            this.affected.add(ch);
            if (!Level.water[ch.pos] || ch.flying) {
                i = damage;
            } else {
                i = damage * 2;
            }
            ch.damage(i, LightningTrap.LIGHTNING);
            ch.sprite.centerEmitter().burst(SparkParticle.FACTORY, 3);
            ch.sprite.flash();
            int[] iArr = this.points;
            int i2 = this.nPoints;
            this.nPoints = i2 + 1;
            iArr[i2] = ch.pos;
            Collection ns = new HashSet();
            for (int i22 : Level.NEIGHBOURS8) {
                Char n = Actor.findChar(ch.pos + i22);
                if (!(n == null || this.affected.contains(n))) {
                    ns.add(n);
                }
            }
            if (ns.size() > 0) {
                hit((Char) Random.element(ns), Random.Int(damage / 2, damage));
            }
        }
    }
}
