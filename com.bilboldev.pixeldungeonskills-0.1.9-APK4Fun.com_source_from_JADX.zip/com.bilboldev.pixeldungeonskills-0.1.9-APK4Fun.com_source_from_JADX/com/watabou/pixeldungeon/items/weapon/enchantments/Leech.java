package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Leech extends Enchantment {
    private static Glowing RED = null;
    private static final String TXT_VAMPIRIC = "Vampiric %s";

    static {
        RED = new Glowing(6684706);
    }

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        int level = Math.max(0, weapon.level);
        int effValue = Math.min(Random.IntRange(0, ((level + 2) * damage) / (level + 6)), attacker.HT - attacker.HP);
        if (effValue <= 0) {
            return false;
        }
        attacker.HP += effValue;
        attacker.sprite.emitter().start(Speck.factory(0), 0.4f, 1);
        attacker.sprite.showStatus(CharSprite.POSITIVE, Integer.toString(effValue), new Object[0]);
        return true;
    }

    public Glowing glowing() {
        return RED;
    }

    public String name(String weaponName) {
        return String.format(TXT_VAMPIRIC, new Object[]{weaponName});
    }
}
