package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;

public class Tempering extends Enchantment {
    private static Glowing GRAY = null;
    private static final String TXT_TEMPERED = "Tempered %s";

    static {
        GRAY = new Glowing(13404296);
    }

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        weapon.polish();
        return true;
    }

    public Glowing glowing() {
        return GRAY;
    }

    public String name(String weaponName) {
        return String.format(TXT_TEMPERED, new Object[]{weaponName});
    }
}
