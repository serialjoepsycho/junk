package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Burning;
import com.watabou.pixeldungeon.effects.particles.FlameParticle;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Fire extends Enchantment {
    private static Glowing ORANGE = null;
    private static final String TXT_BLAZING = "Blazing %s";

    static {
        ORANGE = new Glowing(16729088);
    }

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        int level = Math.max(0, weapon.level);
        if (Random.Int(level + 3) < 2) {
            return false;
        }
        if (Random.Int(2) == 0) {
            ((Burning) Buff.affect(defender, Burning.class)).reignite(defender);
        }
        defender.damage(Random.Int(1, level + 2), this);
        defender.sprite.emitter().burst(FlameParticle.FACTORY, level + 1);
        return true;
    }

    public Glowing glowing() {
        return ORANGE;
    }

    public String name(String weaponName) {
        return String.format(TXT_BLAZING, new Object[]{weaponName});
    }
}
