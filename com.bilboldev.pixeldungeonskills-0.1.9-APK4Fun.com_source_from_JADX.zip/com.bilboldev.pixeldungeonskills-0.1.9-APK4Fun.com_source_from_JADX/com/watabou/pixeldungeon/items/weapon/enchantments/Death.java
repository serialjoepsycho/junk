package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.particles.ShadowParticle;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Death extends Enchantment {
    private static Glowing BLACK = null;
    private static final String TXT_GRIM = "Grim %s";

    static {
        BLACK = new Glowing(0);
    }

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        if (Random.Int(Math.max(0, weapon.level) + 100) < 92) {
            return false;
        }
        defender.damage(defender.HP, this);
        defender.sprite.emitter().burst(ShadowParticle.UP, 5);
        if (!defender.isAlive() && (attacker instanceof Hero)) {
            Badges.validateGrimWeapon();
        }
        return true;
    }

    public Glowing glowing() {
        return BLACK;
    }

    public String name(String weaponName) {
        return String.format(TXT_GRIM, new Object[]{weaponName});
    }
}
