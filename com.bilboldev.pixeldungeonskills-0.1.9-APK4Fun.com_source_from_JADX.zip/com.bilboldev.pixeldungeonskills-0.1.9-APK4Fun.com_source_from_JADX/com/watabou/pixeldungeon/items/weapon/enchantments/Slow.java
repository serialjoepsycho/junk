package com.watabou.pixeldungeon.items.weapon.enchantments;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Enchantment;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Slow extends Enchantment {
    private static Glowing BLUE = null;
    private static final String TXT_CHILLING = "Chilling %s";

    static {
        BLUE = new Glowing(17663);
    }

    public boolean proc(Weapon weapon, Char attacker, Char defender, int damage) {
        int level = Math.max(0, weapon.level);
        if (Random.Int(level + 4) < 3) {
            return false;
        }
        Buff.prolong(defender, com.watabou.pixeldungeon.actors.buffs.Slow.class, Random.Float(Key.TIME_TO_UNLOCK, Sleep.SWS + ((float) level)));
        return true;
    }

    public Glowing glowing() {
        return BLUE;
    }

    public String name(String weaponName) {
        return String.format(TXT_CHILLING, new Object[]{weaponName});
    }
}
