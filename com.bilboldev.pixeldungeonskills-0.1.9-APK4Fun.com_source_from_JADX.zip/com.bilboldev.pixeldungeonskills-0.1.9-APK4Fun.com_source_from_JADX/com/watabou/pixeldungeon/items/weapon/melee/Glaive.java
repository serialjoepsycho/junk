package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.items.keys.Key;

public class Glaive extends MeleeWeapon {
    public Glaive() {
        super(5, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK);
        this.name = "glaive";
        this.image = 30;
    }

    public String desc() {
        return "A polearm consisting of a sword blade on the end of a pole.";
    }
}
