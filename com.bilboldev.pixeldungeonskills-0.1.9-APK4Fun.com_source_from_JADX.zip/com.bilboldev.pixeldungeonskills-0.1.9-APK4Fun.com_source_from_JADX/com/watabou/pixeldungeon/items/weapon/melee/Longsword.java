package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.items.keys.Key;

public class Longsword extends MeleeWeapon {
    public Longsword() {
        super(4, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK);
        this.name = "longsword";
        this.image = 21;
    }

    public String desc() {
        return "This towering blade inflicts heavy damage by investing its heft into every cut.";
    }
}
