package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class DualSwords extends MeleeWeapon {
    public DualSwords() {
        super(1, 0.6f, Key.TIME_TO_UNLOCK);
        this.name = "dualswords";
        this.image = ItemSpriteSheet.DualSwords;
    }

    public String desc() {
        return "Two razor sharp blades for more damage.";
    }
}
