package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.items.keys.Key;

public class BattleAxe extends MeleeWeapon {
    public BattleAxe() {
        super(4, 1.2f, Key.TIME_TO_UNLOCK);
        this.name = "battle axe";
        this.image = 22;
    }

    public String desc() {
        return "The enormous steel head of this battle axe puts considerable heft behind each stroke.";
    }
}
