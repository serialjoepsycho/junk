package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.items.keys.Key;

public class Quarterstaff extends MeleeWeapon {
    public Quarterstaff() {
        super(2, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK);
        this.name = "quarterstaff";
        this.image = 17;
    }

    public String desc() {
        return "A staff of hardwood, its ends are shod with iron.";
    }
}
