package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.items.keys.Key;

public class Dagger extends MeleeWeapon {
    public Dagger() {
        super(1, 1.2f, Key.TIME_TO_UNLOCK);
        this.name = "dagger";
        this.image = 19;
    }

    public String desc() {
        return "A simple iron dagger with a well worn wooden handle.";
    }
}
