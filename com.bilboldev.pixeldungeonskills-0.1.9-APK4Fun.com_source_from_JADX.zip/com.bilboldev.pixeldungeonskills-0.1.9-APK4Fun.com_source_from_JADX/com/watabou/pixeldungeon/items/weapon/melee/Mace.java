package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.items.keys.Key;

public class Mace extends MeleeWeapon {
    public Mace() {
        super(3, Key.TIME_TO_UNLOCK, 0.8f);
        this.name = "mace";
        this.image = 18;
    }

    public String desc() {
        return "The iron head of this weapon inflicts substantial damage.";
    }
}
