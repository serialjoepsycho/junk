package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Imbue;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Random;

public class MeleeWeapon extends Weapon {
    private int tier;

    /* renamed from: com.watabou.pixeldungeon.items.weapon.melee.MeleeWeapon.1 */
    static /* synthetic */ class C00981 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$items$weapon$Weapon$Imbue;

        static {
            $SwitchMap$com$watabou$pixeldungeon$items$weapon$Weapon$Imbue = new int[Imbue.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$weapon$Weapon$Imbue[Imbue.SPEED.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$weapon$Weapon$Imbue[Imbue.ACCURACY.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$weapon$Weapon$Imbue[Imbue.NONE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    public MeleeWeapon(int tier, float acu, float dly) {
        this.tier = tier;
        this.ACU = acu;
        this.DLY = dly;
        this.STR = typicalSTR();
        this.MIN = min();
        this.MAX = max();
    }

    private int min() {
        return this.tier;
    }

    private int max() {
        return (int) ((((float) (((this.tier * this.tier) - this.tier) + 10)) / this.ACU) * this.DLY);
    }

    public final Item upgrade() {
        return upgrade(false);
    }

    public Item upgrade(boolean enchant) {
        this.STR--;
        this.MIN++;
        this.MAX += this.tier;
        return super.upgrade(enchant);
    }

    public Item safeUpgrade() {
        return upgrade(this.enchantment != null);
    }

    public Item degrade() {
        this.STR++;
        this.MIN--;
        this.MAX -= this.tier;
        return super.degrade();
    }

    public int typicalSTR() {
        return (this.tier * 2) + 8;
    }

    public String info() {
        Object obj = 1;
        String p = "\n\n";
        StringBuilder info = new StringBuilder(desc());
        String quality = (!this.levelKnown || this.level == 0) ? BuildConfig.VERSION_NAME : this.level > 0 ? "upgraded" : "degraded";
        info.append("\n\n");
        info.append("This " + this.name + " is " + Utils.indefinite(quality));
        info.append(" tier-" + this.tier + " melee weapon. ");
        if (this.levelKnown) {
            info.append("Its average damage is " + (this.MIN + ((this.MAX - this.MIN) / 2)) + " points per hit. ");
        } else {
            info.append("Its typical average damage is " + (min() + ((max() - min()) / 2)) + " points per hit " + "and usually it requires " + typicalSTR() + " points of strength. ");
            if (typicalSTR() > Dungeon.hero.STR()) {
                info.append("Probably this weapon is too heavy for you. ");
            }
        }
        if (this.DLY != Key.TIME_TO_UNLOCK) {
            info.append("This is a rather " + (this.DLY < Key.TIME_TO_UNLOCK ? "fast" : "slow"));
            if (this.ACU != Key.TIME_TO_UNLOCK) {
                Object obj2;
                if (this.ACU > Key.TIME_TO_UNLOCK) {
                    obj2 = 1;
                } else {
                    obj2 = null;
                }
                if (this.DLY >= Key.TIME_TO_UNLOCK) {
                    obj = null;
                }
                if (obj2 == obj) {
                    info.append(" and ");
                } else {
                    info.append(" but ");
                }
                info.append(this.ACU > Key.TIME_TO_UNLOCK ? "accurate" : "inaccurate");
            }
            info.append(" weapon. ");
        } else if (this.ACU != Key.TIME_TO_UNLOCK) {
            info.append("This is a rather " + (this.ACU > Key.TIME_TO_UNLOCK ? "accurate" : "inaccurate") + " weapon. ");
        }
        switch (C00981.$SwitchMap$com$watabou$pixeldungeon$items$weapon$Weapon$Imbue[this.imbue.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                info.append("It was balanced to make it faster. ");
                break;
            case WndUpdates.ID_CAVES /*2*/:
                info.append("It was balanced to make it more accurate. ");
                break;
        }
        if (this.enchantment != null) {
            info.append("It is enchanted.");
        }
        if (this.levelKnown && Dungeon.hero.belongings.backpack.items.contains(this)) {
            if (this.STR > Dungeon.hero.STR()) {
                info.append("\n\n");
                info.append("Because of your inadequate strength the accuracy and speed of your attack with this " + this.name + " is decreased.");
            }
            if (this.STR < Dungeon.hero.STR()) {
                info.append("\n\n");
                info.append("Because of your excess strength the damage of your attack with this " + this.name + " is increased.");
            }
        }
        if (isEquipped(Dungeon.hero)) {
            info.append("\n\n");
            info.append("You hold the " + this.name + " at the ready" + (this.cursed ? ", and because it is cursed, you are powerless to let go." : "."));
        } else if (this.cursedKnown && this.cursed) {
            info.append("\n\n");
            info.append("You can feel a malevolent magic lurking within " + this.name + ".");
        }
        return info.toString();
    }

    public int price() {
        int price = (1 << (this.tier - 1)) * 20;
        if (this.enchantment != null) {
            price = (int) (((double) price) * 1.5d);
        }
        if (this.cursed && this.cursedKnown) {
            price /= 2;
        }
        if (this.levelKnown) {
            if (this.level > 0) {
                price *= this.level + 1;
            } else if (this.level < 0) {
                price /= 1 - this.level;
            }
        }
        if (price < 1) {
            return 1;
        }
        return price;
    }

    public Item random() {
        super.random();
        if (Random.Int(this.level + 10) == 0) {
            enchant();
        }
        return this;
    }
}
