package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.items.keys.Key;

public class WarHammer extends MeleeWeapon {
    public WarHammer() {
        super(5, 1.2f, Key.TIME_TO_UNLOCK);
        this.name = "war hammer";
        this.image = 23;
    }

    public String desc() {
        return "Few creatures can withstand the crushing blow of this towering mass of lead and steel, but only the strongest of adventurers can use it effectively.";
    }
}
