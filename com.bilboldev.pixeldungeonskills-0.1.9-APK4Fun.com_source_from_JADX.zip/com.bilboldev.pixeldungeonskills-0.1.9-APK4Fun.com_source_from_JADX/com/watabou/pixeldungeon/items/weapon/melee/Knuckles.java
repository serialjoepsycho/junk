package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.items.keys.Key;

public class Knuckles extends MeleeWeapon {
    public Knuckles() {
        super(1, Key.TIME_TO_UNLOCK, 0.5f);
        this.name = "knuckleduster";
        this.image = 16;
    }

    public String desc() {
        return "A piece of iron shaped to fit around the knuckles.";
    }
}
