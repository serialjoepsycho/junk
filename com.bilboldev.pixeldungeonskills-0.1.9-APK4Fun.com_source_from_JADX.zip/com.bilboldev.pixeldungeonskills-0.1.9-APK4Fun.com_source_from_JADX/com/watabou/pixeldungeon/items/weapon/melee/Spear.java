package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.items.keys.Key;

public class Spear extends MeleeWeapon {
    public Spear() {
        super(2, Key.TIME_TO_UNLOCK, Sleep.SWS);
        this.name = "spear";
        this.image = 29;
    }

    public String desc() {
        return "A slender wooden rod tipped with sharpened iron.";
    }
}
