package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.noosa.tweeners.AlphaTweener;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.actors.mobs.npcs.Skeleton;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Pushing;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.particles.ShadowParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Collection;

public class NecroBlade extends MeleeWeapon {
    public int charge;

    public NecroBlade() {
        super(1, 0.7f, Key.TIME_TO_UNLOCK);
        this.name = "necroblade";
        this.image = ItemSpriteSheet.NecroBlade0;
        this.charge = 0;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (this.charge > 25) {
            actions.add("Heal");
        }
        if (this.charge > 55) {
            actions.add("Summon");
        }
        if (this.charge == 100) {
            actions.add("Consume");
        }
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action.equals("Heal")) {
            hero.HP = (int) (((double) hero.HP) + (((double) hero.HT) * 0.15d));
            if (hero.HP > hero.HT) {
                hero.HP = hero.HT;
            }
            GLog.m3p("NecroBlade heals " + ((int) (((double) hero.HT) * 0.15d)) + " HP", new Object[0]);
            updateCharge(-25);
            CellEmitter.center(hero.pos).burst(Speck.factory(0), 1);
            return;
        }
        if (action.equals("Summon")) {
            int newPos = hero.pos;
            if (Actor.findChar(newPos) != null) {
                Collection candidates = new ArrayList();
                boolean[] passable = Level.passable;
                for (int n : Level.NEIGHBOURS4) {
                    int c = hero.pos + n;
                    if (passable[c] && Actor.findChar(c) == null) {
                        candidates.add(Integer.valueOf(c));
                    }
                }
                newPos = candidates.size() > 0 ? ((Integer) Random.element(candidates)).intValue() : -1;
            }
            if (newPos != -1) {
                updateCharge(-55);
                Mob skel = new Skeleton();
                if ((this.level > 1 ? this.level + 1 : 1) > 7) {
                    skel.spawn(7);
                    skel.HP = skel.HT;
                    skel.pos = newPos;
                    GameScene.add(skel);
                    Actor.addDelayed(new Pushing(skel, hero.pos, newPos), -1.0f);
                    skel.sprite.alpha(0.0f);
                    skel.sprite.parent.add(new AlphaTweener(skel.sprite, Key.TIME_TO_UNLOCK, 0.15f));
                    CellEmitter.center(newPos).burst(ShadowParticle.UP, Random.IntRange(3, 5));
                    GLog.m3p("NecroBlade summoned a skeleton", new Object[0]);
                } else {
                    skel.spawn(7);
                    skel.HP = skel.HT;
                    skel.pos = newPos;
                    GameScene.add(skel);
                    Actor.addDelayed(new Pushing(skel, hero.pos, newPos), -1.0f);
                    skel.sprite.alpha(0.0f);
                    skel.sprite.parent.add(new AlphaTweener(skel.sprite, Key.TIME_TO_UNLOCK, 0.15f));
                    CellEmitter.center(newPos).burst(ShadowParticle.UP, Random.IntRange(3, 5));
                    GLog.m3p("NecroBlade summoned a skeleton", new Object[0]);
                }
                return;
            }
            GLog.m1i("No place to summon", new Object[0]);
            return;
        }
        if (action.equals("Consume")) {
            updateCharge(-100);
            upgrade(1);
            GLog.m3p("NecroBlade consumed the souls within. It looks much better now.", new Object[0]);
            return;
        }
        super.execute(hero, action);
    }

    public void updateCharge(int change) {
        this.charge += change;
        if (this.charge > 100) {
            this.charge = 100;
        }
        if (this.charge < 0) {
            this.charge = 0;
        }
        switch ((int) Math.floor((double) (this.charge / 20))) {
            case WndUpdates.ID_SEWERS /*0*/:
                this.image = ItemSpriteSheet.NecroBlade0;
            case WndUpdates.ID_PRISON /*1*/:
                this.image = ItemSpriteSheet.NecroBlade1;
            case WndUpdates.ID_CAVES /*2*/:
                this.image = ItemSpriteSheet.NecroBlade2;
            case WndUpdates.ID_METROPOLIS /*3*/:
                this.image = ItemSpriteSheet.NecroBlade3;
            case WndUpdates.ID_HALLS /*4*/:
                this.image = ItemSpriteSheet.NecroBlade4;
            case BuffIndicator.HUNGER /*5*/:
                this.image = ItemSpriteSheet.NecroBlade5;
            default:
        }
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.charge = bundle.getInt("CHARGE");
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put("CHARGE", this.charge);
    }

    public String desc() {
        return "A blade forged from dark magic. NecroBlades consume the souls of those who perish by them. The more they consume, the stronger they become.\nNecroBlade energy at " + this.charge + "/100";
    }
}
