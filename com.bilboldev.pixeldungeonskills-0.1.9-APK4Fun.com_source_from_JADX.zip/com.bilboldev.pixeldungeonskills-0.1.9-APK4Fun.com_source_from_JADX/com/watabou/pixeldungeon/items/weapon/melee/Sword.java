package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.pixeldungeon.items.keys.Key;

public class Sword extends MeleeWeapon {
    public Sword() {
        super(3, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK);
        this.name = "sword";
        this.image = 20;
    }

    public String desc() {
        return "The razor-sharp length of steel blade shines reassuringly.";
    }
}
