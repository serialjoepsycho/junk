package com.watabou.pixeldungeon.items.weapon.melee;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfUpgrade;
import com.watabou.pixeldungeon.items.weapon.missiles.Boomerang;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndBag.Listener;
import com.watabou.pixeldungeon.windows.WndBag.Mode;
import java.util.ArrayList;

public class ShortSword extends MeleeWeapon {
    public static final String AC_REFORGE = "REFORGE";
    private static final float TIME_TO_REFORGE = 2.0f;
    private static final String TXT_NOT_BOOMERANG = "you can't upgrade a boomerang this way";
    private static final String TXT_REFORGED = "you reforged the short sword to upgrade your %s";
    private static final String TXT_SELECT_WEAPON = "Select a weapon to upgrade";
    private boolean equipped;
    private final Listener itemSelector;

    /* renamed from: com.watabou.pixeldungeon.items.weapon.melee.ShortSword.1 */
    class C00991 implements Listener {
        C00991() {
        }

        public void onSelect(Item item) {
            if (item == null || (item instanceof Boomerang)) {
                if (item instanceof Boomerang) {
                    GLog.m4w(ShortSword.TXT_NOT_BOOMERANG, new Object[0]);
                }
                if (ShortSword.this.equipped) {
                    ShortSword.curUser.belongings.weapon = ShortSword.this;
                    return;
                }
                ShortSword.this.collect(ShortSword.curUser.belongings.backpack);
                return;
            }
            Sample.INSTANCE.play(Assets.SND_EVOKE);
            ScrollOfUpgrade.upgrade(ShortSword.curUser);
            Item.evoke(ShortSword.curUser);
            GLog.m4w(ShortSword.TXT_REFORGED, item.name());
            ((MeleeWeapon) item).safeUpgrade();
            ShortSword.curUser.spendAndNext(ShortSword.TIME_TO_REFORGE);
            Badges.validateItemLevelAquired(item);
        }
    }

    public ShortSword() {
        super(1, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK);
        this.name = "short sword";
        this.image = 2;
        this.itemSelector = new C00991();
        this.STR = 11;
        this.MAX = 12;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (this.level > 0) {
            actions.add(AC_REFORGE);
        }
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action == AC_REFORGE) {
            if (hero.belongings.weapon == this) {
                this.equipped = true;
                hero.belongings.weapon = null;
            } else {
                this.equipped = false;
                detach(hero.belongings.backpack);
            }
            curUser = hero;
            GameScene.selectItem(this.itemSelector, Mode.WEAPON, TXT_SELECT_WEAPON);
            return;
        }
        super.execute(hero, action);
    }

    public String desc() {
        return "It is indeed quite short, just a few inches longer, than a dagger.";
    }
}
