package com.watabou.pixeldungeon.items.weapon;

import com.watabou.noosa.Camera;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.actors.buffs.Weakness;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.KindOfWeapon;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.weapon.enchantments.Death;
import com.watabou.pixeldungeon.items.weapon.enchantments.Fire;
import com.watabou.pixeldungeon.items.weapon.enchantments.Horror;
import com.watabou.pixeldungeon.items.weapon.enchantments.Instability;
import com.watabou.pixeldungeon.items.weapon.enchantments.Leech;
import com.watabou.pixeldungeon.items.weapon.enchantments.Luck;
import com.watabou.pixeldungeon.items.weapon.enchantments.Paralysis;
import com.watabou.pixeldungeon.items.weapon.enchantments.Poison;
import com.watabou.pixeldungeon.items.weapon.enchantments.Shock;
import com.watabou.pixeldungeon.items.weapon.enchantments.Slow;
import com.watabou.pixeldungeon.items.weapon.enchantments.Tempering;
import com.watabou.pixeldungeon.items.weapon.missiles.Arrow;
import com.watabou.pixeldungeon.items.weapon.missiles.BombArrow;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.items.weapon.missiles.MissileWeapon;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;

public class Weapon extends KindOfWeapon {
    private static final String ENCHANTMENT = "enchantment";
    private static final int HITS_TO_KNOW = 20;
    private static final String IMBUE = "imbue";
    private static final String TXT_IDENTIFY = "You are now familiar enough with your %s to identify it. It is %s.";
    private static final String TXT_INCOMPATIBLE = "Interaction of different types of magic has negated the enchantment on this weapon!";
    private static final String TXT_TO_STRING = "%s :%d";
    private static final String UNFAMILIRIARITY = "unfamiliarity";
    public float ACU;
    public float DLY;
    public int STR;
    protected Enchantment enchantment;
    private int hitsToKnow;
    public Imbue imbue;

    /* renamed from: com.watabou.pixeldungeon.items.weapon.Weapon.1 */
    static /* synthetic */ class C00971 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass;

        static {
            $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass = new int[HeroClass.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.WARRIOR.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.HUNTRESS.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
        }
    }

    public static abstract class Enchantment implements Bundlable {
        private static final float[] chances;
        private static final Class<?>[] enchants;

        public abstract boolean proc(Weapon weapon, Char charR, Char charR2, int i);

        static {
            enchants = new Class[]{Fire.class, Poison.class, Death.class, Paralysis.class, Leech.class, Slow.class, Shock.class, Instability.class, Horror.class, Luck.class, Tempering.class};
            chances = new float[]{TomeOfMastery.TIME_TO_READ, TomeOfMastery.TIME_TO_READ, Key.TIME_TO_UNLOCK, Pickaxe.TIME_TO_MINE, Key.TIME_TO_UNLOCK, Pickaxe.TIME_TO_MINE, 6.0f, CurareDart.DURATION, Pickaxe.TIME_TO_MINE, Pickaxe.TIME_TO_MINE, CurareDart.DURATION};
        }

        public String name(String weaponName) {
            return weaponName;
        }

        public void restoreFromBundle(Bundle bundle) {
        }

        public void storeInBundle(Bundle bundle) {
        }

        public Glowing glowing() {
            return Glowing.WHITE;
        }

        public static Enchantment random() {
            try {
                return (Enchantment) enchants[Random.chances(chances)].newInstance();
            } catch (Exception e) {
                return null;
            }
        }
    }

    public enum Imbue {
        NONE,
        SPEED,
        ACCURACY
    }

    public Weapon() {
        this.STR = 10;
        this.ACU = Key.TIME_TO_UNLOCK;
        this.DLY = Key.TIME_TO_UNLOCK;
        this.imbue = Imbue.NONE;
        this.hitsToKnow = HITS_TO_KNOW;
    }

    public void proc(Char attacker, Char defender, int damage) {
        if (this.enchantment != null) {
            this.enchantment.proc(this, attacker, defender, damage);
        }
        if (!this.levelKnown) {
            int i = this.hitsToKnow - 1;
            this.hitsToKnow = i;
            if (i <= 0) {
                this.levelKnown = true;
                GLog.m1i(TXT_IDENTIFY, name(), toString());
                Badges.validateItemLevelAquired(this);
            }
        }
        use();
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(UNFAMILIRIARITY, this.hitsToKnow);
        bundle.put(ENCHANTMENT, this.enchantment);
        bundle.put(IMBUE, this.imbue);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        int i = bundle.getInt(UNFAMILIRIARITY);
        this.hitsToKnow = i;
        if (i == 0) {
            this.hitsToKnow = HITS_TO_KNOW;
        }
        this.enchantment = (Enchantment) bundle.get(ENCHANTMENT);
        this.imbue = (Imbue) bundle.getEnum(IMBUE, Imbue.class);
    }

    public float acuracyFactor(Hero hero) {
        float pow;
        float f;
        int encumbrance = this.STR - hero.STR();
        if (this instanceof MissileWeapon) {
            switch (C00971.$SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[hero.heroClass.ordinal()]) {
                case WndUpdates.ID_PRISON /*1*/:
                    encumbrance += 3;
                    break;
                case WndUpdates.ID_CAVES /*2*/:
                    encumbrance -= 2;
                    break;
            }
            if (Dungeon.hero.belongings.bow != null && ((this instanceof Arrow) || (this instanceof BombArrow))) {
                encumbrance -= 5;
            }
            if (Dungeon.hero.belongings.bow != null && (((this instanceof Arrow) || (this instanceof BombArrow)) && hero.heroClass == HeroClass.HUNTRESS)) {
                encumbrance -= 3;
            }
        }
        if (encumbrance > 0) {
            pow = (float) (((double) this.ACU) / Math.pow(1.5d, (double) encumbrance));
        } else {
            pow = this.ACU;
        }
        if (this.imbue == Imbue.ACCURACY) {
            f = Sleep.SWS;
        } else {
            f = Key.TIME_TO_UNLOCK;
        }
        return pow * f;
    }

    public float speedFactor(Hero hero) {
        int encumrance = this.STR - hero.STR();
        if ((this instanceof MissileWeapon) && hero.heroClass == HeroClass.HUNTRESS) {
            encumrance -= 2;
        }
        return (encumrance > 0 ? (float) (((double) this.DLY) * Math.pow(1.2d, (double) encumrance)) : this.DLY) * (this.imbue == Imbue.SPEED ? 0.6f : Key.TIME_TO_UNLOCK);
    }

    public int damageRoll(Hero hero) {
        int damage = super.damageRoll(hero);
        if (hero.heroClass == HeroClass.WARRIOR && hero.rangedWeapon == null) {
            damage += Random.Int(hero.skillMelee);
            if (hero.skillFirstActive && !hero.skillSecondActive) {
                damage += hero.skillStr + 3;
                hero.skillFirstActive = false;
                GLog.m3p("Smash used", new Object[0]);
                hero.sprite.showStatus(CharSprite.NEUTRAL, "Smash!", new Object[0]);
                Camera.main.shake(CurareDart.DURATION, 0.15f);
            }
            if (hero.skillSecondActive) {
                damage = (int) (((double) damage) + (6.0d + (((double) hero.skillStr) * 1.2d)));
                hero.skillFirstActive = false;
                hero.skillSecondActive = false;
                GLog.m2n("Smite used.... you feel weak", new Object[0]);
                hero.sprite.showStatus(CharSprite.NEUTRAL, "Smite!", new Object[0]);
                hero.sprite.showStatus(CharSprite.NEGATIVE, "I don't feel so good...", new Object[0]);
                Buff.affect(hero, Weakness.class, TomeOfMastery.TIME_TO_READ);
                Camera.main.shake(CurareDart.DURATION, 0.3f);
            }
        }
        if ((hero.rangedWeapon != null ? 1 : null) != (hero.heroClass == HeroClass.HUNTRESS ? 1 : null)) {
            return damage;
        }
        int exStr = hero.STR() - this.STR;
        if (exStr > 0) {
            damage += Random.IntRange(0, exStr);
        }
        return damage + Random.Int(hero.skillRanged);
    }

    public Item upgrade(boolean enchant) {
        if (this.enchantment != null) {
            if (!enchant && Random.Int(this.level) > 0) {
                GLog.m4w(TXT_INCOMPATIBLE, new Object[0]);
                enchant(null);
            }
        } else if (enchant) {
            enchant();
        }
        return super.upgrade();
    }

    public int maxDurability(int lvl) {
        return (lvl < 16 ? 16 - lvl : 1) * 4;
    }

    public String toString() {
        if (!this.levelKnown) {
            return super.toString();
        }
        return Utils.format(TXT_TO_STRING, super.toString(), Integer.valueOf(this.STR));
    }

    public String name() {
        return this.enchantment == null ? super.name() : this.enchantment.name(super.name());
    }

    public Item random() {
        if (((double) Random.Float()) < 0.4d) {
            int n = 1;
            if (Random.Int(3) == 0) {
                n = 1 + 1;
                if (Random.Int(3) == 0) {
                    n++;
                }
            }
            if (Random.Int(2) == 0) {
                upgrade(n);
            } else {
                degrade(n);
                this.cursed = true;
            }
        }
        return this;
    }

    public Weapon enchant(Enchantment ench) {
        this.enchantment = ench;
        return this;
    }

    public Weapon enchant() {
        Class<? extends Enchantment> oldEnchantment = this.enchantment != null ? this.enchantment.getClass() : null;
        Enchantment ench = Enchantment.random();
        while (ench.getClass() == oldEnchantment) {
            ench = Enchantment.random();
        }
        return enchant(ench);
    }

    public boolean isEnchanted() {
        return this.enchantment != null;
    }

    public Glowing glowing() {
        return this.enchantment != null ? this.enchantment.glowing() : null;
    }
}
