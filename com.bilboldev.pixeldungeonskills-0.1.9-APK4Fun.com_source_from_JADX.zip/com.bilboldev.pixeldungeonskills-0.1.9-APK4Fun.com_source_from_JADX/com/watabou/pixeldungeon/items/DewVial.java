package com.watabou.pixeldungeon.items;

import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.particles.Emitter;
import com.watabou.noosa.particles.Emitter.Factory;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.particles.ShaftParticle;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Bundle;
import java.util.ArrayList;

public class DewVial extends Item {
    private static final String AC_DRINK = "DRINK";
    private static final int MAX_VOLUME = 10;
    private static final double NUM = 20.0d;
    private static final double POW;
    private static final float TIME_TO_DRINK = 1.0f;
    private static final String TXT_AUTO_DRINK = "The dew vial was emptied to heal your wounds.";
    private static final String TXT_COLLECTED = "You collected a dewdrop into your dew vial.";
    private static final String TXT_EMPTY = "Your dew vial is empty!";
    private static final String TXT_FULL = "Your dew vial is full!";
    private static final String TXT_STATUS = "%d/%d";
    private static final String TXT_VALUE = "%+dHP";
    private static final String VOLUME = "volume";
    private static final Glowing WHITE;
    private int volume;

    public DewVial() {
        this.name = "dew vial";
        this.image = ItemSpriteSheet.VIAL;
        this.defaultAction = AC_DRINK;
        this.unique = true;
        this.volume = 0;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(VOLUME, this.volume);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.volume = bundle.getInt(VOLUME);
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (this.volume > 0) {
            actions.add(AC_DRINK);
        }
        return actions;
    }

    static {
        POW = Math.log10(NUM);
        WHITE = new Glowing(16777164);
    }

    public void execute(Hero hero, String action) {
        if (!action.equals(AC_DRINK)) {
            super.execute(hero, action);
        } else if (this.volume > 0) {
            int effect = Math.min(hero.HT - hero.HP, (int) Math.ceil((Math.pow((double) this.volume, POW) / NUM) * ((double) hero.HT)));
            if (effect > 0) {
                int i;
                hero.HP += effect;
                Emitter emitter = hero.sprite.emitter();
                Factory factory = Speck.factory(0);
                if (this.volume > 5) {
                    i = 2;
                } else {
                    i = 1;
                }
                emitter.burst(factory, i);
                hero.sprite.showStatus(CharSprite.POSITIVE, TXT_VALUE, Integer.valueOf(effect));
            }
            this.volume = 0;
            hero.spend(TIME_TO_DRINK);
            hero.busy();
            Sample.INSTANCE.play(Assets.SND_DRINK);
            hero.sprite.operate(hero.pos);
            updateQuickslot();
        } else {
            GLog.m4w(TXT_EMPTY, new Object[0]);
        }
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public boolean isFull() {
        return this.volume >= MAX_VOLUME;
    }

    public void collectDew(Dewdrop dew) {
        GLog.m1i(TXT_COLLECTED, new Object[0]);
        this.volume += dew.quantity;
        if (this.volume >= MAX_VOLUME) {
            this.volume = MAX_VOLUME;
            GLog.m3p(TXT_FULL, new Object[0]);
        }
        updateQuickslot();
    }

    public void fill() {
        this.volume = MAX_VOLUME;
        updateQuickslot();
    }

    public static void autoDrink(Hero hero) {
        DewVial vial = (DewVial) hero.belongings.getItem(DewVial.class);
        if (vial != null && vial.isFull()) {
            vial.execute(hero);
            hero.sprite.emitter().start(ShaftParticle.FACTORY, 0.2f, 3);
            GLog.m4w(TXT_AUTO_DRINK, new Object[0]);
        }
    }

    public Glowing glowing() {
        return isFull() ? WHITE : null;
    }

    public String status() {
        return Utils.format(TXT_STATUS, Integer.valueOf(this.volume), Integer.valueOf(MAX_VOLUME));
    }

    public String info() {
        return "You can store excess dew in this tiny vessel for drinking it later. If the vial is full, in a moment of deadly peril the dew will be consumed automatically.";
    }

    public String toString() {
        return super.toString() + " (" + status() + ")";
    }
}
