package com.watabou.pixeldungeon.items;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.particles.ShadowParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.utils.GLog;

public abstract class EquipableItem extends Item {
    public static final String AC_EQUIP = "EQUIP";
    public static final String AC_UNEQUIP = "UNEQUIP";
    private static final String TXT_UNEQUIP_CURSED = "You can't remove cursed %s!";

    public abstract boolean doEquip(Hero hero);

    public void execute(Hero hero, String action) {
        if (action.equals(AC_EQUIP)) {
            doEquip(hero);
        } else if (action.equals(AC_UNEQUIP)) {
            doUnequip(hero, true);
        } else {
            super.execute(hero, action);
        }
    }

    public void doDrop(Hero hero) {
        if (!isEquipped(hero) || doUnequip(hero, false, false)) {
            super.doDrop(hero);
        }
    }

    public void doAddStorage(Hero hero) {
        if (!isEquipped(hero) || doUnequip(hero, false, false)) {
            super.doAddStorage(hero);
        }
    }

    public void cast(Hero user, int dst) {
        if (!isEquipped(user) || this.quantity != 1 || doUnequip(user, false, false)) {
            super.cast(user, dst);
        }
    }

    protected static void equipCursed(Hero hero) {
        hero.sprite.emitter().burst(ShadowParticle.CURSE, 6);
        Sample.INSTANCE.play(Assets.SND_CURSED);
    }

    protected float time2equip(Hero hero) {
        return Key.TIME_TO_UNLOCK;
    }

    public boolean doUnequip(Hero hero, boolean collect, boolean single) {
        if (this.cursed) {
            GLog.m4w(TXT_UNEQUIP_CURSED, name());
            return false;
        }
        if (single) {
            hero.spendAndNext(time2equip(hero));
        } else {
            hero.spend(time2equip(hero));
        }
        if (collect && !collect(hero.belongings.backpack)) {
            Dungeon.level.drop(this, hero.pos);
        }
        return true;
    }

    public final boolean doUnequip(Hero hero, boolean collect) {
        return doUnequip(hero, collect, true);
    }
}
