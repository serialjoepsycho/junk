package com.watabou.pixeldungeon.items;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.PixelDungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.actors.buffs.SnipersMark;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.Degradation;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.bags.Bag;
import com.watabou.pixeldungeon.items.rings.Ring;
import com.watabou.pixeldungeon.items.wands.Wand;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.missiles.MissileWeapon;
import com.watabou.pixeldungeon.mechanics.Ballistica;
import com.watabou.pixeldungeon.scenes.CellSelector.Listener;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.sprites.MissileSprite;
import com.watabou.pixeldungeon.ui.QuickSlot;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.Callback;
import com.watabou.utils.PointF;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class Item implements Bundlable {
    public static final String AC_DROP = "DROP";
    public static final String AC_STORE = "STORE";
    public static final String AC_THROW = "THROW";
    private static final String CURSED = "cursed";
    private static final String CURSED_KNOWN = "cursedKnown";
    private static final String DURABILITY = "durability";
    private static final float DURABILITY_WARNING_LEVEL = 0.16666667f;
    private static final String LEVEL = "level";
    private static final String LEVEL_KNOWN = "levelKnown";
    private static final String QUANTITY = "quantity";
    protected static final float TIME_TO_DROP = 0.5f;
    protected static final float TIME_TO_PICK_UP = 1.0f;
    protected static final float TIME_TO_THROW = 1.0f;
    private static final String TXT_DEGRADED = "Because of frequent use, your %s has degraded.";
    private static final String TXT_GONNA_DEGRADE = "Because of frequent use, your %s is going to degrade soon.";
    private static final String TXT_PACK_FULL = "Your pack is too full for the %s";
    private static final String TXT_TO_STRING = "%s";
    private static final String TXT_TO_STRING_LVL = "%s%+d";
    private static final String TXT_TO_STRING_LVL_X = "%s%+d x%d";
    private static final String TXT_TO_STRING_X = "%s x%d";
    protected static Item curItem;
    protected static Hero curUser;
    private static Comparator<Item> itemComparator;
    protected static Listener thrower;
    public boolean cursed;
    public boolean cursedKnown;
    public String defaultAction;
    private int durability;
    protected int image;
    public int level;
    public boolean levelKnown;
    protected String name;
    public boolean noDegrade;
    protected int quantity;
    public boolean stackable;
    public boolean unique;

    /* renamed from: com.watabou.pixeldungeon.items.Item.1 */
    static class C00721 implements Comparator<Item> {
        C00721() {
        }

        public int compare(Item lhs, Item rhs) {
            return Category.order(lhs) - Category.order(rhs);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.items.Item.2 */
    class C00732 implements Callback {
        final /* synthetic */ int val$cell;
        final /* synthetic */ float val$finalDelay;
        final /* synthetic */ Hero val$user;

        C00732(Hero hero, int i, float f) {
            this.val$user = hero;
            this.val$cell = i;
            this.val$finalDelay = f;
        }

        public void call() {
            Item.this.detach(this.val$user.belongings.backpack).onThrow(this.val$cell);
            this.val$user.spendAndNext(this.val$finalDelay);
        }
    }

    /* renamed from: com.watabou.pixeldungeon.items.Item.3 */
    static class C00743 implements Listener {
        C00743() {
        }

        public void onSelect(Integer target) {
            if (target != null) {
                Item.curItem.cast(Item.curUser, target.intValue());
            }
        }

        public String prompt() {
            return "Choose direction of throw";
        }
    }

    public Item() {
        boolean z = true;
        this.name = "smth";
        this.image = 0;
        this.stackable = false;
        this.quantity = 1;
        if (PixelDungeon.itemDeg()) {
            z = false;
        }
        this.noDegrade = z;
        this.level = 0;
        this.levelKnown = false;
        this.durability = maxDurability();
        this.unique = false;
    }

    static {
        itemComparator = new C00721();
        curUser = null;
        curItem = null;
        thrower = new C00743();
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = new ArrayList();
        actions.add(AC_DROP);
        actions.add(AC_THROW);
        if (hero.pos == Dungeon.level.storage) {
            actions.add(AC_STORE);
        }
        return actions;
    }

    public boolean doPickUp(Hero hero) {
        if (!collect(hero.belongings.backpack)) {
            return false;
        }
        GameScene.pickUp(this);
        Sample.INSTANCE.play(Assets.SND_ITEM);
        hero.spendAndNext(TIME_TO_THROW);
        return true;
    }

    public void doDrop(Hero hero) {
        hero.spendAndNext(TIME_TO_DROP);
        Dungeon.level.drop(detachAll(hero.belongings.backpack), hero.pos).sprite.drop(hero.pos);
    }

    public void doThrow(Hero hero) {
        GameScene.selectCell(thrower);
    }

    public void doTakeStorage(Hero hero) {
        hero.spendAndNext(TIME_TO_DROP);
        Dungeon.level.drop(detachAll(hero.storage.backpack), hero.pos).sprite.drop(hero.pos);
    }

    public void doAddStorage(Hero hero) {
        if (collect(hero.storage.backpack)) {
            hero.spendAndNext(TIME_TO_DROP);
            detachAll(hero.belongings.backpack);
        }
    }

    public void execute(Hero hero, String action) {
        curUser = hero;
        curItem = this;
        if (action.equals(AC_DROP)) {
            doDrop(hero);
        } else if (action.equals(AC_THROW)) {
            doThrow(hero);
        } else if (action.equals(AC_STORE)) {
            doAddStorage(hero);
        } else if (action.equals("Take from storage")) {
            doTakeStorage(hero);
        }
    }

    public void execute(Hero hero) {
        execute(hero, this.defaultAction);
    }

    protected void onThrow(int cell) {
        Heap heap = Dungeon.level.drop(this, cell);
        if (!heap.isEmpty()) {
            heap.sprite.drop(cell);
        }
    }

    public boolean collect(Bag container) {
        ArrayList<Item> items = container.items;
        if (items.contains(this)) {
            return true;
        }
        Iterator it = items.iterator();
        while (it.hasNext()) {
            Item item = (Item) it.next();
            if ((item instanceof Bag) && ((Bag) item).grab(this)) {
                return collect((Bag) item);
            }
        }
        if (this.stackable) {
            Class<?> c = getClass();
            Iterator it2 = items.iterator();
            while (it2.hasNext()) {
                item = (Item) it2.next();
                if (item.getClass() == c) {
                    item.quantity += this.quantity;
                    item.updateQuickslot();
                    return true;
                }
            }
        }
        if (items.size() < container.size) {
            if (Dungeon.hero != null && Dungeon.hero.isAlive()) {
                Badges.validateItemLevelAquired(this);
            }
            items.add(this);
            QuickSlot.refresh();
            Collections.sort(items, itemComparator);
            return true;
        }
        GLog.m2n("Not enough space for the %s", name());
        return false;
    }

    public boolean collect() {
        return collect(Dungeon.hero.belongings.backpack);
    }

    public final Item detach(Bag container) {
        if (this.quantity <= 0) {
            return null;
        }
        if (this.quantity == 1) {
            return detachAll(container);
        }
        this.quantity--;
        updateQuickslot();
        try {
            Item detached = (Item) getClass().newInstance();
            detached.onDetach();
            return detached;
        } catch (Exception e) {
            return null;
        }
    }

    public final Item detachAll(Bag container) {
        Iterator it = container.items.iterator();
        while (it.hasNext()) {
            Item item = (Item) it.next();
            if (item == this) {
                container.items.remove(this);
                item.onDetach();
                QuickSlot.refresh();
                return this;
            } else if (item instanceof Bag) {
                Bag bag = (Bag) item;
                if (bag.contains(this)) {
                    return detachAll(bag);
                }
            }
        }
        return this;
    }

    protected void onDetach() {
    }

    public Item upgrade() {
        this.cursed = false;
        this.cursedKnown = true;
        this.level++;
        fix();
        return this;
    }

    public final Item upgrade(int n) {
        for (int i = 0; i < n; i++) {
            upgrade();
        }
        return this;
    }

    public Item degrade() {
        this.level--;
        fix();
        return this;
    }

    public final Item degrade(int n) {
        for (int i = 0; i < n; i++) {
            degrade();
        }
        return this;
    }

    public void use() {
        if (!this.noDegrade && this.level > 0) {
            int threshold = (int) (((float) maxDurability()) * DURABILITY_WARNING_LEVEL);
            int i = this.durability;
            this.durability = i - 1;
            if (i >= threshold && threshold > this.durability) {
                GLog.m4w(TXT_GONNA_DEGRADE, name());
            }
            if (this.durability <= 0) {
                degrade();
                if (this.levelKnown) {
                    GLog.m2n(TXT_DEGRADED, name());
                    Dungeon.hero.interrupt();
                    CharSprite sprite = Dungeon.hero.sprite;
                    PointF point = sprite.center().offset(0.0f, -16.0f);
                    if (this instanceof Weapon) {
                        sprite.parent.add(Degradation.weapon(point));
                    } else if (this instanceof Armor) {
                        sprite.parent.add(Degradation.armor(point));
                    } else if (this instanceof Ring) {
                        sprite.parent.add(Degradation.ring(point));
                    } else if (this instanceof Wand) {
                        sprite.parent.add(Degradation.wand(point));
                    }
                    Sample.INSTANCE.play(Assets.SND_DEGRADE);
                }
            }
        }
    }

    public void fix() {
        this.durability = maxDurability();
    }

    public void polish() {
        if (this.durability < maxDurability()) {
            this.durability++;
        }
    }

    public int durability() {
        return this.durability;
    }

    public int maxDurability(int lvl) {
        return 1;
    }

    public final int maxDurability() {
        return maxDurability(this.level);
    }

    public int visiblyUpgraded() {
        return this.levelKnown ? this.level : 0;
    }

    public boolean visiblyCursed() {
        return this.cursed && this.cursedKnown;
    }

    public boolean isUpgradable() {
        return true;
    }

    public boolean isIdentified() {
        return this.levelKnown && this.cursedKnown;
    }

    public boolean isEquipped(Hero hero) {
        return false;
    }

    public Item identify() {
        this.levelKnown = true;
        this.cursedKnown = true;
        return this;
    }

    public static void evoke(Hero hero) {
        hero.sprite.emitter().burst(Speck.factory(ItemSpriteSheet.ORE), 5);
    }

    public String toString() {
        if (!this.levelKnown || this.level == 0) {
            if (this.quantity > 1) {
                return Utils.format(TXT_TO_STRING_X, name(), Integer.valueOf(this.quantity));
            }
            return Utils.format(TXT_TO_STRING, name());
        } else if (this.quantity > 1) {
            return Utils.format(TXT_TO_STRING_LVL_X, name(), Integer.valueOf(this.level), Integer.valueOf(this.quantity));
        } else {
            return Utils.format(TXT_TO_STRING_LVL, name(), Integer.valueOf(this.level));
        }
    }

    public String name() {
        return this.name;
    }

    public final String trueName() {
        return this.name;
    }

    public int image() {
        return this.image;
    }

    public Glowing glowing() {
        return null;
    }

    public String info() {
        return desc();
    }

    public String desc() {
        return BuildConfig.VERSION_NAME;
    }

    public int quantity() {
        return this.quantity;
    }

    public void quantity(int value) {
        this.quantity = value;
    }

    public int price() {
        return 0;
    }

    public static Item virtual(Class<? extends Item> cl) {
        try {
            Item item = (Item) cl.newInstance();
            item.quantity = 0;
            return item;
        } catch (Exception e) {
            return null;
        }
    }

    public Item random() {
        return this;
    }

    public String status() {
        return this.quantity != 1 ? Integer.toString(this.quantity) : null;
    }

    public void updateQuickslot() {
        if (this.stackable) {
            Class<? extends Item> cl = getClass();
            if (QuickSlot.primaryValue == cl || QuickSlot.secondaryValue == cl) {
                QuickSlot.refresh();
            }
        } else if (QuickSlot.primaryValue == this || QuickSlot.secondaryValue == this) {
            QuickSlot.refresh();
        }
    }

    public void storeInBundle(Bundle bundle) {
        bundle.put(QUANTITY, this.quantity);
        bundle.put(LEVEL, this.level);
        bundle.put(LEVEL_KNOWN, this.levelKnown);
        bundle.put(CURSED, this.cursed);
        bundle.put(CURSED_KNOWN, this.cursedKnown);
        if (isUpgradable()) {
            bundle.put(DURABILITY, this.durability);
        }
        QuickSlot.save(bundle, this);
    }

    public void restoreFromBundle(Bundle bundle) {
        this.quantity = bundle.getInt(QUANTITY);
        this.levelKnown = bundle.getBoolean(LEVEL_KNOWN);
        this.cursedKnown = bundle.getBoolean(CURSED_KNOWN);
        int level = bundle.getInt(LEVEL);
        if (level > 0) {
            upgrade(level);
        } else if (level < 0) {
            degrade(-level);
        }
        this.cursed = bundle.getBoolean(CURSED);
        if (isUpgradable()) {
            this.durability = bundle.getInt(DURABILITY);
        }
        if (this.durability <= 0) {
            this.durability = maxDurability(level);
        }
        QuickSlot.restore(bundle, this);
    }

    public void cast(Hero user, int dst) {
        int cell = Ballistica.cast(user.pos, dst, false, true);
        user.sprite.zap(cell);
        user.busy();
        Sample.INSTANCE.play(Assets.SND_MISS, 0.6f, 0.6f, Sleep.SWS);
        Char enemy = Actor.findChar(cell);
        QuickSlot.target(this, enemy);
        float delay = TIME_TO_THROW;
        if (this instanceof MissileWeapon) {
            delay = TIME_TO_THROW * ((MissileWeapon) this).speedFactor(user);
            if (enemy != null) {
                SnipersMark mark = (SnipersMark) user.buff(SnipersMark.class);
                if (mark != null) {
                    if (mark.object == enemy.id()) {
                        delay *= TIME_TO_DROP;
                    }
                    user.remove(mark);
                }
            }
        }
        ((MissileSprite) user.sprite.parent.recycle(MissileSprite.class)).reset(user.pos, cell, this, new C00732(user, cell, delay));
    }
}
