package com.watabou.pixeldungeon.items.quest;

import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class CorpseDust extends Item {
    public CorpseDust() {
        this.name = "corpse dust";
        this.image = ItemSpriteSheet.DUST;
        this.cursed = true;
        this.cursedKnown = true;
        this.unique = true;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String info() {
        return "The ball of corpse dust doesn't differ outwardly from a regular dust ball. However, you know somehow that it's better to get rid of it as soon as possible.";
    }
}
