package com.watabou.pixeldungeon.items.quest;

import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class RatSkull extends Item {
    public RatSkull() {
        this.name = "giant rat skull";
        this.image = ItemSpriteSheet.SKULL;
        this.unique = true;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String info() {
        return "It could be a nice hunting trophy, but it smells too bad to place it on a wall.";
    }

    public int price() {
        return 100;
    }
}
