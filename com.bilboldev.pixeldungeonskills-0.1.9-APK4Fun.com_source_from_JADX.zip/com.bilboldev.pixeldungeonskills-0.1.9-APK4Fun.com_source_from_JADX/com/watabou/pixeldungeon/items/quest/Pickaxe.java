package com.watabou.pixeldungeon.items.quest;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Hunger;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.mobs.Bat;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Bundle;
import com.watabou.utils.Callback;
import java.util.ArrayList;

public class Pickaxe extends Weapon {
    public static final String AC_MINE = "MINE";
    private static final String BLOODSTAINED = "bloodStained";
    private static final Glowing BLOODY;
    public static final float TIME_TO_MINE = 2.0f;
    private static final String TXT_NO_VEIN = "There is no dark gold vein near you to mine";
    public boolean bloodStained;

    /* renamed from: com.watabou.pixeldungeon.items.quest.Pickaxe.1 */
    class C00891 implements Callback {
        final /* synthetic */ Hero val$hero;
        final /* synthetic */ int val$pos;

        C00891(int i, Hero hero) {
            this.val$pos = i;
            this.val$hero = hero;
        }

        public void call() {
            CellEmitter.center(this.val$pos).burst(Speck.factory(1), 7);
            Sample.INSTANCE.play(Assets.SND_EVOKE);
            Level.set(this.val$pos, 4);
            GameScene.updateMap(this.val$pos);
            DarkGold gold = new DarkGold();
            if (gold.doPickUp(Dungeon.hero)) {
                GLog.m1i(Hero.TXT_YOU_NOW_HAVE, gold.name());
            } else {
                Dungeon.level.drop(gold, this.val$hero.pos).sprite.drop();
            }
            Hunger hunger = (Hunger) this.val$hero.buff(Hunger.class);
            if (!(hunger == null || hunger.isStarving())) {
                hunger.satisfy(-36.0f);
                BuffIndicator.refreshHero();
            }
            this.val$hero.onOperateComplete();
        }
    }

    public Pickaxe() {
        this.name = "pickaxe";
        this.image = ItemSpriteSheet.PICKAXE;
        this.unique = true;
        this.defaultAction = AC_MINE;
        this.STR = 14;
        this.MIN = 3;
        this.MAX = 12;
        this.bloodStained = false;
    }

    static {
        BLOODY = new Glowing(5570560);
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_MINE);
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action != AC_MINE) {
            super.execute(hero, action);
        } else if (Dungeon.depth < 11 || Dungeon.depth > 15) {
            GLog.m4w(TXT_NO_VEIN, new Object[0]);
        } else {
            for (int i : Level.NEIGHBOURS8) {
                int pos = hero.pos + i;
                if (Dungeon.level.map[pos] == 12) {
                    hero.spend(TIME_TO_MINE);
                    hero.busy();
                    hero.sprite.attack(pos, new C00891(pos, hero));
                    return;
                }
            }
            GLog.m4w(TXT_NO_VEIN, new Object[0]);
        }
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public void proc(Char attacker, Char defender, int damage) {
        if (!this.bloodStained && (defender instanceof Bat) && defender.HP <= damage) {
            this.bloodStained = true;
            updateQuickslot();
        }
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(BLOODSTAINED, this.bloodStained);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.bloodStained = bundle.getBoolean(BLOODSTAINED);
    }

    public Glowing glowing() {
        return this.bloodStained ? BLOODY : null;
    }

    public String info() {
        return "This is a large and sturdy tool for breaking rocks. Probably it can be used as a weapon.";
    }
}
