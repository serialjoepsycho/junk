package com.watabou.pixeldungeon.items.quest;

import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class DarkGold extends Item {
    public DarkGold() {
        this.name = "dark gold ore";
        this.image = ItemSpriteSheet.ORE;
        this.stackable = true;
        this.unique = true;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String info() {
        return "This metal is called dark not because of its color (it doesn't differ from the normal gold), but because it melts under the daylight, making it useless on the surface.";
    }

    public int price() {
        return this.quantity;
    }
}
