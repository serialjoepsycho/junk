package com.watabou.pixeldungeon.items.quest;

import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class DwarfToken extends Item {
    public DwarfToken() {
        this.name = "dwarf token";
        this.image = ItemSpriteSheet.TOKEN;
        this.stackable = true;
        this.unique = true;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String info() {
        return "Many dwarves and some of their larger creations carry these small pieces of metal of unknown purpose. Maybe they are jewelry or maybe some kind of ID. Dwarves are strange folk.";
    }

    public int price() {
        return this.quantity * 100;
    }
}
