package com.watabou.pixeldungeon.items.quest;

import com.watabou.pixeldungeon.items.Item;

public class DriedRose extends Item {
    public DriedRose() {
        this.name = "dried rose";
        this.image = 100;
        this.unique = true;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String info() {
        return "The rose has dried long ago, but it has kept all its petals somehow.";
    }
}
