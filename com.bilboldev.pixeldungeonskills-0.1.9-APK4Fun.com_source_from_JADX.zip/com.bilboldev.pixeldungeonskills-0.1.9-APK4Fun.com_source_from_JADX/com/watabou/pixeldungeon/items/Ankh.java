package com.watabou.pixeldungeon.items;

public class Ankh extends Item {
    public Ankh() {
        this.stackable = true;
        this.name = "Ankh";
        this.image = 1;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String info() {
        return "The ancient symbol of immortality grants an ability to return to life after death. Upon resurrection all non-equipped items are lost.";
    }

    public int price() {
        return this.quantity * 50;
    }
}
