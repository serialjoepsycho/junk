package com.watabou.pixeldungeon.items;

import com.watabou.utils.Bundle;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

public class ItemStatusHandler<T extends Item> {
    private static final String PFX_IMAGE = "_image";
    private static final String PFX_KNOWN = "_known";
    private static final String PFX_LABEL = "_label";
    private HashMap<Class<? extends T>, Integer> images;
    private Class<? extends T>[] items;
    private HashSet<Class<? extends T>> known;
    private HashMap<Class<? extends T>, String> labels;

    public ItemStatusHandler(Class<? extends T>[] items, String[] allLabels, Integer[] allImages, int exclude) {
        int i;
        this.items = items;
        this.images = new HashMap();
        this.labels = new HashMap();
        this.known = new HashSet();
        ArrayList<String> labelsLeft = new ArrayList(Arrays.asList(allLabels));
        ArrayList<Integer> imagesLeft = new ArrayList(Arrays.asList(allImages));
        for (i = 0; i < items.length - exclude; i++) {
            Class<? extends T> item = items[i];
            int index = Random.Int(labelsLeft.size() - exclude);
            this.labels.put(item, labelsLeft.get(index));
            labelsLeft.remove(index);
            this.images.put(item, imagesLeft.get(index));
            imagesLeft.remove(index);
        }
        for (i = items.length - exclude; i < items.length; i++) {
            item = items[i];
            this.labels.put(item, allLabels[i]);
            this.images.put(item, allImages[i]);
        }
    }

    public ItemStatusHandler(Class<? extends T>[] items, String[] allLabels, Integer[] allImages) {
        this.items = items;
        this.images = new HashMap();
        this.labels = new HashMap();
        this.known = new HashSet();
        ArrayList<String> labelsLeft = new ArrayList(Arrays.asList(allLabels));
        ArrayList<Integer> imagesLeft = new ArrayList(Arrays.asList(allImages));
        for (Class<? extends T> item : items) {
            int index = Random.Int(labelsLeft.size());
            this.labels.put(item, labelsLeft.get(index));
            labelsLeft.remove(index);
            this.images.put(item, imagesLeft.get(index));
            imagesLeft.remove(index);
        }
    }

    public ItemStatusHandler(Class<? extends T>[] items, String[] labels, Integer[] images, Bundle bundle) {
        this.items = items;
        this.images = new HashMap();
        this.labels = new HashMap();
        this.known = new HashSet();
        restore(bundle, labels, images);
    }

    public void save(Bundle bundle) {
        for (int i = 0; i < this.items.length; i++) {
            String itemName = this.items[i].toString();
            bundle.put(itemName + PFX_IMAGE, ((Integer) this.images.get(this.items[i])).intValue());
            bundle.put(itemName + PFX_LABEL, (String) this.labels.get(this.items[i]));
            bundle.put(itemName + PFX_KNOWN, this.known.contains(this.items[i]));
        }
    }

    private void restore(Bundle bundle, String[] allLabels, Integer[] allImages) {
        ArrayList<String> labelsLeft = new ArrayList(Arrays.asList(allLabels));
        ArrayList<Integer> imagesLeft = new ArrayList(Arrays.asList(allImages));
        for (Class<? extends T> item : this.items) {
            String itemName = item.toString();
            if (bundle.contains(itemName + PFX_LABEL)) {
                String label = bundle.getString(itemName + PFX_LABEL);
                this.labels.put(item, label);
                labelsLeft.remove(label);
                Integer image = Integer.valueOf(bundle.getInt(itemName + PFX_IMAGE));
                this.images.put(item, image);
                imagesLeft.remove(image);
                if (bundle.getBoolean(itemName + PFX_KNOWN)) {
                    this.known.add(item);
                }
            } else {
                int index = Random.Int(labelsLeft.size());
                this.labels.put(item, labelsLeft.get(index));
                labelsLeft.remove(index);
                this.images.put(item, imagesLeft.get(index));
                imagesLeft.remove(index);
            }
        }
    }

    public int image(T item) {
        return ((Integer) this.images.get(item.getClass())).intValue();
    }

    public String label(T item) {
        return (String) this.labels.get(item.getClass());
    }

    public boolean isKnown(T item) {
        return this.known.contains(item.getClass());
    }

    public void know(T item) {
        this.known.add(item.getClass());
        if (this.known.size() == this.items.length - 1) {
            int i = 0;
            while (i < this.items.length) {
                if (this.known.contains(this.items[i])) {
                    i++;
                } else {
                    this.known.add(this.items[i]);
                    return;
                }
            }
        }
    }

    public HashSet<Class<? extends T>> known() {
        return this.known;
    }

    public HashSet<Class<? extends T>> unknown() {
        HashSet<Class<? extends T>> result = new HashSet();
        for (Class<? extends T> i : this.items) {
            if (!this.known.contains(i)) {
                result.add(i);
            }
        }
        return result;
    }
}
