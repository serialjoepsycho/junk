package com.watabou.pixeldungeon.items;

import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Light;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.particles.FlameParticle;
import java.util.ArrayList;

public class Torch extends Item {
    public static final String AC_LIGHT = "LIGHT";
    public static final float TIME_TO_LIGHT = 1.0f;

    public Torch() {
        this.name = "torch";
        this.image = 84;
        this.stackable = true;
        this.defaultAction = AC_LIGHT;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_LIGHT);
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action == AC_LIGHT) {
            hero.spend(TIME_TO_LIGHT);
            hero.busy();
            hero.sprite.operate(hero.pos);
            detach(hero.belongings.backpack);
            Buff.affect(hero, Light.class, Light.DURATION);
            hero.sprite.centerEmitter().start(FlameParticle.FACTORY, 0.2f, 3);
            return;
        }
        super.execute(hero, action);
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public int price() {
        return this.quantity * 10;
    }

    public String info() {
        return "It's an indispensable item in The Demon Halls, which are notorious for their poor ambient lighting.";
    }
}
