package com.watabou.pixeldungeon.items;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.actors.buffs.Blindness;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Fury;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.hero.HeroSubClass;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.SpellSprite;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndChooseWay;
import com.watabou.pixeldungeon.windows.WndUpdates;
import java.util.ArrayList;

public class TomeOfMastery extends Item {
    public static final String AC_READ = "READ";
    public static final float TIME_TO_READ = 10.0f;
    private static final String TXT_BLINDED = "You can't read while blinded";

    /* renamed from: com.watabou.pixeldungeon.items.TomeOfMastery.1 */
    static /* synthetic */ class C00751 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass;

        static {
            $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass = new int[HeroClass.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.WARRIOR.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.MAGE.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.ROGUE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.HUNTRESS.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
        }
    }

    public TomeOfMastery() {
        this.stackable = false;
        this.name = "Tome of Mastery";
        this.image = 82;
        this.unique = true;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_READ);
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (!action.equals(AC_READ)) {
            super.execute(hero, action);
        } else if (hero.buff(Blindness.class) != null) {
            GLog.m4w(TXT_BLINDED, new Object[0]);
        } else {
            curUser = hero;
            HeroSubClass way1 = null;
            HeroSubClass way2 = null;
            switch (C00751.$SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[hero.heroClass.ordinal()]) {
                case WndUpdates.ID_PRISON /*1*/:
                    way1 = HeroSubClass.GLADIATOR;
                    way2 = HeroSubClass.BERSERKER;
                    break;
                case WndUpdates.ID_CAVES /*2*/:
                    way1 = HeroSubClass.BATTLEMAGE;
                    way2 = HeroSubClass.WARLOCK;
                    break;
                case WndUpdates.ID_METROPOLIS /*3*/:
                    way1 = HeroSubClass.FREERUNNER;
                    way2 = HeroSubClass.ASSASSIN;
                    break;
                case WndUpdates.ID_HALLS /*4*/:
                    way1 = HeroSubClass.SNIPER;
                    way2 = HeroSubClass.WARDEN;
                    break;
            }
            GameScene.show(new WndChooseWay(this, way1, way2));
        }
    }

    public boolean doPickUp(Hero hero) {
        Badges.validateMastery();
        return super.doPickUp(hero);
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String info() {
        return "This worn leather book is not that thick, but you feel somehow, that you can gather a lot from it. Remember though that reading this tome may require some time.";
    }

    public void choose(HeroSubClass way) {
        detach(curUser.belongings.backpack);
        curUser.spend(TIME_TO_READ);
        curUser.busy();
        curUser.subClass = way;
        curUser.sprite.operate(curUser.pos);
        Sample.INSTANCE.play(Assets.SND_MASTERY);
        SpellSprite.show(curUser, 3);
        curUser.sprite.emitter().burst(Speck.factory(ItemSpriteSheet.SKULL), 12);
        GLog.m4w("You have chosen the way of the %s!", Utils.capitalize(way.title()));
        if (way == HeroSubClass.BERSERKER && ((float) curUser.HP) <= ((float) curUser.HT) * Fury.LEVEL) {
            Buff.affect(curUser, Fury.class);
        }
    }
}
