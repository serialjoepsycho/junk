package com.watabou.pixeldungeon.items;

import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.weapon.missiles.Arrow;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import java.util.ArrayList;

public class TomeOfKnowledge extends Item {
    public static final String AC_READ = "READ";
    public static final float TIME_TO_READ = 1.0f;

    public TomeOfKnowledge() {
        this.stackable = false;
        this.name = "Tome of Knowledge";
        this.image = ItemSpriteSheet.Knowledge;
        this.unique = true;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_READ);
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action.equals(AC_READ)) {
            detach(hero.belongings.backpack);
            new Arrow(30).collect();
            GLog.m3p("30 arrows obtained!", new Object[0]);
            return;
        }
        super.execute(hero, action);
    }

    public boolean doPickUp(Hero hero) {
        return super.doPickUp(hero);
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String info() {
        return "Welcome to Skillful Pixel Dungeon 0.1.9!\nLatest Updates:\n- Storage added!\n- Donations now possible!\nRead me for some 0.1.9 freebies!";
    }
}
