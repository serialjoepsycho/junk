package com.watabou.pixeldungeon.items.bags;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.windows.WndBag;
import com.watabou.pixeldungeon.windows.WndBag.Mode;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import java.util.ArrayList;
import java.util.Iterator;

public class Bag extends Item implements Iterable<Item> {
    public static final String AC_OPEN = "OPEN";
    private static final String ITEMS = "inventory";
    private static final String ITEMS2 = "inventory2";
    public ArrayList<Item> items;
    public Char owner;
    public int size;

    private class ItemIterator implements Iterator<Item> {
        private int index;
        private Iterator<Item> nested;

        private ItemIterator() {
            this.index = 0;
            this.nested = null;
        }

        public boolean hasNext() {
            boolean z = true;
            if (this.nested == null) {
                if (this.index >= Bag.this.items.size()) {
                    z = false;
                }
                return z;
            } else if (this.nested.hasNext() || this.index < Bag.this.items.size()) {
                return true;
            } else {
                return false;
            }
        }

        public Item next() {
            if (this.nested != null && this.nested.hasNext()) {
                return (Item) this.nested.next();
            }
            this.nested = null;
            ArrayList arrayList = Bag.this.items;
            int i = this.index;
            this.index = i + 1;
            Item item = (Item) arrayList.get(i);
            if (item instanceof Bag) {
                this.nested = ((Bag) item).iterator();
            }
            return item;
        }

        public void remove() {
            if (this.nested != null) {
                this.nested.remove();
            } else {
                Bag.this.items.remove(this.index);
            }
        }
    }

    public Bag() {
        this.image = 11;
        this.defaultAction = AC_OPEN;
        this.items = new ArrayList();
        this.size = 1;
    }

    public ArrayList<String> actions(Hero hero) {
        return super.actions(hero);
    }

    public void execute(Hero hero, String action) {
        if (action.equals(AC_OPEN)) {
            GameScene.show(new WndBag(this, null, Mode.ALL, null));
        } else {
            super.execute(hero, action);
        }
    }

    public boolean collect(Bag container) {
        int i = 0;
        if (!super.collect(container)) {
            return false;
        }
        this.owner = container.owner;
        Item[] itemArr = (Item[]) container.items.toArray(new Item[0]);
        int length = itemArr.length;
        while (i < length) {
            Item item = itemArr[i];
            if (grab(item)) {
                item.detachAll(container);
                item.collect(this);
            }
            i++;
        }
        Badges.validateAllBagsBought(this);
        return true;
    }

    public void onDetach() {
        this.owner = null;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public void clear() {
        this.items.clear();
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(ITEMS, this.items);
    }

    public void storeInBundle2(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(ITEMS2, this.items);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        for (Bundlable item : bundle.getCollection(ITEMS)) {
            ((Item) item).collect(this);
        }
    }

    public void restoreFromBundle2(Bundle bundle) {
        super.restoreFromBundle(bundle);
        for (Bundlable item : bundle.getCollection(ITEMS2)) {
            ((Item) item).collect(this);
        }
    }

    public boolean contains(Item item) {
        Iterator it = this.items.iterator();
        while (it.hasNext()) {
            Item i = (Item) it.next();
            if (i == item) {
                return true;
            }
            if ((i instanceof Bag) && ((Bag) i).contains(item)) {
                return true;
            }
        }
        return false;
    }

    public boolean grab(Item item) {
        return false;
    }

    public Iterator<Item> iterator() {
        return new ItemIterator();
    }
}
