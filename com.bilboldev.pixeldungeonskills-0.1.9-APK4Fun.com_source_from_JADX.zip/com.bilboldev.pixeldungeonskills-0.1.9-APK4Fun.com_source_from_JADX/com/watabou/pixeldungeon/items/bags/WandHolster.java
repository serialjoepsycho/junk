package com.watabou.pixeldungeon.items.bags;

import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.wands.Wand;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import java.util.Iterator;

public class WandHolster extends Bag {
    public WandHolster() {
        this.name = "wand holster";
        this.image = ItemSpriteSheet.HOLSTER;
        this.size = 12;
    }

    public boolean grab(Item item) {
        return item instanceof Wand;
    }

    public boolean collect(Bag container) {
        if (!super.collect(container)) {
            return false;
        }
        if (this.owner != null) {
            Iterator it = this.items.iterator();
            while (it.hasNext()) {
                ((Wand) ((Item) it.next())).charge(this.owner);
            }
        }
        return true;
    }

    public void onDetach() {
        Iterator it = this.items.iterator();
        while (it.hasNext()) {
            ((Wand) ((Item) it.next())).stopCharging();
        }
    }

    public int price() {
        return 50;
    }

    public String info() {
        return "This slim holder is made of leather of some exotic animal. It allows to compactly carry up to " + this.size + " wands.";
    }
}
