package com.watabou.pixeldungeon.items.bags;

import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.scrolls.Scroll;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class ScrollHolder extends Bag {
    public ScrollHolder() {
        this.name = "scroll holder";
        this.image = ItemSpriteSheet.HOLDER;
        this.size = 12;
    }

    public boolean grab(Item item) {
        return item instanceof Scroll;
    }

    public int price() {
        return 50;
    }

    public String info() {
        return "You can place any number of scrolls into this tubular container. It saves room in your backpack and protects scrolls from fire.";
    }
}
