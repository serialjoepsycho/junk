package com.watabou.pixeldungeon.items.bags;

import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class Keyring extends Bag {
    public Keyring() {
        this.name = "key ring";
        this.image = ItemSpriteSheet.KEYRING;
        this.size = 12;
    }

    public boolean grab(Item item) {
        return item instanceof Key;
    }

    public int price() {
        return 50;
    }

    public String info() {
        return "This is a copper key ring, that lets you keep all your keys separately from the rest of your belongings.";
    }
}
