package com.watabou.pixeldungeon.items.bags;

import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.plants.Plant.Seed;

public class SeedPouch extends Bag {
    public SeedPouch() {
        this.name = "seed pouch";
        this.image = 83;
        this.size = 8;
    }

    public boolean grab(Item item) {
        return item instanceof Seed;
    }

    public int price() {
        return 50;
    }

    public String info() {
        return "This small velvet pouch allows you to store any number of seeds in it. Very convenient.";
    }
}
