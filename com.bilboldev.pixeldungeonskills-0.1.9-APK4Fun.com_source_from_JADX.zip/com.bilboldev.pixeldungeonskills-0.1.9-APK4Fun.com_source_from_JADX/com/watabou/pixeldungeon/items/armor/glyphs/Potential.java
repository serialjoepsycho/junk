package com.watabou.pixeldungeon.items.armor.glyphs;

import com.watabou.noosa.Camera;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.effects.Lightning;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.Armor.Glyph;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.traps.LightningTrap;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Potential extends Glyph {
    private static Glowing BLUE = null;
    private static final String TXT_POTENTIAL = "%s of potential";

    static {
        BLUE = new Glowing(6737134);
    }

    public int proc(Armor armor, Char attacker, Char defender, int damage) {
        int level = Math.max(0, armor.level);
        if (Level.adjacent(attacker.pos, defender.pos) && Random.Int(level + 7) >= 6) {
            int dmg = Random.IntRange(1, damage);
            attacker.damage(dmg, LightningTrap.LIGHTNING);
            defender.damage(Random.IntRange(1, dmg), LightningTrap.LIGHTNING);
            checkOwner(defender);
            if (defender == Dungeon.hero) {
                Camera.main.shake(Pickaxe.TIME_TO_MINE, 0.3f);
            }
            attacker.sprite.parent.add(new Lightning(new int[]{attacker.pos, defender.pos}, 2, null));
        }
        return damage;
    }

    public String name(String weaponName) {
        return String.format(TXT_POTENTIAL, new Object[]{weaponName});
    }

    public Glowing glowing() {
        return BLUE;
    }
}
