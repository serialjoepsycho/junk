package com.watabou.pixeldungeon.items.armor.glyphs;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Charm;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.Armor.Glyph;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.GameMath;
import com.watabou.utils.Random;

public class Affection extends Glyph {
    private static Glowing PINK = null;
    private static final String TXT_AFFECTION = "%s of affection";

    static {
        PINK = new Glowing(16729224);
    }

    public int proc(Armor armor, Char attacker, Char defender, int damage) {
        int level = (int) GameMath.gate(0.0f, (float) armor.level, 6.0f);
        if (Level.adjacent(attacker.pos, defender.pos) && Random.Int((level / 2) + 5) >= 4) {
            int duration = Random.IntRange(3, 7);
            ((Charm) Buff.affect(attacker, Charm.class, Charm.durationFactor(attacker) * ((float) duration))).object = defender.id();
            attacker.sprite.centerEmitter().start(Speck.factory(11), 0.2f, 5);
            ((Charm) Buff.affect(defender, Charm.class, Charm.durationFactor(defender) * ((float) ((int) (((float) duration) * Random.Float(0.5f, Key.TIME_TO_UNLOCK)))))).object = attacker.id();
            defender.sprite.centerEmitter().start(Speck.factory(11), 0.2f, 5);
        }
        return damage;
    }

    public String name(String weaponName) {
        return String.format(TXT_AFFECTION, new Object[]{weaponName});
    }

    public Glowing glowing() {
        return PINK;
    }
}
