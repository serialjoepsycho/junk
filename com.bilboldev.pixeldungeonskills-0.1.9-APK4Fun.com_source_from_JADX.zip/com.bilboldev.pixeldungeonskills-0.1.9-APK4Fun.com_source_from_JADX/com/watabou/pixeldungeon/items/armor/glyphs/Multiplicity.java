package com.watabou.pixeldungeon.items.armor.glyphs;

import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.actors.mobs.npcs.MirrorImage;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.Armor.Glyph;
import com.watabou.pixeldungeon.items.wands.WandOfBlink;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Collection;

public class Multiplicity extends Glyph {
    private static Glowing PINK = null;
    private static final String TXT_MULTIPLICITY = "%s of multiplicity";

    static {
        PINK = new Glowing(13413000);
    }

    public int proc(Armor armor, Char attacker, Char defender, int damage) {
        if (Random.Int((Math.max(0, armor.level) / 2) + 6) >= 5) {
            Collection respawnPoints = new ArrayList();
            for (int i : Level.NEIGHBOURS8) {
                int p = defender.pos + i;
                if (Actor.findChar(p) == null && (Level.passable[p] || Level.avoid[p])) {
                    respawnPoints.add(Integer.valueOf(p));
                }
            }
            if (respawnPoints.size() > 0) {
                Mob mob = new MirrorImage();
                mob.duplicate((Hero) defender);
                GameScene.add(mob);
                WandOfBlink.appear(mob, ((Integer) Random.element(respawnPoints)).intValue());
                defender.damage(Random.IntRange(1, defender.HT / 6), this);
                checkOwner(defender);
            }
        }
        return damage;
    }

    public String name(String weaponName) {
        return String.format(TXT_MULTIPLICITY, new Object[]{weaponName});
    }

    public Glowing glowing() {
        return PINK;
    }
}
