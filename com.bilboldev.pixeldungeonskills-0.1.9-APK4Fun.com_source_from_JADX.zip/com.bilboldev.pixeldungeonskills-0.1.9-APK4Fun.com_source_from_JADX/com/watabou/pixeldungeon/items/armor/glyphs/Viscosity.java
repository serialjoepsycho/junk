package com.watabou.pixeldungeon.items.armor.glyphs;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.Armor.Glyph;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.ui.ItemSlot;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;

public class Viscosity extends Glyph {
    private static Glowing PURPLE = null;
    private static final String TXT_VISCOSITY = "%s of viscosity";

    public static class DeferedDamage extends Buff {
        private static final String DAMAGE = "damage";
        protected int damage;

        public DeferedDamage() {
            this.damage = 0;
        }

        public void storeInBundle(Bundle bundle) {
            super.storeInBundle(bundle);
            bundle.put(DAMAGE, this.damage);
        }

        public void restoreFromBundle(Bundle bundle) {
            super.restoreFromBundle(bundle);
            this.damage = bundle.getInt(DAMAGE);
        }

        public boolean attachTo(Char target) {
            if (!super.attachTo(target)) {
                return false;
            }
            postpone(Key.TIME_TO_UNLOCK);
            return true;
        }

        public void prolong(int damage) {
            this.damage += damage;
        }

        public int icon() {
            return 28;
        }

        public String toString() {
            return Utils.format("Defered damage (%d)", Integer.valueOf(this.damage));
        }

        public boolean act() {
            if (this.target.isAlive()) {
                this.target.damage(1, this);
                if (this.target == Dungeon.hero && !this.target.isAlive()) {
                    Dungeon.fail(Utils.format(ResultDescriptions.GLYPH, "enchantment of viscosity", Integer.valueOf(Dungeon.depth)));
                    GLog.m2n("The enchantment of viscosity killed you...", new Object[0]);
                    Badges.validateDeathFromGlyph();
                }
                spend(Key.TIME_TO_UNLOCK);
                int i = this.damage - 1;
                this.damage = i;
                if (i <= 0) {
                    detach();
                }
            } else {
                detach();
            }
            return true;
        }
    }

    static {
        PURPLE = new Glowing(8930508);
    }

    public int proc(Armor armor, Char attacker, Char defender, int damage) {
        if (damage == 0) {
            return 0;
        }
        if (Random.Int(Math.max(0, armor.level) + 7) < 6) {
            return damage;
        }
        DeferedDamage debuff = (DeferedDamage) defender.buff(DeferedDamage.class);
        if (debuff == null) {
            debuff = new DeferedDamage();
            debuff.attachTo(defender);
        }
        debuff.prolong(damage);
        defender.sprite.showStatus(ItemSlot.WARNING, "deferred %d", Integer.valueOf(damage));
        return 0;
    }

    public String name(String weaponName) {
        return String.format(TXT_VISCOSITY, new Object[]{weaponName});
    }

    public Glowing glowing() {
        return PURPLE;
    }
}
