package com.watabou.pixeldungeon.items.armor.glyphs;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Hunger;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.Armor.Glyph;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.utils.Random;

public class Metabolism extends Glyph {
    private static Glowing RED = null;
    private static final String TXT_METABOLISM = "%s of metabolism";

    static {
        RED = new Glowing(13369344);
    }

    public int proc(Armor armor, Char attacker, Char defender, int damage) {
        if (Random.Int((Math.max(0, armor.level) / 2) + 5) >= 4) {
            int healing = Math.min(defender.HT - defender.HP, Random.Int(1, defender.HT / 5));
            if (healing > 0) {
                Hunger hunger = (Hunger) defender.buff(Hunger.class);
                if (!(hunger == null || hunger.isStarving())) {
                    hunger.satisfy(-36.0f);
                    BuffIndicator.refreshHero();
                    defender.HP += healing;
                    defender.sprite.emitter().burst(Speck.factory(0), 1);
                    defender.sprite.showStatus(CharSprite.POSITIVE, Integer.toString(healing), new Object[0]);
                }
            }
        }
        return damage;
    }

    public String name(String weaponName) {
        return String.format(TXT_METABOLISM, new Object[]{weaponName});
    }

    public Glowing glowing() {
        return RED;
    }
}
