package com.watabou.pixeldungeon.items.armor.glyphs;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Burning;
import com.watabou.pixeldungeon.actors.buffs.Frost;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.FlameParticle;
import com.watabou.pixeldungeon.effects.particles.SnowParticle;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.Armor.Glyph;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class AntiEntropy extends Glyph {
    private static Glowing BLUE = null;
    private static final String TXT_ANTI_ENTROPY = "%s of anti-entropy";

    static {
        BLUE = new Glowing(255);
    }

    public int proc(Armor armor, Char attacker, Char defender, int damage) {
        int level = Math.max(0, armor.level);
        if (Level.adjacent(attacker.pos, defender.pos) && Random.Int(level + 6) >= 5) {
            Buff.prolong(attacker, Frost.class, Frost.duration(attacker) * Random.Float(Key.TIME_TO_UNLOCK, Sleep.SWS));
            CellEmitter.get(attacker.pos).start(SnowParticle.FACTORY, 0.2f, 6);
            ((Burning) Buff.affect(defender, Burning.class)).reignite(defender);
            defender.sprite.emitter().burst(FlameParticle.FACTORY, 5);
        }
        return damage;
    }

    public String name(String weaponName) {
        return String.format(TXT_ANTI_ENTROPY, new Object[]{weaponName});
    }

    public Glowing glowing() {
        return BLUE;
    }
}
