package com.watabou.pixeldungeon.items.armor.glyphs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.effects.Pushing;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.Armor.Glyph;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.utils.Random;

public class Bounce extends Glyph {
    private static final String TXT_BOUNCE = "%s of bounce";

    public int proc(Armor armor, Char attacker, Char defender, int damage) {
        int level = Math.max(0, armor.level);
        if (Level.adjacent(attacker.pos, defender.pos) && Random.Int(level + 5) >= 4) {
            int i = 0;
            while (i < Level.NEIGHBOURS8.length) {
                int ofs = Level.NEIGHBOURS8[i];
                if (attacker.pos - defender.pos == ofs) {
                    int newPos = attacker.pos + ofs;
                    if ((Level.passable[newPos] || Level.avoid[newPos]) && Actor.findChar(newPos) == null) {
                        Actor.addDelayed(new Pushing(attacker, attacker.pos, newPos), -1.0f);
                        attacker.pos = newPos;
                        if (attacker instanceof Mob) {
                            Dungeon.level.mobPress((Mob) attacker);
                        } else {
                            Dungeon.level.press(newPos, attacker);
                        }
                    }
                } else {
                    i++;
                }
            }
        }
        return damage;
    }

    public String name(String weaponName) {
        return String.format(TXT_BOUNCE, new Object[]{weaponName});
    }
}
