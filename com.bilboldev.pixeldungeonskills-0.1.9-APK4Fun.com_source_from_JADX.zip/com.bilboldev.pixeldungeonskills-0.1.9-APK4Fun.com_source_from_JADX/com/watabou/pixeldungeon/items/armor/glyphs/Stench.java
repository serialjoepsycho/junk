package com.watabou.pixeldungeon.items.armor.glyphs;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.blobs.ToxicGas;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.Armor.Glyph;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Stench extends Glyph {
    private static Glowing GREEN = null;
    private static final String TXT_STENCH = "%s of stench";

    static {
        GREEN = new Glowing(2280516);
    }

    public int proc(Armor armor, Char attacker, Char defender, int damage) {
        int level = Math.max(0, armor.level);
        if (Level.adjacent(attacker.pos, defender.pos) && Random.Int(level + 5) >= 4) {
            GameScene.add(Blob.seed(attacker.pos, 20, ToxicGas.class));
        }
        return damage;
    }

    public String name(String weaponName) {
        return String.format(TXT_STENCH, new Object[]{weaponName});
    }

    public Glowing glowing() {
        return GREEN;
    }
}
