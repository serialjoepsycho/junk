package com.watabou.pixeldungeon.items.armor.glyphs;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.Armor.Glyph;
import com.watabou.pixeldungeon.items.wands.WandOfBlink;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Displacement extends Glyph {
    private static Glowing BLUE = null;
    private static final String TXT_DISPLACEMENT = "%s of displacement";

    static {
        BLUE = new Glowing(6728447);
    }

    public int proc(Armor armor, Char attacker, Char defender, int damage) {
        if (!Dungeon.bossLevel()) {
            int nTries = (armor.level < 0 ? 1 : armor.level + 1) * 5;
            for (int i = 0; i < nTries; i++) {
                int pos = Random.Int(Level.LENGTH);
                if (Dungeon.visible[pos] && Level.passable[pos] && Actor.findChar(pos) == null) {
                    WandOfBlink.appear(defender, pos);
                    Dungeon.level.press(pos, defender);
                    Dungeon.observe();
                    break;
                }
            }
        }
        return damage;
    }

    public String name(String weaponName) {
        return String.format(TXT_DISPLACEMENT, new Object[]{weaponName});
    }

    public Glowing glowing() {
        return BLUE;
    }
}
