package com.watabou.pixeldungeon.items.armor.glyphs;

import com.watabou.noosa.Camera;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Roots;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.EarthParticle;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.Armor.Glyph;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.plants.Earthroot;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.utils.Random;

public class Entanglement extends Glyph {
    private static Glowing GREEN = null;
    private static final String TXT_ENTANGLEMENT = "%s of entanglement";

    static {
        GREEN = new Glowing(4491298);
    }

    public int proc(Armor armor, Char attacker, Char defender, int damage) {
        int level = Math.max(0, armor.level);
        if (Random.Int(4) == 0) {
            Buff.prolong(defender, Roots.class, (float) (5 - (level / 5)));
            ((Earthroot.Armor) Buff.affect(defender, Earthroot.Armor.class)).level((level + 1) * 5);
            CellEmitter.bottom(defender.pos).start(EarthParticle.FACTORY, 0.05f, 8);
            Camera.main.shake(Key.TIME_TO_UNLOCK, 0.4f);
        }
        return damage;
    }

    public String name(String weaponName) {
        return String.format(TXT_ENTANGLEMENT, new Object[]{weaponName});
    }

    public Glowing glowing() {
        return GREEN;
    }
}
