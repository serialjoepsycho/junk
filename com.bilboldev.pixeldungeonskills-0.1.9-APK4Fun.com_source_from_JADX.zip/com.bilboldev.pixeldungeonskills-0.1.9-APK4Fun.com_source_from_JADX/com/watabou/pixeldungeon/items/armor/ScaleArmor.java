package com.watabou.pixeldungeon.items.armor;

public class ScaleArmor extends Armor {
    public ScaleArmor() {
        super(4);
        this.name = "scale armor";
        this.image = 27;
    }

    public String desc() {
        return "The metal scales sewn onto a leather vest create a flexible, yet protective armor.";
    }
}
