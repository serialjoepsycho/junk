package com.watabou.pixeldungeon.items.armor;

import com.watabou.noosa.Camera;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Fury;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.buffs.Paralysis;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.hero.HeroSubClass;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.mechanics.Ballistica;
import com.watabou.pixeldungeon.scenes.CellSelector.Listener;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Callback;

public class WarriorArmor extends ClassArmor {
    private static final String AC_SPECIAL = "HEROIC LEAP";
    private static int LEAP_TIME = 0;
    private static int SHOCK_TIME = 0;
    private static final String TXT_NOT_WARRIOR = "Only warriors can use this armor!";
    protected static Listener leaper;

    /* renamed from: com.watabou.pixeldungeon.items.armor.WarriorArmor.1 */
    static class C00841 implements Listener {

        /* renamed from: com.watabou.pixeldungeon.items.armor.WarriorArmor.1.1 */
        class C00831 implements Callback {
            final /* synthetic */ int val$dest;

            C00831(int i) {
                this.val$dest = i;
            }

            public void call() {
                WarriorArmor.curUser.move(this.val$dest);
                Dungeon.level.press(this.val$dest, WarriorArmor.curUser);
                Dungeon.observe();
                for (int i : Level.NEIGHBOURS8) {
                    Char mob = Actor.findChar(WarriorArmor.curUser.pos + i);
                    if (!(mob == null || mob == WarriorArmor.curUser)) {
                        Buff.prolong(mob, Paralysis.class, (float) WarriorArmor.SHOCK_TIME);
                    }
                }
                CellEmitter.center(this.val$dest).burst(Speck.factory(ItemSpriteSheet.CURARE_DART), 10);
                Camera.main.shake(Pickaxe.TIME_TO_MINE, 0.5f);
                WarriorArmor.curUser.spendAndNext((float) WarriorArmor.LEAP_TIME);
            }
        }

        C00841() {
        }

        public void onSelect(Integer target) {
            if (target != null && target.intValue() != WarriorArmor.curUser.pos) {
                int cell = Ballistica.cast(WarriorArmor.curUser.pos, target.intValue(), false, true);
                if (!(Actor.findChar(cell) == null || cell == WarriorArmor.curUser.pos)) {
                    cell = Ballistica.trace[Ballistica.distance - 2];
                }
                Hero access$300 = WarriorArmor.curUser;
                access$300.HP -= WarriorArmor.curUser.HP / 3;
                if (WarriorArmor.curUser.subClass == HeroSubClass.BERSERKER && ((float) WarriorArmor.curUser.HP) <= ((float) WarriorArmor.curUser.HT) * Fury.LEVEL) {
                    Buff.affect(WarriorArmor.curUser, Fury.class);
                }
                Invisibility.dispel();
                int dest = cell;
                WarriorArmor.curUser.busy();
                WarriorArmor.curUser.sprite.jump(WarriorArmor.curUser.pos, cell, new C00831(dest));
            }
        }

        public String prompt() {
            return "Choose direction to leap";
        }
    }

    public WarriorArmor() {
        this.name = "warrior suit of armor";
        this.image = 97;
    }

    static {
        LEAP_TIME = 1;
        SHOCK_TIME = 3;
        leaper = new C00841();
    }

    public String special() {
        return AC_SPECIAL;
    }

    public void doSpecial() {
        GameScene.selectCell(leaper);
    }

    public boolean doEquip(Hero hero) {
        if (hero.heroClass == HeroClass.WARRIOR) {
            return super.doEquip(hero);
        }
        GLog.m4w(TXT_NOT_WARRIOR, new Object[0]);
        return false;
    }

    public String desc() {
        return "While this armor looks heavy, it allows a warrior to perform heroic leap towards a targeted location, slamming down to stun all neighbouring enemies.";
    }
}
