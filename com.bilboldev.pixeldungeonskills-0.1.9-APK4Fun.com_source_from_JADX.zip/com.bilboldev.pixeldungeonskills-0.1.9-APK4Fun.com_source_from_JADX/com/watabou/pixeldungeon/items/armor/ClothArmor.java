package com.watabou.pixeldungeon.items.armor;

public class ClothArmor extends Armor {
    public ClothArmor() {
        super(1);
        this.name = "cloth armor";
        this.image = 24;
    }

    public String desc() {
        return "This lightweight armor offers basic protection.";
    }
}
