package com.watabou.pixeldungeon.items.armor;

public class PlateArmor extends Armor {
    public PlateArmor() {
        super(5);
        this.name = "plate armor";
        this.image = 28;
    }

    public String desc() {
        return "Enormous plates of metal are joined together into a suit that provides unmatched protection to any adventurer strong enough to bear its staggering weight.";
    }
}
