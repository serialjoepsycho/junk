package com.watabou.pixeldungeon.items.armor;

import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundle;
import java.util.ArrayList;

public abstract class ClassArmor extends Armor {
    private static final String ARMOR_DR = "DR";
    private static final String ARMOR_STR = "STR";
    private static final String TXT_LOW_HEALTH = "Your health is too low!";
    private static final String TXT_NOT_EQUIPPED = "You need to be wearing this armor to use its special power!";

    /* renamed from: com.watabou.pixeldungeon.items.armor.ClassArmor.1 */
    static /* synthetic */ class C00801 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass;

        static {
            $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass = new int[HeroClass.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.WARRIOR.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.ROGUE.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.MAGE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.HUNTRESS.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
        }
    }

    public abstract void doSpecial();

    public abstract String special();

    public ClassArmor() {
        super(6);
        this.levelKnown = true;
        this.cursedKnown = true;
        this.defaultAction = special();
    }

    public static ClassArmor upgrade(Hero owner, Armor armor) {
        ClassArmor classArmor = null;
        switch (C00801.$SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[owner.heroClass.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
                classArmor = new WarriorArmor();
                break;
            case WndUpdates.ID_CAVES /*2*/:
                classArmor = new RogueArmor();
                break;
            case WndUpdates.ID_METROPOLIS /*3*/:
                classArmor = new MageArmor();
                break;
            case WndUpdates.ID_HALLS /*4*/:
                classArmor = new HuntressArmor();
                break;
        }
        classArmor.STR = armor.STR;
        classArmor.DR = armor.DR;
        classArmor.inscribe(armor.glyph);
        return classArmor;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(ARMOR_STR, this.STR);
        bundle.put(ARMOR_DR, this.DR);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.STR = bundle.getInt(ARMOR_STR);
        this.DR = bundle.getInt(ARMOR_DR);
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (hero.HP >= 3 && isEquipped(hero)) {
            actions.add(special());
        }
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action != special()) {
            super.execute(hero, action);
        } else if (hero.HP < 3) {
            GLog.m4w(TXT_LOW_HEALTH, new Object[0]);
        } else if (isEquipped(hero)) {
            curUser = hero;
            doSpecial();
        } else {
            GLog.m4w(TXT_NOT_EQUIPPED, new Object[0]);
        }
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public int price() {
        return 0;
    }

    public String desc() {
        return "The thing looks awesome!";
    }
}
