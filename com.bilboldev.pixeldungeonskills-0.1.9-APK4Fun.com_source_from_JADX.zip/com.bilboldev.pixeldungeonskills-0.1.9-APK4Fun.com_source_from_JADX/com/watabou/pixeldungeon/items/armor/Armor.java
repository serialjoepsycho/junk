package com.watabou.pixeldungeon.items.armor;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.EquipableItem;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.armor.glyphs.Affection;
import com.watabou.pixeldungeon.items.armor.glyphs.AntiEntropy;
import com.watabou.pixeldungeon.items.armor.glyphs.Bounce;
import com.watabou.pixeldungeon.items.armor.glyphs.Displacement;
import com.watabou.pixeldungeon.items.armor.glyphs.Entanglement;
import com.watabou.pixeldungeon.items.armor.glyphs.Metabolism;
import com.watabou.pixeldungeon.items.armor.glyphs.Multiplicity;
import com.watabou.pixeldungeon.items.armor.glyphs.Potential;
import com.watabou.pixeldungeon.items.armor.glyphs.Stench;
import com.watabou.pixeldungeon.items.armor.glyphs.Viscosity;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.sprites.HeroSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class Armor extends EquipableItem {
    private static final String GLYPH = "glyph";
    private static final int HITS_TO_KNOW = 10;
    private static final String TXT_EQUIP_CURSED = "your %s constricts around you painfully";
    private static final String TXT_IDENTIFY = "you are now familiar enough with your %s to identify it. It is %s.";
    private static final String TXT_INCOMPATIBLE = "Interaction of different types of magic has erased the glyph on this armor!";
    private static final String TXT_TO_STRING = "%s :%d";
    private static final String UNFAMILIRIARITY = "unfamiliarity";
    public int DR;
    public int STR;
    public Glyph glyph;
    private int hitsToKnow;
    public int tier;

    public static abstract class Glyph implements Bundlable {
        private static final float[] chances;
        private static final Class<?>[] glyphs;

        public abstract int proc(Armor armor, Char charR, Char charR2, int i);

        static {
            Class[] clsArr = new Class[Armor.HITS_TO_KNOW];
            clsArr[0] = Bounce.class;
            clsArr[1] = Affection.class;
            clsArr[2] = AntiEntropy.class;
            clsArr[3] = Multiplicity.class;
            clsArr[4] = Potential.class;
            clsArr[5] = Metabolism.class;
            clsArr[6] = Stench.class;
            clsArr[7] = Viscosity.class;
            clsArr[8] = Displacement.class;
            clsArr[9] = Entanglement.class;
            glyphs = clsArr;
            chances = new float[]{Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK};
        }

        public String name(String armorName) {
            return armorName;
        }

        public void restoreFromBundle(Bundle bundle) {
        }

        public void storeInBundle(Bundle bundle) {
        }

        public Glowing glowing() {
            return Glowing.WHITE;
        }

        public boolean checkOwner(Char owner) {
            if (owner.isAlive() || !(owner instanceof Hero)) {
                return false;
            }
            ((Hero) owner).killerGlyph = this;
            Badges.validateDeathFromGlyph();
            return true;
        }

        public static Glyph random() {
            try {
                return (Glyph) glyphs[Random.chances(chances)].newInstance();
            } catch (Exception e) {
                return null;
            }
        }
    }

    public Armor(int tier) {
        this.hitsToKnow = HITS_TO_KNOW;
        this.tier = tier;
        this.STR = typicalSTR();
        this.DR = typicalDR();
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(UNFAMILIRIARITY, this.hitsToKnow);
        bundle.put(GLYPH, this.glyph);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        int i = bundle.getInt(UNFAMILIRIARITY);
        this.hitsToKnow = i;
        if (i == 0) {
            this.hitsToKnow = HITS_TO_KNOW;
        }
        inscribe((Glyph) bundle.get(GLYPH));
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(isEquipped(hero) ? EquipableItem.AC_UNEQUIP : EquipableItem.AC_EQUIP);
        return actions;
    }

    public boolean doEquip(Hero hero) {
        detach(hero.belongings.backpack);
        if (hero.belongings.armor == null || hero.belongings.armor.doUnequip(hero, true, false)) {
            hero.belongings.armor = this;
            this.cursedKnown = true;
            if (this.cursed) {
                EquipableItem.equipCursed(hero);
                GLog.m2n(TXT_EQUIP_CURSED, toString());
            }
            ((HeroSprite) hero.sprite).updateArmor();
            hero.spendAndNext(time2equip(hero));
            return true;
        }
        collect(hero.belongings.backpack);
        return false;
    }

    protected float time2equip(Hero hero) {
        return Pickaxe.TIME_TO_MINE / hero.speed();
    }

    public boolean doUnequip(Hero hero, boolean collect, boolean single) {
        if (!super.doUnequip(hero, collect, single)) {
            return false;
        }
        hero.belongings.armor = null;
        ((HeroSprite) hero.sprite).updateArmor();
        return true;
    }

    public boolean isEquipped(Hero hero) {
        return hero.belongings.armor == this;
    }

    public Item upgrade() {
        return upgrade(false);
    }

    public Item upgrade(boolean inscribe) {
        if (this.glyph != null) {
            if (!inscribe && Random.Int(this.level) > 0) {
                GLog.m4w(TXT_INCOMPATIBLE, new Object[0]);
                inscribe(null);
            }
        } else if (inscribe) {
            inscribe();
        }
        this.DR += this.tier;
        this.STR--;
        return super.upgrade();
    }

    public Item safeUpgrade() {
        return upgrade(this.glyph != null);
    }

    public Item degrade() {
        this.DR -= this.tier;
        this.STR++;
        return super.degrade();
    }

    public int maxDurability(int lvl) {
        return (lvl < 16 ? 16 - lvl : 1) * 6;
    }

    public int proc(Char attacker, Char defender, int damage) {
        if (this.glyph != null) {
            damage = this.glyph.proc(this, attacker, defender, damage);
        }
        if (!this.levelKnown) {
            int i = this.hitsToKnow - 1;
            this.hitsToKnow = i;
            if (i <= 0) {
                this.levelKnown = true;
                GLog.m4w(TXT_IDENTIFY, name(), toString());
                Badges.validateItemLevelAquired(this);
            }
        }
        use();
        return damage;
    }

    public String toString() {
        if (!this.levelKnown) {
            return super.toString();
        }
        return Utils.format(TXT_TO_STRING, super.toString(), Integer.valueOf(this.STR));
    }

    public String name() {
        return this.glyph == null ? super.name() : this.glyph.name(super.name());
    }

    public String info() {
        String name = name();
        StringBuilder info = new StringBuilder(desc());
        if (this.levelKnown) {
            info.append("\n\nThis " + name + " provides damage absorption up to " + BuildConfig.VERSION_NAME + Math.max(this.DR, 0) + " points per attack. ");
            if (this.STR > Dungeon.hero.STR()) {
                if (isEquipped(Dungeon.hero)) {
                    info.append("\n\nBecause of your inadequate strength your movement speed and defense skill is decreased. ");
                } else {
                    info.append("\n\nBecause of your inadequate strength wearing this armor will decrease your movement speed and defense skill. ");
                }
            }
        } else {
            info.append("\n\nTypical " + name + " provides damage absorption up to " + typicalDR() + " points per attack " + " and requires " + typicalSTR() + " points of strength. ");
            if (typicalSTR() > Dungeon.hero.STR()) {
                info.append("Probably this armor is too heavy for you. ");
            }
        }
        if (this.glyph != null) {
            info.append("It is enchanted.");
        }
        if (isEquipped(Dungeon.hero)) {
            info.append("\n\nYou are wearing the " + name + (this.cursed ? ", and because it is cursed, you are powerless to remove it." : "."));
        } else if (this.cursedKnown && this.cursed) {
            info.append("\n\nYou can feel a malevolent magic lurking within the " + name + ".");
        }
        return info.toString();
    }

    public Item random() {
        if (((double) Random.Float()) < 0.4d) {
            int n = 1;
            if (Random.Int(3) == 0) {
                n = 1 + 1;
                if (Random.Int(3) == 0) {
                    n++;
                }
            }
            if (Random.Int(2) == 0) {
                upgrade(n);
            } else {
                degrade(n);
                this.cursed = true;
            }
        }
        if (Random.Int(HITS_TO_KNOW) == 0) {
            inscribe();
        }
        return this;
    }

    public int typicalSTR() {
        return (this.tier * 2) + 7;
    }

    public int typicalDR() {
        return this.tier * 2;
    }

    public int price() {
        int price = (1 << (this.tier - 1)) * HITS_TO_KNOW;
        if (this.glyph != null) {
            price = (int) (((double) price) * 1.5d);
        }
        if (this.cursed && this.cursedKnown) {
            price /= 2;
        }
        if (this.levelKnown) {
            if (this.level > 0) {
                price *= this.level + 1;
            } else if (this.level < 0) {
                price /= 1 - this.level;
            }
        }
        if (price < 1) {
            return 1;
        }
        return price;
    }

    public Armor inscribe(Glyph glyph) {
        if (glyph != null && this.glyph == null) {
            this.DR += this.tier;
        } else if (glyph == null && this.glyph != null) {
            this.DR -= this.tier;
        }
        this.glyph = glyph;
        return this;
    }

    public Armor inscribe() {
        Class<? extends Glyph> oldGlyphClass = this.glyph != null ? this.glyph.getClass() : null;
        Glyph gl = Glyph.random();
        while (gl.getClass() == oldGlyphClass) {
            gl = Glyph.random();
        }
        return inscribe(gl);
    }

    public boolean isInscribed() {
        return this.glyph != null;
    }

    public Glowing glowing() {
        return this.glyph != null ? this.glyph.glowing() : null;
    }
}
