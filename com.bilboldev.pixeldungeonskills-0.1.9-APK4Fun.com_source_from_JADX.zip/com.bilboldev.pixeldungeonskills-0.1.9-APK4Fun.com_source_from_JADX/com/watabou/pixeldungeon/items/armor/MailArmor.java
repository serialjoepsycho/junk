package com.watabou.pixeldungeon.items.armor;

public class MailArmor extends Armor {
    public MailArmor() {
        super(3);
        this.name = "mail armor";
        this.image = 26;
    }

    public String desc() {
        return "Interlocking metal links make for a tough but flexible suit of armor.";
    }
}
