package com.watabou.pixeldungeon.items.armor;

public class LeatherArmor extends Armor {
    public LeatherArmor() {
        super(2);
        this.name = "leather armor";
        this.image = 25;
    }

    public String desc() {
        return "Armor made from tanned monster hide. Not as light as cloth armor but provides better protection.";
    }
}
