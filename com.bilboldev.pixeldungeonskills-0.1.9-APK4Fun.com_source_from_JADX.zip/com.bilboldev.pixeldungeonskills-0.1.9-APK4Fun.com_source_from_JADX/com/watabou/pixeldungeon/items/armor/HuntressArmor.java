package com.watabou.pixeldungeon.items.armor;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.weapon.missiles.Shuriken;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.sprites.MissileSprite;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Callback;
import java.util.HashMap;
import java.util.Iterator;

public class HuntressArmor extends ClassArmor {
    private static final String AC_SPECIAL = "SPECTRAL BLADES";
    private static final String TXT_NOT_HUNTRESS = "Only huntresses can use this armor!";
    private static final String TXT_NO_ENEMIES = "No enemies in sight";
    private HashMap<Callback, Mob> targets;

    /* renamed from: com.watabou.pixeldungeon.items.armor.HuntressArmor.1 */
    class C00811 implements Callback {
        C00811() {
        }

        public void call() {
            HuntressArmor.curUser.attack((Char) HuntressArmor.this.targets.get(this));
            HuntressArmor.this.targets.remove(this);
            if (HuntressArmor.this.targets.isEmpty()) {
                HuntressArmor.curUser.spendAndNext(HuntressArmor.curUser.attackDelay());
            }
        }
    }

    public HuntressArmor() {
        this.name = "huntress cloak";
        this.image = 99;
        this.targets = new HashMap();
    }

    public String special() {
        return AC_SPECIAL;
    }

    public void doSpecial() {
        Item proto = new Shuriken();
        Iterator it = Dungeon.level.mobs.iterator();
        while (it.hasNext()) {
            Mob mob = (Mob) it.next();
            if (Level.fieldOfView[mob.pos]) {
                Callback callback = new C00811();
                ((MissileSprite) curUser.sprite.parent.recycle(MissileSprite.class)).reset(curUser.pos, mob.pos, proto, callback);
                this.targets.put(callback, mob);
            }
        }
        if (this.targets.size() == 0) {
            GLog.m4w(TXT_NO_ENEMIES, new Object[0]);
            return;
        }
        Hero hero = curUser;
        hero.HP -= curUser.HP / 3;
        curUser.sprite.zap(curUser.pos);
        curUser.busy();
    }

    public boolean doEquip(Hero hero) {
        if (hero.heroClass == HeroClass.HUNTRESS) {
            return super.doEquip(hero);
        }
        GLog.m4w(TXT_NOT_HUNTRESS, new Object[0]);
        return false;
    }

    public String desc() {
        return "A huntress in such cloak can create a fan of spectral blades. Each of these blades will target a single enemy in the huntress's field of view, inflicting damage depending on her currently equipped melee weapon.";
    }
}
