package com.watabou.pixeldungeon.items.armor;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.buffs.Blindness;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.wands.WandOfBlink;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.CellSelector.Listener;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.utils.GLog;
import java.util.Iterator;

public class RogueArmor extends ClassArmor {
    private static final String AC_SPECIAL = "SMOKE BOMB";
    private static final String TXT_FOV = "You can only jump to an empty location in your field of view";
    private static final String TXT_NOT_ROGUE = "Only rogues can use this armor!";
    protected static Listener teleporter;

    /* renamed from: com.watabou.pixeldungeon.items.armor.RogueArmor.1 */
    static class C00821 implements Listener {
        C00821() {
        }

        public void onSelect(Integer target) {
            if (target == null) {
                return;
            }
            if (Level.fieldOfView[target.intValue()] && ((Level.passable[target.intValue()] || Level.avoid[target.intValue()]) && Actor.findChar(target.intValue()) == null)) {
                Hero access$000 = RogueArmor.curUser;
                access$000.HP -= RogueArmor.curUser.HP / 3;
                Iterator it = Dungeon.level.mobs.iterator();
                while (it.hasNext()) {
                    Mob mob = (Mob) it.next();
                    if (Level.fieldOfView[mob.pos]) {
                        Buff.prolong(mob, Blindness.class, Pickaxe.TIME_TO_MINE);
                        mob.state = mob.WANDERING;
                        mob.sprite.emitter().burst(Speck.factory(2), 4);
                    }
                }
                WandOfBlink.appear(RogueArmor.curUser, target.intValue());
                CellEmitter.get(target.intValue()).burst(Speck.factory(7), 10);
                Sample.INSTANCE.play(Assets.SND_PUFF);
                Dungeon.level.press(target.intValue(), RogueArmor.curUser);
                Dungeon.observe();
                RogueArmor.curUser.spendAndNext(Key.TIME_TO_UNLOCK);
                return;
            }
            GLog.m4w(RogueArmor.TXT_FOV, new Object[0]);
        }

        public String prompt() {
            return "Choose a location to jump to";
        }
    }

    public RogueArmor() {
        this.name = "rogue garb";
        this.image = 96;
    }

    public String special() {
        return AC_SPECIAL;
    }

    public void doSpecial() {
        GameScene.selectCell(teleporter);
    }

    public boolean doEquip(Hero hero) {
        if (hero.heroClass == HeroClass.ROGUE) {
            return super.doEquip(hero);
        }
        GLog.m4w(TXT_NOT_ROGUE, new Object[0]);
        return false;
    }

    public String desc() {
        return "Wearing this dark garb, a rogue can perform a trick, that is called \"smoke bomb\" (though no real explosives are used): he blinds enemies who could see him and jumps aside.";
    }

    static {
        teleporter = new C00821();
    }
}
