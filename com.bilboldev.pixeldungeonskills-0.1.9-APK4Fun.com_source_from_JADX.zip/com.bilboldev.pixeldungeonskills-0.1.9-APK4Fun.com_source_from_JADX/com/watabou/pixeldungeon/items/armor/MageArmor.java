package com.watabou.pixeldungeon.items.armor;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Burning;
import com.watabou.pixeldungeon.actors.buffs.Roots;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.effects.particles.ElmoParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.utils.GLog;
import java.util.Iterator;

public class MageArmor extends ClassArmor {
    private static final String AC_SPECIAL = "MOLTEN EARTH";
    private static final String TXT_NOT_MAGE = "Only mages can use this armor!";

    public MageArmor() {
        this.name = "mage robe";
        this.image = 98;
    }

    public String special() {
        return AC_SPECIAL;
    }

    public String desc() {
        return "Wearing this gorgeous robe, a mage can cast a spell of molten earth: all the enemies in his field of view will be set on fire and unable to move at the same time.";
    }

    public void doSpecial() {
        Iterator it = Dungeon.level.mobs.iterator();
        while (it.hasNext()) {
            Mob mob = (Mob) it.next();
            if (Level.fieldOfView[mob.pos]) {
                ((Burning) Buff.affect(mob, Burning.class)).reignite(mob);
                Buff.prolong(mob, Roots.class, CurareDart.DURATION);
            }
        }
        Hero hero = curUser;
        hero.HP -= curUser.HP / 3;
        curUser.spend(Key.TIME_TO_UNLOCK);
        curUser.sprite.operate(curUser.pos);
        curUser.busy();
        curUser.sprite.centerEmitter().start(ElmoParticle.FACTORY, 0.15f, 4);
        Sample.INSTANCE.play(Assets.SND_READ);
    }

    public boolean doEquip(Hero hero) {
        if (hero.heroClass == HeroClass.MAGE) {
            return super.doEquip(hero);
        }
        GLog.m4w(TXT_NOT_MAGE, new Object[0]);
        return false;
    }
}
