package com.watabou.pixeldungeon.items;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.sprites.CharSprite;

public class Dewdrop extends Item {
    private static final String TXT_VALUE = "%+dHP";

    public Dewdrop() {
        this.name = "dewdrop";
        this.image = 81;
        this.stackable = true;
    }

    public boolean doPickUp(Hero hero) {
        DewVial vial = (DewVial) hero.belongings.getItem(DewVial.class);
        if (hero.HP < hero.HT || vial == null || vial.isFull()) {
            int value = ((Dungeon.depth - 1) / 5) + 1;
            if (hero.heroClass == HeroClass.HUNTRESS) {
                value++;
            }
            int effect = Math.min(hero.HT - hero.HP, this.quantity * value);
            if (effect > 0) {
                hero.HP += effect;
                hero.sprite.emitter().burst(Speck.factory(0), 1);
                hero.sprite.showStatus(CharSprite.POSITIVE, TXT_VALUE, Integer.valueOf(effect));
            }
        } else if (vial != null) {
            vial.collectDew(this);
        }
        Sample.INSTANCE.play(Assets.SND_DEWDROP);
        hero.spendAndNext(Key.TIME_TO_UNLOCK);
        return true;
    }

    public String info() {
        return "A crystal clear dewdrop.";
    }
}
