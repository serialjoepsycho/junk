package com.watabou.pixeldungeon.items.food;

import com.watabou.pixeldungeon.actors.buffs.Barkskin;
import com.watabou.pixeldungeon.actors.buffs.Bleeding;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Cripple;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.buffs.Poison;
import com.watabou.pixeldungeon.actors.buffs.Weakness;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Random;

public class FrozenCarpaccio extends Food {
    public FrozenCarpaccio() {
        this.name = "frozen carpaccio";
        this.image = ItemSpriteSheet.CARPACCIO;
        this.energy = 100.0f;
    }

    public void execute(Hero hero, String action) {
        super.execute(hero, action);
        if (action.equals(Food.AC_EAT)) {
            switch (Random.Int(5)) {
                case WndUpdates.ID_SEWERS /*0*/:
                    GLog.m1i("You see your hands turn invisible!", new Object[0]);
                    Buff.affect(hero, Invisibility.class, Invisibility.DURATION);
                case WndUpdates.ID_PRISON /*1*/:
                    GLog.m1i("You feel your skin hardens!", new Object[0]);
                    ((Barkskin) Buff.affect(hero, Barkskin.class)).level(hero.HT / 4);
                case WndUpdates.ID_CAVES /*2*/:
                    GLog.m1i("Refreshing!", new Object[0]);
                    Buff.detach(hero, Poison.class);
                    Buff.detach(hero, Cripple.class);
                    Buff.detach(hero, Weakness.class);
                    Buff.detach(hero, Bleeding.class);
                case WndUpdates.ID_METROPOLIS /*3*/:
                    GLog.m1i("You feel better!", new Object[0]);
                    if (hero.HP < hero.HT) {
                        hero.HP = Math.min(hero.HP + (hero.HT / 4), hero.HT);
                        hero.sprite.emitter().burst(Speck.factory(0), 1);
                    }
                default:
            }
        }
    }

    public String info() {
        return "It's a piece of frozen raw meat. The only way to eat it is by cutting thin slices of it. And this way it's suprisingly good.";
    }

    public int price() {
        return this.quantity * 10;
    }

    public static Food cook(MysteryMeat ingredient) {
        FrozenCarpaccio result = new FrozenCarpaccio();
        result.quantity = ingredient.quantity();
        return result;
    }
}
