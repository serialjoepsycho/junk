package com.watabou.pixeldungeon.items.food;

import com.watabou.pixeldungeon.actors.buffs.Hunger;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class Pasty extends Food {
    public Pasty() {
        this.name = "pasty";
        this.image = ItemSpriteSheet.PASTY;
        this.energy = Hunger.STARVING;
    }

    public String info() {
        return "This is authentic Cornish pasty with traditional filling of beef and potato.";
    }

    public int price() {
        return this.quantity * 20;
    }
}
