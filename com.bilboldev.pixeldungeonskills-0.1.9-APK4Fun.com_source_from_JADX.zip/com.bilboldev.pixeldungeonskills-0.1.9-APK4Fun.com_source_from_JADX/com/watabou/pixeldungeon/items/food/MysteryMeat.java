package com.watabou.pixeldungeon.items.food;

import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Burning;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.buffs.Paralysis;
import com.watabou.pixeldungeon.actors.buffs.Poison;
import com.watabou.pixeldungeon.actors.buffs.Roots;
import com.watabou.pixeldungeon.actors.buffs.Slow;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Random;

public class MysteryMeat extends Food {
    public MysteryMeat() {
        this.name = "mystery meat";
        this.image = ItemSpriteSheet.MEAT;
        this.energy = 100.0f;
        this.message = "That food tasted... strange.";
    }

    public void execute(Hero hero, String action) {
        super.execute(hero, action);
        if (action.equals(Food.AC_EAT)) {
            switch (Random.Int(5)) {
                case WndUpdates.ID_SEWERS /*0*/:
                    GLog.m4w("Oh it's hot!", new Object[0]);
                    ((Burning) Buff.affect(hero, Burning.class)).reignite(hero);
                case WndUpdates.ID_PRISON /*1*/:
                    GLog.m4w("You can't feel your legs!", new Object[0]);
                    Buff.prolong(hero, Roots.class, Paralysis.duration(hero));
                case WndUpdates.ID_CAVES /*2*/:
                    GLog.m4w("You are not feeling well.", new Object[0]);
                    ((Poison) Buff.affect(hero, Poison.class)).set((Poison.durationFactor(hero) * ((float) hero.HT)) / GasesImmunity.DURATION);
                case WndUpdates.ID_METROPOLIS /*3*/:
                    GLog.m4w("You are stuffed.", new Object[0]);
                    Buff.prolong(hero, Slow.class, Slow.duration(hero));
                default:
            }
        }
    }

    public String info() {
        return "Eat at your own risk!";
    }

    public int price() {
        return this.quantity * 5;
    }
}
