package com.watabou.pixeldungeon.items.food;

import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class HuntedMeat extends Food {
    public HuntedMeat() {
        this.name = "animal meat";
        this.image = ItemSpriteSheet.MEAT;
        this.energy = 100.0f;
        this.message = "Animal meat tasted good.";
    }

    public void execute(Hero hero, String action) {
        super.execute(hero, action);
    }

    public String info() {
        return "Hunted animal meat looks good";
    }

    public int price() {
        return this.quantity * 5;
    }
}
