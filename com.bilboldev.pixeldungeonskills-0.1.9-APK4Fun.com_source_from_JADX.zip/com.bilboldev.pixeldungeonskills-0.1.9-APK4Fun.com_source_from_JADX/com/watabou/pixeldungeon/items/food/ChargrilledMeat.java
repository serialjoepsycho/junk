package com.watabou.pixeldungeon.items.food;

import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class ChargrilledMeat extends Food {
    public ChargrilledMeat() {
        this.name = "chargrilled meat";
        this.image = ItemSpriteSheet.STEAK;
        this.energy = 100.0f;
    }

    public String info() {
        return "It looks like a decent steak.";
    }

    public int price() {
        return this.quantity * 5;
    }

    public static Food cook(MysteryMeat ingredient) {
        ChargrilledMeat result = new ChargrilledMeat();
        result.quantity = ingredient.quantity();
        return result;
    }
}
