package com.watabou.pixeldungeon.items.food;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Statistics;
import com.watabou.pixeldungeon.actors.buffs.Hunger;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.SpellSprite;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfRecharging;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndUpdates;
import java.util.ArrayList;

public class Food extends Item {
    public static final String AC_EAT = "EAT";
    private static final float TIME_TO_EAT = 3.0f;
    public float energy;
    public String message;

    /* renamed from: com.watabou.pixeldungeon.items.food.Food.1 */
    static /* synthetic */ class C00861 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass;

        static {
            $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass = new int[HeroClass.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.WARRIOR.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.MAGE.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.ROGUE.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[HeroClass.HUNTRESS.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
        }
    }

    public Food() {
        this.energy = Hunger.HUNGRY;
        this.message = "That food tasted delicious!";
        this.stackable = true;
        this.name = "ration of food";
        this.image = 4;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_EAT);
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action.equals(AC_EAT)) {
            detach(hero.belongings.backpack);
            ((Hunger) hero.buff(Hunger.class)).satisfy(this.energy);
            GLog.m1i(this.message, new Object[0]);
            switch (C00861.$SwitchMap$com$watabou$pixeldungeon$actors$hero$HeroClass[hero.heroClass.ordinal()]) {
                case WndUpdates.ID_PRISON /*1*/:
                    if (hero.HP < hero.HT) {
                        hero.HP = Math.min(hero.HP + 5, hero.HT);
                        hero.sprite.emitter().burst(Speck.factory(0), 1);
                        break;
                    }
                    break;
                case WndUpdates.ID_CAVES /*2*/:
                    hero.belongings.charge(false);
                    ScrollOfRecharging.charge(hero);
                    break;
            }
            hero.sprite.operate(hero.pos);
            hero.busy();
            SpellSprite.show(hero, 0);
            Sample.INSTANCE.play(Assets.SND_EAT);
            hero.spend(TIME_TO_EAT);
            Statistics.foodEaten++;
            Badges.validateFoodEaten();
            return;
        }
        super.execute(hero, action);
    }

    public String info() {
        return "Nothing fancy here: dried meat, some biscuits - things like that.";
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public int price() {
        return this.quantity * 10;
    }
}
