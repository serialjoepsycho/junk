package com.watabou.pixeldungeon.items.food;

import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;

public class OverpricedRation extends Food {
    public OverpricedRation() {
        this.name = "overpriced food ration";
        this.image = ItemSpriteSheet.OVERPRICED;
        this.energy = 100.0f;
        this.message = "That food tasted ok.";
    }

    public String info() {
        return "It looks exactly like a standard ration of food but smaller.";
    }

    public int price() {
        return this.quantity * 20;
    }
}
