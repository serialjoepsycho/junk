package com.watabou.pixeldungeon.items;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.utils.Random;

public class RemoteBomb extends Item {
    public RemoteBomb() {
        this.name = "remote bomb";
        this.image = ItemSpriteSheet.RemoteBomb;
        this.defaultAction = Item.AC_THROW;
        this.stackable = true;
    }

    protected void onThrow(int cell) {
        if (Level.pit[cell]) {
            super.onThrow(cell);
            return;
        }
        RemoteBombGround tmp = new RemoteBombGround();
        tmp.pos = cell;
        Dungeon.level.drop(tmp, cell).sprite.drop();
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public Item random() {
        this.quantity = Random.Int(1, 1);
        return this;
    }

    public int price() {
        return this.quantity * 10;
    }

    public String info() {
        return "After being thrown, this bomb will explode once it receives a signal from a trigger beacon.";
    }
}
