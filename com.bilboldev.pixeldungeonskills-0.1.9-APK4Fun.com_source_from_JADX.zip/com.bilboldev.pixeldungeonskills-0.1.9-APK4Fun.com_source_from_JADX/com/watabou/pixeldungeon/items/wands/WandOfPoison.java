package com.watabou.pixeldungeon.items.wands;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Poison;
import com.watabou.pixeldungeon.effects.MagicMissile;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Callback;

public class WandOfPoison extends Wand {
    public WandOfPoison() {
        this.name = "Wand of Poison";
    }

    protected void onZap(int cell) {
        Char ch = Actor.findChar(cell);
        if (ch != null) {
            ((Poison) Buff.affect(ch, Poison.class)).set(Poison.durationFactor(ch) * ((float) (level() + 5)));
        } else {
            GLog.m1i("nothing happened", new Object[0]);
        }
    }

    protected void fx(int cell, Callback callback) {
        MagicMissile.poison(curUser.sprite.parent, curUser.pos, cell, callback);
        Sample.INSTANCE.play(Assets.SND_ZAP);
    }

    public String desc() {
        return "The vile blast of this twisted bit of wood will imbue its target with a deadly venom. A creature that is poisoned will suffer periodic damage until the effect ends. The duration of the effect increases with the level of the staff.";
    }
}
