package com.watabou.pixeldungeon.items.wands;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.effects.MagicMissile;
import com.watabou.pixeldungeon.items.EquipableItem;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.ItemStatusHandler;
import com.watabou.pixeldungeon.items.KindOfWeapon;
import com.watabou.pixeldungeon.items.bags.Bag;
import com.watabou.pixeldungeon.items.rings.RingOfPower.Power;
import com.watabou.pixeldungeon.mechanics.Ballistica;
import com.watabou.pixeldungeon.scenes.CellSelector.Listener;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.ui.QuickSlot;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Bundle;
import com.watabou.utils.Callback;
import com.watabou.utils.Random;
import java.util.ArrayList;

public abstract class Wand extends KindOfWeapon {
    public static final String AC_ZAP = "ZAP";
    private static final String CUR_CHARGES = "curCharges";
    private static final String CUR_CHARGE_KNOWN = "curChargeKnown";
    private static final String MAX_CHARGES = "maxCharges";
    private static final float TIME_TO_ZAP = 1.0f;
    private static final String TXT_DAMAGE = "When this wand is used as a melee weapon, its average damage is %d points per hit.";
    private static final String TXT_FIZZLES = "your wand fizzles; it must be out of charges for now";
    private static final String TXT_IDENTIFY = "You are now familiar enough with your %s.";
    private static final String TXT_SELF_TARGET = "You can't target yourself";
    private static final String TXT_WEAPON = "You can use this wand as a melee weapon.";
    private static final String TXT_WOOD = "This thin %s wand is warm to the touch. Who knows what it will do when used?";
    private static final String UNFAMILIRIARITY = "unfamiliarity";
    private static final int USAGES_TO_KNOW = 40;
    private static ItemStatusHandler<Wand> handler;
    private static final Integer[] images;
    private static final Class<?>[] wands;
    private static final String[] woods;
    protected static Listener zapper;
    protected Charger charger;
    private boolean curChargeKnown;
    public int curCharges;
    protected boolean hitChars;
    public int maxCharges;
    private int usagesToKnow;
    private String wood;

    /* renamed from: com.watabou.pixeldungeon.items.wands.Wand.1 */
    static class C00941 implements Listener {

        /* renamed from: com.watabou.pixeldungeon.items.wands.Wand.1.1 */
        class C00931 implements Callback {
            final /* synthetic */ int val$cell;
            final /* synthetic */ Wand val$curWand;

            C00931(Wand wand, int i) {
                this.val$curWand = wand;
                this.val$cell = i;
            }

            public void call() {
                this.val$curWand.onZap(this.val$cell);
                this.val$curWand.wandUsed();
            }
        }

        C00941() {
        }

        public void onSelect(Integer target) {
            if (target == null) {
                return;
            }
            if (target.intValue() == Wand.curUser.pos) {
                GLog.m1i(Wand.TXT_SELF_TARGET, new Object[0]);
                return;
            }
            Wand curWand = (Wand) Wand.curItem;
            curWand.setKnown();
            int cell = Ballistica.cast(Wand.curUser.pos, target.intValue(), true, curWand.hitChars);
            Wand.curUser.sprite.zap(cell);
            QuickSlot.target(Wand.curItem, Actor.findChar(cell));
            if (curWand.curCharges > 0) {
                Wand.curUser.busy();
                curWand.fx(cell, new C00931(curWand, cell));
                Invisibility.dispel();
                return;
            }
            Wand.curUser.spendAndNext(Wand.TIME_TO_ZAP);
            GLog.m4w(Wand.TXT_FIZZLES, new Object[0]);
            curWand.levelKnown = true;
            curWand.updateQuickslot();
        }

        public String prompt() {
            return "Choose direction to zap";
        }
    }

    protected class Charger extends Buff {
        private static final float TIME_TO_CHARGE = 40.0f;

        protected Charger() {
        }

        public boolean attachTo(Char target) {
            super.attachTo(target);
            delay();
            return true;
        }

        public boolean act() {
            if (Wand.this.curCharges < Wand.this.maxCharges) {
                Wand wand = Wand.this;
                wand.curCharges++;
                Wand.this.updateQuickslot();
            }
            delay();
            return true;
        }

        protected void delay() {
            float time2charge = TIME_TO_CHARGE;
            if (((Hero) this.target).heroClass == HeroClass.MAGE) {
                time2charge = TIME_TO_CHARGE / ((float) Math.sqrt((double) (Wand.this.level + 1)));
            }
            spend(time2charge);
        }
    }

    protected abstract void onZap(int i);

    static {
        wands = new Class[]{WandOfTeleportation.class, WandOfSlowness.class, WandOfFirebolt.class, WandOfPoison.class, WandOfRegrowth.class, WandOfBlink.class, WandOfLightning.class, WandOfAmok.class, WandOfTelekinesis.class, WandOfFlock.class, WandOfDisintegration.class, WandOfAvalanche.class};
        woods = new String[]{"holly", "yew", "ebony", "cherry", "teak", "rowan", "willow", "mahogany", "bamboo", "purpleheart", "oak", "birch"};
        images = new Integer[]{Integer.valueOf(48), Integer.valueOf(49), Integer.valueOf(50), Integer.valueOf(51), Integer.valueOf(52), Integer.valueOf(53), Integer.valueOf(54), Integer.valueOf(55), Integer.valueOf(68), Integer.valueOf(69), Integer.valueOf(70), Integer.valueOf(71)};
        zapper = new C00941();
    }

    public static void initWoods() {
        handler = new ItemStatusHandler(wands, woods, images);
    }

    public static void save(Bundle bundle) {
        handler.save(bundle);
    }

    public static void restore(Bundle bundle) {
        handler = new ItemStatusHandler(wands, woods, images, bundle);
    }

    public Wand() {
        this.maxCharges = initialCharges();
        this.curCharges = this.maxCharges;
        this.curChargeKnown = false;
        this.usagesToKnow = USAGES_TO_KNOW;
        this.hitChars = true;
        this.defaultAction = AC_ZAP;
        calculateDamage();
        try {
            this.image = handler.image(this);
            this.wood = handler.label(this);
        } catch (Exception e) {
        }
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (this.curCharges > 0 || !this.curChargeKnown) {
            actions.add(AC_ZAP);
        }
        if (hero.heroClass != HeroClass.MAGE) {
            actions.remove(EquipableItem.AC_EQUIP);
            actions.remove(EquipableItem.AC_UNEQUIP);
        }
        return actions;
    }

    public boolean doUnequip(Hero hero, boolean collect, boolean single) {
        onDetach();
        return super.doUnequip(hero, collect, single);
    }

    public void activate(Hero hero) {
        charge(hero);
    }

    public void execute(Hero hero, String action) {
        if (action.equals(AC_ZAP)) {
            curUser = hero;
            curItem = this;
            GameScene.selectCell(zapper);
            return;
        }
        super.execute(hero, action);
    }

    public boolean collect(Bag container) {
        if (!super.collect(container)) {
            return false;
        }
        if (container.owner != null) {
            charge(container.owner);
        }
        return true;
    }

    public void charge(Char owner) {
        if (this.charger == null) {
            Charger charger = new Charger();
            this.charger = charger;
            charger.attachTo(owner);
        }
    }

    public void onDetach() {
        stopCharging();
    }

    public void stopCharging() {
        if (this.charger != null) {
            this.charger.detach();
            this.charger = null;
        }
    }

    public int level() {
        if (this.charger == null) {
            return this.level;
        }
        Power power = (Power) this.charger.target.buff(Power.class);
        return power == null ? this.level : Math.max(this.level + power.level, 0);
    }

    protected boolean isKnown() {
        return handler.isKnown(this);
    }

    public void setKnown() {
        if (!isKnown()) {
            handler.know(this);
        }
        Badges.validateAllWandsIdentified();
    }

    public Item identify() {
        setKnown();
        this.curChargeKnown = true;
        super.identify();
        updateQuickslot();
        return this;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        String status = status();
        if (status != null) {
            sb.append(" (" + status + ")");
        }
        return sb.toString();
    }

    public String name() {
        return isKnown() ? this.name : this.wood + " wand";
    }

    public String info() {
        String desc;
        if (isKnown()) {
            desc = desc();
        } else {
            desc = String.format(TXT_WOOD, new Object[]{this.wood});
        }
        StringBuilder info = new StringBuilder(desc);
        if (Dungeon.hero.heroClass == HeroClass.MAGE) {
            info.append("\n\n");
            if (this.levelKnown) {
                info.append(String.format(TXT_DAMAGE, new Object[]{Integer.valueOf(this.MIN + ((this.MAX - this.MIN) / 2))}));
            } else {
                info.append(String.format(TXT_WEAPON, new Object[0]));
            }
        }
        return info.toString();
    }

    public boolean isIdentified() {
        return super.isIdentified() && isKnown() && this.curChargeKnown;
    }

    public String status() {
        if (!this.levelKnown) {
            return null;
        }
        return (this.curChargeKnown ? Integer.valueOf(this.curCharges) : "?") + "/" + this.maxCharges;
    }

    public Item upgrade() {
        super.upgrade();
        updateLevel();
        this.curCharges = Math.min(this.curCharges + 1, this.maxCharges);
        updateQuickslot();
        return this;
    }

    public Item degrade() {
        super.degrade();
        updateLevel();
        updateQuickslot();
        return this;
    }

    public int maxDurability(int lvl) {
        return (lvl < 16 ? 16 - lvl : 1) * 5;
    }

    protected void updateLevel() {
        this.maxCharges = Math.min(initialCharges() + this.level, 9);
        this.curCharges = Math.min(this.curCharges, this.maxCharges);
        calculateDamage();
    }

    protected int initialCharges() {
        return 2;
    }

    private void calculateDamage() {
        int tier = (this.level / 3) + 1;
        this.MIN = tier;
        this.MAX = ((((tier * tier) - tier) + 10) / 2) + this.level;
    }

    protected void fx(int cell, Callback callback) {
        MagicMissile.blueLight(curUser.sprite.parent, curUser.pos, cell, callback);
        Sample.INSTANCE.play(Assets.SND_ZAP);
    }

    protected void wandUsed() {
        this.curCharges--;
        if (!isIdentified()) {
            int i = this.usagesToKnow - 1;
            this.usagesToKnow = i;
            if (i <= 0) {
                identify();
                GLog.m4w(TXT_IDENTIFY, name());
                use();
                curUser.spendAndNext(TIME_TO_ZAP);
            }
        }
        updateQuickslot();
        use();
        curUser.spendAndNext(TIME_TO_ZAP);
    }

    public Item random() {
        if (Random.Float() < 0.5f) {
            upgrade();
            if (Random.Float() < 0.15f) {
                upgrade();
            }
        }
        return this;
    }

    public static boolean allKnown() {
        return handler.known().size() == wands.length;
    }

    public int price() {
        int price = 50;
        if (this.cursed && this.cursedKnown) {
            price = 50 / 2;
        }
        if (this.levelKnown) {
            if (this.level > 0) {
                price *= this.level + 1;
            } else if (this.level < 0) {
                price /= 1 - this.level;
            }
        }
        if (price < 1) {
            return 1;
        }
        return price;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(UNFAMILIRIARITY, this.usagesToKnow);
        bundle.put(MAX_CHARGES, this.maxCharges);
        bundle.put(CUR_CHARGES, this.curCharges);
        bundle.put(CUR_CHARGE_KNOWN, this.curChargeKnown);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        int i = bundle.getInt(UNFAMILIRIARITY);
        this.usagesToKnow = i;
        if (i == 0) {
            this.usagesToKnow = USAGES_TO_KNOW;
        }
        this.maxCharges = bundle.getInt(MAX_CHARGES);
        this.curCharges = bundle.getInt(CUR_CHARGES);
        this.curChargeKnown = bundle.getBoolean(CUR_CHARGE_KNOWN);
    }
}
