package com.watabou.pixeldungeon.items.wands;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfUpgrade;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndBag.Listener;
import com.watabou.pixeldungeon.windows.WndBag.Mode;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class WandOfMagicMissile extends Wand {
    public static final String AC_DISENCHANT = "DISENCHANT";
    private static final float TIME_TO_DISENCHANT = 2.0f;
    private static final String TXT_DISENCHANTED = "you disenchanted the Wand of Magic Missile and used its essence to upgrade your %s";
    private static final String TXT_SELECT_WAND = "Select a wand to upgrade";
    private boolean disenchantEquipped;
    private final Listener itemSelector;

    /* renamed from: com.watabou.pixeldungeon.items.wands.WandOfMagicMissile.1 */
    class C00951 implements Listener {
        C00951() {
        }

        public void onSelect(Item item) {
            if (item != null) {
                Sample.INSTANCE.play(Assets.SND_EVOKE);
                ScrollOfUpgrade.upgrade(WandOfMagicMissile.curUser);
                Item.evoke(WandOfMagicMissile.curUser);
                GLog.m4w(WandOfMagicMissile.TXT_DISENCHANTED, item.name());
                item.upgrade();
                WandOfMagicMissile.curUser.spendAndNext(WandOfMagicMissile.TIME_TO_DISENCHANT);
                Badges.validateItemLevelAquired(item);
            } else if (WandOfMagicMissile.this.disenchantEquipped) {
                WandOfMagicMissile.curUser.belongings.weapon = WandOfMagicMissile.this;
                WandOfMagicMissile.this.updateQuickslot();
            } else {
                WandOfMagicMissile.this.collect(WandOfMagicMissile.curUser.belongings.backpack);
            }
        }
    }

    public WandOfMagicMissile() {
        this.name = "Wand of Magic Missile";
        this.image = 3;
        this.itemSelector = new C00951();
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (this.level > 0) {
            actions.add(AC_DISENCHANT);
        }
        return actions;
    }

    protected void onZap(int cell) {
        Char ch = Actor.findChar(cell);
        if (ch != null) {
            int level = level();
            if (ch == curUser || curUser.skillWand <= 0) {
                ch.damage(Random.Int(1, (level * 2) + 6), this);
            } else {
                ch.damage(Random.Int(1, ((level * 2) + 6) + curUser.skillWand), this);
            }
            ch.sprite.burst(-6697729, (level / 2) + 2);
            if (ch == curUser && !ch.isAlive()) {
                Dungeon.fail(Utils.format(ResultDescriptions.WAND, this.name, Integer.valueOf(Dungeon.depth)));
                GLog.m2n("You killed yourself with your own Wand of Magic Missile...", new Object[0]);
            }
        }
    }

    public void execute(Hero hero, String action) {
        if (action.equals(AC_DISENCHANT)) {
            if (hero.belongings.weapon == this) {
                this.disenchantEquipped = true;
                hero.belongings.weapon = null;
                updateQuickslot();
            } else {
                this.disenchantEquipped = false;
                detach(hero.belongings.backpack);
            }
            curUser = hero;
            GameScene.selectItem(this.itemSelector, Mode.WAND, TXT_SELECT_WAND);
            return;
        }
        super.execute(hero, action);
    }

    protected boolean isKnown() {
        return true;
    }

    public void setKnown() {
    }

    protected int initialCharges() {
        return 3;
    }

    public String desc() {
        return "This wand launches missiles of pure magical energy, dealing moderate damage to a target creature.";
    }
}
