package com.watabou.pixeldungeon.items.wands;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Slow;
import com.watabou.pixeldungeon.effects.MagicMissile;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Callback;

public class WandOfSlowness extends Wand {
    public WandOfSlowness() {
        this.name = "Wand of Slowness";
    }

    protected void onZap(int cell) {
        Char ch = Actor.findChar(cell);
        if (ch != null) {
            Buff.affect(ch, Slow.class, (Slow.duration(ch) / CurareDart.DURATION) + ((float) level()));
        } else {
            GLog.m1i("nothing happened", new Object[0]);
        }
    }

    protected void fx(int cell, Callback callback) {
        MagicMissile.slowness(curUser.sprite.parent, curUser.pos, cell, callback);
        Sample.INSTANCE.play(Assets.SND_ZAP);
    }

    public String desc() {
        return "This wand will cause a creature to move and attack at half its ordinary speed until the effect ends";
    }
}
