package com.watabou.pixeldungeon.items.wands;

import com.watabou.noosa.Camera;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Paralysis;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.MagicMissile;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.mechanics.Ballistica;
import com.watabou.pixeldungeon.utils.BArray;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Callback;
import com.watabou.utils.PathFinder;
import com.watabou.utils.Random;

public class WandOfAvalanche extends Wand {
    public WandOfAvalanche() {
        this.name = "Wand of Avalanche";
        this.hitChars = false;
    }

    protected void onZap(int cell) {
        Sample.INSTANCE.play(Assets.SND_ROCKS);
        int level = level();
        Ballistica.distance = Math.min(Ballistica.distance, level + 8);
        int size = (level / 3) + 1;
        PathFinder.buildDistanceMap(cell, BArray.not(Level.solid, null), size);
        for (int i = 0; i < Level.LENGTH; i++) {
            int d = PathFinder.distance[i];
            if (d < Integer.MAX_VALUE) {
                Char ch = Actor.findChar(i);
                if (ch != null) {
                    ch.sprite.flash();
                    if (ch == curUser || curUser.skillWand <= 0) {
                        ch.damage(Random.Int(2, ((size - d) * 2) + 6), this);
                    } else {
                        ch.damage(Random.Int(2, (((size - d) * 2) + 6) + (curUser.skillWand * 2)), this);
                    }
                    if (ch.isAlive() && Random.Int(d + 2) == 0) {
                        Buff.prolong(ch, Paralysis.class, (float) Random.IntRange(2, 6));
                    }
                }
                CellEmitter.get(i).start(Speck.factory(8), 0.07f, (size - d) + 3);
                Camera.main.shake(CurareDart.DURATION, ((float) ((size - d) + 3)) * 0.07f);
            }
        }
        if (!curUser.isAlive()) {
            Dungeon.fail(Utils.format(ResultDescriptions.WAND, this.name, Integer.valueOf(Dungeon.depth)));
            GLog.m2n("You killed yourself with your own Wand of Avalanche...", new Object[0]);
        }
    }

    protected void fx(int cell, Callback callback) {
        MagicMissile.earth(curUser.sprite.parent, curUser.pos, cell, callback);
        Sample.INSTANCE.play(Assets.SND_ZAP);
    }

    public String desc() {
        return "When a discharge of this wand hits a wall (or any other solid obstacle) it causes an avalanche of stones, damaging and stunning all creatures in the affected area.";
    }
}
