package com.watabou.pixeldungeon.items.wands;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.blobs.Regrowth;
import com.watabou.pixeldungeon.effects.MagicMissile;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.mechanics.Ballistica;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Callback;

public class WandOfRegrowth extends Wand {
    public WandOfRegrowth() {
        this.name = "Wand of Regrowth";
    }

    protected void onZap(int cell) {
        int c;
        for (int i = 1; i < Ballistica.distance - 1; i++) {
            int p = Ballistica.trace[i];
            c = Dungeon.level.map[p];
            if (c == 1 || c == 9 || c == 24) {
                Level.set(p, 2);
            }
        }
        c = Dungeon.level.map[cell];
        if (c == 1 || c == 9 || c == 24 || c == 2 || c == 15) {
            GameScene.add(Blob.seed(cell, (level() + 2) * 20, Regrowth.class));
        } else {
            GLog.m1i("nothing happened", new Object[0]);
        }
    }

    protected void fx(int cell, Callback callback) {
        MagicMissile.foliage(curUser.sprite.parent, curUser.pos, cell, callback);
        Sample.INSTANCE.play(Assets.SND_ZAP);
    }

    public String desc() {
        return "\"When life ceases new life always begins to grow... The eternal cycle always remains!\"";
    }
}
