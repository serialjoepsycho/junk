package com.watabou.pixeldungeon.items.wands;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.actors.mobs.npcs.NPC;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.MagicMissile;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.mechanics.Ballistica;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.SheepSprite;
import com.watabou.pixeldungeon.utils.BArray;
import com.watabou.utils.Callback;
import com.watabou.utils.PathFinder;
import com.watabou.utils.Random;
import java.util.Iterator;

public class WandOfFlock extends Wand {

    public static class Sheep extends NPC {
        private static final String[] QUOTES;
        private boolean initialized;
        public float lifespan;

        public Sheep() {
            this.name = "sheep";
            this.spriteClass = SheepSprite.class;
            this.initialized = false;
        }

        static {
            QUOTES = new String[]{"Baa!", "Baa?", "Baa.", "Baa..."};
        }

        protected boolean act() {
            if (this.initialized) {
                this.HP = 0;
                destroy();
                this.sprite.die();
            } else {
                this.initialized = true;
                spend(this.lifespan + Random.Float(Pickaxe.TIME_TO_MINE));
            }
            return true;
        }

        public void damage(int dmg, Object src) {
        }

        public String description() {
            return "This is a magic sheep. What's so magical about it? You can't kill it. It will stand there until it magcially fades away, all the while chewing cud with a blank stare.";
        }

        public void interact() {
            yell((String) Random.element(QUOTES));
        }
    }

    public WandOfFlock() {
        this.name = "Wand of Flock";
    }

    protected void onZap(int cell) {
        int level = level();
        int n = level + 2;
        if (Actor.findChar(cell) != null && Ballistica.distance > 2) {
            cell = Ballistica.trace[Ballistica.distance - 2];
        }
        boolean[] passable = BArray.or(Level.passable, Level.avoid, null);
        Iterator it = Actor.all().iterator();
        while (it.hasNext()) {
            Actor actor = (Actor) it.next();
            if (actor instanceof Char) {
                passable[((Char) actor).pos] = false;
            }
        }
        PathFinder.buildDistanceMap(cell, passable, n);
        int dist = 0;
        if (Actor.findChar(cell) != null) {
            PathFinder.distance[cell] = Integer.MAX_VALUE;
            dist = 1;
        }
        float lifespan = (float) (level + 3);
        for (int i = 0; i < n; i++) {
            do {
                for (int j = 0; j < Level.LENGTH; j++) {
                    if (PathFinder.distance[j] == dist) {
                        Mob sheep = new Sheep();
                        sheep.lifespan = lifespan;
                        sheep.pos = j;
                        GameScene.add(sheep);
                        Dungeon.level.mobPress(sheep);
                        CellEmitter.get(j).burst(Speck.factory(7), 4);
                        PathFinder.distance[j] = Integer.MAX_VALUE;
                        break;
                    }
                }
                dist++;
            } while (dist < n);
        }
    }

    protected void fx(int cell, Callback callback) {
        MagicMissile.wool(curUser.sprite.parent, curUser.pos, cell, callback);
        Sample.INSTANCE.play(Assets.SND_ZAP);
    }

    public String desc() {
        return "A flick of this wand summons a flock of magic sheep, creating temporary impenetrable obstacle.";
    }
}
