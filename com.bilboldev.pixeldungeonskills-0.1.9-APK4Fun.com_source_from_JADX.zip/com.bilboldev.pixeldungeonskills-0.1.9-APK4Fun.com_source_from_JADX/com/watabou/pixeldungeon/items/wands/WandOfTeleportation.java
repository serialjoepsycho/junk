package com.watabou.pixeldungeon.items.wands;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.effects.MagicMissile;
import com.watabou.utils.Callback;

public class WandOfTeleportation extends Wand {
    public WandOfTeleportation() {
        this.name = "Wand of Teleportation";
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected void onZap(int r8) {
        /*
        r7 = this;
        r5 = -1;
        r6 = 0;
        r0 = com.watabou.pixeldungeon.actors.Actor.findChar(r8);
        r4 = curUser;
        if (r0 != r4) goto L_0x0013;
    L_0x000a:
        r7.setKnown();
        r4 = curUser;
        com.watabou.pixeldungeon.items.scrolls.ScrollOfTeleportation.teleportHero(r4);
    L_0x0012:
        return;
    L_0x0013:
        if (r0 == 0) goto L_0x0069;
    L_0x0015:
        r1 = 10;
    L_0x0017:
        r4 = com.watabou.pixeldungeon.Dungeon.level;
        r3 = r4.randomRespawnCell();
        r2 = r1 + -1;
        if (r1 > 0) goto L_0x002b;
    L_0x0021:
        if (r3 != r5) goto L_0x002f;
    L_0x0023:
        r4 = "Strong magic aura of this place prevents you from teleporting!";
        r5 = new java.lang.Object[r6];
        com.watabou.pixeldungeon.utils.GLog.m4w(r4, r5);
        goto L_0x0012;
    L_0x002b:
        if (r3 != r5) goto L_0x0021;
    L_0x002d:
        r1 = r2;
        goto L_0x0017;
    L_0x002f:
        r0.pos = r3;
        r4 = r0.sprite;
        r5 = r0.pos;
        r4.place(r5);
        r4 = r0.sprite;
        r5 = com.watabou.pixeldungeon.Dungeon.visible;
        r5 = r5[r3];
        r4.visible = r5;
        r4 = new java.lang.StringBuilder;
        r4.<init>();
        r5 = curUser;
        r5 = r5.name;
        r4 = r4.append(r5);
        r5 = " teleported ";
        r4 = r4.append(r5);
        r5 = r0.name;
        r4 = r4.append(r5);
        r5 = " to somewhere";
        r4 = r4.append(r5);
        r4 = r4.toString();
        r5 = new java.lang.Object[r6];
        com.watabou.pixeldungeon.utils.GLog.m1i(r4, r5);
        goto L_0x0012;
    L_0x0069:
        r4 = "nothing happened";
        r5 = new java.lang.Object[r6];
        com.watabou.pixeldungeon.utils.GLog.m1i(r4, r5);
        goto L_0x0012;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.watabou.pixeldungeon.items.wands.WandOfTeleportation.onZap(int):void");
    }

    protected void fx(int cell, Callback callback) {
        MagicMissile.coldLight(curUser.sprite.parent, curUser.pos, cell, callback);
        Sample.INSTANCE.play(Assets.SND_ZAP);
    }

    public String desc() {
        return "A blast from this wand will teleport a creature against its will to a random place on the current level.";
    }
}
