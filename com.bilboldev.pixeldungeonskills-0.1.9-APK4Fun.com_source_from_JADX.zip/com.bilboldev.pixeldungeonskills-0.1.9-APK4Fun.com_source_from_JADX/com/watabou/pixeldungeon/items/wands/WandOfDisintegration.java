package com.watabou.pixeldungeon.items.wands;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.DungeonTilemap;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.DeathRay;
import com.watabou.pixeldungeon.effects.particles.PurpleParticle;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.mechanics.Ballistica;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.utils.Callback;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Iterator;

public class WandOfDisintegration extends Wand {
    public WandOfDisintegration() {
        this.name = "Wand of Disintegration";
        this.hitChars = false;
    }

    protected void onZap(int cell) {
        boolean terrainAffected = false;
        int level = level();
        Ballistica.distance = Math.min(Ballistica.distance, distance());
        ArrayList<Char> chars = new ArrayList();
        for (int i = 1; i < Ballistica.distance; i++) {
            int c = Ballistica.trace[i];
            Char ch = Actor.findChar(c);
            if (ch != null) {
                chars.add(ch);
            }
            int terr = Dungeon.level.map[c];
            if (terr == 5 || terr == 13) {
                Level.set(c, 9);
                GameScene.updateMap(c);
                terrainAffected = true;
            } else if (terr == 15) {
                Level.set(c, 2);
                GameScene.updateMap(c);
                terrainAffected = true;
            }
            CellEmitter.center(c).burst(PurpleParticle.BURST, Random.IntRange(1, 2));
        }
        if (terrainAffected) {
            Dungeon.observe();
        }
        int lvl = level + chars.size();
        int dmgMin = lvl;
        int dmgMax = ((lvl * lvl) / 3) + 8;
        Iterator it = chars.iterator();
        while (it.hasNext()) {
            ch = (Char) it.next();
            if (ch == curUser || curUser.skillWand <= 0) {
                ch.damage(Random.NormalIntRange(dmgMin, dmgMax), this);
            } else {
                ch.damage(Random.NormalIntRange(dmgMin, curUser.skillWand + dmgMax), this);
            }
            ch.sprite.centerEmitter().burst(PurpleParticle.BURST, Random.IntRange(1, 2));
            ch.sprite.flash();
        }
    }

    private int distance() {
        return level() + 4;
    }

    protected void fx(int cell, Callback callback) {
        curUser.sprite.parent.add(new DeathRay(curUser.sprite.center(), DungeonTilemap.tileCenterToWorld(Ballistica.trace[Math.min(Ballistica.distance, distance()) - 1])));
        callback.call();
    }

    public String desc() {
        return "This wand emits a beam of destructive energy, which pierces all creatures in its way. The more targets it hits, the more damage it inflicts to each of them.";
    }
}
