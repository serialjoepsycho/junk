package com.watabou.pixeldungeon.items.wands;

import com.watabou.noosa.Camera;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.ResultDescriptions;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Lightning;
import com.watabou.pixeldungeon.effects.particles.SparkParticle;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.traps.LightningTrap;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Callback;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

public class WandOfLightning extends Wand {
    private ArrayList<Char> affected;
    private int nPoints;
    private int[] points;

    public WandOfLightning() {
        this.name = "Wand of Lightning";
        this.affected = new ArrayList();
        this.points = new int[20];
    }

    protected void onZap(int cell) {
        if (!curUser.isAlive()) {
            Dungeon.fail(Utils.format(ResultDescriptions.WAND, this.name, Integer.valueOf(Dungeon.depth)));
            GLog.m2n("You killed yourself with your own Wand of Lightning...", new Object[0]);
        }
    }

    private void hit(Char ch, int damage) {
        if (damage >= 1) {
            int i;
            if (ch == Dungeon.hero) {
                Camera.main.shake(Pickaxe.TIME_TO_MINE, 0.3f);
            }
            this.affected.add(ch);
            if (!Level.water[ch.pos] || ch.flying) {
                i = damage;
            } else {
                i = damage * 2;
            }
            ch.damage(i, LightningTrap.LIGHTNING);
            ch.sprite.centerEmitter().burst(SparkParticle.FACTORY, 3);
            ch.sprite.flash();
            int[] iArr = this.points;
            int i2 = this.nPoints;
            this.nPoints = i2 + 1;
            iArr[i2] = ch.pos;
            Collection ns = new HashSet();
            for (int i22 : Level.NEIGHBOURS8) {
                Char n = Actor.findChar(ch.pos + i22);
                if (!(n == null || this.affected.contains(n))) {
                    ns.add(n);
                }
            }
            if (ns.size() > 0) {
                hit((Char) Random.element(ns), Random.Int(damage / 2, damage));
            }
        }
    }

    protected void fx(int cell, Callback callback) {
        this.nPoints = 0;
        int[] iArr = this.points;
        int i = this.nPoints;
        this.nPoints = i + 1;
        iArr[i] = Dungeon.hero.pos;
        Char ch = Actor.findChar(cell);
        if (ch != null) {
            this.affected.clear();
            int lvl = level();
            if (ch == curUser || curUser.skillWand <= 0) {
                hit(ch, Random.Int((lvl / 2) + 5, lvl + 10));
            } else {
                hit(ch, Random.Int((lvl / 2) + 5, (lvl + 10) + curUser.skillWand));
            }
        } else {
            iArr = this.points;
            i = this.nPoints;
            this.nPoints = i + 1;
            iArr[i] = cell;
            CellEmitter.center(cell).burst(SparkParticle.FACTORY, 3);
        }
        curUser.sprite.parent.add(new Lightning(this.points, this.nPoints, callback));
    }

    public String desc() {
        return "This wand conjures forth deadly arcs of electricity, which deal damage to several creatures standing close to each other.";
    }
}
