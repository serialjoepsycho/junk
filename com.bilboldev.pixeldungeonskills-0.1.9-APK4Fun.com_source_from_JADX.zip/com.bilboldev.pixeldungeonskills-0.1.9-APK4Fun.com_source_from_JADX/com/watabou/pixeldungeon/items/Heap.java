package com.watabou.pixeldungeon.items;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Statistics;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Burning;
import com.watabou.pixeldungeon.actors.buffs.Frost;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.mobs.Mimic;
import com.watabou.pixeldungeon.actors.mobs.Wraith;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.Splash;
import com.watabou.pixeldungeon.effects.particles.ElmoParticle;
import com.watabou.pixeldungeon.effects.particles.FlameParticle;
import com.watabou.pixeldungeon.effects.particles.ShadowParticle;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.food.ChargrilledMeat;
import com.watabou.pixeldungeon.items.food.FrozenCarpaccio;
import com.watabou.pixeldungeon.items.food.MysteryMeat;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.scrolls.Scroll;
import com.watabou.pixeldungeon.plants.Plant.Seed;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.sprites.ItemSprite.Glowing;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.BuffIndicator;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class Heap implements Bundlable {
    private static final String ITEMS = "items";
    private static final String POS = "pos";
    private static final int SEEDS_TO_POTION = 3;
    private static final String TXT_MIMIC = "This is a mimic!";
    private static final String TYPE = "type";
    public LinkedList<Item> items;
    public int pos;
    public ItemSprite sprite;
    public Type type;

    /* renamed from: com.watabou.pixeldungeon.items.Heap.1 */
    static /* synthetic */ class C00711 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type;

        static {
            $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type = new int[Type.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[Type.HEAP.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[Type.FOR_SALE.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[Type.STORAGE.ordinal()] = Heap.SEEDS_TO_POTION;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[Type.CHEST.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[Type.MIMIC.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[Type.LOCKED_CHEST.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[Type.CRYSTAL_CHEST.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[Type.TOMB.ordinal()] = 8;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[Type.SKELETON.ordinal()] = 9;
            } catch (NoSuchFieldError e9) {
            }
        }
    }

    public enum Type {
        HEAP,
        FOR_SALE,
        CHEST,
        LOCKED_CHEST,
        CRYSTAL_CHEST,
        TOMB,
        SKELETON,
        MIMIC,
        STORAGE
    }

    public Heap() {
        this.type = Type.HEAP;
        this.pos = 0;
        this.items = new LinkedList();
    }

    public int image() {
        switch (C00711.$SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[this.type.ordinal()]) {
            case WndUpdates.ID_PRISON /*1*/:
            case WndUpdates.ID_CAVES /*2*/:
                if (size() > 0) {
                    return ((Item) this.items.peek()).image();
                }
                return 0;
            case SEEDS_TO_POTION /*3*/:
                return ItemSpriteSheet.STORAGE;
            case WndUpdates.ID_HALLS /*4*/:
            case BuffIndicator.HUNGER /*5*/:
                return 11;
            case BuffIndicator.STARVATION /*6*/:
                return 12;
            case BuffIndicator.SLOW /*7*/:
                return ItemSpriteSheet.CRYSTAL_CHEST;
            case BuffIndicator.OOZE /*8*/:
                return 13;
            default:
                return 0;
        }
    }

    public Glowing glowing() {
        return ((this.type == Type.HEAP || this.type == Type.FOR_SALE) && this.items.size() > 0) ? ((Item) this.items.peek()).glowing() : null;
    }

    public void open(Hero hero) {
        switch (C00711.$SwitchMap$com$watabou$pixeldungeon$items$Heap$Type[this.type.ordinal()]) {
            case BuffIndicator.HUNGER /*5*/:
                if (Mimic.spawnAt(this.pos, this.items) == null) {
                    this.type = Type.CHEST;
                    break;
                }
                GLog.m2n(TXT_MIMIC, new Object[0]);
                destroy();
                break;
            case BuffIndicator.OOZE /*8*/:
                Wraith.spawnAround(hero.pos);
                break;
            case BuffIndicator.AMOK /*9*/:
                CellEmitter.center(this.pos).start(Speck.factory(ItemSpriteSheet.CRYSTAL_CHEST), 0.1f, SEEDS_TO_POTION);
                Iterator it = this.items.iterator();
                while (it.hasNext()) {
                    if (((Item) it.next()).cursed) {
                        if (Wraith.spawnAt(this.pos) == null) {
                            hero.sprite.emitter().burst(ShadowParticle.CURSE, 6);
                            hero.damage(hero.HP / 2, this);
                        }
                        Sample.INSTANCE.play(Assets.SND_CURSED);
                        break;
                    }
                }
                break;
        }
        if (this.type != Type.MIMIC) {
            this.type = Type.HEAP;
            this.sprite.link();
            this.sprite.drop();
        }
    }

    public int size() {
        return this.items.size();
    }

    public void removeRemoteBombs() {
        LinkedList<Item> tmp = new LinkedList();
        Iterator it = this.items.iterator();
        while (it.hasNext()) {
            Item item = (Item) it.next();
            if (!(item instanceof RemoteBombGround)) {
                tmp.add(item);
            }
        }
        this.items.clear();
        this.items = tmp;
    }

    public Item pickUp() {
        Item item = (Item) this.items.removeFirst();
        if (this.items.isEmpty()) {
            destroy();
        } else if (this.sprite != null) {
            this.sprite.view(image(), glowing());
        }
        return item;
    }

    public Item peek() {
        return (Item) this.items.peek();
    }

    public void drop(Item item) {
        try {
            if (item.stackable) {
                Class<?> c = item.getClass();
                Iterator it = this.items.iterator();
                while (it.hasNext()) {
                    Item i = (Item) it.next();
                    if (i.getClass() == c) {
                        i.quantity += item.quantity;
                        item = i;
                        break;
                    }
                }
                this.items.remove(item);
            }
            if (item instanceof Dewdrop) {
                this.items.add(item);
            } else {
                this.items.addFirst(item);
            }
            if (this.sprite != null) {
                this.sprite.view(image(), glowing());
            }
        } catch (Exception e) {
            GLog.m2n("Something went seriously wrong...", new Object[0]);
        }
    }

    public void replace(Item a, Item b) {
        int index = this.items.indexOf(a);
        if (index != -1) {
            this.items.remove(index);
            this.items.add(index, b);
        }
    }

    public void burn() {
        if (this.type == Type.MIMIC) {
            Mimic m = Mimic.spawnAt(this.pos, this.items);
            if (m != null) {
                ((Burning) Buff.affect(m, Burning.class)).reignite(m);
                m.sprite.emitter().burst(FlameParticle.FACTORY, 5);
                destroy();
            }
        }
        if (this.type == Type.HEAP) {
            boolean burnt = false;
            boolean evaporated = false;
            for (Item item : (Item[]) this.items.toArray(new Item[0])) {
                if (item instanceof Scroll) {
                    this.items.remove(item);
                    burnt = true;
                } else if (item instanceof Dewdrop) {
                    this.items.remove(item);
                    evaporated = true;
                } else if (item instanceof MysteryMeat) {
                    replace(item, ChargrilledMeat.cook((MysteryMeat) item));
                    burnt = true;
                }
            }
            if (burnt || evaporated) {
                if (Dungeon.visible[this.pos]) {
                    if (burnt) {
                        burnFX(this.pos);
                    } else {
                        evaporateFX(this.pos);
                    }
                }
                if (isEmpty()) {
                    destroy();
                } else if (this.sprite != null) {
                    this.sprite.view(image(), glowing());
                }
            }
        }
    }

    public void freeze() {
        if (this.type == Type.MIMIC) {
            Mimic m = Mimic.spawnAt(this.pos, this.items);
            if (m != null) {
                Buff.prolong(m, Frost.class, Frost.duration(m) * Random.Float(Key.TIME_TO_UNLOCK, Sleep.SWS));
                destroy();
            }
        }
        if (this.type == Type.HEAP) {
            boolean frozen = false;
            for (Item item : (Item[]) this.items.toArray(new Item[0])) {
                if (item instanceof MysteryMeat) {
                    replace(item, FrozenCarpaccio.cook((MysteryMeat) item));
                    frozen = true;
                }
            }
            if (!frozen) {
                return;
            }
            if (isEmpty()) {
                destroy();
            } else if (this.sprite != null) {
                this.sprite.view(image(), glowing());
            }
        }
    }

    public Item transmute() {
        CellEmitter.get(this.pos).burst(Speck.factory(12), SEEDS_TO_POTION);
        Splash.at(this.pos, (int) CharSprite.DEFAULT, (int) SEEDS_TO_POTION);
        float[] chances = new float[this.items.size()];
        int count = 0;
        int index = 0;
        Iterator it = this.items.iterator();
        while (it.hasNext()) {
            Item item = (Item) it.next();
            if (!(item instanceof Seed)) {
                count = 0;
                break;
            }
            count += item.quantity;
            int index2 = index + 1;
            chances[index] = (float) item.quantity;
            index = index2;
        }
        if (count < SEEDS_TO_POTION) {
            return null;
        }
        CellEmitter.get(this.pos).burst(Speck.factory(7), 6);
        Sample.INSTANCE.play(Assets.SND_PUFF);
        if (Random.Int(count) == 0) {
            CellEmitter.center(this.pos).burst(Speck.factory(ItemSpriteSheet.ORE), SEEDS_TO_POTION);
            destroy();
            Statistics.potionsCooked++;
            Badges.validatePotionsCooked();
            return Generator.random(Category.POTION);
        }
        Class<? extends Item> itemClass = ((Seed) this.items.get(Random.chances(chances))).alchemyClass;
        destroy();
        Statistics.potionsCooked++;
        Badges.validatePotionsCooked();
        if (itemClass == null) {
            return Generator.random(Category.POTION);
        }
        try {
            return (Item) itemClass.newInstance();
        } catch (Exception e) {
            return null;
        }
    }

    public static void burnFX(int pos) {
        CellEmitter.get(pos).burst(ElmoParticle.FACTORY, 6);
        Sample.INSTANCE.play(Assets.SND_BURNING);
    }

    public static void evaporateFX(int pos) {
        CellEmitter.get(pos).burst(Speck.factory(13), 5);
    }

    public boolean isEmpty() {
        return this.items == null || this.items.size() == 0;
    }

    public void destroy() {
        Dungeon.level.heaps.remove(this.pos);
        if (this.sprite != null) {
            this.sprite.kill();
        }
        this.items.clear();
        this.items = null;
    }

    public void restoreFromBundle(Bundle bundle) {
        this.pos = bundle.getInt(POS);
        this.type = Type.valueOf(bundle.getString(TYPE));
        Collection<Bundlable> tmp = bundle.getCollection(ITEMS);
        this.items = new LinkedList();
        for (Bundlable item : tmp) {
            this.items.add((Item) item);
        }
    }

    public void storeInBundle(Bundle bundle) {
        bundle.put(POS, this.pos);
        bundle.put(TYPE, this.type.toString());
        bundle.put(ITEMS, this.items);
    }
}
