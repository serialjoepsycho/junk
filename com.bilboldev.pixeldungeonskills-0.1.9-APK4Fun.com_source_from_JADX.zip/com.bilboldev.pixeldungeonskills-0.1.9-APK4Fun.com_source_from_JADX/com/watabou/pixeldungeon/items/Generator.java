package com.watabou.pixeldungeon.items;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.mobs.npcs.Wandmaker.Rotberry;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.armor.ClothArmor;
import com.watabou.pixeldungeon.items.armor.LeatherArmor;
import com.watabou.pixeldungeon.items.armor.MailArmor;
import com.watabou.pixeldungeon.items.armor.PlateArmor;
import com.watabou.pixeldungeon.items.armor.ScaleArmor;
import com.watabou.pixeldungeon.items.bags.Bag;
import com.watabou.pixeldungeon.items.food.Food;
import com.watabou.pixeldungeon.items.food.HuntedMeat;
import com.watabou.pixeldungeon.items.food.MysteryMeat;
import com.watabou.pixeldungeon.items.food.Pasty;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.potions.Potion;
import com.watabou.pixeldungeon.items.potions.PotionOfExperience;
import com.watabou.pixeldungeon.items.potions.PotionOfFrost;
import com.watabou.pixeldungeon.items.potions.PotionOfHealing;
import com.watabou.pixeldungeon.items.potions.PotionOfInvisibility;
import com.watabou.pixeldungeon.items.potions.PotionOfLevitation;
import com.watabou.pixeldungeon.items.potions.PotionOfLiquidFlame;
import com.watabou.pixeldungeon.items.potions.PotionOfMight;
import com.watabou.pixeldungeon.items.potions.PotionOfMindVision;
import com.watabou.pixeldungeon.items.potions.PotionOfParalyticGas;
import com.watabou.pixeldungeon.items.potions.PotionOfPurity;
import com.watabou.pixeldungeon.items.potions.PotionOfStrength;
import com.watabou.pixeldungeon.items.potions.PotionOfToxicGas;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.rings.Ring;
import com.watabou.pixeldungeon.items.rings.RingOfAccuracy;
import com.watabou.pixeldungeon.items.rings.RingOfDetection;
import com.watabou.pixeldungeon.items.rings.RingOfElements;
import com.watabou.pixeldungeon.items.rings.RingOfEvasion;
import com.watabou.pixeldungeon.items.rings.RingOfHaggler;
import com.watabou.pixeldungeon.items.rings.RingOfHaste;
import com.watabou.pixeldungeon.items.rings.RingOfHerbalism;
import com.watabou.pixeldungeon.items.rings.RingOfMending;
import com.watabou.pixeldungeon.items.rings.RingOfPower;
import com.watabou.pixeldungeon.items.rings.RingOfSatiety;
import com.watabou.pixeldungeon.items.rings.RingOfShadows;
import com.watabou.pixeldungeon.items.rings.RingOfThorns;
import com.watabou.pixeldungeon.items.scrolls.Scroll;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfBloodyRitual;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfChallenge;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfEnchantment;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfHome;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfIdentify;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfLullaby;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfMagicMapping;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfMirrorImage;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfPsionicBlast;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfReadiness;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfRecharging;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfRemoveCurse;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfSacrifice;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfSkill;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfTerror;
import com.watabou.pixeldungeon.items.scrolls.ScrollOfUpgrade;
import com.watabou.pixeldungeon.items.wands.Wand;
import com.watabou.pixeldungeon.items.wands.WandOfAmok;
import com.watabou.pixeldungeon.items.wands.WandOfAvalanche;
import com.watabou.pixeldungeon.items.wands.WandOfBlink;
import com.watabou.pixeldungeon.items.wands.WandOfDisintegration;
import com.watabou.pixeldungeon.items.wands.WandOfFirebolt;
import com.watabou.pixeldungeon.items.wands.WandOfFlock;
import com.watabou.pixeldungeon.items.wands.WandOfLightning;
import com.watabou.pixeldungeon.items.wands.WandOfMagicMissile;
import com.watabou.pixeldungeon.items.wands.WandOfPoison;
import com.watabou.pixeldungeon.items.wands.WandOfRegrowth;
import com.watabou.pixeldungeon.items.wands.WandOfSlowness;
import com.watabou.pixeldungeon.items.wands.WandOfTelekinesis;
import com.watabou.pixeldungeon.items.wands.WandOfTeleportation;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.melee.BattleAxe;
import com.watabou.pixeldungeon.items.weapon.melee.Dagger;
import com.watabou.pixeldungeon.items.weapon.melee.DualSwords;
import com.watabou.pixeldungeon.items.weapon.melee.Glaive;
import com.watabou.pixeldungeon.items.weapon.melee.Knuckles;
import com.watabou.pixeldungeon.items.weapon.melee.Longsword;
import com.watabou.pixeldungeon.items.weapon.melee.Mace;
import com.watabou.pixeldungeon.items.weapon.melee.NecroBlade;
import com.watabou.pixeldungeon.items.weapon.melee.Quarterstaff;
import com.watabou.pixeldungeon.items.weapon.melee.ShortSword;
import com.watabou.pixeldungeon.items.weapon.melee.Spear;
import com.watabou.pixeldungeon.items.weapon.melee.Sword;
import com.watabou.pixeldungeon.items.weapon.melee.WarHammer;
import com.watabou.pixeldungeon.items.weapon.missiles.Arrow;
import com.watabou.pixeldungeon.items.weapon.missiles.BombArrow;
import com.watabou.pixeldungeon.items.weapon.missiles.Boomerang;
import com.watabou.pixeldungeon.items.weapon.missiles.Bow;
import com.watabou.pixeldungeon.items.weapon.missiles.CurareDart;
import com.watabou.pixeldungeon.items.weapon.missiles.Dart;
import com.watabou.pixeldungeon.items.weapon.missiles.FrostBow;
import com.watabou.pixeldungeon.items.weapon.missiles.IncendiaryDart;
import com.watabou.pixeldungeon.items.weapon.missiles.Javelin;
import com.watabou.pixeldungeon.items.weapon.missiles.Shuriken;
import com.watabou.pixeldungeon.items.weapon.missiles.Tamahawk;
import com.watabou.pixeldungeon.plants.Dreamweed;
import com.watabou.pixeldungeon.plants.Earthroot;
import com.watabou.pixeldungeon.plants.Fadeleaf;
import com.watabou.pixeldungeon.plants.Firebloom;
import com.watabou.pixeldungeon.plants.Icecap;
import com.watabou.pixeldungeon.plants.Plant.Seed;
import com.watabou.pixeldungeon.plants.Sorrowmoss;
import com.watabou.pixeldungeon.plants.Sungrass;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Random;
import java.util.HashMap;

public class Generator {
    private static HashMap<Category, Float> categoryProbs;

    /* renamed from: com.watabou.pixeldungeon.items.Generator.1 */
    static /* synthetic */ class C00701 {
        static final /* synthetic */ int[] $SwitchMap$com$watabou$pixeldungeon$items$Generator$Category;

        static {
            $SwitchMap$com$watabou$pixeldungeon$items$Generator$Category = new int[Category.values().length];
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Generator$Category[Category.ARMOR.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$watabou$pixeldungeon$items$Generator$Category[Category.WEAPON.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
        }
    }

    public enum Category {
        WEAPON(Invisibility.DURATION, Weapon.class),
        ARMOR(TomeOfMastery.TIME_TO_READ, Armor.class),
        POTION(50.0f, Potion.class),
        SCROLL(40.0f, Scroll.class),
        WAND(4.0f, Wand.class),
        RING(Pickaxe.TIME_TO_MINE, Ring.class),
        SEED(GasesImmunity.DURATION, Seed.class),
        FOOD(0.0f, Food.class),
        GOLD(50.0f, Gold.class),
        MISC(GasesImmunity.DURATION, Item.class);
        
        public Class<?>[] classes;
        public float prob;
        public float[] probs;
        public Class<? extends Item> superClass;

        private Category(float prob, Class<? extends Item> superClass) {
            this.prob = prob;
            this.superClass = superClass;
        }

        public static int order(Item item) {
            for (int i = 0; i < values().length; i++) {
                if (values()[i].superClass.isInstance(item)) {
                    return i;
                }
            }
            return item instanceof Bag ? Integer.MAX_VALUE : 2147483646;
        }
    }

    static {
        categoryProbs = new HashMap();
        Class[] clsArr = new Class[]{Gold.class};
        Category.GOLD.classes = clsArr;
        float[] fArr = new float[]{Key.TIME_TO_UNLOCK};
        Category.GOLD.probs = fArr;
        clsArr = new Class[]{ScrollOfIdentify.class, ScrollOfTeleportation.class, ScrollOfRemoveCurse.class, ScrollOfRecharging.class, ScrollOfMagicMapping.class, ScrollOfChallenge.class, ScrollOfTerror.class, ScrollOfLullaby.class, ScrollOfPsionicBlast.class, ScrollOfMirrorImage.class, ScrollOfUpgrade.class, ScrollOfEnchantment.class, ScrollOfBloodyRitual.class, ScrollOfSacrifice.class, ScrollOfHome.class, ScrollOfReadiness.class, ScrollOfSkill.class};
        Category.SCROLL.classes = clsArr;
        Category.SCROLL.probs = new float[]{30.0f, TomeOfMastery.TIME_TO_READ, Invisibility.DURATION, TomeOfMastery.TIME_TO_READ, Invisibility.DURATION, 12.0f, 8.0f, 8.0f, 4.0f, 6.0f, 0.0f, Key.TIME_TO_UNLOCK, GasesImmunity.DURATION, GasesImmunity.DURATION, GasesImmunity.DURATION, GasesImmunity.DURATION, GasesImmunity.DURATION};
        clsArr = new Class[]{PotionOfHealing.class, PotionOfExperience.class, PotionOfToxicGas.class, PotionOfParalyticGas.class, PotionOfLiquidFlame.class, PotionOfLevitation.class, PotionOfStrength.class, PotionOfMindVision.class, PotionOfPurity.class, PotionOfInvisibility.class, PotionOfMight.class, PotionOfFrost.class};
        Category.POTION.classes = clsArr;
        Category.POTION.probs = new float[]{45.0f, 4.0f, Invisibility.DURATION, TomeOfMastery.TIME_TO_READ, Invisibility.DURATION, TomeOfMastery.TIME_TO_READ, 0.0f, MindVision.DURATION, 12.0f, TomeOfMastery.TIME_TO_READ, 0.0f, TomeOfMastery.TIME_TO_READ};
        clsArr = new Class[]{WandOfTeleportation.class, WandOfSlowness.class, WandOfFirebolt.class, WandOfRegrowth.class, WandOfPoison.class, WandOfBlink.class, WandOfLightning.class, WandOfAmok.class, WandOfTelekinesis.class, WandOfFlock.class, WandOfMagicMissile.class, WandOfDisintegration.class, WandOfAvalanche.class};
        Category.WAND.classes = clsArr;
        Category.WAND.probs = new float[]{TomeOfMastery.TIME_TO_READ, TomeOfMastery.TIME_TO_READ, Invisibility.DURATION, 6.0f, TomeOfMastery.TIME_TO_READ, 11.0f, Invisibility.DURATION, TomeOfMastery.TIME_TO_READ, 6.0f, TomeOfMastery.TIME_TO_READ, 0.0f, GasesImmunity.DURATION, GasesImmunity.DURATION};
        clsArr = new Class[]{Dagger.class, Knuckles.class, Quarterstaff.class, Spear.class, Mace.class, Sword.class, Longsword.class, BattleAxe.class, WarHammer.class, Glaive.class, ShortSword.class, Dart.class, Javelin.class, IncendiaryDart.class, CurareDart.class, Shuriken.class, Boomerang.class, Tamahawk.class, DualSwords.class, Bow.class, Arrow.class, BombArrow.class, NecroBlade.class, FrostBow.class};
        Category.WEAPON.classes = clsArr;
        Category.WEAPON.probs = new float[]{Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, 0.0f, 0.0f, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, 0.0f, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK};
        clsArr = new Class[]{ClothArmor.class, LeatherArmor.class, MailArmor.class, ScaleArmor.class, PlateArmor.class};
        Category.ARMOR.classes = clsArr;
        Category.ARMOR.probs = new float[]{Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK};
        clsArr = new Class[]{Food.class, Pasty.class, MysteryMeat.class, HuntedMeat.class};
        Category.FOOD.classes = clsArr;
        Category.FOOD.probs = new float[]{4.0f, Key.TIME_TO_UNLOCK, 0.0f, 0.0f};
        clsArr = new Class[]{RingOfMending.class, RingOfDetection.class, RingOfShadows.class, RingOfPower.class, RingOfHerbalism.class, RingOfAccuracy.class, RingOfEvasion.class, RingOfSatiety.class, RingOfHaste.class, RingOfElements.class, RingOfHaggler.class, RingOfThorns.class};
        Category.RING.classes = clsArr;
        Category.RING.probs = new float[]{Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, 0.0f, 0.0f};
        clsArr = new Class[]{Firebloom.Seed.class, Icecap.Seed.class, Sorrowmoss.Seed.class, Dreamweed.Seed.class, Sungrass.Seed.class, Earthroot.Seed.class, Fadeleaf.Seed.class, Rotberry.Seed.class};
        Category.SEED.classes = clsArr;
        Category.SEED.probs = new float[]{Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, 0.0f};
        clsArr = new Class[]{Bomb.class, RemoteBomb.class, Honeypot.class};
        Category.MISC.classes = clsArr;
        Category.MISC.probs = new float[]{Pickaxe.TIME_TO_MINE, Pickaxe.TIME_TO_MINE, Key.TIME_TO_UNLOCK};
    }

    public static void reset() {
        for (Category cat : Category.values()) {
            categoryProbs.put(cat, Float.valueOf(cat.prob));
        }
    }

    public static Item random() {
        return random((Category) Random.chances(categoryProbs));
    }

    public static Item random(Category cat) {
        try {
            categoryProbs.put(cat, Float.valueOf(((Float) categoryProbs.get(cat)).floatValue() / Pickaxe.TIME_TO_MINE));
            switch (C00701.$SwitchMap$com$watabou$pixeldungeon$items$Generator$Category[cat.ordinal()]) {
                case WndUpdates.ID_PRISON /*1*/:
                    return randomArmor();
                case WndUpdates.ID_CAVES /*2*/:
                    return randomWeapon();
                default:
                    return ((Item) cat.classes[Random.chances(cat.probs)].newInstance()).random();
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static Item random(Class<? extends Item> cl) {
        try {
            return ((Item) cl.newInstance()).random();
        } catch (Exception e) {
            return null;
        }
    }

    public static Armor randomArmor() throws Exception {
        int curStr = Dungeon.potionOfStrength + 10;
        Category cat = Category.ARMOR;
        Armor a1 = (Armor) cat.classes[Random.chances(cat.probs)].newInstance();
        Armor a2 = (Armor) cat.classes[Random.chances(cat.probs)].newInstance();
        a1.random();
        a2.random();
        return Math.abs(curStr - a1.STR) < Math.abs(curStr - a2.STR) ? a1 : a2;
    }

    public static Weapon randomWeapon() throws Exception {
        int curStr = Dungeon.potionOfStrength + 10;
        Category cat = Category.WEAPON;
        Weapon w1 = (Weapon) cat.classes[Random.chances(cat.probs)].newInstance();
        Weapon w2 = (Weapon) cat.classes[Random.chances(cat.probs)].newInstance();
        w1.random();
        w2.random();
        return Math.abs(curStr - w1.STR) < Math.abs(curStr - w2.STR) ? w1 : w2;
    }
}
