package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.armor.Armor;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndBag.Mode;

public class ScrollOfEnchantment extends InventoryScroll {
    private static final String TXT_GLOWS = "your %s glows in the dark";

    public ScrollOfEnchantment() {
        this.name = "Scroll of Enchantment";
        this.inventoryTitle = "Select an enchantable item";
        this.mode = Mode.ENCHANTABLE;
    }

    protected void onItemSelected(Item item) {
        ScrollOfRemoveCurse.uncurse(Dungeon.hero, item);
        if (item instanceof Weapon) {
            ((Weapon) item).enchant();
        } else {
            ((Armor) item).inscribe();
        }
        item.fix();
        curUser.sprite.emitter().start(Speck.factory(2), 0.1f, 5);
        GLog.m4w(TXT_GLOWS, item.name());
    }

    public String desc() {
        return "This scroll is able to imbue a weapon or an armor with a random enchantment, granting it a special power.";
    }
}
