package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.buffs.Sleep;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndUpdates;

public class ScrollOfLullaby extends Scroll {
    public ScrollOfLullaby() {
        this.name = "Scroll of Lullaby";
    }

    protected void doRead() {
        curUser.sprite.centerEmitter().start(Speck.factory(9), 0.3f, 5);
        Sample.INSTANCE.play(Assets.SND_LULLABY);
        Invisibility.dispel();
        int count = 0;
        Mob affected = null;
        for (Mob mob : (Mob[]) Dungeon.level.mobs.toArray(new Mob[0])) {
            if (Level.fieldOfView[mob.pos]) {
                Buff.affect(mob, Sleep.class);
                if (mob.buff(Sleep.class) != null) {
                    affected = mob;
                    count++;
                }
            }
        }
        switch (count) {
            case WndUpdates.ID_SEWERS /*0*/:
                GLog.m1i("The scroll utters a soothing melody.", new Object[0]);
                break;
            case WndUpdates.ID_PRISON /*1*/:
                GLog.m1i("The scroll utters a soothing melody and the " + affected.name + " falls asleep!", new Object[0]);
                break;
            default:
                GLog.m1i("The scroll utters a soothing melody and the monsters fall asleep!", new Object[0]);
                break;
        }
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "A soothing melody will put all creatures in your field of view into a deep sleep, giving you a chance to flee or make a surprise attack on them.";
    }

    public int price() {
        return isKnown() ? this.quantity * 50 : super.price();
    }
}
