package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.items.keys.Key;

public class ScrollOfTeleportation extends Scroll {
    public static final String TXT_NO_TELEPORT = "Strong magic aura of this place prevents you from teleporting!";
    public static final String TXT_TELEPORTED = "In a blink of an eye you were teleported to another location of the level.";

    public ScrollOfTeleportation() {
        this.name = "Scroll of Teleportation";
    }

    protected void doRead() {
        Sample.INSTANCE.play(Assets.SND_READ);
        Invisibility.dispel();
        teleportHero(curUser);
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void teleportHero(com.watabou.pixeldungeon.actors.hero.Hero r6) {
        /*
        r5 = 0;
        r4 = -1;
        r0 = 10;
    L_0x0004:
        r3 = com.watabou.pixeldungeon.Dungeon.level;
        r2 = r3.randomRespawnCell();
        r1 = r0 + -1;
        if (r0 > 0) goto L_0x0018;
    L_0x000e:
        if (r2 != r4) goto L_0x001c;
    L_0x0010:
        r3 = "Strong magic aura of this place prevents you from teleporting!";
        r4 = new java.lang.Object[r5];
        com.watabou.pixeldungeon.utils.GLog.m4w(r3, r4);
    L_0x0017:
        return;
    L_0x0018:
        if (r2 != r4) goto L_0x000e;
    L_0x001a:
        r0 = r1;
        goto L_0x0004;
    L_0x001c:
        com.watabou.pixeldungeon.items.wands.WandOfBlink.appear(r6, r2);
        r3 = com.watabou.pixeldungeon.Dungeon.level;
        r3.press(r2, r6);
        com.watabou.pixeldungeon.Dungeon.observe();
        r3 = "In a blink of an eye you were teleported to another location of the level.";
        r4 = new java.lang.Object[r5];
        com.watabou.pixeldungeon.utils.GLog.m1i(r3, r4);
        goto L_0x0017;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.watabou.pixeldungeon.items.scrolls.ScrollOfTeleportation.teleportHero(com.watabou.pixeldungeon.actors.hero.Hero):void");
    }

    public String desc() {
        return "The spell on this parchment instantly transports the reader to a random location on the dungeon level. It can be used to escape a dangerous situation, but the unlucky reader might find himself in an even more dangerous place.";
    }

    public int price() {
        return isKnown() ? this.quantity * 40 : super.price();
    }
}
