package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.actors.mobs.npcs.MirrorImage;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.wands.WandOfBlink;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class ScrollOfMirrorImage extends Scroll {
    private static final int NIMAGES = 3;

    public ScrollOfMirrorImage() {
        this.name = "Scroll of Mirror Image";
    }

    protected void doRead() {
        ArrayList<Integer> respawnPoints = new ArrayList();
        for (int i : Level.NEIGHBOURS8) {
            int p = curUser.pos + i;
            if (Actor.findChar(p) == null && (Level.passable[p] || Level.avoid[p])) {
                respawnPoints.add(Integer.valueOf(p));
            }
        }
        int nImages = NIMAGES;
        while (nImages > 0 && respawnPoints.size() > 0) {
            int index = Random.index(respawnPoints);
            Mob mob = new MirrorImage();
            mob.duplicate(curUser);
            GameScene.add(mob);
            WandOfBlink.appear(mob, ((Integer) respawnPoints.get(index)).intValue());
            respawnPoints.remove(index);
            nImages--;
        }
        if (nImages < NIMAGES) {
            setKnown();
        }
        Sample.INSTANCE.play(Assets.SND_READ);
        Invisibility.dispel();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "The incantation on this scroll will create illusionary twins of the reader, which will chase his enemies.";
    }
}
