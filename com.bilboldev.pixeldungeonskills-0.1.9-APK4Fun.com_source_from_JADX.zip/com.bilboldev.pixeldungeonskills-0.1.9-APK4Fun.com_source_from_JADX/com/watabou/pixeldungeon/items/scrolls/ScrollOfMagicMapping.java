package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.effects.SpellSprite;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.levels.Terrain;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;

public class ScrollOfMagicMapping extends Scroll {
    private static final String TXT_LAYOUT = "You are now aware of the level layout.";

    public ScrollOfMagicMapping() {
        this.name = "Scroll of Magic Mapping";
    }

    protected void doRead() {
        int[] map = Dungeon.level.map;
        boolean[] mapped = Dungeon.level.mapped;
        boolean[] discoverable = Level.discoverable;
        boolean noticed = false;
        for (int i = 0; i < Level.LENGTH; i++) {
            int terr = map[i];
            if (discoverable[i]) {
                mapped[i] = true;
                if ((Terrain.flags[terr] & 8) != 0) {
                    Level.set(i, Terrain.discover(terr));
                    GameScene.updateMap(i);
                    if (Dungeon.visible[i]) {
                        GameScene.discoverTile(i, terr);
                        discover(i);
                        noticed = true;
                    }
                }
            }
        }
        Dungeon.observe();
        GLog.m1i(TXT_LAYOUT, new Object[0]);
        if (noticed) {
            Sample.INSTANCE.play(Assets.SND_SECRET);
        }
        SpellSprite.show(curUser, 1);
        Sample.INSTANCE.play(Assets.SND_READ);
        Invisibility.dispel();
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "When this scroll is read, an image of crystal clarity will be etched into your memory, alerting you to the precise layout of the level and revealing all hidden secrets. The locations of items and creatures will remain unknown.";
    }

    public int price() {
        return isKnown() ? this.quantity * 25 : super.price();
    }

    public static void discover(int cell) {
        CellEmitter.get(cell).start(Speck.factory(ItemSpriteSheet.PICKAXE), 0.1f, 4);
    }
}
