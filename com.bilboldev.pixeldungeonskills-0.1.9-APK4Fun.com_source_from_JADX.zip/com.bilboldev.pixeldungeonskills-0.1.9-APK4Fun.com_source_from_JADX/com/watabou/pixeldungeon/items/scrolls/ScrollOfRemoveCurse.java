package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.buffs.Weakness;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.Flare;
import com.watabou.pixeldungeon.effects.particles.ShadowParticle;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.utils.GLog;

public class ScrollOfRemoveCurse extends Scroll {
    private static final String TXT_NOT_PROCCED = "Your pack glows with a cleansing light, but nothing happens.";
    private static final String TXT_PROCCED = "Your pack glows with a cleansing light, and a malevolent energy disperses.";

    public ScrollOfRemoveCurse() {
        this.name = "Scroll of Remove Curse";
    }

    protected void doRead() {
        new Flare(6, 32.0f).show(curUser.sprite, Pickaxe.TIME_TO_MINE);
        Sample.INSTANCE.play(Assets.SND_READ);
        Invisibility.dispel();
        boolean procced = uncurse(curUser, curUser.belongings.weapon, curUser.belongings.armor, curUser.belongings.ring1, curUser.belongings.ring2) || uncurse(curUser, (Item[]) curUser.belongings.backpack.items.toArray(new Item[0]));
        Buff.detach(curUser, Weakness.class);
        if (procced) {
            GLog.m3p(TXT_PROCCED, new Object[0]);
        } else {
            GLog.m1i(TXT_NOT_PROCCED, new Object[0]);
        }
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "The incantation on this scroll will instantly strip from the reader's weapon, armor, rings and carried items any evil enchantments that might prevent the wearer from removing them.";
    }

    public static boolean uncurse(Hero hero, Item... items) {
        boolean procced = false;
        for (Item item : items) {
            if (item != null && item.cursed) {
                item.cursed = false;
                procced = true;
            }
        }
        if (procced) {
            hero.sprite.emitter().start(ShadowParticle.UP, 0.05f, 10);
        }
        return procced;
    }

    public int price() {
        return isKnown() ? this.quantity * 30 : super.price();
    }
}
