package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.effects.Identification;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndBag.Mode;

public class ScrollOfIdentify extends InventoryScroll {
    public ScrollOfIdentify() {
        this.name = "Scroll of Identify";
        this.inventoryTitle = "Select an item to identify";
        this.mode = Mode.UNIDENTIFED;
    }

    protected void onItemSelected(Item item) {
        curUser.sprite.parent.add(new Identification(curUser.sprite.center().offset(0.0f, -16.0f)));
        item.identify();
        GLog.m1i("It is " + item, new Object[0]);
        Badges.validateItemLevelAquired(item);
    }

    public String desc() {
        return "Permanently reveals all of the secrets of a single item.";
    }

    public int price() {
        return isKnown() ? this.quantity * 30 : super.price();
    }
}
