package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.mobs.Mimic;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.Heap;
import com.watabou.pixeldungeon.items.Heap.Type;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.utils.GLog;
import java.util.Iterator;

public class ScrollOfChallenge extends Scroll {
    public ScrollOfChallenge() {
        this.name = "Scroll of Challenge";
    }

    protected void doRead() {
        Iterator it = Dungeon.level.mobs.iterator();
        while (it.hasNext()) {
            ((Mob) it.next()).beckon(curUser.pos);
        }
        for (Heap heap : Dungeon.level.heaps.values()) {
            if (heap.type == Type.MIMIC) {
                Mimic m = Mimic.spawnAt(heap.pos, heap.items);
                if (m != null) {
                    m.beckon(curUser.pos);
                    heap.destroy();
                }
            }
        }
        GLog.m4w("The scroll emits a challenging roar that echoes throughout the dungeon!", new Object[0]);
        setKnown();
        curUser.sprite.centerEmitter().start(Speck.factory(5), 0.3f, 3);
        Sample.INSTANCE.play(Assets.SND_CHALLENGE);
        Invisibility.dispel();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "When read aloud, this scroll will unleash a challenging roar that will awaken all monsters and alert them to the reader's location.";
    }
}
