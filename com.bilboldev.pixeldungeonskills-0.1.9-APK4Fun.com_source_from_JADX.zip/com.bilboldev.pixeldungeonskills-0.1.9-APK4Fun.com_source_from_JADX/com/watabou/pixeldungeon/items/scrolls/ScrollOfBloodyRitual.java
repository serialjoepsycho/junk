package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Random;

public class ScrollOfBloodyRitual extends Scroll {
    public ScrollOfBloodyRitual() {
        this.name = "Scroll of Bloody Ritual";
    }

    protected void doRead() {
        GameScene.flash(CharSprite.NEGATIVE);
        Sample.INSTANCE.play(Assets.SND_BLAST);
        Invisibility.dispel();
        int damage = (int) Math.round(((double) Dungeon.hero.HT) * 0.2d);
        for (Mob mob : (Mob[]) Dungeon.level.mobs.toArray(new Mob[0])) {
            if (Level.fieldOfView[mob.pos]) {
                mob.damage(Random.IntRange(damage, damage), this);
            }
        }
        Hero hero = Dungeon.hero;
        hero.HT -= damage;
        Dungeon.hero.HP = Dungeon.hero.HT;
        GLog.m2n("Scroll of bloody ritual took away " + damage + " of your max hp!", new Object[0]);
        GLog.m3p("A dark aura heals all your wounds... but you are not comfortable with the aura around you...", new Object[0]);
        Dungeon.observe();
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "The scroll holds the secret of a forbidden ritual. In exchange for the reader's well being, the scroll damages everyone nearby and fully heals him.";
    }

    public int price() {
        return isKnown() ? this.quantity * 80 : super.price();
    }
}
