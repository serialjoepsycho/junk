package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.actors.buffs.Blindness;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.ItemStatusHandler;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Bundle;
import java.util.ArrayList;
import java.util.HashSet;

public abstract class Scroll extends Item {
    public static final String AC_READ = "READ";
    protected static final float TIME_TO_READ = 1.0f;
    private static final String TXT_BLINDED = "You can't read a scroll while blinded";
    private static ItemStatusHandler<Scroll> handler;
    private static final Integer[] images;
    private static final String[] runes;
    private static final Class<?>[] scrolls;
    private String rune;

    protected abstract void doRead();

    static {
        scrolls = new Class[]{ScrollOfIdentify.class, ScrollOfMagicMapping.class, ScrollOfRecharging.class, ScrollOfRemoveCurse.class, ScrollOfTeleportation.class, ScrollOfChallenge.class, ScrollOfTerror.class, ScrollOfLullaby.class, ScrollOfPsionicBlast.class, ScrollOfMirrorImage.class, ScrollOfUpgrade.class, ScrollOfEnchantment.class, ScrollOfSkill.class, ScrollOfReadiness.class, ScrollOfHome.class, ScrollOfSacrifice.class, ScrollOfBloodyRitual.class};
        runes = new String[]{"KAUNAN", "SOWILO", "LAGUZ", "YNGVI", "GYFU", "RAIDO", "ISAZ", "MANNAZ", "NAUDIZ", "BERKANAN", "ODAL", "TIWAZ", BuildConfig.VERSION_NAME, BuildConfig.VERSION_NAME, BuildConfig.VERSION_NAME, BuildConfig.VERSION_NAME, BuildConfig.VERSION_NAME};
        images = new Integer[]{Integer.valueOf(40), Integer.valueOf(41), Integer.valueOf(42), Integer.valueOf(43), Integer.valueOf(44), Integer.valueOf(45), Integer.valueOf(46), Integer.valueOf(47), Integer.valueOf(76), Integer.valueOf(77), Integer.valueOf(78), Integer.valueOf(79), Integer.valueOf(ItemSpriteSheet.SCROLL_SKILLPOINT), Integer.valueOf(ItemSpriteSheet.SCROLL_SKILLRESETACTIVE), Integer.valueOf(ItemSpriteSheet.SCROLL_GOHOME), Integer.valueOf(ItemSpriteSheet.SCROLL_SACRIFICE), Integer.valueOf(ItemSpriteSheet.SCROLL_BLOODY)};
    }

    public static void initLabels() {
        handler = new ItemStatusHandler(scrolls, runes, images, 5);
    }

    public static void save(Bundle bundle) {
        handler.save(bundle);
    }

    public static void restore(Bundle bundle) {
        handler = new ItemStatusHandler(scrolls, runes, images, bundle);
    }

    public Scroll() {
        this.stackable = true;
        this.defaultAction = AC_READ;
        this.image = handler.image(this);
        this.rune = handler.label(this);
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_READ);
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (!action.equals(AC_READ)) {
            super.execute(hero, action);
        } else if (hero.buff(Blindness.class) != null) {
            GLog.m4w(TXT_BLINDED, new Object[0]);
        } else {
            curUser = hero;
            curItem = detach(hero.belongings.backpack);
            doRead();
        }
    }

    public boolean isKnown() {
        return handler.isKnown(this);
    }

    public void setKnown() {
        if (!isKnown()) {
            handler.know(this);
        }
        Badges.validateAllScrollsIdentified();
    }

    public Item identify() {
        setKnown();
        return super.identify();
    }

    public String name() {
        return isKnown() ? this.name : "scroll \"" + this.rune + "\"";
    }

    public String info() {
        return isKnown() ? desc() : "This parchment is covered with indecipherable writing, and bears a title of rune " + this.rune + ". Who knows what it will do when read aloud?";
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return isKnown();
    }

    public static HashSet<Class<? extends Scroll>> getKnown() {
        return handler.known();
    }

    public static HashSet<Class<? extends Scroll>> getUnknown() {
        return handler.unknown();
    }

    public static boolean allKnown() {
        return handler.known().size() == scrolls.length;
    }

    public int price() {
        return this.quantity * 15;
    }
}
