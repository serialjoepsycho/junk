package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.buffs.Terror;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.effects.Flare;
import com.watabou.pixeldungeon.items.TomeOfMastery;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndUpdates;

public class ScrollOfTerror extends Scroll {
    public ScrollOfTerror() {
        this.name = "Scroll of Terror";
    }

    protected void doRead() {
        new Flare(5, 32.0f).color(CharSprite.NEGATIVE, true).show(curUser.sprite, Pickaxe.TIME_TO_MINE);
        Sample.INSTANCE.play(Assets.SND_READ);
        Invisibility.dispel();
        int count = 0;
        Mob affected = null;
        for (Mob mob : (Mob[]) Dungeon.level.mobs.toArray(new Mob[0])) {
            if (Level.fieldOfView[mob.pos]) {
                ((Terror) Buff.affect(mob, Terror.class, TomeOfMastery.TIME_TO_READ)).object = curUser.id();
                count++;
                affected = mob;
            }
        }
        switch (count) {
            case WndUpdates.ID_SEWERS /*0*/:
                GLog.m1i("The scroll emits a brilliant flash of red light", new Object[0]);
                break;
            case WndUpdates.ID_PRISON /*1*/:
                GLog.m1i("The scroll emits a brilliant flash of red light and the " + affected.name + " flees!", new Object[0]);
                break;
            default:
                GLog.m1i("The scroll emits a brilliant flash of red light and the monsters flee!", new Object[0]);
                break;
        }
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "A flash of red light will overwhelm all creatures in your field of view with terror, and they will turn and flee. Attacking a fleeing enemy will dispel the effect.";
    }

    public int price() {
        return isKnown() ? this.quantity * 50 : super.price();
    }
}
