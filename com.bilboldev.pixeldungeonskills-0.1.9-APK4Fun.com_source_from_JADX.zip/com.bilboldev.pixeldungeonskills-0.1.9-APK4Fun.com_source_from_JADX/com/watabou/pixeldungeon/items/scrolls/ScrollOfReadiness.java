package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.utils.GLog;

public class ScrollOfReadiness extends Scroll {
    public ScrollOfReadiness() {
        this.name = "Scroll of Readiness";
    }

    protected void doRead() {
        Dungeon.hero.skillSecondActive = false;
        Dungeon.hero.skillFirstActive = false;
        Dungeon.hero.skillSecondCooldown = 0;
        Dungeon.hero.skillFirstCooldown = 0;
        GLog.m4w("Inspiring words that boost moral and remove fatigue!", new Object[0]);
        GLog.m3p("Your active skills are ready!", new Object[0]);
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "When read, words of inspiration will make your ready for combat.";
    }
}
