package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.SpellSprite;
import com.watabou.pixeldungeon.effects.particles.EnergyParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.utils.GLog;

public class ScrollOfRecharging extends Scroll {
    public ScrollOfRecharging() {
        this.name = "Scroll of Recharging";
    }

    protected void doRead() {
        int count = curUser.belongings.charge(true);
        charge(curUser);
        Sample.INSTANCE.play(Assets.SND_READ);
        Invisibility.dispel();
        if (count > 0) {
            GLog.m1i("a surge of energy courses through your pack, recharging your wand" + (count > 1 ? "s" : BuildConfig.VERSION_NAME), new Object[0]);
            SpellSprite.show(curUser, 2);
        } else {
            GLog.m1i("a surge of energy courses through your pack, but nothing happens", new Object[0]);
        }
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "The raw magical power bound up in this parchment will, when released, recharge all of the reader's wands to full power.";
    }

    public static void charge(Hero hero) {
        hero.sprite.centerEmitter().burst(EnergyParticle.FACTORY, 15);
    }

    public int price() {
        return isKnown() ? this.quantity * 40 : super.price();
    }
}
