package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.wands.WandOfBlink;
import com.watabou.pixeldungeon.utils.GLog;

public class ScrollOfHome extends Scroll {
    public ScrollOfHome() {
        this.name = "Scroll of Refuge";
    }

    protected void doRead() {
        Sample.INSTANCE.play(Assets.SND_READ);
        if (Dungeon.bossLevel()) {
            GLog.m4w(ScrollOfTeleportation.TXT_NO_TELEPORT, new Object[0]);
        } else {
            WandOfBlink.appear(curUser, Dungeon.level.entrance);
            GLog.m1i("The scroll takes you back to the level entrance", new Object[0]);
        }
        Dungeon.observe();
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "Opens a magical portal that takes you back to the entrance of this dungeon level.";
    }

    public int price() {
        return isKnown() ? this.quantity * 40 : super.price();
    }
}
