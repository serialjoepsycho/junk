package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.utils.GLog;

public class ScrollOfSkill extends Scroll {
    public ScrollOfSkill() {
        this.name = "Scroll of Skill";
    }

    protected void doRead() {
        Hero hero = Dungeon.hero;
        hero.skillPoints++;
        GLog.m4w("The scroll contains valuable information about your specialties!", new Object[0]);
        GLog.m3p("+1 skill point!", new Object[0]);
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "When read, words of wisdom will increase your skill.";
    }
}
