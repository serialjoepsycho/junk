package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.utils.GLog;

public class ScrollOfSacrifice extends Scroll {
    public ScrollOfSacrifice() {
        this.name = "Scroll of Sacrifice";
    }

    protected void doRead() {
        Hero hero = Dungeon.hero;
        hero.STR++;
        if (Dungeon.hero.HT > 3) {
            hero = Dungeon.hero;
            hero.HT -= 3;
        } else {
            Dungeon.hero.HT = 1;
        }
        if (Dungeon.hero.HP > Dungeon.hero.HT) {
            Dungeon.hero.HP = Dungeon.hero.HT;
        }
        GLog.m4w("The scroll boosts your strength, but at a cost!", new Object[0]);
        GLog.m3p("+1 strength!", new Object[0]);
        GLog.m2n("-3 max HP!", new Object[0]);
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "A scroll that boosts strength at a certain cost.";
    }
}
