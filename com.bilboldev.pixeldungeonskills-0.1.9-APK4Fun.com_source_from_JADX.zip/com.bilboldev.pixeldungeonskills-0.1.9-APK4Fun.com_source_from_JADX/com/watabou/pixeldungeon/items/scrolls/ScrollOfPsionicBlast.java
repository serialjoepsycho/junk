package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.Blindness;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.utils.Random;

public class ScrollOfPsionicBlast extends Scroll {
    public ScrollOfPsionicBlast() {
        this.name = "Scroll of Psionic Blast";
    }

    protected void doRead() {
        int i = 0;
        GameScene.flash(CharSprite.DEFAULT);
        Sample.INSTANCE.play(Assets.SND_BLAST);
        Invisibility.dispel();
        Mob[] mobArr = (Mob[]) Dungeon.level.mobs.toArray(new Mob[0]);
        int length = mobArr.length;
        while (i < length) {
            Mob mob = mobArr[i];
            if (Level.fieldOfView[mob.pos]) {
                Buff.prolong(mob, Blindness.class, (float) Random.Int(3, 6));
                mob.damage(Random.IntRange(1, (mob.HT * 2) / 3), this);
            }
            i++;
        }
        Buff.prolong(curUser, Blindness.class, (float) Random.Int(3, 6));
        Dungeon.observe();
        setKnown();
        curUser.spendAndNext(Key.TIME_TO_UNLOCK);
    }

    public String desc() {
        return "This scroll contains destructive energy, that can be psionically channeled to inflict a massive damage to all creatures within a field of view. An accompanying flash of light will temporarily blind everybody in the area of effect including the reader of the scroll.";
    }

    public int price() {
        return isKnown() ? this.quantity * 80 : super.price();
    }
}
