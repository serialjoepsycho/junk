package com.watabou.pixeldungeon.items.scrolls;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.buffs.Invisibility;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.windows.WndBag.Listener;
import com.watabou.pixeldungeon.windows.WndBag.Mode;
import com.watabou.pixeldungeon.windows.WndOptions;
import com.watabou.pixeldungeon.windows.WndUpdates;

public abstract class InventoryScroll extends Scroll {
    private static final String TXT_NO = "No, I changed my mind";
    private static final String TXT_WARNING = "Do you really want to cancel this scroll usage? It will be consumed anyway.";
    private static final String TXT_YES = "Yes, I'm positive";
    protected static boolean identifiedByUse;
    protected static Listener itemSelector;
    protected String inventoryTitle;
    protected Mode mode;

    /* renamed from: com.watabou.pixeldungeon.items.scrolls.InventoryScroll.1 */
    class C00911 extends WndOptions {
        C00911(String title, String message, String... options) {
            super(title, message, options);
        }

        protected void onSelect(int index) {
            switch (index) {
                case WndUpdates.ID_SEWERS /*0*/:
                    InventoryScroll.curUser.spendAndNext(Key.TIME_TO_UNLOCK);
                    InventoryScroll.identifiedByUse = false;
                case WndUpdates.ID_PRISON /*1*/:
                    GameScene.selectItem(InventoryScroll.itemSelector, InventoryScroll.this.mode, InventoryScroll.this.inventoryTitle);
                default:
            }
        }

        public void onBackPressed() {
        }
    }

    /* renamed from: com.watabou.pixeldungeon.items.scrolls.InventoryScroll.2 */
    static class C00922 implements Listener {
        C00922() {
        }

        public void onSelect(Item item) {
            if (item != null) {
                ((InventoryScroll) InventoryScroll.curItem).onItemSelected(item);
                InventoryScroll.curUser.spendAndNext(Key.TIME_TO_UNLOCK);
                Sample.INSTANCE.play(Assets.SND_READ);
                Invisibility.dispel();
            } else if (InventoryScroll.identifiedByUse) {
                ((InventoryScroll) InventoryScroll.curItem).confirmCancelation();
            } else {
                InventoryScroll.curItem.collect(InventoryScroll.curUser.belongings.backpack);
            }
        }
    }

    protected abstract void onItemSelected(Item item);

    public InventoryScroll() {
        this.inventoryTitle = "Select an item";
        this.mode = Mode.ALL;
    }

    protected void doRead() {
        if (isKnown()) {
            identifiedByUse = false;
        } else {
            setKnown();
            identifiedByUse = true;
        }
        GameScene.selectItem(itemSelector, this.mode, this.inventoryTitle);
    }

    private void confirmCancelation() {
        GameScene.show(new C00911(name(), TXT_WARNING, TXT_YES, TXT_NO));
    }

    static {
        identifiedByUse = false;
        itemSelector = new C00922();
    }
}
