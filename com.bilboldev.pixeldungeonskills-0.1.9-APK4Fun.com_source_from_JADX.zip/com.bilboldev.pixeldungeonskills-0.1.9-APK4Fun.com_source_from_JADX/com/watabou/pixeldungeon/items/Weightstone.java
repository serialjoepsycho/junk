package com.watabou.pixeldungeon.items;

import com.watabou.noosa.BitmapTextMultiline;
import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.weapon.Weapon;
import com.watabou.pixeldungeon.items.weapon.Weapon.Imbue;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.scenes.PixelScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.ui.RedButton;
import com.watabou.pixeldungeon.ui.Window;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.IconTitle;
import com.watabou.pixeldungeon.windows.WndBag.Listener;
import com.watabou.pixeldungeon.windows.WndBag.Mode;
import java.util.ArrayList;

public class Weightstone extends Item {
    private static final String AC_APPLY = "APPLY";
    private static final float TIME_TO_APPLY = 2.0f;
    private static final String TXT_ACCURATE = "you balanced your %s to make it more accurate";
    private static final String TXT_FAST = "you balanced your %s to make it faster";
    private static final String TXT_SELECT_WEAPON = "Select a weapon to balance";
    private final Listener itemSelector;

    /* renamed from: com.watabou.pixeldungeon.items.Weightstone.1 */
    class C00761 implements Listener {
        C00761() {
        }

        public void onSelect(Item item) {
            if (item != null) {
                GameScene.show(new WndBalance((Weapon) item));
            }
        }
    }

    public class WndBalance extends Window {
        private static final int BUTTON_HEIGHT = 20;
        private static final int BUTTON_WIDTH = 116;
        private static final int MARGIN = 2;
        private static final String TXT_ACCURACY = "For accuracy";
        private static final String TXT_CANCEL = "Never mind";
        private static final String TXT_CHOICE = "How would you like to balance your %s?";
        private static final String TXT_SPEED = "For speed";
        private static final int WIDTH = 120;

        /* renamed from: com.watabou.pixeldungeon.items.Weightstone.WndBalance.1 */
        class C00771 extends RedButton {
            final /* synthetic */ Weightstone val$this$0;
            final /* synthetic */ Weapon val$weapon;

            C00771(String label, Weightstone weightstone, Weapon weapon) {
                this.val$this$0 = weightstone;
                this.val$weapon = weapon;
                super(label);
            }

            protected void onClick() {
                WndBalance.this.hide();
                Weightstone.this.apply(this.val$weapon, true);
            }
        }

        /* renamed from: com.watabou.pixeldungeon.items.Weightstone.WndBalance.2 */
        class C00782 extends RedButton {
            final /* synthetic */ Weightstone val$this$0;
            final /* synthetic */ Weapon val$weapon;

            C00782(String label, Weightstone weightstone, Weapon weapon) {
                this.val$this$0 = weightstone;
                this.val$weapon = weapon;
                super(label);
            }

            protected void onClick() {
                WndBalance.this.hide();
                Weightstone.this.apply(this.val$weapon, false);
            }
        }

        /* renamed from: com.watabou.pixeldungeon.items.Weightstone.WndBalance.3 */
        class C00793 extends RedButton {
            final /* synthetic */ Weightstone val$this$0;

            C00793(String label, Weightstone weightstone) {
                this.val$this$0 = weightstone;
                super(label);
            }

            protected void onClick() {
                WndBalance.this.hide();
            }
        }

        public WndBalance(Weapon weapon) {
            IconTitle titlebar = new IconTitle(weapon);
            titlebar.setRect(0.0f, 0.0f, 120.0f, 0.0f);
            add(titlebar);
            BitmapTextMultiline tfMesage = PixelScene.createMultiline(Utils.format(TXT_CHOICE, weapon.name()), 8.0f);
            tfMesage.maxWidth = BUTTON_WIDTH;
            tfMesage.measure();
            tfMesage.x = Weightstone.TIME_TO_APPLY;
            tfMesage.y = titlebar.bottom() + Weightstone.TIME_TO_APPLY;
            add(tfMesage);
            float pos = tfMesage.y + tfMesage.height();
            if (weapon.imbue != Imbue.SPEED) {
                RedButton btnSpeed = new C00771(TXT_SPEED, Weightstone.this, weapon);
                btnSpeed.setRect(Weightstone.TIME_TO_APPLY, pos + Weightstone.TIME_TO_APPLY, 116.0f, MindVision.DURATION);
                add(btnSpeed);
                pos = btnSpeed.bottom();
            }
            if (weapon.imbue != Imbue.ACCURACY) {
                RedButton btnAccuracy = new C00782(TXT_ACCURACY, Weightstone.this, weapon);
                btnAccuracy.setRect(Weightstone.TIME_TO_APPLY, pos + Weightstone.TIME_TO_APPLY, 116.0f, MindVision.DURATION);
                add(btnAccuracy);
                pos = btnAccuracy.bottom();
            }
            RedButton btnCancel = new C00793(TXT_CANCEL, Weightstone.this);
            btnCancel.setRect(Weightstone.TIME_TO_APPLY, pos + Weightstone.TIME_TO_APPLY, 116.0f, MindVision.DURATION);
            add(btnCancel);
            resize(WIDTH, ((int) btnCancel.bottom()) + MARGIN);
        }

        protected void onSelect(int index) {
        }
    }

    public Weightstone() {
        this.name = "weightstone";
        this.image = ItemSpriteSheet.WEIGHT;
        this.stackable = true;
        this.itemSelector = new C00761();
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_APPLY);
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action == AC_APPLY) {
            curUser = hero;
            GameScene.selectItem(this.itemSelector, Mode.WEAPON, TXT_SELECT_WEAPON);
            return;
        }
        super.execute(hero, action);
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    private void apply(Weapon weapon, boolean forSpeed) {
        detach(curUser.belongings.backpack);
        weapon.fix();
        if (forSpeed) {
            weapon.imbue = Imbue.SPEED;
            GLog.m3p(TXT_FAST, weapon.name());
        } else {
            weapon.imbue = Imbue.ACCURACY;
            GLog.m3p(TXT_ACCURATE, weapon.name());
        }
        curUser.sprite.operate(curUser.pos);
        Sample.INSTANCE.play(Assets.SND_MISS);
        curUser.spend(TIME_TO_APPLY);
        curUser.busy();
    }

    public int price() {
        return this.quantity * 40;
    }

    public String info() {
        return "Using a weightstone, you can balance your melee weapon to increase its speed or accuracy.";
    }
}
