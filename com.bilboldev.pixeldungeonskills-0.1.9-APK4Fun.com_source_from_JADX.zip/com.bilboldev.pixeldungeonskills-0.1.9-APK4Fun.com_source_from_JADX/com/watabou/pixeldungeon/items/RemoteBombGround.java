package com.watabou.pixeldungeon.items;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Paralysis;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.BlastParticle;
import com.watabou.pixeldungeon.effects.particles.SmokeParticle;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;

public class RemoteBombGround extends Item {
    public int pos;

    public RemoteBombGround() {
        this.name = "remote bomb";
        this.image = ItemSpriteSheet.RemoteBomb;
        this.defaultAction = Item.AC_THROW;
        this.stackable = true;
        this.pos = 0;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put("pos", this.pos);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.pos = bundle.getInt("pos");
    }

    protected void onThrow(int cell) {
        if (Level.pit[cell]) {
            super.onThrow(cell);
        }
    }

    public boolean doPickUp(Hero hero) {
        GLog.m1i("Cannot be retrieved anymore...", new Object[0]);
        return false;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public Item random() {
        this.quantity = 1;
        return this;
    }

    public int price() {
        return this.quantity * 10;
    }

    public String info() {
        return "This small bomb will explode as soon as a signal is sent from a trigger beacon.";
    }

    public void explode() {
        Sample.INSTANCE.play(Assets.SND_BLAST, Pickaxe.TIME_TO_MINE);
        if (Dungeon.visible[this.pos]) {
            CellEmitter.center(this.pos).burst(BlastParticle.FACTORY, 30);
        }
        for (int n : Level.NEIGHBOURS9) {
            int c = this.pos + n;
            if (c >= 0 && c < Level.LENGTH) {
                if (Dungeon.visible[c]) {
                    CellEmitter.get(c).burst(SmokeParticle.FACTORY, 4);
                }
                if (Level.flamable[c]) {
                    Level.set(c, 9);
                    GameScene.updateMap(c);
                }
                Char ch = Actor.findChar(c);
                if (ch != null) {
                    int dmg = Random.Int(Dungeon.depth + 1, (Dungeon.depth * 2) + 10) - Random.Int(ch.dr());
                    if (dmg > 0) {
                        ch.damage(dmg, this);
                        if (ch.isAlive()) {
                            Buff.prolong(ch, Paralysis.class, Pickaxe.TIME_TO_MINE);
                        }
                    }
                }
            }
        }
    }
}
