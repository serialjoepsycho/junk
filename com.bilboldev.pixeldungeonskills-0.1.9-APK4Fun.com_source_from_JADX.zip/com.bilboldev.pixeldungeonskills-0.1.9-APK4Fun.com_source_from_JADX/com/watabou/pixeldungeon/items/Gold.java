package com.watabou.pixeldungeon.items;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.Statistics;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndUpdates;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class Gold extends Item {
    private static final String TXT_COLLECT = "Collect gold coins to spend them later in a shop.";
    private static final String TXT_INFO = "A pile of %d gold coins. Collect gold coins to spend them later in a shop.";
    private static final String TXT_INFO_1 = "One gold coin. Collect gold coins to spend them later in a shop.";
    private static final String TXT_VALUE = "%+d";
    private static final String TXT_VALUE_LOOT = "%+d (%+d loot!)";
    private static final String VALUE = "value";

    public Gold() {
        this(1);
    }

    public Gold(int value) {
        this.name = "gold";
        this.image = 14;
        this.stackable = true;
        this.quantity = value;
    }

    public ArrayList<String> actions(Hero hero) {
        return new ArrayList();
    }

    public boolean doPickUp(Hero hero) {
        Dungeon.gold += (this.quantity * ((hero.skillLoot / 10) + 1)) + hero.skillLoot;
        Statistics.goldCollected += this.quantity * ((hero.skillLoot / 10) + 1);
        Badges.validateGoldCollected();
        GameScene.pickUp(this);
        if (hero.heroClass != HeroClass.ROGUE) {
            hero.sprite.showStatus(CharSprite.NEUTRAL, TXT_VALUE, Integer.valueOf(this.quantity));
        } else {
            hero.sprite.showStatus(CharSprite.NEUTRAL, TXT_VALUE_LOOT, Integer.valueOf(this.quantity), Integer.valueOf(hero.skillLoot + ((this.quantity * hero.skillLoot) / 10)));
        }
        hero.spendAndNext(Key.TIME_TO_UNLOCK);
        Sample.INSTANCE.play(Assets.SND_GOLD, Key.TIME_TO_UNLOCK, Key.TIME_TO_UNLOCK, Random.Float(0.9f, 1.1f));
        return true;
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public String info() {
        switch (this.quantity) {
            case WndUpdates.ID_SEWERS /*0*/:
                return TXT_COLLECT;
            case WndUpdates.ID_PRISON /*1*/:
                return TXT_INFO_1;
            default:
                return Utils.format(TXT_INFO, Integer.valueOf(this.quantity));
        }
    }

    public Item random() {
        this.quantity = Random.Int((Dungeon.depth * 10) + 20, (Dungeon.depth * 20) + 40);
        return this;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(VALUE, this.quantity);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.quantity = bundle.getInt(VALUE);
    }
}
