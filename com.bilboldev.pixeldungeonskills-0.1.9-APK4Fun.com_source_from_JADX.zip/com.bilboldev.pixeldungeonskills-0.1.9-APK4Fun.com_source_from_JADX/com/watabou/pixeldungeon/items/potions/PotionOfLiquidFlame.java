package com.watabou.pixeldungeon.items.potions;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.blobs.Fire;
import com.watabou.pixeldungeon.scenes.GameScene;

public class PotionOfLiquidFlame extends Potion {
    public PotionOfLiquidFlame() {
        this.name = "Potion of Liquid Flame";
    }

    public void shatter(int cell) {
        if (Dungeon.visible[cell]) {
            setKnown();
            splash(cell);
            Sample.INSTANCE.play(Assets.SND_SHATTER);
        }
        GameScene.add(Blob.seed(cell, 2, Fire.class));
    }

    public String desc() {
        return "This flask contains an unstable compound which will burst violently into flame upon exposure to open air.";
    }

    public int price() {
        return isKnown() ? this.quantity * 40 : super.price();
    }
}
