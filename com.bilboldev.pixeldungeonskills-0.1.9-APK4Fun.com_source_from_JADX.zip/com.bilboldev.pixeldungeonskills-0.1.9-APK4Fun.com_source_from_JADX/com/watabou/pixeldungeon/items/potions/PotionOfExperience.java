package com.watabou.pixeldungeon.items.potions;

import com.watabou.pixeldungeon.actors.hero.Hero;

public class PotionOfExperience extends Potion {
    public PotionOfExperience() {
        this.name = "Potion of Experience";
    }

    protected void apply(Hero hero) {
        setKnown();
        hero.earnExp(hero.maxExp() - hero.exp);
    }

    public String desc() {
        return "The storied experiences of multitudes of battles reduced to liquid form, this draught will instantly raise your experience level.";
    }

    public int price() {
        return isKnown() ? this.quantity * 80 : super.price();
    }
}
