package com.watabou.pixeldungeon.items.potions;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.sprites.CharSprite;
import com.watabou.pixeldungeon.utils.GLog;

public class PotionOfMight extends PotionOfStrength {
    public PotionOfMight() {
        this.name = "Potion of Might";
    }

    protected void apply(Hero hero) {
        setKnown();
        hero.STR++;
        hero.HT += 5;
        hero.HP += 5;
        hero.sprite.showStatus(CharSprite.POSITIVE, "+1 str, +5 ht", new Object[0]);
        GLog.m3p("Newfound strength surges through your body.", new Object[0]);
        Badges.validateStrengthAttained();
    }

    public String desc() {
        return "This powerful liquid will course through your muscles, permanently increasing your strength by one point and health by five points.";
    }

    public int price() {
        return isKnown() ? this.quantity * 200 : super.price();
    }
}
