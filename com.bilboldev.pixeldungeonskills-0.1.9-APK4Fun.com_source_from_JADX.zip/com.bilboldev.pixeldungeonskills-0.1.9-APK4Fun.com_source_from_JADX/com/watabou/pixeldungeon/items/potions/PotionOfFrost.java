package com.watabou.pixeldungeon.items.potions;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.blobs.Fire;
import com.watabou.pixeldungeon.actors.blobs.Freezing;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.utils.BArray;
import com.watabou.utils.PathFinder;

public class PotionOfFrost extends Potion {
    private static final int DISTANCE = 2;

    public PotionOfFrost() {
        this.name = "Potion of Frost";
    }

    public void shatter(int cell) {
        PathFinder.buildDistanceMap(cell, BArray.not(Level.losBlocking, null), (int) DISTANCE);
        Fire fire = (Fire) Dungeon.level.blobs.get(Fire.class);
        boolean visible = false;
        for (int i = 0; i < Level.LENGTH; i++) {
            if (PathFinder.distance[i] < Integer.MAX_VALUE) {
                visible = Freezing.affect(i, fire) || visible;
            }
        }
        if (visible) {
            splash(cell);
            Sample.INSTANCE.play(Assets.SND_SHATTER);
            setKnown();
        }
    }

    public String desc() {
        return "Upon exposure to open air, this chemical will evaporate into a freezing cloud, causing any creature that contacts it to be frozen in place, unable to act and move.";
    }

    public int price() {
        return isKnown() ? this.quantity * 50 : super.price();
    }
}
