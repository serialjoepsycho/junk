package com.watabou.pixeldungeon.items.potions;

import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Levitation;
import com.watabou.pixeldungeon.actors.buffs.MindVision;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.utils.GLog;

public class PotionOfLevitation extends Potion {
    public PotionOfLevitation() {
        this.name = "Potion of Levitation";
    }

    protected void apply(Hero hero) {
        setKnown();
        Buff.affect(hero, Levitation.class, MindVision.DURATION);
        GLog.m1i("You float into the air!", new Object[0]);
    }

    public String desc() {
        return "Drinking this curious liquid will cause you to hover in the air, able to drift effortlessly over traps. Flames and gases fill the air, however, and cannot be bypassed while airborne.";
    }

    public int price() {
        return isKnown() ? this.quantity * 35 : super.price();
    }
}
