package com.watabou.pixeldungeon.items.potions;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.blobs.ParalyticGas;
import com.watabou.pixeldungeon.actors.blobs.ToxicGas;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.GasesImmunity;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.BArray;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.PathFinder;

public class PotionOfPurity extends Potion {
    private static final int DISTANCE = 2;
    private static final String TXT_FRESHNESS = "You feel uncommon freshness in the air.";
    private static final String TXT_NO_SMELL = "You've stopped sensing any smells!";

    public PotionOfPurity() {
        this.name = "Potion of Purification";
    }

    public void shatter(int cell) {
        boolean heroAffected = true;
        PathFinder.buildDistanceMap(cell, BArray.not(Level.losBlocking, null), (int) DISTANCE);
        boolean procd = false;
        Blob[] blobs = new Blob[DISTANCE];
        blobs[0] = (Blob) Dungeon.level.blobs.get(ToxicGas.class);
        blobs[1] = (Blob) Dungeon.level.blobs.get(ParalyticGas.class);
        for (Blob blob : blobs) {
            if (blob != null) {
                for (int i = 0; i < Level.LENGTH; i++) {
                    if (PathFinder.distance[i] < Integer.MAX_VALUE) {
                        int value = blob.cur[i];
                        if (value > 0) {
                            blob.cur[i] = 0;
                            blob.volume -= value;
                            procd = true;
                            if (Dungeon.visible[i]) {
                                CellEmitter.get(i).burst(Speck.factory(ItemSpriteSheet.PICKAXE), 1);
                            }
                        }
                    }
                }
            }
        }
        if (PathFinder.distance[Dungeon.hero.pos] >= Integer.MAX_VALUE) {
            heroAffected = false;
        }
        if (procd) {
            if (Dungeon.visible[cell]) {
                splash(cell);
                Sample.INSTANCE.play(Assets.SND_SHATTER);
            }
            setKnown();
            if (heroAffected) {
                GLog.m3p(TXT_FRESHNESS, new Object[0]);
                return;
            }
            return;
        }
        super.shatter(cell);
        if (heroAffected) {
            GLog.m1i(TXT_FRESHNESS, new Object[0]);
            setKnown();
        }
    }

    protected void apply(Hero hero) {
        GLog.m4w(TXT_NO_SMELL, new Object[0]);
        Buff.prolong(hero, GasesImmunity.class, GasesImmunity.DURATION);
        setKnown();
    }

    public String desc() {
        return "This reagent will quickly neutralize all harmful gases in the area of effect. Drinking it will give you a temporary immunity to such gases.";
    }

    public int price() {
        return isKnown() ? this.quantity * 50 : super.price();
    }
}
