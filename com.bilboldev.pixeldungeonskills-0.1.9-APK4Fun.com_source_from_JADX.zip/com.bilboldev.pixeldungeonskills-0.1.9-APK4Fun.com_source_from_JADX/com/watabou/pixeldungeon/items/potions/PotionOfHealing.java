package com.watabou.pixeldungeon.items.potions;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.buffs.Bleeding;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Cripple;
import com.watabou.pixeldungeon.actors.buffs.Poison;
import com.watabou.pixeldungeon.actors.buffs.Weakness;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndUpdates;

public class PotionOfHealing extends Potion {
    public PotionOfHealing() {
        this.name = "Potion of Healing";
    }

    protected void apply(Hero hero) {
        setKnown();
        switch (hero.difficulty) {
            case WndUpdates.ID_SEWERS /*0*/:
            case WndUpdates.ID_PRISON /*1*/:
                heal(Dungeon.hero, 100);
                GLog.m3p("Your wounds heal completely.", new Object[0]);
            case WndUpdates.ID_CAVES /*2*/:
                heal(Dungeon.hero, 75);
                GLog.m3p("Healing potion heals " + Math.floor(0.75d * ((double) hero.HT)) + " hit points!", new Object[0]);
            case WndUpdates.ID_METROPOLIS /*3*/:
                heal(Dungeon.hero, 50);
                GLog.m3p("Healing potion heals " + Math.floor(0.5d * ((double) hero.HT)) + " hit points!", new Object[0]);
            case WndUpdates.ID_HALLS /*4*/:
                heal(Dungeon.hero, 25);
                GLog.m3p("Healing potion heals " + Math.floor(0.25d * ((double) hero.HT)) + " hit points!", new Object[0]);
            default:
        }
    }

    public static void heal(Hero hero, int limit) {
        hero.HP += (hero.HT * limit) / 100;
        if (hero.HP > hero.HT) {
            hero.HP = hero.HT;
        }
        Buff.detach(hero, Poison.class);
        Buff.detach(hero, Cripple.class);
        Buff.detach(hero, Weakness.class);
        Buff.detach(hero, Bleeding.class);
        hero.sprite.emitter().start(Speck.factory(0), 0.4f, 4);
    }

    public String desc() {
        return "An elixir that will instantly return you to full health and cure poison.";
    }

    public int price() {
        return isKnown() ? this.quantity * 30 : super.price();
    }
}
