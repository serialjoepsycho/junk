package com.watabou.pixeldungeon.items.potions;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.blobs.ToxicGas;
import com.watabou.pixeldungeon.scenes.GameScene;

public class PotionOfToxicGas extends Potion {
    public PotionOfToxicGas() {
        this.name = "Potion of Toxic Gas";
    }

    public void shatter(int cell) {
        if (Dungeon.visible[cell]) {
            setKnown();
            splash(cell);
            Sample.INSTANCE.play(Assets.SND_SHATTER);
        }
        GameScene.add(Blob.seed(cell, 1000, ToxicGas.class));
    }

    public String desc() {
        return "Uncorking or shattering this pressurized glass will cause its contents to explode into a deadly cloud of toxic green gas. You might choose to fling this potion at distant enemies instead of uncorking it by hand.";
    }

    public int price() {
        return isKnown() ? this.quantity * 40 : super.price();
    }
}
