package com.watabou.pixeldungeon.items.potions;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.Splash;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.ItemStatusHandler;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSprite;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.windows.WndOptions;
import com.watabou.utils.Bundle;
import java.util.ArrayList;
import java.util.HashSet;

public class Potion extends Item {
    public static final String AC_DRINK = "DRINK";
    private static final float TIME_TO_DRINK = 1.0f;
    private static final String TXT_BENEFICIAL = "Beneficial potion";
    private static final String TXT_HARMFUL = "Harmful potion!";
    private static final String TXT_NO = "No, I changed my mind";
    private static final String TXT_R_U_SURE_DRINK = "Are you sure you want to drink it? In most cases you should throw such potions at your enemies.";
    private static final String TXT_R_U_SURE_THROW = "Are you sure you want to throw it? In most cases it makes sense to drink it.";
    private static final String TXT_YES = "Yes, I know what I'm doing";
    private static final String[] colors;
    private static ItemStatusHandler<Potion> handler;
    private static final Integer[] images;
    private static final Class<?>[] potions;
    private String color;

    /* renamed from: com.watabou.pixeldungeon.items.potions.Potion.1 */
    class C00871 extends WndOptions {
        final /* synthetic */ Hero val$hero;

        C00871(String title, String message, String[] options, Hero hero) {
            this.val$hero = hero;
            super(title, message, options);
        }

        protected void onSelect(int index) {
            if (index == 0) {
                Potion.this.drink(this.val$hero);
            }
        }
    }

    /* renamed from: com.watabou.pixeldungeon.items.potions.Potion.2 */
    class C00882 extends WndOptions {
        final /* synthetic */ Hero val$hero;

        C00882(String title, String message, String[] options, Hero hero) {
            this.val$hero = hero;
            super(title, message, options);
        }

        protected void onSelect(int index) {
            if (index == 0) {
                super.doThrow(this.val$hero);
            }
        }
    }

    static {
        potions = new Class[]{PotionOfHealing.class, PotionOfExperience.class, PotionOfToxicGas.class, PotionOfLiquidFlame.class, PotionOfStrength.class, PotionOfParalyticGas.class, PotionOfLevitation.class, PotionOfMindVision.class, PotionOfPurity.class, PotionOfInvisibility.class, PotionOfMight.class, PotionOfFrost.class};
        colors = new String[]{"turquoise", "crimson", "azure", "jade", "golden", "magenta", "charcoal", "ivory", "amber", "bistre", "indigo", "silver"};
        images = new Integer[]{Integer.valueOf(56), Integer.valueOf(57), Integer.valueOf(58), Integer.valueOf(59), Integer.valueOf(60), Integer.valueOf(61), Integer.valueOf(62), Integer.valueOf(63), Integer.valueOf(64), Integer.valueOf(65), Integer.valueOf(66), Integer.valueOf(67)};
    }

    public static void initColors() {
        handler = new ItemStatusHandler(potions, colors, images);
    }

    public static void save(Bundle bundle) {
        handler.save(bundle);
    }

    public static void restore(Bundle bundle) {
        handler = new ItemStatusHandler(potions, colors, images, bundle);
    }

    public Potion() {
        this.stackable = true;
        this.defaultAction = AC_DRINK;
        this.image = handler.image(this);
        this.color = handler.label(this);
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_DRINK);
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (!action.equals(AC_DRINK)) {
            super.execute(hero, action);
        } else if (isKnown() && ((this instanceof PotionOfLiquidFlame) || (this instanceof PotionOfToxicGas) || (this instanceof PotionOfParalyticGas))) {
            GameScene.show(new C00871(TXT_HARMFUL, TXT_R_U_SURE_DRINK, new String[]{TXT_YES, TXT_NO}, hero));
        } else {
            drink(hero);
        }
    }

    public void doThrow(Hero hero) {
        if (isKnown() && ((this instanceof PotionOfExperience) || (this instanceof PotionOfHealing) || (this instanceof PotionOfLevitation) || (this instanceof PotionOfMindVision) || (this instanceof PotionOfStrength) || (this instanceof PotionOfInvisibility) || (this instanceof PotionOfMight))) {
            GameScene.show(new C00882(TXT_BENEFICIAL, TXT_R_U_SURE_THROW, new String[]{TXT_YES, TXT_NO}, hero));
            return;
        }
        super.doThrow(hero);
    }

    protected void drink(Hero hero) {
        detach(hero.belongings.backpack);
        hero.spend(TIME_TO_DRINK);
        hero.busy();
        onThrow(hero.pos);
        Sample.INSTANCE.play(Assets.SND_DRINK);
        hero.sprite.operate(hero.pos);
    }

    protected void onThrow(int cell) {
        if (Dungeon.hero.pos == cell) {
            apply(Dungeon.hero);
        } else if (Dungeon.level.map[cell] == 34 || Level.pit[cell]) {
            super.onThrow(cell);
        } else {
            shatter(cell);
        }
    }

    protected void apply(Hero hero) {
        shatter(hero.pos);
    }

    public void shatter(int cell) {
        if (Dungeon.visible[cell]) {
            GLog.m1i("The flask shatters and " + color() + " liquid splashes harmlessly", new Object[0]);
            Sample.INSTANCE.play(Assets.SND_SHATTER);
            splash(cell);
        }
    }

    public boolean isKnown() {
        return handler.isKnown(this);
    }

    public void setKnown() {
        if (!isKnown()) {
            handler.know(this);
        }
        Badges.validateAllPotionsIdentified();
    }

    public Item identify() {
        setKnown();
        return this;
    }

    protected String color() {
        return this.color;
    }

    public String name() {
        return isKnown() ? this.name : this.color + " potion";
    }

    public String info() {
        return isKnown() ? desc() : "This flask contains a swirling " + this.color + " liquid. " + "Who knows what it will do when drunk or thrown?";
    }

    public boolean isIdentified() {
        return isKnown();
    }

    public boolean isUpgradable() {
        return false;
    }

    public static HashSet<Class<? extends Potion>> getKnown() {
        return handler.known();
    }

    public static HashSet<Class<? extends Potion>> getUnknown() {
        return handler.unknown();
    }

    public static boolean allKnown() {
        return handler.known().size() == potions.length;
    }

    protected void splash(int cell) {
        Splash.at(cell, ItemSprite.pick(this.image, 8, 10), 5);
    }

    public int price() {
        return this.quantity * 20;
    }
}
