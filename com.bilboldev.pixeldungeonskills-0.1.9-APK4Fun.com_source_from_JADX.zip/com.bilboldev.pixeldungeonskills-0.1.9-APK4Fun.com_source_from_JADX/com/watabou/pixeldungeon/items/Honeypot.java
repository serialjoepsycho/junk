package com.watabou.pixeldungeon.items;

import com.watabou.noosa.audio.Sample;
import com.watabou.noosa.tweeners.AlphaTweener;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Actor;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.mobs.Mob;
import com.watabou.pixeldungeon.actors.mobs.npcs.Bee;
import com.watabou.pixeldungeon.effects.Pushing;
import com.watabou.pixeldungeon.effects.Splash;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.scenes.GameScene;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Collection;

public class Honeypot extends Item {
    public static final String AC_SHATTER = "SHATTER";

    public Honeypot() {
        this.name = "honeypot";
        this.image = ItemSpriteSheet.HONEYPOT;
        this.defaultAction = Item.AC_THROW;
        this.stackable = true;
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(AC_SHATTER);
        return actions;
    }

    public void execute(Hero hero, String action) {
        if (action.equals(AC_SHATTER)) {
            hero.sprite.zap(hero.pos);
            shatter(hero.pos);
            detach(hero.belongings.backpack);
            hero.spendAndNext(Key.TIME_TO_UNLOCK);
            return;
        }
        super.execute(hero, action);
    }

    protected void onThrow(int cell) {
        if (Level.pit[cell]) {
            super.onThrow(cell);
        } else {
            shatter(cell);
        }
    }

    private void shatter(int pos) {
        Sample.INSTANCE.play(Assets.SND_SHATTER);
        if (Dungeon.visible[pos]) {
            Splash.at(pos, 16766208, 5);
        }
        int newPos = pos;
        if (Actor.findChar(pos) != null) {
            Collection candidates = new ArrayList();
            boolean[] passable = Level.passable;
            for (int n : Level.NEIGHBOURS4) {
                int c = pos + n;
                if (passable[c] && Actor.findChar(c) == null) {
                    candidates.add(Integer.valueOf(c));
                }
            }
            if (candidates.size() > 0) {
                newPos = ((Integer) Random.element(candidates)).intValue();
            } else {
                newPos = -1;
            }
        }
        if (newPos != -1) {
            Mob bee = new Bee();
            bee.spawn(Dungeon.depth);
            bee.HP = bee.HT;
            bee.pos = newPos;
            GameScene.add(bee);
            Actor.addDelayed(new Pushing(bee, pos, newPos), -1.0f);
            bee.sprite.alpha(0.0f);
            bee.sprite.parent.add(new AlphaTweener(bee.sprite, Key.TIME_TO_UNLOCK, 0.15f));
            Sample.INSTANCE.play(Assets.SND_BEE);
        }
    }

    public boolean isUpgradable() {
        return false;
    }

    public boolean isIdentified() {
        return true;
    }

    public int price() {
        return this.quantity * 50;
    }

    public String info() {
        return "There is not much honey in this small honeypot, but there is a golden bee there and it doesn't want to leave it.";
    }
}
