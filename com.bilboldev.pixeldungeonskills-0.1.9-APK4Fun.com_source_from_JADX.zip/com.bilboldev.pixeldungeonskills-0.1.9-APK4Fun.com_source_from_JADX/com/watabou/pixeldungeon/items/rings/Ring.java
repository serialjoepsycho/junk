package com.watabou.pixeldungeon.items.rings;

import com.watabou.noosa.Game;
import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.BuildConfig;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroClass;
import com.watabou.pixeldungeon.items.EquipableItem;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.ItemStatusHandler;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.pixeldungeon.windows.WndOptions;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class Ring extends EquipableItem {
    private static final int TICKS_TO_KNOW = 200;
    private static final float TIME_TO_EQUIP = 1.0f;
    private static final String TXT_IDENTIFY = "you are now familiar enough with your %s to identify it. It is %s.";
    private static final String TXT_UNEQUIP_MESSAGE = "You can only wear two rings at a time. Unequip one of your equipped rings.";
    private static final String TXT_UNEQUIP_TITLE = "Unequip one ring";
    private static final String UNFAMILIRIARITY = "unfamiliarity";
    private static final String[] gems;
    private static ItemStatusHandler<Ring> handler;
    private static final Integer[] images;
    private static final Class<?>[] rings;
    protected Buff buff;
    private String gem;
    private int ticksToKnow;

    public class RingBuff extends Buff {
        private static final String TXT_KNOWN = "This is a %s";
        public int level;

        public RingBuff() {
            this.level = Ring.this.level;
        }

        public boolean attachTo(Char target) {
            if ((target instanceof Hero) && ((Hero) target).heroClass == HeroClass.ROGUE && !Ring.this.isKnown()) {
                Ring.this.setKnown();
                GLog.m1i(TXT_KNOWN, Ring.this.name());
                Badges.validateItemLevelAquired(Ring.this);
            }
            return super.attachTo(target);
        }

        public boolean act() {
            if (!Ring.this.isIdentified() && Ring.access$006(Ring.this) <= 0) {
                String gemName = Ring.this.name();
                Ring.this.identify();
                GLog.m4w(Ring.TXT_IDENTIFY, gemName, Ring.this.toString());
                Badges.validateItemLevelAquired(Ring.this);
            }
            Ring.this.use();
            spend(Ring.TIME_TO_EQUIP);
            return true;
        }
    }

    /* renamed from: com.watabou.pixeldungeon.items.rings.Ring.1 */
    class C00901 extends WndOptions {
        final /* synthetic */ Hero val$hero;
        final /* synthetic */ Ring val$r1;
        final /* synthetic */ Ring val$r2;

        C00901(String title, String message, String[] options, Hero hero, Ring ring, Ring ring2) {
            this.val$hero = hero;
            this.val$r1 = ring;
            this.val$r2 = ring2;
            super(title, message, options);
        }

        protected void onSelect(int index) {
            Ring.this.detach(this.val$hero.belongings.backpack);
            if ((index == 0 ? this.val$r1 : this.val$r2).doUnequip(this.val$hero, true, false)) {
                Ring.this.doEquip(this.val$hero);
            } else {
                Ring.this.collect(this.val$hero.belongings.backpack);
            }
        }
    }

    static /* synthetic */ int access$006(Ring x0) {
        int i = x0.ticksToKnow - 1;
        x0.ticksToKnow = i;
        return i;
    }

    static {
        rings = new Class[]{RingOfMending.class, RingOfDetection.class, RingOfShadows.class, RingOfPower.class, RingOfHerbalism.class, RingOfAccuracy.class, RingOfEvasion.class, RingOfSatiety.class, RingOfHaste.class, RingOfHaggler.class, RingOfElements.class, RingOfThorns.class, GemStone.class};
        gems = new String[]{"diamond", "opal", "garnet", "ruby", "amethyst", "topaz", "onyx", "tourmaline", "emerald", "sapphire", "quartz", "agate", BuildConfig.VERSION_NAME};
        images = new Integer[]{Integer.valueOf(32), Integer.valueOf(33), Integer.valueOf(34), Integer.valueOf(35), Integer.valueOf(36), Integer.valueOf(37), Integer.valueOf(38), Integer.valueOf(39), Integer.valueOf(72), Integer.valueOf(73), Integer.valueOf(74), Integer.valueOf(75), Integer.valueOf(ItemSpriteSheet.GemStone)};
    }

    public static void initGems() {
        handler = new ItemStatusHandler(rings, gems, images, 1);
    }

    public static void save(Bundle bundle) {
        handler.save(bundle);
    }

    public static void restore(Bundle bundle) {
        handler = new ItemStatusHandler(rings, gems, images, bundle);
    }

    public Ring() {
        this.ticksToKnow = TICKS_TO_KNOW;
        syncGem();
    }

    public void syncGem() {
        this.image = handler.image(this);
        this.gem = handler.label(this);
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.add(isEquipped(hero) ? EquipableItem.AC_UNEQUIP : EquipableItem.AC_EQUIP);
        return actions;
    }

    public boolean doEquip(Hero hero) {
        if (hero.belongings.ring1 == null || hero.belongings.ring2 == null) {
            if (hero.belongings.ring1 == null) {
                hero.belongings.ring1 = this;
            } else {
                hero.belongings.ring2 = this;
            }
            detach(hero.belongings.backpack);
            activate(hero);
            this.cursedKnown = true;
            if (this.cursed) {
                EquipableItem.equipCursed(hero);
                GLog.m2n("your " + this + " tightens around your finger painfully", new Object[0]);
            }
            hero.spendAndNext(TIME_TO_EQUIP);
            return true;
        }
        Ring r1 = hero.belongings.ring1;
        Ring r2 = hero.belongings.ring2;
        Game.scene().add(new C00901(TXT_UNEQUIP_TITLE, TXT_UNEQUIP_MESSAGE, new String[]{Utils.capitalize(r1.toString()), Utils.capitalize(r2.toString())}, hero, r1, r2));
        return false;
    }

    public void activate(Char ch) {
        this.buff = buff();
        this.buff.attachTo(ch);
    }

    public boolean doUnequip(Hero hero, boolean collect, boolean single) {
        if (!super.doUnequip(hero, collect, single)) {
            return false;
        }
        if (hero.belongings.ring1 == this) {
            hero.belongings.ring1 = null;
        } else {
            hero.belongings.ring2 = null;
        }
        hero.remove(this.buff);
        this.buff = null;
        return true;
    }

    public boolean isEquipped(Hero hero) {
        return hero.belongings.ring1 == this || hero.belongings.ring2 == this;
    }

    public Item upgrade() {
        super.upgrade();
        if (this.buff != null) {
            Char owner = this.buff.target;
            this.buff.detach();
            Buff buff = buff();
            this.buff = buff;
            if (buff != null) {
                this.buff.attachTo(owner);
            }
        }
        return this;
    }

    public Item degrade() {
        super.degrade();
        if (this.buff != null) {
            Char owner = this.buff.target;
            this.buff.detach();
            Buff buff = buff();
            this.buff = buff;
            if (buff != null) {
                this.buff.attachTo(owner);
            }
        }
        return this;
    }

    public int maxDurability(int lvl) {
        int i = 1;
        if (lvl <= 1) {
            return Integer.MAX_VALUE;
        }
        if (lvl < 16) {
            i = 16 - lvl;
        }
        return i * 80;
    }

    public boolean isKnown() {
        return handler.isKnown(this);
    }

    protected void setKnown() {
        if (!isKnown()) {
            handler.know(this);
        }
        Badges.validateAllRingsIdentified();
    }

    public String name() {
        return isKnown() ? this.name : this.gem + " ring";
    }

    public String desc() {
        return "This metal band is adorned with a large " + this.gem + " gem " + "that glitters in the darkness. Who knows what effect it has when worn?";
    }

    public String info() {
        if (isEquipped(Dungeon.hero)) {
            return desc() + "\n\n" + "The " + name() + " is on your finger" + (this.cursed ? ", and because it is cursed, you are powerless to remove it." : ".");
        } else if (this.cursed && this.cursedKnown) {
            return desc() + "\n\nYou can feel a malevolent magic lurking within the " + name() + ".";
        } else {
            return desc();
        }
    }

    public boolean isIdentified() {
        return super.isIdentified() && isKnown();
    }

    public Item identify() {
        setKnown();
        return super.identify();
    }

    public Item random() {
        int lvl = Random.Int(1, 3);
        if (Random.Float() < 0.3f) {
            degrade(lvl);
            this.cursed = true;
        } else {
            upgrade(lvl);
        }
        return this;
    }

    public static boolean allKnown() {
        return handler.known().size() == rings.length + -2;
    }

    public int price() {
        int price = 80;
        if (this.cursed && this.cursedKnown) {
            price = 80 / 2;
        }
        if (this.levelKnown) {
            if (this.level > 0) {
                price *= this.level + 1;
            } else if (this.level < 0) {
                price /= 1 - this.level;
            }
        }
        if (price < 1) {
            return 1;
        }
        return price;
    }

    protected RingBuff buff() {
        return null;
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(UNFAMILIRIARITY, this.ticksToKnow);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        int i = bundle.getInt(UNFAMILIRIARITY);
        this.ticksToKnow = i;
        if (i == 0) {
            this.ticksToKnow = TICKS_TO_KNOW;
        }
    }
}
