package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfMending extends Ring {

    public class Rejuvenation extends RingBuff {
        public Rejuvenation() {
            super();
        }
    }

    public RingOfMending() {
        this.name = "Ring of Mending";
    }

    protected RingBuff buff() {
        return new Rejuvenation();
    }

    public String desc() {
        if (isKnown()) {
            return "This ring increases the body's regenerative properties, allowing one to recover lost health at an accelerated rate. Degraded rings will decrease or even halt one's natural regeneration.";
        }
        return super.desc();
    }
}
