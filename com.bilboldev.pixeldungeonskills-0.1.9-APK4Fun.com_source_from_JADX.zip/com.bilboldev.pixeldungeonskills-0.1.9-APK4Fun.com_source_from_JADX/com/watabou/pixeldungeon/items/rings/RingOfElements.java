package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.actors.blobs.ToxicGas;
import com.watabou.pixeldungeon.actors.buffs.Burning;
import com.watabou.pixeldungeon.actors.buffs.Poison;
import com.watabou.pixeldungeon.actors.mobs.Eye;
import com.watabou.pixeldungeon.actors.mobs.Warlock;
import com.watabou.pixeldungeon.actors.mobs.Yog.BurningFist;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.quest.Pickaxe;
import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;
import com.watabou.pixeldungeon.levels.traps.LightningTrap.Electricity;
import com.watabou.utils.Random;
import java.util.HashSet;

public class RingOfElements extends Ring {
    private static final HashSet<Class<?>> EMPTY;
    private static final HashSet<Class<?>> FULL;

    public class Resistance extends RingBuff {
        public Resistance() {
            super();
        }

        public HashSet<Class<?>> resistances() {
            if (Random.Int(this.level + 3) >= 3) {
                return RingOfElements.FULL;
            }
            return RingOfElements.EMPTY;
        }

        public float durationFactor() {
            return this.level < 0 ? Key.TIME_TO_UNLOCK : (Pickaxe.TIME_TO_MINE + (0.5f * ((float) this.level))) / ((float) (this.level + 2));
        }
    }

    public RingOfElements() {
        this.name = "Ring of Elements";
    }

    protected RingBuff buff() {
        return new Resistance();
    }

    public String desc() {
        if (isKnown()) {
            return "This ring provides resistance to different elements, such as fire, electricity, gases etc. Also it decreases duration of negative effects.";
        }
        return super.desc();
    }

    static {
        EMPTY = new HashSet();
        FULL = new HashSet();
        FULL.add(Burning.class);
        FULL.add(ToxicGas.class);
        FULL.add(Poison.class);
        FULL.add(Electricity.class);
        FULL.add(Warlock.class);
        FULL.add(Eye.class);
        FULL.add(BurningFist.class);
    }
}
