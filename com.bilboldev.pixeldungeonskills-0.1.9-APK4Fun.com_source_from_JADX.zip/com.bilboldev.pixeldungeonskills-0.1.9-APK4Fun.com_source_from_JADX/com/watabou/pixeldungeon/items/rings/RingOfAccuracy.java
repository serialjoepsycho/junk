package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfAccuracy extends Ring {

    public class Accuracy extends RingBuff {
        public Accuracy() {
            super();
        }
    }

    public RingOfAccuracy() {
        this.name = "Ring of Accuracy";
    }

    protected RingBuff buff() {
        return new Accuracy();
    }

    public String desc() {
        if (isKnown()) {
            return "This ring increases your chance to hit the enemy.";
        }
        return super.desc();
    }
}
