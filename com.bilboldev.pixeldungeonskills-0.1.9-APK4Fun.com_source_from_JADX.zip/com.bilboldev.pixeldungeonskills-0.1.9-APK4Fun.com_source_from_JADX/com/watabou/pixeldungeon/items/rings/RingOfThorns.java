package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfThorns extends Ring {

    public class Thorns extends RingBuff {
        public Thorns() {
            super();
        }
    }

    public RingOfThorns() {
        this.name = "Ring of Thorns";
    }

    protected RingBuff buff() {
        return new Thorns();
    }

    public Item random() {
        this.level = 1;
        return this;
    }

    public boolean doPickUp(Hero hero) {
        identify();
        Badges.validateRingOfThorns();
        Badges.validateItemLevelAquired(this);
        return super.doPickUp(hero);
    }

    public boolean isUpgradable() {
        return false;
    }

    public void use() {
    }

    public String desc() {
        if (isKnown()) {
            return "Though this ring doesn't provide real thorns, an enemy that attacks you will itself be wounded by a fraction of the damage that it inflicts. Upgrading this ring won't give any additional bonuses.";
        }
        return super.desc();
    }
}
