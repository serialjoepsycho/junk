package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfDetection extends Ring {

    public class Detection extends RingBuff {
        public Detection() {
            super();
        }
    }

    public RingOfDetection() {
        this.name = "Ring of Detection";
    }

    public boolean doEquip(Hero hero) {
        if (!super.doEquip(hero)) {
            return false;
        }
        Dungeon.hero.search(false);
        return true;
    }

    protected RingBuff buff() {
        return new Detection();
    }

    public String desc() {
        if (isKnown()) {
            return "Wearing this ring will allow the wearer to notice hidden secrets - traps and secret doors - without taking time to search. Degraded rings of detection will dull your senses, making it harder to notice secrets even when actively searching for them.";
        }
        return super.desc();
    }
}
