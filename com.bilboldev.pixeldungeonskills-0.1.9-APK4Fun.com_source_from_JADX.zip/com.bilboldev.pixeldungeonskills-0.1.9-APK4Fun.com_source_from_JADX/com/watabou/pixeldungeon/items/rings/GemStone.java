package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.Speck;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;
import com.watabou.pixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.pixeldungeon.utils.GLog;
import com.watabou.utils.Bundle;
import java.util.ArrayList;

public class GemStone extends Ring {
    public int charge;

    public class GemStoneBuff extends RingBuff {
        public GemStoneBuff() {
            super();
        }
    }

    public GemStone() {
        this.name = "Gemstone";
        this.charge = 0;
    }

    public void ChargeUp() {
        this.charge++;
        if (this.charge == 20) {
            this.image = ItemSpriteSheet.GemStonePart;
            GLog.m3p("Gem stone partially charged!", new Object[0]);
        }
        if (this.charge == 40) {
            this.image = ItemSpriteSheet.GemStoneFull;
            GLog.m3p("Gem stone fully charged!", new Object[0]);
        }
    }

    public void execute(Hero hero, String action) {
        if (action.equals("Activate")) {
            this.image = ItemSpriteSheet.GemStone;
            Hero hero2 = Dungeon.hero;
            hero2.HP += this.charge;
            if (Dungeon.hero.HP > Dungeon.hero.HT) {
                Dungeon.hero.HP = Dungeon.hero.HT;
            }
            CellEmitter.center(hero.pos).burst(Speck.factory(0), 1);
            if (this.charge == 40) {
                GLog.m3p("Gemstone fully healed you!", new Object[0]);
                Dungeon.hero.HP = Dungeon.hero.HT;
            } else {
                GLog.m3p("Gemstone heals for " + this.charge + "HP!", new Object[0]);
            }
            this.charge = 0;
            return;
        }
        super.execute(hero, action);
    }

    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put("charge", this.charge);
    }

    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.charge = bundle.getInt("charge");
        if (this.charge > 19) {
            this.image = ItemSpriteSheet.GemStonePart;
        }
        if (this.charge == 40) {
            this.image = ItemSpriteSheet.GemStoneFull;
        }
    }

    public Item random() {
        this.level = 1;
        return this;
    }

    protected RingBuff buff() {
        return new GemStoneBuff();
    }

    public boolean doPickUp(Hero hero) {
        identify();
        return super.doPickUp(hero);
    }

    public boolean isUpgradable() {
        return false;
    }

    public void use() {
    }

    public String desc() {
        if (isKnown()) {
            return "The Gemstone is a unique artifact capable of storing life energy for later use. Although it does not damage the wearer, it drains away any rejuvenation his body possesses. That is until it fully charges and becomes a life savior in times of need.\n The Gemstone's current charge is " + this.charge + "/40";
        }
        return super.desc();
    }

    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (this.charge > 19) {
            actions.add("Activate");
        }
        return actions;
    }

    public String info() {
        if (isEquipped(Dungeon.hero)) {
            return desc();
        }
        if (this.cursed && this.cursedKnown) {
            return desc() + "\n\nYou can feel a malevolent magic lurking within the " + name() + ".";
        }
        return desc();
    }
}
