package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfPower extends Ring {

    public class Power extends RingBuff {
        public Power() {
            super();
        }
    }

    public RingOfPower() {
        this.name = "Ring of Power";
    }

    protected RingBuff buff() {
        return new Power();
    }

    public String desc() {
        if (isKnown()) {
            return "Your wands will become more powerful in the energy field that radiates from this ring. Degraded rings of power will instead weaken your wands.";
        }
        return super.desc();
    }
}
