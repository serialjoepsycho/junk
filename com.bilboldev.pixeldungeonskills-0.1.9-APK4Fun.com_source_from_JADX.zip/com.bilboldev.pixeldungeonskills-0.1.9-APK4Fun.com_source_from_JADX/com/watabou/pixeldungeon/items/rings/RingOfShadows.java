package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfShadows extends Ring {

    public class Shadows extends RingBuff {
        public Shadows() {
            super();
        }
    }

    public RingOfShadows() {
        this.name = "Ring of Shadows";
    }

    protected RingBuff buff() {
        return new Shadows();
    }

    public String desc() {
        if (isKnown()) {
            return "Enemies will be less likely to notice you if you wear this ring. Degraded rings of shadows will alert enemies who might otherwise not have noticed your presence.";
        }
        return super.desc();
    }
}
