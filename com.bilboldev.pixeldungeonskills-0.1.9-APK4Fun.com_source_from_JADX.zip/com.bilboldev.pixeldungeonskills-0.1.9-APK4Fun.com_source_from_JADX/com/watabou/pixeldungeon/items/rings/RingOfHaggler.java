package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.Badges;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfHaggler extends Ring {

    public class Haggling extends RingBuff {
        public Haggling() {
            super();
        }
    }

    public RingOfHaggler() {
        this.name = "Ring of Haggler";
    }

    protected RingBuff buff() {
        return new Haggling();
    }

    public Item random() {
        this.level = 1;
        return this;
    }

    public boolean doPickUp(Hero hero) {
        identify();
        Badges.validateRingOfHaggler();
        Badges.validateItemLevelAquired(this);
        return super.doPickUp(hero);
    }

    public boolean isUpgradable() {
        return false;
    }

    public void use() {
    }

    public String desc() {
        if (isKnown()) {
            return "In fact this ring doesn't provide any magic effect, but it demonstrates to shopkeepers and vendors, that the owner of the ring is a member of The Thieves' Guild. Usually they are glad to give a discount in exchange for temporary immunity guarantee. Upgrading this ring won't give any additional bonuses.";
        }
        return super.desc();
    }
}
