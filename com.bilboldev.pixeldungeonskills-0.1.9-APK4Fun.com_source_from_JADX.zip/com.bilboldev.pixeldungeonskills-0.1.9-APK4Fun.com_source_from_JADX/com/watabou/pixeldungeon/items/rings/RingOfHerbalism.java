package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfHerbalism extends Ring {

    public class Herbalism extends RingBuff {
        public Herbalism() {
            super();
        }
    }

    public RingOfHerbalism() {
        this.name = "Ring of Herbalism";
    }

    protected RingBuff buff() {
        return new Herbalism();
    }

    public String desc() {
        if (isKnown()) {
            return "This ring increases your chance to gather dew and seeds from trampled grass.";
        }
        return super.desc();
    }
}
