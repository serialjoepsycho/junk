package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfEvasion extends Ring {

    public class Evasion extends RingBuff {
        public Evasion() {
            super();
        }
    }

    public RingOfEvasion() {
        this.name = "Ring of Evasion";
    }

    protected RingBuff buff() {
        return new Evasion();
    }

    public String desc() {
        if (isKnown()) {
            return "This ring increases your chance to dodge enemy attack.";
        }
        return super.desc();
    }
}
