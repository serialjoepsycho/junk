package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfHaste extends Ring {

    public class Haste extends RingBuff {
        public Haste() {
            super();
        }
    }

    public RingOfHaste() {
        this.name = "Ring of Haste";
    }

    protected RingBuff buff() {
        return new Haste();
    }

    public String desc() {
        if (isKnown()) {
            return "This ring accelerates the wearer's flow of time, allowing one to perform all actions a little faster.";
        }
        return super.desc();
    }
}
