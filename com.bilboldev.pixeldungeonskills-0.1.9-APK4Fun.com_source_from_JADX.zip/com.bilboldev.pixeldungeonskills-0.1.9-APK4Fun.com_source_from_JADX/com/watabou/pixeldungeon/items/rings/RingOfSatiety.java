package com.watabou.pixeldungeon.items.rings;

import com.watabou.pixeldungeon.items.rings.Ring.RingBuff;

public class RingOfSatiety extends Ring {

    public class Satiety extends RingBuff {
        public Satiety() {
            super();
        }
    }

    public RingOfSatiety() {
        this.name = "Ring of Satiety";
    }

    protected RingBuff buff() {
        return new Satiety();
    }

    public String desc() {
        if (isKnown()) {
            return "Wearing this ring you can go without food longer. Degraded rings of satiety will cause the opposite effect.";
        }
        return super.desc();
    }
}
