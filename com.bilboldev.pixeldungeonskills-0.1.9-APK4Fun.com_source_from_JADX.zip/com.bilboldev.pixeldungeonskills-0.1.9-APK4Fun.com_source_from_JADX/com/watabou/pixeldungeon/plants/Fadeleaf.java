package com.watabou.pixeldungeon.plants;

import com.watabou.pixeldungeon.items.potions.PotionOfMindVision;

public class Fadeleaf extends Plant {
    private static final String TXT_DESC = "Touching a Fadeleaf will teleport any creature to a random place on the current level.";

    public static class Seed extends com.watabou.pixeldungeon.plants.Plant.Seed {
        public Seed() {
            this.plantName = "Fadeleaf";
            this.name = "seed of " + this.plantName;
            this.image = 94;
            this.plantClass = Fadeleaf.class;
            this.alchemyClass = PotionOfMindVision.class;
        }

        public String desc() {
            return Fadeleaf.TXT_DESC;
        }
    }

    public Fadeleaf() {
        this.image = 6;
        this.plantName = "Fadeleaf";
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void activate(com.watabou.pixeldungeon.actors.Char r8) {
        /*
        r7 = this;
        r4 = -1;
        super.activate(r8);
        r3 = r8 instanceof com.watabou.pixeldungeon.actors.hero.Hero;
        if (r3 == 0) goto L_0x002e;
    L_0x0008:
        r3 = r8;
        r3 = (com.watabou.pixeldungeon.actors.hero.Hero) r3;
        com.watabou.pixeldungeon.items.scrolls.ScrollOfTeleportation.teleportHero(r3);
        r8 = (com.watabou.pixeldungeon.actors.hero.Hero) r8;
        r3 = 0;
        r8.curAction = r3;
    L_0x0013:
        r3 = com.watabou.pixeldungeon.Dungeon.visible;
        r4 = r7.pos;
        r3 = r3[r4];
        if (r3 == 0) goto L_0x002d;
    L_0x001b:
        r3 = r7.pos;
        r3 = com.watabou.pixeldungeon.effects.CellEmitter.get(r3);
        r4 = 2;
        r4 = com.watabou.pixeldungeon.effects.Speck.factory(r4);
        r5 = 1045220557; // 0x3e4ccccd float:0.2 double:5.164075695E-315;
        r6 = 3;
        r3.start(r4, r5, r6);
    L_0x002d:
        return;
    L_0x002e:
        r3 = r8 instanceof com.watabou.pixeldungeon.actors.mobs.Mob;
        if (r3 == 0) goto L_0x0013;
    L_0x0032:
        r0 = 10;
    L_0x0034:
        r3 = com.watabou.pixeldungeon.Dungeon.level;
        r2 = r3.randomRespawnCell();
        r1 = r0 + -1;
        if (r0 > 0) goto L_0x0054;
    L_0x003e:
        if (r2 == r4) goto L_0x0013;
    L_0x0040:
        r8.pos = r2;
        r3 = r8.sprite;
        r4 = r8.pos;
        r3.place(r4);
        r3 = r8.sprite;
        r4 = com.watabou.pixeldungeon.Dungeon.visible;
        r5 = r7.pos;
        r4 = r4[r5];
        r3.visible = r4;
        goto L_0x0013;
    L_0x0054:
        if (r2 != r4) goto L_0x003e;
    L_0x0056:
        r0 = r1;
        goto L_0x0034;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.watabou.pixeldungeon.plants.Fadeleaf.activate(com.watabou.pixeldungeon.actors.Char):void");
    }

    public String desc() {
        return TXT_DESC;
    }
}
