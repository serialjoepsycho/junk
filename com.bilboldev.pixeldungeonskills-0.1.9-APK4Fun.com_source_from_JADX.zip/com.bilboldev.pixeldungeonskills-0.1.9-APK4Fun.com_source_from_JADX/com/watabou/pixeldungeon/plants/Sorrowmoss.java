package com.watabou.pixeldungeon.plants;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.buffs.Poison;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.PoisonParticle;
import com.watabou.pixeldungeon.items.potions.PotionOfToxicGas;

public class Sorrowmoss extends Plant {
    private static final String TXT_DESC = "A Sorrowmoss is a flower (not a moss) with razor-sharp petals, coated with a deadly venom.";

    public static class Seed extends com.watabou.pixeldungeon.plants.Plant.Seed {
        public Seed() {
            this.plantName = "Sorrowmoss";
            this.name = "seed of " + this.plantName;
            this.image = 90;
            this.plantClass = Sorrowmoss.class;
            this.alchemyClass = PotionOfToxicGas.class;
        }

        public String desc() {
            return Sorrowmoss.TXT_DESC;
        }
    }

    public Sorrowmoss() {
        this.image = 2;
        this.plantName = "Sorrowmoss";
    }

    public void activate(Char ch) {
        super.activate(ch);
        if (ch != null) {
            ((Poison) Buff.affect(ch, Poison.class)).set(Poison.durationFactor(ch) * ((float) ((Dungeon.depth / 2) + 4)));
        }
        if (Dungeon.visible[this.pos]) {
            CellEmitter.center(this.pos).burst(PoisonParticle.SPLASH, 3);
        }
    }

    public String desc() {
        return TXT_DESC;
    }
}
