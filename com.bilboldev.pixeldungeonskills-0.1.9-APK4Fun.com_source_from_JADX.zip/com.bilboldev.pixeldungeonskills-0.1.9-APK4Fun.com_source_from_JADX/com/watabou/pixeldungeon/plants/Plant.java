package com.watabou.pixeldungeon.plants;

import com.watabou.noosa.audio.Sample;
import com.watabou.pixeldungeon.Assets;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Barkskin;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.actors.hero.Hero;
import com.watabou.pixeldungeon.actors.hero.HeroSubClass;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.LeafParticle;
import com.watabou.pixeldungeon.items.Dewdrop;
import com.watabou.pixeldungeon.items.Generator;
import com.watabou.pixeldungeon.items.Generator.Category;
import com.watabou.pixeldungeon.items.Item;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.sprites.PlantSprite;
import com.watabou.pixeldungeon.utils.Utils;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;
import java.util.ArrayList;

public class Plant implements Bundlable {
    private static final String POS = "pos";
    public int image;
    public String plantName;
    public int pos;
    public PlantSprite sprite;

    public static class Seed extends Item {
        public static final String AC_PLANT = "PLANT";
        private static final float TIME_TO_PLANT = 1.0f;
        private static final String TXT_INFO = "Throw this seed to the place where you want to grow %s.\n\n%s";
        public Class<? extends Item> alchemyClass;
        protected Class<? extends Plant> plantClass;
        protected String plantName;

        public Seed() {
            this.stackable = true;
            this.defaultAction = Item.AC_THROW;
        }

        public ArrayList<String> actions(Hero hero) {
            ArrayList<String> actions = super.actions(hero);
            actions.add(AC_PLANT);
            return actions;
        }

        protected void onThrow(int cell) {
            if (Dungeon.level.map[cell] == 42 || Level.pit[cell]) {
                super.onThrow(cell);
            } else {
                Dungeon.level.plant(this, cell);
            }
        }

        public void execute(Hero hero, String action) {
            if (action.equals(AC_PLANT)) {
                hero.spend(TIME_TO_PLANT);
                hero.busy();
                ((Seed) detach(hero.belongings.backpack)).onThrow(hero.pos);
                hero.sprite.operate(hero.pos);
                return;
            }
            super.execute(hero, action);
        }

        public Plant couch(int pos) {
            try {
                if (Dungeon.visible[pos]) {
                    Sample.INSTANCE.play(Assets.SND_PLANT);
                }
                Plant plant = (Plant) this.plantClass.newInstance();
                plant.pos = pos;
                return plant;
            } catch (Exception e) {
                return null;
            }
        }

        public boolean isUpgradable() {
            return false;
        }

        public boolean isIdentified() {
            return true;
        }

        public int price() {
            return this.quantity * 10;
        }

        public String info() {
            return String.format(TXT_INFO, new Object[]{Utils.indefinite(this.plantName), desc()});
        }
    }

    public void activate(Char ch) {
        if ((ch instanceof Hero) && ((Hero) ch).subClass == HeroSubClass.WARDEN) {
            ((Barkskin) Buff.affect(ch, Barkskin.class)).level(ch.HT / 3);
        }
        wither();
    }

    public void wither() {
        Dungeon.level.uproot(this.pos);
        this.sprite.kill();
        if (Dungeon.visible[this.pos]) {
            CellEmitter.get(this.pos).burst(LeafParticle.GENERAL, 6);
        }
        if (Dungeon.hero.subClass == HeroSubClass.WARDEN) {
            if (Random.Int(5) == 0) {
                Dungeon.level.drop(Generator.random(Category.SEED), this.pos).sprite.drop();
            }
            if (Random.Int(5) == 0) {
                Dungeon.level.drop(new Dewdrop(), this.pos).sprite.drop();
            }
        }
    }

    public void restoreFromBundle(Bundle bundle) {
        this.pos = bundle.getInt(POS);
    }

    public void storeInBundle(Bundle bundle) {
        bundle.put(POS, this.pos);
    }

    public String desc() {
        return null;
    }
}
