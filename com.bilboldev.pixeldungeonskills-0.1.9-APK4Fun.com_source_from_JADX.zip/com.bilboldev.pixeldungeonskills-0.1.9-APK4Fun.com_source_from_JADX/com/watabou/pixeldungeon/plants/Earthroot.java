package com.watabou.pixeldungeon.plants;

import com.watabou.noosa.Camera;
import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.buffs.Buff;
import com.watabou.pixeldungeon.effects.CellEmitter;
import com.watabou.pixeldungeon.effects.particles.EarthParticle;
import com.watabou.pixeldungeon.items.keys.Key;
import com.watabou.pixeldungeon.items.potions.PotionOfParalyticGas;
import com.watabou.utils.Bundle;

public class Earthroot extends Plant {
    private static final String TXT_DESC = "When a creature touches an Earthroot, its roots create a kind of natural armor around it.";

    public static class Armor extends Buff {
        private static final String LEVEL = "level";
        private static final String POS = "pos";
        private static final float STEP = 1.0f;
        private int level;
        private int pos;

        public boolean attachTo(Char target) {
            this.pos = target.pos;
            return super.attachTo(target);
        }

        public boolean act() {
            if (this.target.pos != this.pos) {
                detach();
            }
            spend(STEP);
            return true;
        }

        public int absorb(int damage) {
            if (damage >= this.level) {
                detach();
                return damage - this.level;
            }
            this.level -= damage;
            return 0;
        }

        public void level(int value) {
            if (this.level < value) {
                this.level = value;
            }
        }

        public int icon() {
            return 20;
        }

        public String toString() {
            return "Herbal armor";
        }

        public void storeInBundle(Bundle bundle) {
            super.storeInBundle(bundle);
            bundle.put(POS, this.pos);
            bundle.put(LEVEL, this.level);
        }

        public void restoreFromBundle(Bundle bundle) {
            super.restoreFromBundle(bundle);
            this.pos = bundle.getInt(POS);
            this.level = bundle.getInt(LEVEL);
        }
    }

    public static class Seed extends com.watabou.pixeldungeon.plants.Plant.Seed {
        public Seed() {
            this.plantName = "Earthroot";
            this.name = "seed of " + this.plantName;
            this.image = 93;
            this.plantClass = Earthroot.class;
            this.alchemyClass = PotionOfParalyticGas.class;
        }

        public String desc() {
            return Earthroot.TXT_DESC;
        }
    }

    public Earthroot() {
        this.image = 5;
        this.plantName = "Earthroot";
    }

    public void activate(Char ch) {
        super.activate(ch);
        if (ch != null) {
            ((Armor) Buff.affect(ch, Armor.class)).level = ch.HT;
        }
        if (Dungeon.visible[this.pos]) {
            CellEmitter.bottom(this.pos).start(EarthParticle.FACTORY, 0.05f, 8);
            Camera.main.shake(Key.TIME_TO_UNLOCK, 0.4f);
        }
    }

    public String desc() {
        return TXT_DESC;
    }
}
