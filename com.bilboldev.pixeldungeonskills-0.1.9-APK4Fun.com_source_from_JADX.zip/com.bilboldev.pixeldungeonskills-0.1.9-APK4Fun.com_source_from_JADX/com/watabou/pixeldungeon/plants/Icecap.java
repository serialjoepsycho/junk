package com.watabou.pixeldungeon.plants;

import com.watabou.pixeldungeon.Dungeon;
import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.blobs.Fire;
import com.watabou.pixeldungeon.actors.blobs.Freezing;
import com.watabou.pixeldungeon.items.potions.PotionOfFrost;
import com.watabou.pixeldungeon.levels.Level;
import com.watabou.pixeldungeon.utils.BArray;
import com.watabou.utils.PathFinder;

public class Icecap extends Plant {
    private static final String TXT_DESC = "Upon touching an Icecap excretes a pollen, which freezes everything in its vicinity.";

    public static class Seed extends com.watabou.pixeldungeon.plants.Plant.Seed {
        public Seed() {
            this.plantName = "Icecap";
            this.name = "seed of " + this.plantName;
            this.image = 89;
            this.plantClass = Icecap.class;
            this.alchemyClass = PotionOfFrost.class;
        }

        public String desc() {
            return Icecap.TXT_DESC;
        }
    }

    public Icecap() {
        this.image = 1;
        this.plantName = "Icecap";
    }

    public void activate(Char ch) {
        super.activate(ch);
        PathFinder.buildDistanceMap(this.pos, BArray.not(Level.losBlocking, null), 1);
        Fire fire = (Fire) Dungeon.level.blobs.get(Fire.class);
        for (int i = 0; i < Level.LENGTH; i++) {
            if (PathFinder.distance[i] < Integer.MAX_VALUE) {
                Freezing.affect(i, fire);
            }
        }
    }

    public String desc() {
        return TXT_DESC;
    }
}
