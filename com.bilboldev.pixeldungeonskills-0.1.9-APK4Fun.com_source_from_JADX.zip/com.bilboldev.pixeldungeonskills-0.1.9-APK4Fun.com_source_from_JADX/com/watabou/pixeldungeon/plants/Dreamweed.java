package com.watabou.pixeldungeon.plants;

import com.watabou.pixeldungeon.actors.Char;
import com.watabou.pixeldungeon.actors.blobs.Blob;
import com.watabou.pixeldungeon.actors.blobs.ConfusionGas;
import com.watabou.pixeldungeon.items.potions.PotionOfInvisibility;
import com.watabou.pixeldungeon.scenes.GameScene;

public class Dreamweed extends Plant {
    private static final String TXT_DESC = "Upon touching a Dreamweed it secretes a glittering cloud of confusing gas.";

    public static class Seed extends com.watabou.pixeldungeon.plants.Plant.Seed {
        public Seed() {
            this.plantName = "Dreamweed";
            this.name = "seed of " + this.plantName;
            this.image = 91;
            this.plantClass = Dreamweed.class;
            this.alchemyClass = PotionOfInvisibility.class;
        }

        public String desc() {
            return Dreamweed.TXT_DESC;
        }
    }

    public Dreamweed() {
        this.image = 3;
        this.plantName = "Dreamweed";
    }

    public void activate(Char ch) {
        super.activate(ch);
        if (ch != null) {
            GameScene.add(Blob.seed(this.pos, 400, ConfusionGas.class));
        }
    }

    public String desc() {
        return TXT_DESC;
    }
}
