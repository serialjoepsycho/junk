package com.watabou.pixeldungeon.mechanics;

public class Ballistica {
    public static int distance;
    public static int[] trace;

    static {
        trace = new int[Math.max(32, 32)];
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int cast(int r19, int r20, boolean r21, boolean r22) {
        /*
        r11 = 32;
        r12 = r19 % r11;
        r13 = r20 % r11;
        r14 = r19 / r11;
        r15 = r20 / r11;
        r4 = r13 - r12;
        r5 = r15 - r14;
        if (r4 <= 0) goto L_0x0060;
    L_0x0010:
        r9 = 1;
    L_0x0011:
        if (r5 <= 0) goto L_0x0062;
    L_0x0013:
        r10 = 1;
    L_0x0014:
        r4 = java.lang.Math.abs(r4);
        r5 = java.lang.Math.abs(r5);
        if (r4 <= r5) goto L_0x0064;
    L_0x001e:
        r7 = r9;
        r8 = r10 * r11;
        r2 = r4;
        r3 = r5;
    L_0x0023:
        r16 = 1;
        distance = r16;
        r16 = trace;
        r17 = 0;
        r16[r17] = r19;
        r1 = r19;
        r6 = r2 / 2;
    L_0x0031:
        r0 = r20;
        if (r1 != r0) goto L_0x0037;
    L_0x0035:
        if (r21 == 0) goto L_0x007b;
    L_0x0037:
        r1 = r1 + r7;
        r6 = r6 + r3;
        if (r6 < r2) goto L_0x003d;
    L_0x003b:
        r6 = r6 - r2;
        r1 = r1 + r8;
    L_0x003d:
        r16 = trace;
        r17 = distance;
        r18 = r17 + 1;
        distance = r18;
        r16[r17] = r1;
        r16 = com.watabou.pixeldungeon.levels.Level.passable;
        r16 = r16[r1];
        if (r16 != 0) goto L_0x006a;
    L_0x004d:
        r16 = com.watabou.pixeldungeon.levels.Level.avoid;
        r16 = r16[r1];
        if (r16 != 0) goto L_0x006a;
    L_0x0053:
        r16 = trace;
        r17 = distance;
        r17 = r17 + -1;
        distance = r17;
        r17 = r17 + -1;
        r20 = r16[r17];
    L_0x005f:
        return r20;
    L_0x0060:
        r9 = -1;
        goto L_0x0011;
    L_0x0062:
        r10 = -1;
        goto L_0x0014;
    L_0x0064:
        r7 = r10 * r11;
        r8 = r9;
        r2 = r5;
        r3 = r4;
        goto L_0x0023;
    L_0x006a:
        r16 = com.watabou.pixeldungeon.levels.Level.losBlocking;
        r16 = r16[r1];
        if (r16 != 0) goto L_0x0078;
    L_0x0070:
        if (r22 == 0) goto L_0x0031;
    L_0x0072:
        r16 = com.watabou.pixeldungeon.actors.Actor.findChar(r1);
        if (r16 == 0) goto L_0x0031;
    L_0x0078:
        r20 = r1;
        goto L_0x005f;
    L_0x007b:
        r16 = trace;
        r17 = distance;
        r18 = r17 + 1;
        distance = r18;
        r16[r17] = r1;
        goto L_0x005f;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.watabou.pixeldungeon.mechanics.Ballistica.cast(int, int, boolean, boolean):int");
    }
}
