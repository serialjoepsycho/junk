package com.watabou.pixeldungeon.mechanics;

import com.watabou.pixeldungeon.levels.Level;
import java.util.Arrays;

public final class ShadowCaster {
    private static final int HEIGHT = 32;
    private static final int MAX_DISTANCE = 8;
    private static final int WIDTH = 32;
    private static int distance;
    private static boolean[] fieldOfView;
    private static int[] limits;
    private static boolean[] losBlocking;
    private static Obstacles obs;
    private static int[][] rounding;

    private static final class Obstacles {
        private static int SIZE;
        private static float[] a1;
        private static float[] a2;
        private int length;
        private int limit;

        private Obstacles() {
        }

        static {
            SIZE = 40;
            a1 = new float[SIZE];
            a2 = new float[SIZE];
        }

        public void reset() {
            this.length = 0;
            this.limit = 0;
        }

        public void add(float o1, float o2) {
            if (this.length <= this.limit || o1 > a2[this.length - 1]) {
                a1[this.length] = o1;
                float[] fArr = a2;
                int i = this.length;
                this.length = i + 1;
                fArr[i] = o2;
                return;
            }
            a2[this.length - 1] = o2;
        }

        public boolean isBlocked(float a) {
            int i = 0;
            while (i < this.limit) {
                if (a >= a1[i] && a <= a2[i]) {
                    return true;
                }
                i++;
            }
            return false;
        }

        public void nextRow() {
            this.limit = this.length;
        }
    }

    static {
        rounding = new int[9][];
        for (int i = 1; i <= MAX_DISTANCE; i++) {
            rounding[i] = new int[(i + 1)];
            for (int j = 1; j <= i; j++) {
                rounding[i][j] = (int) Math.min((long) j, Math.round(((double) i) * Math.cos(Math.asin(((double) j) / (((double) i) + 0.5d)))));
            }
        }
        obs = new Obstacles();
    }

    public static void castShadow(int x, int y, boolean[] fieldOfView, int distance) {
        losBlocking = Level.losBlocking;
        distance = distance;
        limits = rounding[distance];
        fieldOfView = fieldOfView;
        Arrays.fill(fieldOfView, false);
        fieldOfView[(y * WIDTH) + x] = true;
        scanSector(x, y, 1, 1, 0, 0);
        scanSector(x, y, -1, 1, 0, 0);
        scanSector(x, y, 1, -1, 0, 0);
        scanSector(x, y, -1, -1, 0, 0);
        scanSector(x, y, 0, 0, 1, 1);
        scanSector(x, y, 0, 0, -1, 1);
        scanSector(x, y, 0, 0, 1, -1);
        scanSector(x, y, 0, 0, -1, -1);
    }

    private static void scanSector(int cx, int cy, int m1, int m2, int m3, int m4) {
        obs.reset();
        for (int p = 1; p <= distance; p++) {
            float dq2 = 0.5f / ((float) p);
            int pp = limits[p];
            for (int q = 0; q <= pp; q++) {
                int x = ((q * m1) + cx) + (p * m3);
                int y = ((p * m2) + cy) + (q * m4);
                if (y >= 0 && y < WIDTH && x >= 0 && x < WIDTH) {
                    float a0 = ((float) q) / ((float) p);
                    float a1 = a0 - dq2;
                    float a2 = a0 + dq2;
                    int pos = (y * WIDTH) + x;
                    if (!(obs.isBlocked(a0) && obs.isBlocked(a1) && obs.isBlocked(a2))) {
                        fieldOfView[pos] = true;
                    }
                    if (losBlocking[pos]) {
                        obs.add(a1, a2);
                    }
                }
            }
            obs.nextRow();
        }
    }
}
